var sites = {
    urlFilter: [ "<all_urls>" ],
    credentials: [
        {realm: "nobody", username: "u", password: "p"}
    ]
}