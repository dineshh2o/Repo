package tech.nike.automation.common.framework.testdatamanager;

import com.sun.rowset.WebRowSetImpl;
import org.apache.commons.io.output.ByteArrayOutputStream;

import javax.sql.rowset.WebRowSet;
import java.sql.SQLException;

/**
 * Created by PSibb1 on 6/7/2016.
 */
@SuppressWarnings("restriction")
public class DataManager {
    // Database Driver
    private final String databaseDriver = "oracle.jdbc.driver.OracleDriver";

    // Database URL
    private String DB_URL ; //Example:  "jdbc:oracle:thin:@m0438ussac1.cust.aops-eds.com:1521:tnot13";

    // Database credentials
    private String USER ;
    private String PASS ;

    public DataManager(String user, String pass, String databaseUrl) {
        this.USER = user;
        this.PASS = pass;
        this.DB_URL = databaseUrl;
    }

    /*
     * Takes a configuration query, usually a SELECT and returns an XML representation of the result set
     *
     * @param query SQL query that is passed in to execute
     *
     * @return XML representation of the result set.  Returns an empty string if there are errors
     */
    public String performQuery(String query) {
        WebRowSet resultList = null;
        String xmlResult = "";

        try {
            resultList = new WebRowSetImpl();
            resultList.setUrl(DB_URL);
            resultList.setUsername(USER);
            resultList.setPassword(PASS);

            // Register JDBC driver
            Class.forName(databaseDriver);

            // Execute query
            resultList.setCommand(query);
            resultList.execute();

            // Generate XML from Result Set
            ByteArrayOutputStream boas = new ByteArrayOutputStream();
            resultList.writeXml(boas);

            xmlResult = boas.toString("UTF-8");

            // Clean-up environment
            resultList.close();

        } catch (SQLException se) {
            // Handle errors for JDBC
            se.printStackTrace();
        } catch (Exception e) {
            // Handle errors for Class.forName
            e.printStackTrace();
        } finally {
            try {
                resultList.close();
            } catch (SQLException se) {
                // Handle errors for JDBC
                se.printStackTrace();
            }
        }// end try

        return xmlResult;
    }

}