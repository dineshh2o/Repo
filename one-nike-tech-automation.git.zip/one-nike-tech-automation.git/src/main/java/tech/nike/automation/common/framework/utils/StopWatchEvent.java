package tech.nike.automation.common.framework.utils;

/**
 * Class used to store stopwatch event information
 *
 * @author efeign
 */
public class StopWatchEvent {
    private String name;
    private Long start;
    private Long end;

    /**
     * Default constructor. Stores the event name and sets
     * the start time
     *
     * @param name the event name
     */
    public StopWatchEvent(String name) {
        this.name = name;
        this.start = new Long(System.currentTimeMillis());
    }

    /**
     * Stop the timer for the event by setting the end time
     */
    public void stop() {
        this.end = new Long(System.currentTimeMillis());
    }

    /**
     * Calculate the duration of the timer
     *
     * @return
     */
    public long getDuration() {
        if (start != null && end != null) {
            return end - start;
        }
        return 0;
    }

    /**
     * Calculate the duration of the timer
     *
     * @return
     */
    public String getDurationString() {
        return Long.toString(this.getDuration());
    }

    /**
     * GETTERS AND SETTERS
     **/

    public String toString() {
        return name + ": " + end + " - " + start + " = " + getDuration();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getStart() {
        return start;
    }

    public void setStart(Long start) {
        this.start = start;
    }

    public Long getEnd() {
        return end;
    }

    public void setEnd(Long end) {
        this.end = end;
    }

}
