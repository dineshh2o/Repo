package tech.nike.automation.common.framework.wmsxmlmanager.asn;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

/**
 * Created by psibb1 on 3/4/2017.
 */
@XmlRootElement(name = "ASN")
@XmlAccessorType(XmlAccessType.FIELD)
public class ASN {

    @XmlElement(name = "ASNID")
    private String asnID = null;
    @XmlElement(name = "OriginFacilityAliasID")
    private String originFacAliasID = null;
    @XmlElement(name = "PickupEndDTTM")
    private String pickupEndDTTM = null;
    @XmlElement(name = "AssignedCarrierCode")
    private String assignedCarrierCode = null;
    @XmlElement(name = "OriginType")
    private String originType = null;
    @XmlElement(name = "ContractLocation")
    private String contractLocation = null;
    @XmlElement(name = "LPN")
    private List<LPN> lpn = null;

    public String getASN() {
        return asnID;
    }

    public void setAsnID(String asnID) {
        this.asnID = asnID;
    }

    public String getOriginFacAliasI() {
        return originFacAliasID;
    }

    public void setOriginFacAliasID(String originFacAliasID) {
        this.originFacAliasID = originFacAliasID;
    }

    public String getPickupEndDTTM() {
        return pickupEndDTTM;
    }

    public void setPickupEndDTTM(String pickupEndDTTM) {
        this.pickupEndDTTM = pickupEndDTTM;
    }

    public String getAssignedCarrierCode() {
        return assignedCarrierCode;
    }

    public void setAssignedCarrierCode(String assignedCarrierCode) {
        this.assignedCarrierCode = assignedCarrierCode;
    }

    public String getOriginType() {
        return originType;
    }

    public void setOriginType(String originType) {
        this.originType = originType;
    }

    public String getContractLocation() {
        return contractLocation;
    }

    public void setContractLocation(String contractLocation) {
        this.contractLocation = contractLocation;
    }

    public List<LPN> getLPN() {
        return lpn;
    }

    public void setLPN(List<LPN> lpn) {
        this.lpn = lpn;
    }
}