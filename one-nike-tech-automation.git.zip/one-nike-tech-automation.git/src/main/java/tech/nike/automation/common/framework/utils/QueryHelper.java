package tech.nike.automation.common.framework.utils;

import tech.nike.automation.common.framework.configuration.DBConnect;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Created by dyelur on 9/10/2016.
 */
public class QueryHelper {
    static Connection connection = null;
    static PreparedStatement statement = null;

    /*
     * Updates the query by adding Item name in "not in" condition
     */
    public static String queryUpdateToAvoidDuplicateItemID(String query, ArrayList<String> itemList) {
        String strAppend = "'1',";
        String conditionText;
        String updatedQuery;
        conditionText = "ITEM_NAME NOT IN (";
        for (int i = 0; i < itemList.size(); i++) {
            strAppend = strAppend.concat("'" + itemList.get(i) + "',");
        }
        updatedQuery = query.replace(conditionText, "item_name not IN (" + strAppend + ")");
        updatedQuery = updatedQuery.replace(",)", ")");
        //System.out.println(updatedQuery);
        return updatedQuery;
    }

    /*
     * This method will execute the updated query
     */
    public static ResultSet executeQuery(String strQuery) throws SQLException {
        connection = DBConnect.getDatabaseConnection();
        statement = connection.prepareStatement(strQuery);
        System.out.println("Executing QCQuery Please Wait......");
        ResultSet result = statement.executeQuery();
        return result;
    }

    public static void closeConnection() throws SQLException {
        statement.close();
        connection.close();
    }

}