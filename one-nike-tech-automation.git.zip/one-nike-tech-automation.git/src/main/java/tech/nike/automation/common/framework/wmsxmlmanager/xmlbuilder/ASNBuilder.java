package tech.nike.automation.common.framework.wmsxmlmanager.xmlbuilder;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * Created by psibb1 on 3/8/2017.
 */
public class ASNBuilder {
    private Log logger = LogFactory.getLog(ASNBuilder.class);

   /* public void setASN(Map<String, Object> params) {
        WmsXmlDynamicTagDataHelper dyntags = new WmsXmlDynamicTagDataHelper();
        XMLUpdateHelper xmlhelper = new XMLUpdateHelper();
        String xmlfilePath = (String) params.get("xmlfilename");
        String xmlnodes = (String) params.get("asnxmltags");
        String queryName = (String) params.get("queryname");
        String[] nodeArr = xmlnodes.split(",");
        DataSummary itemName = null;
        DataSummary custId = QCInventoryManager.getCustomerByQueryID(0, "customer_id");
        ;

        QCNamedDataQuery jsonquery = new QCNamedDataQuery();
        for (int i = 0; i < nodeArr.length; i++) {
            String nodeName = nodeArr[i].trim();
            switch (nodeName) {
                case "Reference_ID":
                    xmlhelper.updateSingleTag(xmlfilePath, nodeName, dyntags.getASNNumber());
                    break;
                case "ASNID":
                    xmlhelper.updateSingleTag(xmlfilePath, nodeName, dyntags.getASNNumber());
                    break;
                case "LPNID":
                    xmlhelper.updateSingleTag(xmlfilePath, nodeName, dyntags.getLPNNumber());
                    break;
                case "OriginFacilityAliasID":
                    if (jsonquery.getUnique()) {
                        custId = QCInventoryManager.getCustomerByQueryID(i, "customer_id");
                        xmlhelper.updateSingleTag(xmlfilePath, nodeName, custId.getoriginFacilityAliasID());
                    } else {
                        custId = QCInventoryManager.getCustomerByQueryID(0, "customer_id");
                        xmlhelper.updateSingleTag(xmlfilePath, nodeName, custId.getoriginFacilityAliasID());
                    }
                    break;
                case "PickupEndDTTM":
                    xmlhelper.updateSingleTag(xmlfilePath, nodeName, "");
                case "ItemName":
                    itemName = QCInventoryManager.getCustomerByQueryID(0, queryName);
                    xmlhelper.updateSingleTag(xmlfilePath, nodeName, itemName.getoriginFacilityAliasID());
                    break;
                case "Quantity":
                    xmlhelper.updateSingleTag(xmlfilePath, nodeName, itemName.getItemQty());
                    break;
                case "ShippedAsnQuantity":
                    xmlhelper.updateSingleTag(xmlfilePath, nodeName, itemName.getItemQty());
                    break;
                case "OriginalQuantity":
                    xmlhelper.updateSingleTag(xmlfilePath, nodeName, itemName.getItemQty());
                    break;
                case "ItemAttribute1":
                    xmlhelper.updateSingleTag(xmlfilePath, nodeName, itemName.getitemAttr());
                    break;
                case "CountryofOrigin":
                    xmlhelper.updateSingleTag(xmlfilePath, nodeName, itemName.getcntryoforgn());
                    break;
            }
        }
    }*/
}