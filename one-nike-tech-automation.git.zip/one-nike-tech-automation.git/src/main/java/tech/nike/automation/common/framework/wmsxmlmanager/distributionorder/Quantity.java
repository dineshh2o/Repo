package tech.nike.automation.common.framework.wmsxmlmanager.distributionorder;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by PSibb1 on 3/5/2017.
 */
@XmlRootElement(name = "Quantity")
@XmlAccessorType(XmlAccessType.FIELD)
public class Quantity {

    @XmlElement(name = "OrderQty")
    private String orderQty = null;

    public String getOrderQty() {
        return orderQty;
    }

    public void setOrderQty(String orderQty) {
        this.orderQty = orderQty;
    }

}
