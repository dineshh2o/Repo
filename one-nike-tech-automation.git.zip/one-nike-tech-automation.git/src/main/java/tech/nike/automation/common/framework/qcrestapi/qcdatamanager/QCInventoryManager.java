package tech.nike.automation.common.framework.qcrestapi.qcdatamanager;

import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import tech.nike.automation.common.framework.configuration.QCDBConnect;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class QCInventoryManager {
	private static final String NAMED_PARAMETER_JSON_SRC = "/META-INF/alm_manager_queries.json";
    private static final String QC_INSTANCE_NAME = "QC-PROD";
    private static Logger logger = LoggerFactory.getLogger(QCInventoryManager.class);
    private static QCNamedDataQueries qcNamedDataQueries;

	static {
        ObjectMapper mapper = new ObjectMapper();
		//File src = new File(NAMED_PARAMETER_JSON_SRC);
        mapper.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        InputStream srcAsStream = QCInventoryManager.class.getResourceAsStream(NAMED_PARAMETER_JSON_SRC);
		try {
			//qcNamedDataQueries = mapper.readValue(src, QCNamedDataQueries.class);
			qcNamedDataQueries = mapper.readValue(srcAsStream, QCNamedDataQueries.class);
		} catch (Exception e) {
			logger.error("Could not load file " + NAMED_PARAMETER_JSON_SRC, e);
		}
	}

    /**
     * method to add sql output and use it as object model
     * @param
     * @return
     */
    public static List<DataSummary> getALMTestLabDetailsByQueryID(Map<String, String> params) {
        List<DataSummary> retval = null;
        List<DataSummary> productSummaryList = new ArrayList<DataSummary>();
        String queryid = params.get("queryid");
        QCNamedDataQuery qcNamedDataQuery = qcNamedDataQueries.getNamedDataQueryById(queryid);

        for(QCQuery query : qcNamedDataQuery.getQueries()) {
            Connection conn = null;
            PreparedStatement ps =  null;
            ResultSet rs = null;
            try {
                String queryStr = query.getQuery();
                if(params!=null) {
                    for(String key: params.keySet()) {
                        if(queryStr.contains(":"+key)) {
                            queryStr = queryStr.replace(":" + key, "'"+params.get(key)+"'");
                        }
                    }
                }
                conn = getDatabaseConnection();
                ps = conn.prepareStatement(queryStr);
                rs = ps.executeQuery();
                if(productSummaryList.isEmpty()) {
                    while(rs.next()) {
                        DataSummary productSummary = new DataSummary();
                        productSummary.setRunId(rs.getString("RN_RUN_ID"));
                        productSummary.setCycleId(rs.getString("CY_CYCLE_ID"));
                        productSummary.setTestId(rs.getString("TS_TEST_ID"));
                        productSummary.setConfigId(rs.getString("TC_TEST_CONFIG_ID"));
                        productSummary.setTestInstance(rs.getString("TC_TEST_INSTANCE"));
                        productSummary.setTestCycleId(rs.getString("TC_TESTCYCL_ID"));
                        productSummaryList.add(productSummary);
                    }
                }
                if(productSummaryList.size()==0) {
                    break;
                }
            } catch (Exception e) {
                logger.error("Could not execute query " + query.getQuery(), e);
            } finally {
                if(rs!=null) { try {rs.close();} catch (Exception e) {} }
                if(ps!=null) { try {ps.close();} catch (Exception e) {} }
                if(conn!=null) { try {conn.close();} catch (Exception e) {} }
            }
        }
        if(productSummaryList.size()>0) {
            retval = productSummaryList;
        }
        return retval;
    }

    private static Connection getDatabaseConnection() {
        return QCDBConnect.getQCDatabaseConnection(QC_INSTANCE_NAME);
    }
}