package tech.nike.automation.common.framework.core;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

public class SystemUtil {
    //private static final String ENV_PROP_NAME = "ER";
    private static final String DEFAULT_ENVIRONMENT = "d052";
    //Keys, set or override defaults from command line or ide using -Dkey=value
    private final static String baseUrlKey = "base.url";
    private final static String localeUrlKey = "locale.url";
    private final static String windowWidthKey = "window.width";
    private final static String windowHeightKey = "window.height";
    private final static String testDataDirectorykey = "test.data.directory";
    private final static String httpCredentialsKey = "http.credentials";
    private final static String httpProxyHostKey = "http.proxyHost";
    private final static String httpProxyPortKey = "http.proxyPort";
    private final static String browsersKey = "browsers";
    private final static String basePortKey = "base.port";
    private final static String basePostXMlPortKey = "base.post.xml.port.key";
    private final static String retryListnerKey = "testng.listners.retry";
    //WMS
    private final static String baseDCKey = "dc.type";
    //QC details
    private static final String qcurl = "qc.url";
    private static final String qcRunKey = "qc.run";
    private static final String qcDomainKey = "qc.domain";
    private static final String qcProjectKey = "qc.project";
    private static final String qcUserKey = "qc.user";
    private static final String qcPwKey = "qc.pw";
    private static final String qcVersionKey = "qc.version";
    //Default values
    private final static String baseUrlDefault = "http://nke-lnx-wms-d052.nike.com:";
    private final static String localeUrlDefault = "";
    private final static String basePortDefault = "10000";
    private final static String basePostXMLPortDefault = "10500";
    private final static int windowWidthDefault = 1920;
    private final static int windowHeightDefault = 1080;
    private final static String testDataDirectoryDefault = "target/test-classes";
    private final static String httpCredentialsDefault = "true";
    private final static String httpProxyHostDefault = connsvrExists() ? "connsvr.nike.com" : null;
    private final static String httpProxyPortDefault = connsvrExists() ? "8080" : null;
    private final static String browsersDefault = "Chrome";
    private final static String retryListnerDefault = "tech.nike.automation.common.framework.testng.RetryListener";
    //QC Default values
    private final static String baseQCUrl = "http://alm.nike.com";
    private final static String baseQCRunDefault = "no";
    private static final String baseQcDomainDefault = "DEFAULT";
    private static final String baseQcProjectDefault = "QC_TAO_BPT";
    private static final String baseQcUserDefault = "PSIBB1";
    private static final String baseQcPwDefault = "FFFA7F2A142181B884663345DEB7DA66";
    private static final String baseQcVersionDefault = "yes";
    //WMS Default Values
    private final static String baseWmsDCDefault = "d050";

    //for support of old tests, considered deprecated, will be removed someday
    @Deprecated
    private final static String FIREFOX_DRIVER = "firefoxdriver";
    @Deprecated
    private final static String CHROME_DRIVER = "chromedriver";
    @Deprecated
    private final static String CUSTOM_CHROME_DRIVER = "customchromedriver";
    @Deprecated
    private final static String IPHONE_DRIVER = "iphonedriver";
    @Deprecated
    private final static String INTERNET_EXPLORER_DRIVER = "internetexplorerdriver";
    @Deprecated
    private final static String SAFARI_DRIVER = "safaridriver";
    @Deprecated
    private final static String ANDROID_DRIVER = "androiddriver";
    //instantiations
    private final static String baseUrl = System.getProperties().containsKey(baseUrlKey) ? System.getProperty(baseUrlKey) : baseUrlDefault;
    private final static String localeUrl = System.getProperties().containsKey(localeUrlKey) ? System.getProperty(localeUrlKey) : localeUrlDefault;
    private final static int windowWidth = System.getProperties().containsKey(windowWidthKey) ? Integer.parseInt(System.getProperty(windowWidthKey)) : windowWidthDefault;
    private final static int windowHeight = System.getProperties().containsKey(windowHeightKey) ? Integer.parseInt(System.getProperty(windowHeightKey)) : windowHeightDefault;
    private final static String browsers = System.getProperties().containsKey(browsersKey) ? System.getProperty(browsersKey) : browsersDefault; //new enums
    private final static String testDataDirectory = System.getProperties().containsKey(testDataDirectorykey) ? System.getProperty(testDataDirectorykey) : testDataDirectoryDefault;
    private final static boolean httpCredentials = Boolean.parseBoolean(System.getProperties().containsKey(httpCredentialsKey) ? System.getProperty(httpCredentialsKey) : httpCredentialsDefault);
    private final static String httpProxyHost = System.getProperties().containsKey(httpProxyHostKey) ? System.getProperty(httpProxyHostKey) : httpProxyHostDefault;
    private final static String httpProxyPort = System.getProperties().containsKey(httpProxyPortKey) ? System.getProperty(httpProxyPortKey) : httpProxyPortDefault;
    private final static String basePort = System.getProperties().containsKey(basePortKey) ? System.getProperty(basePortKey) : basePortDefault;
    private final static String basePostXMLPort = System.getProperties().containsKey(basePostXMlPortKey) ? System.getProperty(basePostXMlPortKey) : basePostXMLPortDefault;
    private final static String baseDC = System.getProperties().containsKey(baseDCKey) ? System.getProperty(baseDCKey) : baseWmsDCDefault;
    private final static String retryListner = System.getProperties().containsKey(retryListnerKey) ? System.getProperty(retryListnerKey) : retryListnerDefault;
    //qc instantiations
    private final static String baseQcRun = System.getProperties().containsKey(qcRunKey) ? System.getProperty(qcRunKey) : baseQCRunDefault;
    private final static String baseQcDomain = System.getProperties().containsKey(qcDomainKey) ? System.getProperty(qcDomainKey) : baseQcDomainDefault;
    private final static String baseQcProject = System.getProperties().containsKey(qcProjectKey) ? System.getProperty(qcProjectKey) : baseQcProjectDefault;
    private final static String baseQcUser = System.getProperties().containsKey(qcUserKey) ? System.getProperty(qcUserKey) : baseQcUserDefault;
    private final static String baseQcPw = System.getProperties().containsKey(qcPwKey) ? System.getProperty(qcPwKey) : baseQcPwDefault;
    private final static String baseQcVersion = System.getProperties().containsKey(qcVersionKey) ? System.getProperty(qcVersionKey) : baseQcVersionDefault;
    public static String wmsBaseUrl;
    public static String wmsBasePort;
    public static String wmsPostXMLPort;

    //qc getter methods
    public static String getQCUrl() {
        return baseQCUrl;
    }

    public static String getQCRun() {
        return baseQCRunDefault;
    }

    public static String getQCDomain() {
        return baseQcDomainDefault;
    }

    public static String getQCProject() {
        return baseQcProjectDefault;
    }

    public static String getQCUser() {
        return baseQcUserDefault;
    }

    public static String getQCPassword() {
        return baseQcPwDefault;
    }

    public static String getQCVersion() {
        return baseQcVersionDefault;
    }

    public static String getBaseDC(){
        return getCurrentWMSEnvironment();
    }

    //getter methods
    public static String getBaseUrl() {
        return baseUrl;
    }

    //get defaultbaseurl
    public static String getDefaultBaseUrl() {
        return baseUrlDefault;
    }

    public static String getLocale() {
        return localeUrl;
    }

    public static String getBaseUrlSecure() {
        if (!baseUrl.isEmpty() && (baseUrl.startsWith("http://"))) {
            return baseUrl.replace("http://", "https://");
        } else {
            return "baseUrl is not valid";
        }
    }

//	public static String getBaseStoreUrl()
//	{
//		return getBaseUrl().replaceFirst("www", "store");
//	}

    public static String getCurrentEnvironment() {
        String env = getBaseUrl().substring(7, 12);
        return env.replaceAll("-", "").trim();
    }

    public static String getCurrentWMSEnvironment() {
        String env = getBaseUrl().substring(getBaseUrl().lastIndexOf("-")+1);
        env = env.substring(0,4).trim();
        return env;
    }

    public static int getWindowWidth() {
        return windowWidth;
    }

    public static int getWindowHeight() {
        return windowHeight;
    }

    public static String getTestDataDirectory() {
        return testDataDirectory;
    }

    public static boolean getHttpCredentials() {
        return httpCredentials;
    }

    public static String getHttpProxyHost() {
        return httpProxyHost;
    }

    public static String getHttpProxyPort() {
        return httpProxyPort;
    }

    public static String getBrowsers() {
        //translate old style to new Selenium enums
        if (browsers.contains(CHROME_DRIVER)) {
            browsers.replace(CHROME_DRIVER, Browser.Browsers.Chrome.toString());
        }
        if (browsers.contains(INTERNET_EXPLORER_DRIVER)) {
            browsers.replace(INTERNET_EXPLORER_DRIVER, Browser.Browsers.InternetExplorer.toString());
        }
        return browsers;
    }

    private static boolean connsvrExists() {
        Socket socket = null;
        boolean reachable = false;
        try {
            socket = new Socket("connsvr.nike.com", 8080);
            reachable = true;
        } catch (UnknownHostException e) {
            //no proxy
        } catch (IOException e) {
            //no proxy
        } finally {
            if (socket != null) try {
                socket.close();
            } catch (IOException e) {
            }
        }

        return reachable;
    }


    /**
     * Method to set the URL
     */
    public static void setEnvirnomentUrl() {
        if (!baseUrlKey.isEmpty()) {
            SystemUtil.wmsBaseUrl = baseUrl;
        } else {
            SystemUtil.wmsBaseUrl = baseUrlDefault + basePortDefault;
        }
        /*String environmentName = System.getProperty(ENV_PROP_NAME);
        if (StringUtils.isEmpty(environmentName)) {
            environmentName = DEFAULT_ENVIRONMENT; //for local development
        }
        Envclient getEnv = new Envclient(Envclient.Env.valueOf(environmentName));
        String[] envName = getEnv.getEnvUrl();
        //setWmsBaseUrl();*/
       // setWmsBaseUrl();
    }

    public static String getWmsBaseUrl() {
        wmsBaseUrl = baseUrl;
        return wmsBaseUrl;
    }

    public static String getWmsBasePort() {
        wmsBasePort = basePort;
        return wmsBasePort;
    }

    public static String getWmsPostXMlPort() {
        wmsPostXMLPort = basePostXMLPort;
        return wmsPostXMLPort;
    }

    public static void setWmsBaseUrl() {
        SystemUtil.wmsBaseUrl = baseUrl + basePort;
    }

    public static String getEnvironmentUrl() {
        if (!baseUrlKey.isEmpty()) {
            SystemUtil.wmsBaseUrl = baseUrl;
        } else {
            SystemUtil.wmsBaseUrl = baseUrlDefault + basePortDefault;
        }
        return SystemUtil.wmsBaseUrl;
    }
}