package tech.nike.automation.common.framework.qcrestapi.qcdatamanager;

import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.File;

/**
 * method to run the qc queries manually and check
 */
public class QCQueryBuilder {
	public static void main(String[] args) {
		ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        try {
			File src = new File("src/main/resources/META-INF/alm_manager_queries.json");
			QCNamedDataQueries namedDataQueries = mapper.readValue(src, QCNamedDataQueries.class);
			System.out.println(namedDataQueries.getQcNamedDataQueries().size());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}