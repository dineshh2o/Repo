package tech.nike.automation.common.framework.testdatamanager;

import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.File;

public class QueryBuilder {
	public static void main(String[] args) {
		ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        try {
			File src = new File("src/main/resources/META-INF/ham_inventory_manager_named_queries.json");
			NamedProductQueries namedProductQueries = mapper.readValue(src, NamedProductQueries.class);
			System.out.println(namedProductQueries.getNamedProductQueries().size());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}