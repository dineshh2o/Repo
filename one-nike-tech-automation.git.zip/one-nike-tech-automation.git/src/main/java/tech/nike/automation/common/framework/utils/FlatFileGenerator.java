package tech.nike.automation.common.framework.utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

/**
 * Created by dyelur on 9/10/2016.
 */
public class FlatFileGenerator {
    static FileWriter fstream = null;
    static File file;
    static BufferedWriter out;

    /*
     * Clears the old content in the flat file
     */
    public static void clearFileContents(String flatFileName)  {
        try {
            file = new File(flatFileName);
            fstream = new FileWriter(file);
            fstream.write("");
            fstream.close();
        }catch(Exception e){
            e.getStackTrace();
        }
    }

    /*
     * Creates flat file
     */
    public static void createFlatFile(String flatFileName) {
        try {
            String strflatfile = "";
            String AbsolutePath = new File(".").getAbsolutePath();
            AbsolutePath = AbsolutePath.substring(0, AbsolutePath.length() - 1);
            strflatfile = AbsolutePath + flatFileName;
            file = new File(strflatfile);
            fstream = new FileWriter(file, true);
            out = new BufferedWriter(fstream);
        }catch(Exception e){
            e.getStackTrace();
        }
    }

    /*
     * Appends data to the flat file
     */
    public static void appendDataToFlatFile(String data)  {
        try {
            out.append(data);
        }catch(Exception e){
            e.getStackTrace();
        }
    }

    public static void closeFlatFile() {
        try {
            out.newLine();
            out.flush();
            out.close();
        }catch(Exception e){
            e.getStackTrace();
        }
    }

}