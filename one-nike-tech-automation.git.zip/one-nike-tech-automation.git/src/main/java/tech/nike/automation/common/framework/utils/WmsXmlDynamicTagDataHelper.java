package tech.nike.automation.common.framework.utils;

import tech.nike.automation.common.framework.core.Util;
import tech.nike.automation.common.framework.tools.OSTools;

import java.util.Random;

/**
 * Created by PSibb1 on 1/11/2017.
 */
public class WmsXmlDynamicTagDataHelper {
    /*public static void main(String[] args){
        System.out.println("LPN Number :"+ LPNNumber());
        System.out.println("ASN Number:"+ ASNNumber());
    }*/

    /**
     * method to generate a 20 digit length LPN number as per NIKE WMS project needs
     * @return
     */
    public String getLPNNumber() {
        Random rand = new Random();
        String strLPNNum = Util.generate(14);
        strLPNNum = OSTools.getUsername().toUpperCase() + strLPNNum;
        return strLPNNum;
    }

    /**
     * method to generate a 12 digit length ASN number as per NIKE WMS project needs
     * @return
     */
    public String getASNNumber() {
        Random rand = new Random();
        String strASNNum = Util.generate(3);
        strASNNum = OSTools.getUsername().toUpperCase() + strASNNum;
        return strASNNum;
    }

    /**
     * method to generate a 14 digit DO number as per the NIKE WMS project needs
     * @return
     */
    public String getDONumber() {
        Random rand = new Random();
        String DONum  = Util.generate(8);
        DONum = OSTools.getUsername().toUpperCase() + DONum;
        return DONum;
    }
}