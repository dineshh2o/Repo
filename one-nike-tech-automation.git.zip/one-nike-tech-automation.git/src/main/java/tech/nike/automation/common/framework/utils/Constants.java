package tech.nike.automation.common.framework.utils;

public final class Constants {
    public final static String NALC_DB = "NALC-ER";
    public final static String NALC_FLAT_FILE_PATH = "NALC\\NALC_Flatfile\\NALC_records.txt";
    public final static String NALC_EXECUTION_SHEET_PATH = "NALC\\NALC_Execution_sheet\\Test_Case_Sheet.xlsx";
    public final static String FLAT_FILE_PATH = "NALC\\NALC_Flatfile\\records.txt";
    public final static String HERENTALS_DB = "HTLS-ER";
    public final static String HAM_DB = "HAM-ER";
}
