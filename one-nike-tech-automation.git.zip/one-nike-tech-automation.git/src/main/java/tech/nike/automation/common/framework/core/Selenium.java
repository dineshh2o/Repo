package tech.nike.automation.common.framework.core;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.*;
import tech.nike.automation.common.framework.tools.OSTools;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Arrays;

//import org.openqa.selenium.android.AndroidDriver;

public class Selenium {
    //private static String seleniumGrid = "http://10.199.144.90:4444/wd/hub";
    private static String seleniumGrid = getSetting("selenium.seleniumGrid", "http://10.199.164.123:4444/wd/hub");
    private static String browserMobProxy = getSetting(
            "selenium.browserMobProxy", "10.194.120.41:9090");
    private static String chromeExtension = getSetting(
            "selenium.chromeExtension", "");
    private static String firefoxExtension = getSetting(
            "selenium.firefoxExtension", "");
    private static boolean sauceRecordVideo = Boolean.parseBoolean(getSetting(
            "sauce.record.video", "false"));
    private static boolean sauceRecordScreenshots = Boolean
            .parseBoolean(getSetting("sauce.record.screenshots", "false"));
    private static boolean sauceCaptureHtml = Boolean.parseBoolean(getSetting(
            "sauce.capture.html", "false"));
    private static String sauceTunnelID = getSetting("sauce.tunnel.id", "");
    /**
     * Browser object backing this Selenium object;
     */
    public final Browser browser = new Browser(this);
    /**
     * Assertion object backing this Selenium object;
     */
    public final Assertion assertion = new Assertion();
    /**
     * Data object backing this Selenium object;
     */
    public final Data data = new Data();
    /**
     * element object backing this Selenium object;
     */
    public final Element element = new Element();
    /**
     * Util object backing this Selenium object;
     */
    public final Util util = new Util();
    /**
     * WebDriver object backing this Selenium object;
     */
    public final Log log = new Log(Util.randomNum(0, 9999) + "_" + Util.getDateStamp(new SimpleDateFormat("yyyyMMddkkmmssSSS")));
    /**
     * WebDriver object backing this Selenium object;
     */
    public WebDriver myDriver;
    private Browser.Browsers myBrowser;
    //latest versions of browsers
    private String chromeN = "27";

    //private static String seleniumGrid = "http://localhost:4444/wd/hub";
    //private static String username = "";
    //private static String key = ("");
    // private static String seleniumGrid = "http://" + username + ":" + key +
    // "@ondemand.saucelabs.com:80/wd/hub";
    private String chromeNminus1 = "26";
    private String firefoxN = "21";
    private String firefoxNminus1 = "20";
    private String ieN = "9";
    private String ieNminus1 = "8";
    private String safariN = "6";
    private String safariNminus1 = "5";

    /**
     * Construct basic Selenium object. You need to call newDriver to fully wire
     * the helper for testing.
     */
    public Selenium() {
        //Element.setDriver(myDriver);
        element.setLog(log);
        element.setAssertion(assertion);

        //Browser.setDriver(myDriver);
        browser.setElement(element);
        //Browser.setBrowserType(myBrowser);
        browser.setLog(log);

        data.setLog(log);

        log.setBrowser(browser);
        log.setAssertion(assertion);

        assertion.setLog(log);
        assertion.setBrowser(browser);

        //get system props for versions
        if (System.getProperty("browser.version.chromeN") != null)
            chromeN = System.getProperty("browser.version.chromeN");

        if (System.getProperty("browser.version.chromeNminus1") != null)
            chromeNminus1 = System.getProperty("browser.version.chromeNminus1");

        if (System.getProperty("browser.version.firefoxN") != null)
            firefoxN = System.getProperty("browser.version.firefoxN");

        if (System.getProperty("browser.version.firefoxNminus1") != null)
            firefoxNminus1 = System.getProperty("browser.version.firefoxNminus1");

        if (System.getProperty("browser.version.ieN") != null)
            ieN = System.getProperty("browser.version.ieN");

        if (System.getProperty("browser.version.ieNminus1") != null)
            ieNminus1 = System.getProperty("browser.version.ieNminus1");

        if (System.getProperty("browser.version.safariN") != null)
            ieN = System.getProperty("browser.version.safariN");

        if (System.getProperty("browser.version.safaroNminus1") != null)
            ieNminus1 = System.getProperty("browser.version.safaroNminus1");

    }

    /**
     * Get URL for SeleniumGrid instance
     *
     * @return URL of SeleniumGrid instance
     */
    public static String getSeleniumGrid() {
        return seleniumGrid;
    }

    public static String getSetting(String value, String defaultValue) {
        String sysProp = System.getProperty(value);
        return (sysProp != null && !sysProp.isEmpty()) ? sysProp : defaultValue;
    }

    /**
     * Create a new WebDriver object for the specified browser and pointed at the specific proxy
     *
     * @param myBrowser Browser to create for
     * @param proxy     Proxy to use
     * @return Configured WebDriver object
     */
    public WebDriver newDriver(Browser.Browsers myBrowser, Proxy proxy) {
        this.myBrowser = myBrowser;
        if (myBrowser == Browser.Browsers.Chrome || myBrowser == Browser.Browsers.Firefox || myBrowser == Browser.Browsers.InternetExplorer) {
            browser.closeAllBrowsers();
        }

        myDriver = buildDriver(myBrowser, proxy);

        browser.setDriver(myDriver);
        browser.setBrowserType(myBrowser);
        element.setDriver(myDriver);
        log.setTcBrowserName(browser.getBrowserName());
        log.setTcBrowserVersion(browser.getBrowserVersion());
        if (myBrowser != Browser.Browsers.Chrome) {
            browser.maximizeBrowser();
        }
        return myDriver;
    }

    private WebDriver buildDriver(Browser.Browsers myBrowser, Proxy proxy) {
        WebDriver driver;
        DesiredCapabilities capabilities;
        ChromeOptions options;
        try {
            switch (myBrowser) {
//                case Android:
//                    driver = new AndroidDriver();
//                    break;
                case Firefox:
                    capabilities = DesiredCapabilities.firefox();
                    capabilities.setCapability(CapabilityType.PROXY, proxy);
                    capabilities.setCapability(FirefoxDriver.PROFILE, getFirefoxProfile());
                    driver = new FirefoxDriver(capabilities);
                    break;
                case Chrome:
                    capabilities = DesiredCapabilities.chrome();
                    options = new ChromeOptions();
                    System.setProperty("webdriver.chrome.driver", getChromedriverPath());
                    capabilities.setCapability(CapabilityType.PROXY, proxy);
                    capabilities.setCapability(ChromeOptions.CAPABILITY, options);
                    options.addArguments("start-maximized");
                    addChromeExtension(capabilities);
                    driver = new ChromeDriver(capabilities);
                    break;
                case InternetExplorer:
                    capabilities = DesiredCapabilities.internetExplorer();
                    System.setProperty("webdriver.ie.driver", getIEDriverPath());
                    capabilities.setCapability("ie.ensureCleanSession", true);
                    capabilities.setCapability("EnableNativeEvents", false);
                    capabilities.setCapability("ignoreZoomSetting", true);
                    capabilities.setCapability(InternetExplorerDriver.ENABLE_PERSISTENT_HOVERING, false);
                    capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
                    capabilities.setCapability(CapabilityType.SUPPORTS_FINDING_BY_CSS, true);
                    capabilities.setCapability(CapabilityType.BROWSER_NAME, "internet explorer");
                    capabilities.setCapability(CapabilityType.VERSION, "8");
                    capabilities.setCapability(CapabilityType.PLATFORM, "WINDOWS");
                    driver = new InternetExplorerDriver(capabilities);
                    driver.findElement(By.tagName("html")).sendKeys(Keys.chord(Keys.CONTROL, "0"));
                    break;
                case HtmlUnit:
                    driver = new HtmlUnitDriver();
                    ((HtmlUnitDriver) driver).setJavascriptEnabled(true);
                    capabilities = DesiredCapabilities.firefox();
                    capabilities.setBrowserName("Mozilla/5.0 (X11; Linux x86_64; rv:24.0) Gecko/20100101 Firefox/24.0");
                    capabilities.setVersion("24.0");
                    capabilities.setJavascriptEnabled(true);
                    driver = new HtmlUnitDriver(capabilities);
                    log.setNoScreenShots();
                    break;
                case GridAndroid:
                    capabilities = DesiredCapabilities.android();
                    driver = (new Augmenter()).augment(new RemoteWebDriver(getSeGridUrl(), capabilities));
                    break;
                case GridFirefox:
                    capabilities = DesiredCapabilities.firefox();
                    capabilities.setCapability(FirefoxDriver.PROFILE, new FirefoxProfile());
                    capabilities.setCapability(CapabilityType.PROXY, proxy);
                    capabilities.setCapability(CapabilityType.HAS_NATIVE_EVENTS, true);
                    driver = (new Augmenter()).augment(new RemoteWebDriver(getSeGridUrl(), capabilities));
                    break;
                case GridFirefoxN1:
                    capabilities = DesiredCapabilities.firefox();
                    capabilities.setVersion(firefoxNminus1);
                    capabilities.setCapability(FirefoxDriver.PROFILE, getFirefoxProfile());
                    capabilities.setCapability(CapabilityType.PROXY, proxy);
                    driver = (new Augmenter()).augment(new RemoteWebDriver(getSeGridUrl(), capabilities));
                    break;
                case GridFirefoxN:
                    capabilities = DesiredCapabilities.firefox();
                    capabilities.setVersion(firefoxN);
                    capabilities.setCapability(FirefoxDriver.PROFILE, getFirefoxProfile());
                    capabilities.setCapability(CapabilityType.PROXY, proxy);
                    driver = (new Augmenter()).augment(new RemoteWebDriver(getSeGridUrl(), capabilities));
                    break;
                case GridChrome:
                    capabilities = DesiredCapabilities.chrome();
                    capabilities.setCapability("chrome.switches", Arrays.asList("--no-sandbox"));
                    capabilities.setCapability(CapabilityType.PROXY, proxy);
                    addChromeExtension(capabilities);
                    driver = (new Augmenter()).augment(new RemoteWebDriver(getSeGridUrl(), capabilities));
                    break;
                case GridChromeN1:
                    capabilities = DesiredCapabilities.chrome();
                    capabilities.setCapability("chrome.switches", Arrays.asList("--no-sandbox"));
                    capabilities.setVersion(chromeNminus1);
                    capabilities.setCapability(CapabilityType.PROXY, proxy);
                    addChromeExtension(capabilities);
                    driver = (new Augmenter()).augment(new RemoteWebDriver(getSeGridUrl(), capabilities));
                    break;
                case GridChromeN:
                    capabilities = DesiredCapabilities.chrome();
                    capabilities.setCapability("chrome.switches", Arrays.asList("--no-sandbox"));
                    capabilities.setVersion(chromeN);
                    capabilities.setCapability(CapabilityType.PROXY, proxy);
                    addChromeExtension(capabilities);
                    driver = (new Augmenter()).augment(new RemoteWebDriver(getSeGridUrl(), capabilities));
                    break;
                case GridInternetExplorer:
                    capabilities = DesiredCapabilities.internetExplorer();
                    capabilities.setCapability(CapabilityType.PROXY, proxy);
                    driver = (new Augmenter()).augment(new RemoteWebDriver(getSeGridUrl(), capabilities));
                    break;
                case GridInternetExplorerN1:
                    capabilities = DesiredCapabilities.internetExplorer();
                    capabilities.setCapability(CapabilityType.PROXY, proxy);
                    capabilities.setVersion(ieNminus1);
                    driver = (new Augmenter()).augment(new RemoteWebDriver(getSeGridUrl(), capabilities));
                    break;
                case GridInternetExplorerN:
                    capabilities = DesiredCapabilities.internetExplorer();
                    capabilities.setCapability(CapabilityType.PROXY, proxy);
                    capabilities.setVersion(ieN);
                    driver = (new Augmenter()).augment(new RemoteWebDriver(getSeGridUrl(), capabilities));
                    break;
                case GridGhostDriver:
                    capabilities = DesiredCapabilities.phantomjs();
                    capabilities.setJavascriptEnabled(true);
                    capabilities.setCapability("takesScreenshot", true);
                    driver = (new Augmenter()).augment(new RemoteWebDriver(getSeGridUrl(), capabilities));
                    break;
                case GridSafari:
                    capabilities = DesiredCapabilities.safari();
                    capabilities.setCapability(CapabilityType.PROXY, proxy);
                    driver = (new Augmenter()).augment(new RemoteWebDriver(getSeGridUrl(), capabilities));
                    break;
                case BrowserMobedChrome:
                    capabilities = DesiredCapabilities.chrome();
                    capabilities.setVersion(chromeNminus1);
                    capabilities.setCapability(CapabilityType.PROXY, proxy);
                    addChromeExtension(capabilities);
                    driver = (new Augmenter()).augment(new RemoteWebDriver(getSeGridUrl(), capabilities));
                    break;
                case BrowserMobedFirefox:
                    capabilities = DesiredCapabilities.firefox();
                    capabilities.setVersion(firefoxNminus1);
                    capabilities.setCapability(FirefoxDriver.PROFILE, getFirefoxProfile());
                    capabilities.setCapability(CapabilityType.PROXY, proxy);
                    driver = (new Augmenter()).augment(new RemoteWebDriver(getSeGridUrl(), capabilities));
                    break;
                case BrowserMobedIE:
                    capabilities = DesiredCapabilities.internetExplorer();
                    capabilities.setCapability(CapabilityType.PROXY, proxy);
                    driver = (new Augmenter()).augment(new RemoteWebDriver(getSeGridUrl(), capabilities));
                    break;
                case SauceChrome:
                    capabilities = DesiredCapabilities.chrome();
                    addSauceSettings(capabilities);
                    capabilities.setVersion(chromeN);
                    capabilities.setPlatform(Platform.VISTA);
                    addChromeExtension(capabilities);
                    driver = (new Augmenter()).augment(new RemoteWebDriver(getSeGridUrl(), capabilities));
                    break;
                case SauceFirefox:
                    capabilities = DesiredCapabilities.firefox();
                    addSauceSettings(capabilities);
                    capabilities.setVersion(firefoxN);
                    capabilities.setPlatform(Platform.VISTA);
                    capabilities.setCapability(FirefoxDriver.PROFILE, new FirefoxProfile());
                    driver = (new Augmenter()).augment(new RemoteWebDriver(getSeGridUrl(), capabilities));
                    break;
                case SauceIE:
                    capabilities = DesiredCapabilities.internetExplorer();
                    addSauceSettings(capabilities);
                    capabilities.setVersion(ieN);
                    capabilities.setPlatform(Platform.VISTA);
                    driver = (new Augmenter()).augment(new RemoteWebDriver(getSeGridUrl(), capabilities));
                    break;
                case SauceSafari:
                    capabilities = DesiredCapabilities.safari();
                    addSauceSettings(capabilities);
                    capabilities.setPlatform(Platform.MAC);
                    capabilities.setVersion(safariN);
                    driver = (new Augmenter()).augment(new RemoteWebDriver(getSeGridUrl(), capabilities));
                    break;

                default:
                    return null;
            }
        } catch (UnreachableBrowserException e) {
            System.out.println("Browser Not Reachable, Grid may be down");
            return null;
        }
        return driver;
    }

    private URL getSeGridUrl() {
        URL seGrid = null;
        try {
            seGrid = new URL(seleniumGrid);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return seGrid;
    }

    /**
     * Setup capabilities object to run in saucelabs
     *
     * @param capabilities DesiredCapabilities you want setup for sauce
     */
    private void addSauceSettings(DesiredCapabilities capabilities) {
        capabilities.setCapability("record-video", sauceRecordVideo);
        capabilities.setCapability("record-screenshots", sauceRecordScreenshots);
        capabilities.setCapability("capture-html", sauceCaptureHtml);
        capabilities.setCapability("screen-resolution", "1280x1024");
        if (!sauceTunnelID.isEmpty())
            capabilities.setCapability("tunnel-identifier", sauceTunnelID);
    }

    /**
     * Add system property specified chrome extension to chrome capabilities
     *
     * @param capabilities DesiredCapabilities to add capabilities to
     */
    private void addChromeExtension(DesiredCapabilities capabilities) {
        if (!chromeExtension.isEmpty()) {
            ChromeOptions options = new ChromeOptions();
            options.addExtensions(new File(chromeExtension));
            capabilities.setCapability(ChromeOptions.CAPABILITY, options);
        }
    }

    /**
     * Add system property specified firefox extension to firefox profile
     *
     * @param profile FirefoxProfile to add extension to
     */
    private void addFirefoxExtension(FirefoxProfile profile) {
        if (!firefoxExtension.isEmpty()) {
            try {
                profile.addExtension(new File(firefoxExtension));
            } catch (IOException e) {
                System.out.println("Firefox Extension not found: " + firefoxExtension + ". " + e.getMessage());
            }
        }
    }

    /**
     * Create a new WebDriver object for the specified browser
     *
     * @param myBrowser Browser to create for
     * @return Configured WebDriver object
     */
    public WebDriver newDriver(Browser.Browsers myBrowser) {
        Proxy proxy = new Proxy();
        if (myBrowser == Browser.Browsers.BrowserMobedChrome || myBrowser == Browser.Browsers.BrowserMobedFirefox || myBrowser == Browser.Browsers.BrowserMobedIE) {
            proxy.setAutodetect(false);
            proxy.setHttpProxy(browserMobProxy);
            //proxy.setHttpsProxy(browserMobProxy);
            proxy.setSslProxy(browserMobProxy);
        } else {
            proxy.setAutodetect(true);
            proxy.setProxyType(Proxy.ProxyType.AUTODETECT);
        }
        return newDriver(myBrowser, proxy);
    }

    // TODO: Remove this, not needed
    public void setWebDriver(WebDriver driver) {
        myDriver = driver;
        browser.setDriver(myDriver);
        browser.setBrowserType(null);
        element.setDriver(myDriver);
        log.setTcBrowserName(browser.getBrowserName());
        String strBName = browser.getBrowserName();
        if (strBName.equalsIgnoreCase("HtmlUnit")) {
            log.setTcBrowserVersion("0.0");
        } else {
            log.setTcBrowserVersion(browser.getBrowserVersion());
        }
    }

    /**
     * Builds a standard firefox profile
     *
     * @return standard firefox profile
     */
    private FirefoxProfile getFirefoxProfile() {
        ProfilesIni allProfiles = new ProfilesIni();
        FirefoxProfile profile = allProfiles.getProfile("Selenium");
        if (profile == null)
            profile = allProfiles.getProfile("default");
        return getFirefoxProfile(profile);
    }

    /**
     * Builds a new firefox profile
     *
     * @return standard firefox profile
     */
    private FirefoxProfile getFirefoxProfile(FirefoxProfile profile) {
        if (profile == null)
            profile = new FirefoxProfile();
        addFirefoxExtension(profile);
        profile.setEnableNativeEvents(true);
        return profile;
    }

    /**
     * Returns full path to the IEDriverServer
     *
     * @return full path to IEDriverServer
     */
    public String getIEDriverPath() {
        return OSTools.getUserHome() + "/selenium/IEDriverServer.exe";
    }

    /**
     * Returns full path to the chromedriver executable
     *
     * @return full path to chromedriver
     */
    public String getChromedriverPath() {
        String chomedriverFilename = "chromedriver.exe"; // Default to windows
        // name
        if (OSTools.isMac() || OSTools.isUnix())
            chomedriverFilename = "chromedriver";

        return OSTools.getUserHome() + "/selenium/" + chomedriverFilename;
    }

    @Override
    public String toString() {
        return "Selenium{" + "myBrowser=" + myBrowser + '}';
    }
}