package tech.nike.automation.common.framework.wmsxmlmanager.asn;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by psibb1 on 3/4/2017.
 */
@XmlRootElement(name = "LPNDetailQuantity")
@XmlAccessorType(XmlAccessType.FIELD)
public class LPNDetailQuanity {

    @XmlElement(name = "Quantity")
    private String quantity = null;
    @XmlElement(name = "ShippedAsnQuantity")
    private String shippedAsnQuantity = null;
    @XmlElement(name = "OriginalQuantity")
    private String originalQuantity = null;

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getShippedAsnQuantity() {
        return shippedAsnQuantity;
    }

    public void setShippedAsnQuantity(String shippedAsnQuantity) {
        this.shippedAsnQuantity = shippedAsnQuantity;
    }

    public String getOriginalQuantity() {
        return originalQuantity;
    }

    public void setOriginalQuantity(String originalQuantity) {
        this.originalQuantity = originalQuantity;
    }
}
