package tech.nike.automation.common.framework.wmsxmlmanager.distributionorder;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by psibb1 on 3/4/2017.
 */
@XmlRootElement(name = "Comment")
@XmlAccessorType(XmlAccessType.FIELD)
public class Comment {

    @XmlElement(name = "NoteType")
    private String noteType = null;
    @XmlElement(name = "NoteCode")
    private String noteCode = null;
    @XmlElement(name = "CommentText")
    private String commentText = null;

    public String getNoteType() {
        return noteType;
    }

    public void setNoteType(String noteType) {
        this.noteType = noteType;
    }

    public String getNoteCode() {
        return noteCode;
    }

    public void setNoteCode(String noteCode) {
        this.noteCode = noteCode;
    }

    public String getCommentText() {
        return commentText;
    }

    public void setCommentText(String commentText) {
        this.commentText = commentText;
    }
}
