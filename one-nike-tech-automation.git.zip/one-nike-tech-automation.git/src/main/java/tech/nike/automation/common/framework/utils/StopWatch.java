package tech.nike.automation.common.framework.utils;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Map;

/**
 * A simple stopwatch utility used to track multiple events.
 * <p>
 * USAGE:
 * stopwatch.startEvent("EVENT1");
 * <do something>
 * stopwatch.stopEvent("EVENT1");
 *
 * @author efeign
 */
public class StopWatch {
    //Hashtable of events, initialized to 3 events to save space
    private final Map<String, StopWatchEvent> tasks = new Hashtable<String, StopWatchEvent>(3);

    /**
     * Start the timer a-rollin' for the specified event
     *
     * @param eventName The name of the event
     */
    public void startEvent(String eventName) {
        tasks.put(eventName, new StopWatchEvent(eventName));
    }

    /**
     * Stop the timer for the specified event
     *
     * @param eventName The name of the event
     */
    public void stopEvent(String eventName) {
        tasks.get(eventName).stop();
    }

    /**
     * Gets a specific event from the stopwatch
     *
     * @param eventName The name of the event
     */
    public StopWatchEvent getEvent(String eventName) {
        return tasks.get(eventName);
    }

    /**
     * Return a list of all stopwatch events.
     *
     * @return ArrayList<StopWatchEvent>
     */
    public ArrayList<StopWatchEvent> getEvents() {
        return new ArrayList<StopWatchEvent>(tasks.values());
    }

    /**
     * Return a slightly-pretty string showing event name
     * and duration.
     *
     * @return
     */
    public String getEventList() {
        StringBuffer sb = new StringBuffer();
        for (StopWatchEvent event : tasks.values()) {
            sb.append(event.getName()).append(" : ").append(event.getDuration()).append("\n");
        }
        return sb.toString();
    }

    public String toString() {
        String ret = "STOPWATCH RESULTS\n";
        for (String key : tasks.keySet()) {
            ret += tasks.get(key).toString() + "\n";
        }
        return ret;
    }

}