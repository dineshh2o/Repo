package tech.nike.automation.common.framework.configuration;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import tech.nike.automation.common.framework.core.SystemUtil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Created by psibb1 on 8/18/2016.
 */
public class DBConnect {
    public static Connection connection = null;
    private static Log logger = LogFactory.getLog(DBConnect.class);

    public static Connection getDatabaseConnection() {
        //reading db connection details
        String dc = SystemUtil.getBaseDC();
        Envclient getEnv = new Envclient(Envclient.Env.valueOf(dc));
        String[] envName = getEnv.getEnvUrl();
        String username = envName[1];
        String password = envName[2];
        String dbUrl = envName[3];
        String schemaname = envName[5];
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException e) {
            System.out.println("Where is your Oracle JDBC Driver?");
            logger.trace(e.getMessage());
        }
       // System.out.println("Oracle JDBC Driver Registered!");
        try {
            connection = DriverManager.getConnection(dbUrl, username, password);
            if (username.contains("READONLY")) {
                connection.createStatement().execute("ALTER SESSION SET CURRENT_SCHEMA=" + schemaname);
            }
        } catch (SQLException e) {
            System.out.println("Connection Failed! Check output console");
            logger.trace(e.getMessage());
        }
        if (connection != null) {
            //System.out.println("You made it, take control of your QC database now!");
        } else {
            System.out.println("Failed to make connection!");
        }
        return connection;
    }
}