package tech.nike.automation.common.framework.wmsxmlmanager.asn;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

/**
 * Created by psibb1 on 3/4/2017.
 */
@XmlRootElement(name = "LPN")
@XmlAccessorType(XmlAccessType.FIELD)
public class LPN {

    @XmlElement(name = "LPNID")
    private String lpnID = null;
    @XmlElement(name = "LPNSizeType")
    private String lpnSizeType = null;
    @XmlElement(name = "DestinationFacilityAliasID")
    private String destinationFacilityAliasID = null;
    @XmlElement(name = "ProcessImmdNeeds")
    private String processImmdNeeds = null;
    @XmlElement(name = "LPNDetail")
    private List<LPNDetail> lpnDetail = null;

    public String getLpnID() {
        return lpnID;
    }

    public void setLpnID(String lpnID) {
        this.lpnID = lpnID;
    }

    public String getLpnSizeType() {
        return lpnSizeType;
    }

    public void setLpnSizeType(String lpnSizeType) {
        this.lpnSizeType = lpnSizeType;
    }

    public String getDestinationFacilityAliasID() {
        return destinationFacilityAliasID;
    }

    public void setDestinationFacilityAliasID(String destinationFacilityAliasID) {
        this.destinationFacilityAliasID = destinationFacilityAliasID;
    }

    public String getProcessImmdNeeds() {
        return processImmdNeeds;
    }

    public void setProcessImmdNeeds(String processImmdNeeds) {
        this.processImmdNeeds = processImmdNeeds;
    }

    public List<LPNDetail> getLPNDetail() {
        return lpnDetail;
    }

    public void setLPNDetail(List<LPNDetail> lpnDetail) {
        this.lpnDetail = lpnDetail;
    }
}