package tech.nike.automation.common.framework.wmsxmlmanager.distributionorder;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by PSibb1 on 3/5/2017.
 */
@XmlRootElement(name = "LineProcessInfo")
@XmlAccessorType(XmlAccessType.FIELD)
public class LineProcessInfo {

    @XmlElement(name = "LineRefTextField1")
    private String lineRefTextField1 = null;
    @XmlElement(name = "LineRefTextField3")
    private String lineRefTextField3 = null;
    @XmlElement(name = "LineRefTextField4")
    private String lineRefTextField4 = null;
    @XmlElement(name = "LineRefTextField5")
    private String lineRefTextField5 = null;
    @XmlElement(name = "LineRefTextField6")
    private String lineRefTextField6 = null;
    @XmlElement(name = "LineRefTextField7")
    private String lineRefTextField7 = null;
    @XmlElement(name = "LineRefTextField8")
    private String lineRefTextField8 = null;
    @XmlElement(name = "LineRefTextField9")
    private String lineRefTextField9 = null;

    public String getLineRefTextField1() {
        return lineRefTextField1;
    }

    public void setLineRefTextField1(String lineRefTextField1) {
        this.lineRefTextField1 = lineRefTextField1;
    }

    public String getLineRefTextField3() {
        return lineRefTextField3;
    }

    public void setLineRefTextField3(String lineRefTextField3) {
        this.lineRefTextField3 = lineRefTextField3;
    }

    public String getLineRefTextField4() {
        return lineRefTextField4;
    }

    public void setLineRefTextField4(String lineRefTextField4) {
        this.lineRefTextField4 = lineRefTextField4;
    }

    public String getLineRefTextField5() {
        return lineRefTextField5;
    }

    public void setLineRefTextField5(String lineRefTextField5) {
        this.lineRefTextField5 = lineRefTextField5;
    }

    public String getLineRefTextField6() {
        return lineRefTextField6;
    }

    public void setLineRefTextField6(String lineRefTextField6) {
        this.lineRefTextField6 = lineRefTextField6;
    }

    public String getLineRefTextField7() {
        return lineRefTextField7;
    }

    public void setLineRefTextField7(String lineRefTextField7) {
        this.lineRefTextField7 = lineRefTextField7;
    }

    public String getLineRefTextField8() {
        return lineRefTextField8;
    }

    public void setLineRefTextField8(String lineRefTextField8) {
        this.lineRefTextField8 = lineRefTextField8;
    }

    public String getLineRefTextField9() {
        return lineRefTextField9;
    }

    public void setLineRefTextField9(String lineRefTextField9) {
        this.lineRefTextField9 = lineRefTextField9;
    }
}
