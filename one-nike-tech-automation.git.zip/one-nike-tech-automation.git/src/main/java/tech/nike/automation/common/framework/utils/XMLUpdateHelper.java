package tech.nike.automation.common.framework.utils;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.util.Map;

/**
 * Created by PSibb1 on 1/11/2017.
 */
public class XMLUpdateHelper {
    private Log logger = LogFactory.getLog(XMLUpdateHelper.class);
    int DEPTH_OF_XML = 1;
    String path = new File("src/test/resources/wms/syntheticXmls").getAbsolutePath() + "\\";

    public String getFilePath() {
        return path;
    }

    /**
     * method to update multiple tags in an xml file at their first occurance
     *
     * @param tags
     */
    public void updateUniqueItemWithMultipleTags(Map<String, Object> tags) {
        String xmlFileName = (String) tags.get("xmlfilename");
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(path + xmlFileName);
            for (Map.Entry<String, Object> entry : tags.entrySet()) {
                Node elem = doc.getElementsByTagName(entry.getKey()).item(0);
                if (elem != null) {
                    //update the tag value
                    elem.setTextContent(entry.getValue().toString());
                }
            }
            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(path + xmlFileName);
            transformer.transform(source, result);
        } catch (Exception e) {
            logger.error(e.getMessage() + e.getStackTrace());

        }
    }

    /**
     * method to update multiple tags in an xml file at their first occurance
     *
     * @param tags
     */
    public void updateUniqueItemWithMultipleTags(int tagIndex, Map<String, Object> tags) {
        String xmlFileName = (String) tags.get("xmlfilename");
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(path + xmlFileName);
            for (Map.Entry<String, Object> entry : tags.entrySet()) {
                Node elem = doc.getElementsByTagName(entry.getKey()).item(tagIndex);
                if (elem != null) {
                    //update the tag value
                    elem.setTextContent(entry.getValue().toString());
                }
            }
            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(path + xmlFileName);
            transformer.transform(source, result);
        } catch (Exception e) {
            logger.error(e.getMessage() + e.getStackTrace());

        }
    }

    /**
     * method to update a single xml tag at its first occurance
     *
     * @param xmlFileName
     * @param tagName
     * @param tagValue
     */
    public void updateSingleTag(String xmlFileName, String tagName, String tagValue) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(path + xmlFileName);
            //get the element
            Node elem = doc.getElementsByTagName(tagName).item(0);
            if (elem != null) {
                //update the tag value
                elem.setTextContent(tagValue);
            }
            //Keep this code commented as this is for different XML structure
            // update element attribute
            /*NamedNodeMap attr = elem.getAttributes();
            Node nodeAttr = attr.getNamedItem("id");
            nodeAttr.setTextContent("2");
            */
            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(path + xmlFileName);
            transformer.transform(source, result);
        } catch (Exception e) {
            logger.error(e.getMessage() + e.getStackTrace());
        }
    }

    /**
     * method to update a single xml tag at its iterative occurrence's
     *
     * @param xmlFileName
     * @param tagName
     * @param tagValue
     */
    public void updateSingleTagIterations(String xmlFileName, String tagName, String tagValue) {
        try {
            Node elem = null;
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(path + xmlFileName);
            //get all the node by tag name
            NodeList list = doc.getElementsByTagName(tagName);
            for (int i = 0; i < list.getLength(); i++) {
                elem = doc.getElementsByTagName(tagName).item(i);
                if (elem != null) {
                    //update the tag value
                    elem.setTextContent(tagValue);
                }
            }
            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(path + xmlFileName);
            transformer.transform(source, result);
        } catch (Exception e) {
            logger.error(e.getMessage() + e.getStackTrace());
        }
    }

    /**
     * method to get the xml file depth
     *
     * @param xmlFileName
     * @return
     */
    public int getXmlTagDepthOfXml(String xmlFileName) {
        int output = 0;
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(path + xmlFileName);
            NodeList list = doc.getElementsByTagName("t");
            Element elements = doc.getDocumentElement();
            int level = 1;
            //System.out.println(elements.getNodeName() + "[" + level + "]");
            NodeList nodeList = elements.getChildNodes();
            getDepthOfXml(nodeList, level);
            output = DEPTH_OF_XML;
            //System.out.println("Max depth of XML : " + output);
        } catch (Exception e) {
            logger.error(e.getMessage() + e.getStackTrace());
        }
        return output;
    }

    /**
     * helper method to get the depth of xml file based on node list and level
     *
     * @param nodeList
     * @param level
     * @return
     */
    private void getDepthOfXml(NodeList nodeList, int level) {
        level++;
        if (nodeList != null && nodeList.getLength() > 0) {
            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    System.out.println(node.getNodeName() + "[" + level + "]");
                    getDepthOfXml(node.getChildNodes(), level);
                    // how depth is it?
                    if (level > DEPTH_OF_XML) {
                        DEPTH_OF_XML = level;
                    }
                }
            }
        }
    }

    /**
     * method to get the xml tag value by tag name
     *
     * @param xmlFileName
     * @param tagName
     * @return
     */
    public String getValueByTagName(String xmlFileName, String tagName) {
        String tagValue = "";
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(path + xmlFileName);
            //get the element
            Node elem = doc.getElementsByTagName(tagName).item(0);
            if (elem != null) {
                //update the tag value
                tagValue = elem.getTextContent().trim();
            }
        } catch (Exception e) {
            logger.error(e.getMessage() + e.getStackTrace());
        }
        return tagValue;
    }

    /**
     * method to get the xml tag value by tag name
     *
     * @param xmlFileName
     * @param tagName
     * @return
     */
    public String getValueByTagName(String xmlFileName, int index, String tagName) {
        String tagValue = "";
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(path + xmlFileName);
            //get the element
            Node elem = doc.getElementsByTagName(tagName).item(index);
            if (elem != null) {
                //update the tag value
                tagValue = elem.getTextContent().trim();
            }
        } catch (Exception e) {
            logger.error(e.getMessage() + e.getStackTrace());
        }
        return tagValue;
    }

    /**
     * method to add a tag to existing test data xml file
     *
     * @param xmlFilePath
     * @param tagName
     * @param tagValue
     */
    public void addXmlTagWithValueToXmlFile(String xmlFilePath, String tagName, String tagValue) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(xmlFilePath);
            //get the element
            Node elem = doc.getElementsByTagName("test").item(0);
            if (elem != null) {
                Node newElem = doc.getElementsByTagName(tagName).item(0);
                if (newElem == null) {
                    // append a new node to test
                    Element newTag = doc.createElement(tagName);
                    newTag.appendChild(doc.createTextNode(tagValue));
                    elem.appendChild(newTag);
                } else {
                    //update the existing tag value
                    newElem.setTextContent(tagValue);
                }
            }
            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(xmlFilePath);
            transformer.transform(source, result);
        } catch (Exception e) {
            logger.error(e.getMessage() + e.getStackTrace());
        }
    }

    /**
     * method to add a tag to existing test data xml file
     *
     * @param xmlFilePath
     * @param tagName
     * @param tagValue
     */
    public void addXmlTagWithValueToXmlFile(String xmlFilePath, int index, String tagName, String tagValue) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(xmlFilePath);
            //get the element
            Node elem = doc.getElementsByTagName("test").item(index);
            if (elem != null) {
                Node newElem = doc.getElementsByTagName(tagName).item(index);
                if (newElem == null) {
                    // append a new node to test
                    Element newTag = doc.createElement(tagName);
                    newTag.appendChild(doc.createTextNode(tagValue));
                    elem.appendChild(newTag);
                } else {
                    //update the existing tag value
                    newElem.setTextContent(tagValue);
                }
            }
            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(xmlFilePath);
            transformer.transform(source, result);
        } catch (Exception e) {
            logger.error(e.getMessage() + e.getStackTrace());
        }
    }

    /**
     * method to get the xml tag count tag name
     *
     * @param xmlFileName
     * @param tagName
     * @return int
     */
    public int getTagNameCount(String xmlFileName, String tagName) {
        int cnt = 0;
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(path + xmlFileName);
            //get the element
            NodeList elem = doc.getElementsByTagName(tagName);
            if (elem != null) {
                //update the tag value
                cnt = elem.getLength();
            }
        } catch (Exception e) {
            logger.error(e.getMessage() + e.getStackTrace());
        }
        return cnt;
    }

    /**
     * method to update all the tags based on the XMl parametrization
     *
     * @param xmlFilePath
     * @param tagName
     */
    public void updateXMLTags(String xmlFilePath, String tagName) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(xmlFilePath);

            //Get element by tag name.
            Node tags = doc.getElementsByTagName(tagName).item(0);

            //Get tagName element list.
            NodeList list = tags.getChildNodes();

            //Iterate and process tagName.
            for (int temp = 0; temp < list.getLength(); temp++) {
                Node node = list.item(temp);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element tagElement = (Element) node;
                    if (tagName.equals(tagElement.getNodeName())) {
                        if (tagElement.getNodeValue().contains("$")) {

                        }
                    }
                }
            }

            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(xmlFilePath);
            transformer.transform(source, result);
        } catch (Exception e) {
            logger.error(e.getMessage() + e.getStackTrace());
        }

    }

    /**
     * method to get the node element count
     *
     * @param xmlFilePath
     * @param nodeName
     * @return
     */
    public int getNodeCount(String xmlFilePath, String nodeName) {
        int nodeCnt = 0;
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(xmlFilePath);
            NodeList list = doc.getElementsByTagName(nodeName);
            nodeCnt = list.getLength();
        } catch (Exception e) {
            logger.error(e.getMessage() + e.getStackTrace());
        }
        return nodeCnt;
    }
}