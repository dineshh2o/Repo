package tech.nike.automation.common.framework.qcrestapi;

import org.testng.Assert;
import org.testng.annotations.Test;
import tech.nike.automation.common.framework.core.Selenium;
import tech.nike.automation.common.framework.core.SystemUtil;


/**
 * ALM web service interaction JUnit tests.
 * Validate if the REST web service interaction is working properly.
 *
 * @author
 * @version 21th November 2011
 * @company WhiteSoft
 */
public class QC {
    public static final String almServer = SystemUtil.getQCUrl();
    public static final String almUser = SystemUtil.getQCUser();
    public static final String almqcPwd = SystemUtil.getQCPassword();
    public static final String almDomain = SystemUtil.getQCDomain();
    public static final String almProject = SystemUtil.getQCProject();
    Selenium se;

    private ALMConnection almPrepare() {
        ALMConnection alm = new ALMConnection();
        alm.setAlmUser(almUser);
        alm.setAlmPassword(almqcPwd);
        alm.setAlmDomain(almDomain);
        alm.setAlmProject(almProject);
        alm.setServerURL(almServer);
        alm.setServerPort(8080);
        return alm;
    }

    private boolean almAuthenticate(ALMConnection alm) {
        return alm.Authenticate();
    }


    private boolean almStartSession(ALMConnection alm) {
        return alm.StartSession();
    }

    public boolean testLogout() {
        boolean result = false;
        try {
            ALMConnection alm = almPrepare();
            result = alm.Logout();
        } catch (Exception e) {
            se.log.logSeStep("Error logging out of ALM :" + e.getMessage());
        }
        return result;
    }

    @Test
    public void updateAlmResultsWithAttachments() {
        //boolean result = false;
        try {
            ALMConnection alm = almPrepare();
            almAuthenticate(alm);
            almStartSession(alm);
            //se.assertion.verifyTrue("Not able to add results", ALM.AddVAPITestRun(1, 2, 1, 3, "PSIBB1", "Passed", "57723"));
            Assert.assertTrue(alm.updateQCTestStatus("Passed", "\\GWM AUTOMATION ARTIFACTS\\MISC\\Automation\\EU\\DryRun\\HERENTALS\\HERENTALS_SELENIUM_04_17\\IB_MVP_HERENTALS",
                    "IB_HNTL_E2E_01_ManualRecv_SingleASN_SingleShip_Sorted_MixPalLocn", "IB_1064_PRE_RECV_InitiateShipment_HP_03_SingleASN"),
                    "Able to add results");
            Assert.assertTrue(alm.updateQCRunTestStatus("Passed", 502,
                    "\\GWM AUTOMATION ARTIFACTS\\MISC\\Automation\\EU\\DryRun\\HERENTALS\\HERENTALS_SELENIUM_04_17\\IB_MVP_HERENTALS",
                    "IB_HNTL_E2E_01_ManualRecv_SingleASN_SingleShip_Sorted_MixPalLocn", "IB_1064_PRE_RECV_InitiateShipment_HP_03_SingleASN", "test passed"),
                    "Able to add results");
            Assert.assertTrue(alm.addAttachmentToTestInstance("\\GWM AUTOMATION ARTIFACTS\\MISC\\Automation\\EU\\DryRun\\HERENTALS\\HERENTALS_SELENIUM_04_17\\IB_MVP_HERENTALS",
                    "IB_HNTL_E2E_01_ManualRecv_SingleASN_SingleShip_Sorted_MixPalLocn", "IB_1064_PRE_RECV_InitiateShipment_HP_03_SingleASN", "C:\\AVideo", "raju.xml"),
                    "adding attachment");
            testLogout();
        } catch (Exception e) {
            se.log.logSeStep("error was: " + e.getMessage());
        }
    }
}