package tech.nike.automation.common.framework.core;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.testng.ITestResult;
import org.testng.annotations.*;
import org.xml.sax.SAXException;
import tech.nike.automation.common.framework.qcrestapi.QC;
import tech.nike.automation.common.framework.video.VideoRecorder;
import tech.nike.automation.common.utils.parsers.*;

import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Method;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static tech.nike.automation.common.framework.core.Log.VERDICT.Fail;
import static tech.nike.automation.common.framework.core.Log.VERDICT.Pass;

public abstract class CommonBaseTest {
    VideoRecorder vr = new VideoRecorder();
    QC hpAlm = new QC();
    private Log logger = LogFactory.getLog(CommonBaseTest.class);

    /**
     * Takes an existing parameter list, and expands it with a new list of paramaters.
     * <p>
     * So something like:
     * [ [Chrome], [Firefox] ]
     * Weaved with: [Red, Blue]
     * <p>
     * Becomes:
     * <p>
     * [ [Chrome, Red], [Chrome, Blue], [Firefox, Red], [Firefox, Blue] ]
     *
     * @param baseParameters Object[][] to weave into
     * @param newParameters  List of objects to add
     * @return new Object[][]
     * @author Cognizant Technology CoE
     */
    public static Object[][] weaveInParameters(Object[][] baseParameters, List<?> newParameters) {
        List<List<Object>> returnData = new ArrayList<List<Object>>();
        for (Object[] baseParameter : baseParameters) {
            for (Object newParameter : newParameters) {
                List<Object> column = new ArrayList<Object>();
                Collections.addAll(column, baseParameter);
                column.add(newParameter);
                returnData.add(column);
            }
        }

        Object[][] convertedReturnData = new Object[returnData.size()][];
        for (int row = 0; row < returnData.size(); row++) {
            convertedReturnData[row] = returnData.get(row).toArray();
        }
        return convertedReturnData;
    }

    public static Object[][] weaveInSeHelpers(Object[][] baseParameters) {
        List<List<Object>> returnData = new ArrayList<List<Object>>();
        for (Object[] baseParameter : baseParameters) {
            List<Object> column = new ArrayList<Object>();
            Collections.addAll(column, baseParameter);
            column.add(new Selenium());
            returnData.add(column);
        }

        Object[][] convertedReturnData = new Object[returnData.size()][];
        for (int row = 0; row < returnData.size(); row++) {
            convertedReturnData[row] = returnData.get(row).toArray();
        }
        return convertedReturnData;
    }

    @BeforeSuite(alwaysRun = true)
    protected void beforeSuite() {
        SystemUtil.setEnvirnomentUrl();
    }

    @BeforeMethod(alwaysRun = true)
    protected void beforeMethod(Method method, Object[] params) {
        Test test = method.getAnnotation(Test.class);
        //BasicConfigurator.configure();
        Browser.Browsers myBrowser = (Browser.Browsers) params[0];
        Selenium se = ((Selenium) params[1]);
        se.log.trace("Test Method: " + method.getName());
        se.log.trace("Description: " + test.description());
        se.log.trace("Browser: " + myBrowser.toString());
        se.newDriver(myBrowser);
       /* if (se.myDriver != null)
            se.myDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);*/
        se.myDriver.get(SystemUtil.getEnvironmentUrl());
        //start recording if user has annotated in test method
        Video record = method.getAnnotation(Video.class);
        if (record.recording()) {
            vr.startRecording();
        }
        se.log.trace("*--------------Started - Test  " + method.getName()+"---------*");
    }

    @AfterMethod(alwaysRun = true)
    protected void afterMethod(Method method, ITestResult result, Object[] params) {
        Selenium se = null;
        if (params.length >= 2 && params[1] instanceof Selenium) {
            se = (Selenium) params[1];
        } else if (params.length >= 1 && params[0] instanceof Selenium) {
            se = (Selenium) params[0];
        }
        if (params.length >= 1 && params[params.length - 1] instanceof Map) {
            params[params.length - 1] = "";
        }
        if (se != null) {
            //stop recording if user has annotated in test method
            Video record = method.getAnnotation(Video.class);
            if (record.recording()) {
                vr.stopRecording();
            }
            //report test execution status to alm with attachment of test report
            QCLogging alm = method.getAnnotation(QCLogging.class);
            if (alm.reportALM()) {
                hpAlm.updateAlmResultsWithAttachments();
            }
            se.log.trace("*--------------End of " + method.getName() + " Result: " + result.isSuccess() + "\n");
            se.log.printLogBuilder();
            String verdictText = (result.isSuccess() ? Pass.name() : Fail.name());
            se.log.couchDb(verdictText);
            se.browser.quit();
        }
    }

    protected void testTearDown(Selenium se) {
        se.assertion.checkForFail();
    }

    /**
     * DataProvider to each set of <test></test> xml blocks, against each comma separated browsers list
     *
     * @param testMethod
     * @return
     * @throws Exception
     * @author Cognizant Technology CoE
     */
    @SuppressWarnings("unchecked")
    @DataProvider(name = "browserXml", parallel = true)
    public Object[][] DefaultDataProvider(final Method testMethod) throws Exception {
        //Array of browsers to parameterize test with
        Object[][] browsersParameters = Data.createDataProviderFromDelimitedString(SystemUtil.getBrowsers(), ",");
        //List of parameters to weave in with browsers
        List<Map<String, Object>> dataList = new ArrayList<Map<String, Object>>();
        //get annotation from test method
        TestData testData = testMethod.getAnnotation(TestData.class);

        //check for annotation for filename
        if (testData == null || testData.fileName() == null || testData.fileName().length() == 0) {
            System.out.println(testMethod.getClass().getSimpleName() + " : TEST REQUIRES DATA FILE TO BE DEFINED");
            System.exit(0);
        }
        Object testObject = getTestParameters(testData.fileName()).get("test");

        //if we have more than one test
        if (testObject instanceof List) {
            for (Map<String, Object> test : (List<Map<String, Object>>) testObject) {
                dataList.add(test);
            }
        }
        //if there is only one test tag in xml file
        else if (testObject instanceof Map<?, ?>) {
            dataList.add((Map<String, Object>) testObject);
        }
        //something is wrong with the file
        else {
            throw new Exception(testMethod.getClass().getSimpleName() + " : TEST FORMAT IS INCORRECT");
        }

        //add sehelper
        Object[][] returnDataWithSeHelper = weaveInSeHelpers(browsersParameters);

        //run each set of test parameters in each browser
        Object[][] returnData = weaveInParameters(returnDataWithSeHelper, dataList);

        return returnData;
    }

    /**
     * DataProvider to run each test method against each browser in the browsers comma separated list
     *
     * @return
     * @author Cognizant Technology CoE
     */
    @DataProvider(name = "browser", parallel = true)
    public Object[][] DefaultDataProvider() {
        return weaveInSeHelpers(Data.createDataProviderFromDelimitedString(SystemUtil.getBrowsers(), ","));
    }

    /**
     * Parse xml or csv into Map<String, Object>
     *
     * @param testFileName
     * @return
     */
    protected Map<String, Object> getTestParameters(String testFileName) {
        Map<String, Object> config = null;
        try {
            String fileName = "";
            if (!testFileName.startsWith("/")) {
                fileName += "/" + testFileName;
            }
            //URL url = this.getClass().getResource(fileName).toURI();
            File source = new File(this.getClass().getResource(fileName).toURI());
            DataToMapParser parser = null;

            //check config file type
            if (fileName.toLowerCase().contains(".xml")) {
                parser = new XMLToMapParser();
            } else if (fileName.toLowerCase().contains(".csv")) {
                parser = new CSVToMapParser();
            }else if(fileName.toLowerCase().contains(".xls") | fileName.toLowerCase().contains(".xlsx")){
                parser = new XLToMapParser();
            } else if (fileName.toLowerCase().contains(".json")) {
                //parser = new JsonToMapParser();
            }

            parser.parse(source);

            //based on file type use appropriate parser
            config = parser.getHashMap();
        } catch (IOException e) {
            logger.error(e.getMessage() + e.getStackTrace());
        } catch (ParserConfigurationException e) {
            logger.error(e.getMessage() + e.getStackTrace());
        } catch (SAXException e) {
            logger.error(e.getMessage() + e.getStackTrace());
        } catch (URISyntaxException e) {
            logger.error(e.getMessage() + e.getStackTrace());
        }

        return config;
    }

    /**
     * Method level annotation to specify xml file
     *
     * @author Cognizant Technology CoE
     */
    @Retention(RetentionPolicy.RUNTIME)
    @Target({ElementType.METHOD})
    public @interface TestData {
        String fileName();
    }

    /**
     * Method level annotation to specify xml file
     *
     * @author ADOAN1
     */
    @Retention(RetentionPolicy.RUNTIME)
    @Target({ElementType.METHOD})
    public @interface Video {
        boolean recording() default false;
    }

    /**
     * Method level annotation to specify xml file
     *
     * @author ADOAN1
     */
    @Retention(RetentionPolicy.RUNTIME)
    @Target({ElementType.METHOD})
    public @interface QCLogging {
        boolean reportALM() default false;
    }
}