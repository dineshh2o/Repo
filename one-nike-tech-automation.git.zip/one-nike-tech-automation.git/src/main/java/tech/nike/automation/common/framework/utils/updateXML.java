package tech.nike.automation.common.framework.utils;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


public class updateXML {
    /*
     * Updates the XML Attributes
     */
    public static void postDatatoXML(String testCaseiD, HashMap<String, String> xmlAttributes, int RecordCnt) {
        try {
            HashMap<String, String> XMLDATA = xmlAttributes;
            String fileName = testCaseiD;
            String AbsolutePath = new File(".").getAbsolutePath();
            AbsolutePath = AbsolutePath.substring(0, AbsolutePath.length() - 1);
            String NALC_XML_filePath = AbsolutePath + "NALC\\NALC_XML\\" + fileName + ".xml";
            File fXmlFile = new File(NALC_XML_filePath);
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(fXmlFile);
            doc.getDocumentElement().normalize();

            Node nNodeDoc = doc.getElementsByTagName("DistributionOrder").item(RecordCnt);
            NodeList nListDoc = nNodeDoc.getChildNodes();

            for (int i = 0; i < nListDoc.getLength(); i++) {
                Node nNode = nListDoc.item(i);
                if ("DistributionOrderId".equalsIgnoreCase(nNode.getNodeName())) {
                    String strDONum = xmlAttributes.get("DistributionOrderId");
                    nNode.setTextContent(strDONum);
                }
                //System.out.println("\nCurrent Element :" + nNode.getNodeName());
                    /*if (nNode.getNodeType() == Node.ELEMENT_NODE) {
						Element eElement = (Element) nNode;
						Iterator it = xmlAttributes.entrySet().iterator();
						it.hasNext();
						Map.Entry pair = (Map.Entry) it.next();
						eElement.getElementsByTagName(pair.getKey().toString()).item(0).setTextContent(pair.getValue().toString());
						it.remove();
					}*/
            }

            NodeList nList = doc.getElementsByTagName("LineItem");

            for (int temp = 0; temp < nList.getLength(); temp++) {
                if (temp == RecordCnt) { //Added By Nilanchal
                    Node nNode = nList.item(temp);
                    //System.out.println("\nCurrent Element :" + nNode.getNodeName());
                    if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                        Element eElement = (Element) nNode;
                        Iterator it = xmlAttributes.entrySet().iterator();
                        //it.hasNext(); // Nilanchal to skip the distribution order
                        while (it.hasNext()) {
                            try {
                                Map.Entry pair = (Map.Entry) it.next();
                                if ((!pair.getKey().toString().equalsIgnoreCase("DistributionOrderId")) &&
                                        (!pair.getKey().toString().equalsIgnoreCase("NoteCode")) &&
                                        (!pair.getKey().toString().equalsIgnoreCase("CommentText"))) {
                                    eElement.getElementsByTagName(pair.getKey().toString()).item(0).setTextContent(pair.getValue().toString());
                                    it.remove();
                                }
                            } catch (Exception e) {
                                System.out.println(testCaseiD + "===>Exception Occured in XML update for field: ");
                                e.printStackTrace();
                            }
                        }
                    }
                }
            }


            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(NALC_XML_filePath));
            transformer.transform(source, result);
            System.out.println("-------------------------------------------------------------------------------");
            System.out.println(testCaseiD + "===>XML UpdateDone");
            System.out.println("-------------------------------------------------------------------------------");
        } catch (Exception e) {
            System.out.println(testCaseiD + "===>Exception Occured in XML update");
            e.printStackTrace();
        }
    }

    public static void postVASDatatoXML(String testCaseiD, HashMap<String, String> xmlAttributes, int RecordCnt) {
        try {
            HashMap<String, String> XMLDATA = xmlAttributes;
            String fileName = testCaseiD;
            String NALC_XML_filePath = "target/NALC/NALC_XML/" + fileName + ".xml";
            File fXmlFile = new File(NALC_XML_filePath);
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(fXmlFile);
            doc.getDocumentElement().normalize();
            boolean bflag = true;
            int count = 0;
            String strNoteType = "";
            //VAS Code and Description
            while (bflag) {
                Node nNodeDocVas = doc.getElementsByTagName("Comment").item(count);
                NodeList nListDocVas = nNodeDocVas.getChildNodes();
                System.out.println("Element Count: " + nListDocVas.getLength());
                for (int i = 0; i < nListDocVas.getLength(); i++) {
                    Node nNodeVas = nListDocVas.item(i);
                    System.out.println("Node Name: " + nNodeVas.getNodeName());
                    if ("NoteType".equalsIgnoreCase(nNodeVas.getNodeName())) {
                        strNoteType = nNodeVas.getTextContent();
                    }
                    if (strNoteType.equalsIgnoreCase("VS")) {
                        if ("NoteCode".equalsIgnoreCase(nNodeVas.getNodeName())) {
                            String strVasCode = xmlAttributes.get("NoteCode");
                            nNodeVas.setTextContent(strVasCode);
                        }
                        if ("CommentText".equalsIgnoreCase(nNodeVas.getNodeName())) {
                            String strVasDesc = xmlAttributes.get("CommentText");
                            nNodeVas.setTextContent(strVasDesc);
                        }
                        bflag = false;
                    }

                }
                count++;
            }
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(NALC_XML_filePath));
            transformer.transform(source, result);
            System.out.println("-------------------------------------------------------------------------------");
            System.out.println(testCaseiD + "===>XML UpdateDone for VAS");
            System.out.println("-------------------------------------------------------------------------------");
        } catch (Exception e) {
            System.out.println(testCaseiD + "===>Exception Occured in VAS XML update");
            e.printStackTrace();
        }
    }
}
