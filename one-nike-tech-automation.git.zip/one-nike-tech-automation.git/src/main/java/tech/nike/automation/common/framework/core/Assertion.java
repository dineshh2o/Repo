package tech.nike.automation.common.framework.core;

import net.lightbody.bmp.core.har.HarNameValuePair;
import net.lightbody.bmp.core.har.HarRequest;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.testng.Assert;
import tech.nike.automation.common.framework.testng.NoAssertionsException;

import java.text.DecimalFormat;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import static org.testng.Assert.assertTrue;

public class Assertion {
    private Log myLog;
    private Browser myBrowser;
    private Selenium se;
    private StringBuilder result = new StringBuilder();
    private int totalPass = 0;
    private int totalFail = 0;
    private int totalError = 0;
    private int assertionCount = 0;

    private DecimalFormat df = new DecimalFormat("#%");

    public Assertion() { }

    public void setLog(Log log) {
        myLog = log;
    }

    public void setBrowser(Browser browser) {
        myBrowser = browser;
    }

    /**
     * Clears counts of fails, passes and total assertion calls.
     */
    public void clearAssertions() {
        totalPass = 0;
        totalFail = 0;
        assertionCount = 0;
    }

    /**
     * Get count of all assertions run
     * @return count of assertions run
     */
    public int getAssertionCount() {
        return assertionCount;
    }

    /**
     * Get total passing assertions.
     * @return count of passing assertions
     */
    public int getTotalPass() {
        return totalPass;
    }

    /**
     * Get total failing assertions
     * @return count of failing assertions
     */
    public int getTotalFail() {
        return totalFail;
    }

    /**
     * Get total failing verifications
     *
     * @return count of failing verifications
     */
    public int getTotalError() { return totalError; }

    private boolean logFail(String testname, String message) {
        result.append("\n" + testname + ": " + message);
        String screenShotLink = myLog.takeScreenShot(testname, false);
        String screenshotUrl = myLog.logTcAssertion(assertionCount++, testname, screenShotLink, Log.VERDICT.Fail);
        result.append("\n" + screenshotUrl);
        totalFail++;
        return false;
    }

    private boolean logFailNoScreenShot(String testname, String message) {
        result.append("\n" + testname + ": " + message);
        myLog.logTcAssertion(assertionCount++, testname, null, Log.VERDICT.Fail);
        totalFail++;
        return false;
    }

    private boolean logPass(String testname) {
        String screenShotLink = myLog.takeScreenShot(testname, true);
        myLog.logTcAssertion(assertionCount++, testname, screenShotLink, Log.VERDICT.Pass);
        totalPass++;
        return true;
    }

    private void logError(String errorName) {
        result.append("\nERROR: ").append(errorName);
        myLog.trace("<strong class='error-label'>ERROR: </strong><span class='error-body'>" + errorName + "</span>");
        String screenShotLink = myLog.takeScreenShot(errorName, false);
        String screenshotUrl = myLog.logTcError(assertionCount++, errorName, screenShotLink, Log.VERDICT.Error);
        myLog.trace(screenshotUrl);
    }

    /**
     * Verify that two collections contain equivalent elements in the same order.
     *
     * Logs pass/fail based on results.
     *
     * @param testname Name of this test
     * @param actual Actual collection found
     * @param expected Expected collection
     * @return True if collections match
     */
    public boolean verifyEquals(String testname, JSONObject actual, JSONObject expected) {
        String vpName = getFormattedVPTestName(testname);
        myLog.logSeStep(String.format("%s: Verify JSONObject Equal Actual: '%s' Expected: '%s'", vpName, actual, expected));
        try {
            Assert.assertEquals(actual, expected, vpName);
            logPass(testname);
            return true;
        } catch (AssertionError e) {
            logFail(testname, e.getMessage());
            return false;
        } catch (Exception e) {
            logFail(testname, e.getMessage());
            return false;
        }
    }
    /**
     * Verify that two collections contain equivalent elements in the same order.
     *
     * Logs pass/fail based on results.
     *
     * @param testname Name of this test
     * @param actual Actual collection found
     * @param expected Expected collection
     * @return True if collections match
     */
    public boolean verifyEquals(String testname, Collection<?> actual, Collection<?> expected) {
        String vpName = getFormattedVPTestName(testname);
        myLog.logSeStep(String.format("%s: Verify Collection Equal Actual: '%s' Expected: '%s'", vpName, actual, expected));
        try {
            Assert.assertEquals(actual, expected, vpName);
            logPass(testname);
            return true;
        } catch (AssertionError e) {
            logFail(testname, e.getMessage());
            return false;
        } catch (Exception e) {
            logFail(testname, e.getMessage());
            return false;
        }
    }

    /**
     * Verify that two maps contain equivalent elements
     *
     * Logs pass/fail based on results.
     *
     * @param testname Name of this test
     * @param actual Actual map found
     * @param expected Expected map
     * @return True if maps match
     */
    public boolean verifyEquals(String testname, Map<?,?> actual, Map<?,?> expected) {
        String vpName = getFormattedVPTestName(testname);
        myLog.logSeStep(String.format("%s: Verify Maps Equal Actual: '%s' Expected: '%s'", vpName, actual, expected));
        try {
            Assert.assertEquals(actual, expected, vpName);
            logPass(testname);
            return true;
        } catch (AssertionError e) {
            logFail(testname, e.getMessage());
            return false;
        } catch (Exception e) {
            logFail(testname, e.getMessage());
            return false;
        }
    }


    /**
     * Verify that two Strings are equivalent
     *
     * Logs pass/fail based on results.
     *
     * @param testname Name of this test
     * @param actual Actual string found
     * @param expected Expected string
     * @return True if strings match
     */
    public boolean verifyEquals(String testname, String actual, String expected) {
        String vpName = getFormattedVPTestName(testname);
        myLog.logSeStep(String.format("%s: Verify Strings Equal Actual: '%s' Expected: '%s'", vpName, actual, expected));
        try {
            Assert.assertEquals(actual, expected, vpName);
            logPass(testname);
            return true;
        } catch (AssertionError e) {
            logFail(testname, e.getMessage());
            return false;
        } catch (Exception e) {
            logFail(testname, e.getMessage());
            return false;
        }
    }

    /**
     * Verify that two integers are equivalent
     *
     * Logs pass/fail based on results.
     *
     * @param testname Name of this test
     * @param actual Actual integer found
     * @param expected Expected integer
     * @return True if integers match
     */
    public boolean verifyEquals(String testname, int actual, int expected) {
        String vpName = getFormattedVPTestName(testname);
        myLog.logSeStep(String.format("%s: Verify Integers Equal Actual: '%d' Expected: '%d'", vpName, actual, expected));
        try {
            Assert.assertEquals(actual, expected, vpName);
            logPass(testname);
            return true;
        } catch (AssertionError e) {
            logFail(testname, e.getMessage());
            return false;
        } catch (Exception e) {
            logFail(testname, e.getMessage());
            return false;
        }
    }
    /**
     * Verify that two doubles are equivalent within acceptable delta
     *
     * Logs pass/fail based on results.
     *
     * @param testname Name of this test
     * @param actual Actual double found
     * @param expected Expected double
     * @param delta Delta double
     * @return True if double match
     */
    public boolean verifyEquals(String testname, double actual, double expected, double delta) {
        String vpName = getFormattedVPTestName(testname);
        myLog.logSeStep(String.format("%s: Verify Double Equal Actual with in delta: '%f' Expected: '%f' Delta : '%f'", vpName, actual, expected, delta));
        try {
            Assert.assertEquals(actual, expected, delta, vpName);
            logPass(testname);
            return true;
        } catch (AssertionError e) {
            logFail(testname, e.getMessage());
            return false;
        } catch (Exception e) {
            logFail(testname, e.getMessage());
            return false;
        }
    }
    /**
     * Verify that two Strings are not equivalent
     *
     * Logs pass/fail based on results.
     *
     * @param testname Name of this test
     * @param actual Actual string found
     * @param notExpected Not expected string
     * @return True if strings don't match
     */
    public boolean verifyNotEquals(String testname, String actual, String notExpected) {
        String vpName = getFormattedVPTestName(testname);
        myLog.logSeStep(String.format("%s: Verify Strings Not Equal Actual: '%s' Not Expecting: '%s'", vpName, actual, notExpected));
        try {
            Assert.assertNotSame(actual, notExpected, vpName);
            logPass(testname);
            return true;
        } catch (AssertionError e) {
            if (actual == null)
                logFailNoScreenShot(testname, "Strings are Equal");
            else
                logFail(testname, "Strings are Equal");
            return false;
        } catch (Exception e) {
            logFail(testname, e.getMessage());
            return false;
        }
    }

    /**
     * Verify that two integers are not equivalent
     *
     * Logs pass/fail based on results.
     *
     * @param testname Name of this test
     * @param actual Actual integer found
     * @param notExpected Not expected integer
     * @return True if integers don't match
     */
    public boolean verifyNotEquals(String testname, int actual, int notExpected) {
        String vpName = getFormattedVPTestName(testname);
        myLog.logSeStep(String.format("%s: Verify Integers Not Equal Actual: '%d' Not Expecting: '%d'", vpName, actual, notExpected));
        try {
            Assert.assertEquals(actual, notExpected, vpName);
            logFail(testname, "Integers are Equal");
            return true;
        } catch (AssertionError e) {
            logPass(testname);
            return false;
        } catch (Exception e) {
            logFail(testname, e.getMessage());
            return false;
        }
    }

    /**
     * Needs to be called at the end of all tests. If not called, your test will not report/log correctly.
     *
     * Closes the test session results, recording end time, and logging counts of pass/fail assertions.
     *
     * Logs screenshots and test statistics into CouchDB.
     *
     * If there are no assertions or there are any failing assertions, will cause the test to be reported as failed.
     */
    public void checkForFail() {
        // Close the log
        finalizeLog();

        // Calculate pass/fail
        boolean testPassed = isTestPassed();

        // Write CouchDB record
        myLog.couchDb(verdictText());

        // Give browser a chance to close if needed
        //closeBrowserIfNeeded();

        // Save our log (for below), then clear result log
        StringBuilder testResults = getCurrentResults();


        // if we have a failure assertion, toss it now
        if (hasFailedVerifications()) {
            result.setLength(0);
            throw new AssertionError(testResults);
        } else if (!hasVerifications()) {
            testResults.append("There were no assertions");
            throw new NoAssertionsException(testResults.toString());
        }
    }


    /**
     * Returns if the current log shows the test as passing.
     * <p>
     * Passing is defined as having at least one passing verification and no failed verifications.
     * <p>
     * Having no verifications is considered not passing, so tests will be "failed" until they verify something.
     *
     * @return true if there are passing verifications and no failures, else false
     */
    public boolean isTestPassed() {
        //return !hasVerifications() || hasFailedVerifications();
        return hasVerifications() && !hasFailedVerifications();
    }

    public boolean hasFailedVerifications() {
        return totalFail > 0;
    }

    public boolean hasErrorVerifications() {
        return totalError > 0;
    }

    public boolean hasVerifications() {
        return totalPass > 0;
    }

    /**
     * Gives you a read-only copy of the current results output (failed verification info).
     *
     * @return StringBuilder copy of current results object.
     */

    public StringBuilder getCurrentResults() {
        return new StringBuilder(result);
    }

    /**
     * Adds final test statistics to the log object and dumps the output of the log to the console for debugging.
     */
    public void finalizeLog() {
        myLog.setTcEndTime();
        myLog.setTcAssertionsPass(Integer.toString(totalPass));
        myLog.setTcAssertionsFail(Integer.toString(totalFail));
        myLog.setTcAssertionsError(Integer.toString(totalError));
        myLog.logTestSummary(totalPass, totalFail, totalError);
        if (myLog.hasLog()) {
            myLog.printLogBuilder();
        }
    }


    /**
     * If running on the grid, close the browser.  If running locally, only close the browser if the test passed.
     */
    public void closeBrowserIfNeeded() {
        String seHelperName = se.toString();
        if (seHelperName.contains("Grid") || isTestPassed()) {
            myLog.logSeStep("Closing browser: " + seHelperName);
            se.browser.quit();
        } else {
            myLog.logSeStep("Leaving browser open: " + seHelperName);
        }
    }

    public void checkForFailButDontCloseBrowser() {
        myLog.setTcEndTime();
        myLog.setTcAssertionsPass(Integer.toString(totalPass));
        myLog.setTcAssertionsFail(Integer.toString(totalFail));
        if (result.length() > 0) {
            //Log.reportInfo("<b>Test Summary</b> Verifications Passed: <font color=\"green\">" + totalPass + "</font> Verifications Failed: <font color=\"red\">" + totalFail + "</font>");
            myLog.couchDb(verdictText());
            StringBuilder temp = result;
            result.setLength(0);
            if (myBrowser.getBrowserType() == Browser.Browsers.GridChrome || myBrowser.getBrowserType() == Browser.Browsers.GridFirefox || myBrowser.getBrowserType() == Browser.Browsers.GridInternetExplorer) {
                //myBrowser.quit();
            }
            throw new AssertionError(temp);
        } else {
            myLog.couchDb(verdictText());
            if (myBrowser.getBrowserType() == Browser.Browsers.GridChrome || myBrowser.getBrowserType() == Browser.Browsers.GridFirefox || myBrowser.getBrowserType() == Browser.Browsers.GridInternetExplorer) {
                //myBrowser.quit();
            }
        }
    }

    public void throwAssertionError() {
        if (myLog.hasLog()) {
            myLog.printLogBuilder();
        }
        myLog.couchDb(verdictText());
        StringBuilder temp = new StringBuilder(result);
        result.setLength(0);
        myBrowser.quit();
        throw new AssertionError(temp);
    }

    public boolean verifyEquals(String testname, boolean actual, boolean expected) {
        String vpName = getFormattedVPTestName(testname);
        myLog.logSeStep(String.format("%s: verify boolean Actual: '%s' Expected: '%s'", vpName, actual, expected));
        try {
            Assert.assertEquals(actual, expected, vpName);
            logPass(testname);
            return true;
        } catch (AssertionError e) {
            logFail(testname, e.getMessage());
            return false;
        } catch (Exception e) {
            logFail(testname, e.getMessage());
            return false;
        }
    }

    public String verdictText() {
        if (getTotalFail() > 0)
            return Log.VERDICT.Fail.name();
        else if (getTotalPass() > 0)
            return Log.VERDICT.Pass.name();
        else if ((getTotalError() > 0) || (getAssertionCount() < 1))
            return Log.VERDICT.Error.name();
        return "null";
    }

    public boolean verifyTrue(String testname, boolean actual) {
        return verifyEquals(testname, actual, true);
    }

    public boolean verifyFalse(String testname, boolean actual) {
        return verifyEquals(testname, actual, false);
    }

    public boolean verifyContains(String testname, String actual, String expected) {
        String vpName = getFormattedVPTestName(testname);
        myLog.logSeStep(String.format("%s: verify Contains Actual: '%s' Expected: '%s'", vpName, actual, expected));
        try {
            if (!actual.contains(expected))
                Assert.fail(vpName);
            logPass(testname);
            return true;
        } catch (AssertionError e) {
            if (actual == null)
                logFailNoScreenShot(testname, "Actual is null");
            else
                logFail(testname, "Expected String '" + expected + "' not found in '" + actual + "'");
            return false;
        } catch (Exception e) {
            logFail(testname, e.getMessage());
            return false;
        }
    }

    public boolean verifyContains(String testname, Collection<?> actual, Collection<?> expected) {
        String vpName = getFormattedVPTestName(testname);
        myLog.logSeStep(String.format("%s: verify contains Actual: '%s' Expected: '%s'", vpName, actual, expected));
        if (expected.isEmpty()) {
            return logFail(testname, "expected collection as empty, something went wrong");
        }

        try {
            Collection<?> remainder = CollectionUtils.subtract(expected, actual);
            assertTrue(remainder.isEmpty(), "Missing " + remainder);
            return logPass(testname);
        } catch (AssertionError e) {
            if (actual == null)
                return logFailNoScreenShot(testname, "Actual is null");
            else
                return logFail(testname, e.getMessage());
        } catch (Exception e) {
            return logFail(testname, e.getMessage());
        }
    }

    public boolean verifyContainsIgnoreCase(String testname, String actual, String expected) {
        String vpName = getFormattedVPTestName(testname);
        myLog.logSeStep(String.format("%s: verify Contains Actual: '%s' Expected: '%s'",
                vpName, actual.toLowerCase(), expected.toLowerCase()));
        try {
            if (!actual.toLowerCase().contains(expected.toLowerCase()))
                Assert.fail(vpName);
            logPass(testname);
            return true;
        } catch (AssertionError e) {
            logFail(testname, "Expected String not found");
            return false;
        } catch (Exception e) {
            logFail(testname, e.getMessage());
            return false;
        }
    }

    public boolean verifySimilar(String testname, String actual, String expected, float percentOfCharsThatCanDiffer) {
        String vpName = getFormattedVPTestName(testname);
        int numOfCharsThatCanDiffer = Math.round(((float) expected.length() * percentOfCharsThatCanDiffer));
        int distance = StringUtils.getLevenshteinDistance(actual, expected);
        distance = distance - Math.abs((actual.length() - expected.length()));
        myLog.logSeStep(String.format("%s: verify similar using Levenshtein Distance %s Actual: '%s' Expected: '%s' Levenshtein Distance: %d",
                vpName, df.format(percentOfCharsThatCanDiffer), actual, expected.toLowerCase(), distance));
        try {
            if (!(distance <= numOfCharsThatCanDiffer))
                Assert.fail(vpName);
            logPass(testname);
            return true;
        } catch (AssertionError e) {
            logFail(testname, e.getMessage());
            return false;
        } catch (Exception e) {
            logFail(testname, e.getMessage());
            return false;
        }
    }

    public boolean verifyContainsFuzzy(String testname, String actual, String expected, float percentPassRequired) {
        String vpName = getFormattedVPTestName(testname);
        myLog.logSeStep(String.format("%s: verify Contains using fuzzy logic at %s Actual: '%s' Expected: '%s'",
                vpName, df.format(percentPassRequired), actual, expected.toLowerCase()));
        try {
            String[] expecteds = expected.split("\\W");
            int numberOfPassesNeeded = Math.round(((float) expecteds.length) * percentPassRequired);
            int numberOfPasses = 0;
            boolean result = true;
            for (int i = 0; i < expecteds.length; i++) {
                String expect = expecteds[i];
                boolean currentResult = actual.toLowerCase().contains(expect.toLowerCase());
                if (currentResult)
                    numberOfPasses++;
                result |= currentResult;
            }
            if (!result || (numberOfPasses < numberOfPassesNeeded))
                Assert.fail(vpName);
            logPass(testname);
            return true;
        } catch (AssertionError e) {
            logFail(testname, e.getMessage());
            return false;
        } catch (Exception e) {
            logFail(testname, e.getMessage());
            return false;
        }
    }

    public boolean verifyNotContains(String testname, String actual, String notExpecting) {
        String vpName = getFormattedVPTestName(testname);
        myLog.logSeStep(String.format("%s: verify Not Contains Actual: '%s' Not Expecting: '%s'",
                vpName, actual, notExpecting));
        try {
            if (actual.contains(notExpecting))
                Assert.fail(vpName);
            logPass(testname);
            return true;
        } catch (AssertionError e) {
            if (actual == null)
                logFailNoScreenShot(testname, "Actual is null");
            else
                logFail(testname, "Expected String was found");
            return false;
        } catch (Exception e) {
            logFail(testname, e.getMessage());
            return false;
        }
    }

    public boolean verifyGreaterThan(String testname, int actual, int expecting) {
        String vpName = getFormattedVPTestName(testname);
        myLog.logSeStep(String.format("%s: Verify Greater Than Actual: '%d' Expecting: '>%d'",
                vpName, actual, expecting));
        try {
            Assert.assertEquals((actual > expecting), true, vpName);
            logPass(testname);
            return true;
        } catch (AssertionError e) {
            logFail(testname, "Not Greater Than");
            return false;
        } catch (Exception e) {
            logFail(testname, e.getMessage());
            return false;
        }
    }

    public boolean verifyLessThan(String testname, int actual, int expecting) {
        String vpName = getFormattedVPTestName(testname);
        myLog.logSeStep(String.format("%s: Verify Less Than Actual: '%d' Expecting: '<%d'",
                vpName, actual, expecting));
        try {
            Assert.assertEquals(actual < expecting, true, vpName);
            logPass(testname);
            return true;
        } catch (AssertionError e) {
            logFail(testname, "Not Less Than");
            return false;
        } catch (Exception e) {
            logFail(testname, e.getMessage());
            return false;
        }
    }

    public <T> boolean verifyContainsKey(String testname, Map<T, ?> map, T key) {
        String vpName = getFormattedVPTestName(testname);
        myLog.logSeStep(String.format("%s: Verify map has key Actual: '%s' Expecting key: '%s'",
                vpName, StringUtils.join(map.keySet(), ","), key));
        try {
            assertTrue(map.containsKey(key), vpName);
            logPass(testname);
            return true;
        } catch (AssertionError e) {
            logFail(testname, "Key doesn't exist");
            return false;
        } catch (Exception e) {
            logFail(testname, e.getMessage());
            return false;
        }
    }

    public void requireVerifyTrue(String verificationName, boolean expected) {
        if(!verifyTrue("Requiring verificiation to pass " + verificationName, expected))
        {
            myLog.printLogBuilder();
            myLog.couchDb(verdictText());
            myBrowser.quit();
            throwAssertionError();
        }
    }

    public void requireVerifyEquals(String verificationName, String actual, String expected) {
        if(!verifyEquals("Requiring verificiation to pass " + verificationName, actual, expected))
        {
            myLog.printLogBuilder();
            myLog.couchDb(verdictText());
            myBrowser.quit();
            throwAssertionError();
        }
    }

    public void requireVerifyContains(String verificationName, String actual, String expected) {
        if(!verifyContains("Requiring verificiation to pass " + verificationName, actual, expected))
        {
            myLog.printLogBuilder();
            myLog.couchDb(verdictText());
            myBrowser.quit();
            throwAssertionError();
        }
    }
    public void requireTrue(String expectationMessage, boolean expectation) {
        if (!expectation)
        {
            logError(expectationMessage);
            myLog.printLogBuilder();
            myLog.couchDb(verdictText());
            myBrowser.quit();
            throwAssertionError();
        }
    }
    /**
     * Verify a single tag exists in a List of tags
     * @author Cognizant Technology CoE
     * @param actualTags
     * @param expectedTag
     * @return
     */
    public boolean verifySingleNameValuePair(List<HarNameValuePair> actualTags, HarNameValuePair expectedTag){
        boolean pass = false;
        myLog.testStep("Looking for a single Name Value Pair " + expectedTag.toString() + " in " + actualTags.toString());
        for(HarNameValuePair actual : actualTags){
            if(actual.getName().equals(expectedTag.getName())){
                pass = actual.getValue().equals(expectedTag.getValue());
                try {
                    Assert.assertEquals(actual.getValue(), expectedTag.getValue(), "Tags are not equal");
                    logPass("Looking for a single Name Value Pair");
                    return pass;
                } catch (AssertionError e) {
                    myLog.trace("Could not find " + expectedTag.toString());
                    myLog.trace(e.getMessage());
                    logFail("Looking for a single Name Value Pair", e.getMessage());
                }
            }
        }
        return pass;
    }
    /**
     * Verify a single tag exists in a List of tags
     * @author Cognizant Technology CoE
     * @param actualTags
     * @param expectedTag
     * @return
     */
    public boolean verifySingleNameValuePairMatches(List<HarNameValuePair> actualTags, HarNameValuePair expectedTag){
        boolean pass = false;
        myLog.testStep("Looking for a single Name Value Pair " + expectedTag.toString() + " in " + actualTags.toString());
        for(HarNameValuePair actual : actualTags){
            if(actual.getName().equals(expectedTag.getName())){
                pass = actual.getValue().matches(expectedTag.getValue());
            }
        }
        try {
            assertTrue(pass, "Tags don't match expected: " + expectedTag.toString() + " actual: " + actualTags.toString());
            logPass("Looking for a single Name Value Pair Matches");
            return pass;
        } catch (AssertionError e) {
            myLog.trace("Could not find " + expectedTag.toString());
            myLog.trace(e.getMessage());
            logFail("Looking for a single Name Value Pair Matches", e.getMessage());
        }
        return pass;
    }
    /**
     * Verify a single tag contains in a List of tags
     * @author Cognizant Technology CoE
     * @param actualTags
     * @param expectedTag
     * @return
     */
    public boolean verifySingleNameValuePairContains(List<HarNameValuePair> actualTags, HarNameValuePair expectedTag){
        boolean pass = false;
        myLog.testStep("Looking for " + expectedTag.toString() + " in " + actualTags.toString());
        for(HarNameValuePair actual : actualTags){
            if(actual.getName().equals(expectedTag.getName())){
                if(actual.getValue().contains(expectedTag.getValue())){
                    pass=true;
                }
            }
        }
        try {
            assertTrue(pass, "Expected " + expectedTag.toString() + " Actual: " + actualTags.toString());
            logPass("Looking for a single Name Value Pair Contains");
            return pass;
        } catch (AssertionError e) {
            myLog.trace(expectedTag.toString() + " not found");
            logFail("Looking for a single Name Value Pair Contains", e.getMessage());
        }
        return pass;
    }
    /**
     * Verify a List of expected tags exist in a List of actual tags
     * @author Cognizant Technology CoE
     * @param actualTags
     * @param expectedTags
     * @return
     */
    public boolean verifyMultipleNameValuePairs(List<HarNameValuePair> actualTags, List<HarNameValuePair> expectedTags){
        boolean myResult = true;
        myLog.testStep("Looking for a list of Name Value Pairs" + expectedTags.toString());
        for(HarNameValuePair expectedTag : expectedTags) {
            myResult &= verifySingleNameValuePair(actualTags, expectedTag);
        }
        try {
            assertTrue(myResult, "Verify complete List expected: " + expectedTags.toString() + " actual: " + actualTags.toString());
            logPass("Looking for a list of Name Value Pairs");
        } catch (AssertionError e) {
            myLog.trace("Could not find " + expectedTags.toString());
            myLog.trace(e.getMessage());
            logFail("Could not find " + expectedTags.toString(), e.getMessage());
        }
        return myResult;
    }
    /**
     * Verify a List of expected tags contains in a List of actual tags
     * @author Cognizant Technology CoE
     * @param actualTags
     * @param expectedTags
     * @return
     */
    public boolean verifyMultipleNameValuePairsContains(List<HarNameValuePair> actualTags, List<HarNameValuePair> expectedTags){
        boolean myResult = true;
        myLog.testStep("Looking for a list of Name Value Pairs" + expectedTags.toString());
        for(HarNameValuePair expectedTag : expectedTags) {
            myResult &= verifySingleNameValuePairContains(actualTags, expectedTag);
        }
        try {
            assertTrue(myResult, "Verify Complete List not found expected: " + expectedTags.toString() + " actual: " + actualTags.toString());
            logPass("Looking for a list of Name Value Pairs");
        } catch (AssertionError e) {
            myLog.trace("Could not find " + expectedTags.toString());
            myLog.trace(e.getMessage());
            logFail("Could not find " + expectedTags.toString(), e.getMessage());
        }
        return myResult;
    }
    /**
     * Verify a List of expected tags are found within single request given a list of requests
     * @author Cognizant Technology CoE
     * @param harRequests
     * @param expectedTags
     * @return
     */
    public boolean verifySetOfNameValuePairExitsWithinRequests(List<HarRequest> harRequests, List<HarNameValuePair> expectedTags){
        boolean allExpectedTagsFound = false;
        myLog.testStep("Searching requests for " + expectedTags.toString() + "in " + harRequests.toString());
        //foreach request
        for(HarRequest request : harRequests) {
            int namesFound = 0;
            boolean valuesMatch = false;
            //for each expected
            List<HarNameValuePair> actualTags = request.getQueryString();
            myLog.trace("Looking for " + expectedTags.toString() + " in " + actualTags.toString());
            for(HarNameValuePair expectedTag : expectedTags) {
                //find the expected in the query strings
                for(HarNameValuePair actual : actualTags){
                    if(actual.getName().equals(expectedTag.getName())){
                        if (namesFound == 0){
                            valuesMatch = actual.getValue().equals(expectedTag.getValue());
                        }
                        valuesMatch &= actual.getValue().equals(expectedTag.getValue());
                        namesFound++;
                    }
                }
            }
            if (valuesMatch && namesFound==expectedTags.size()) {
                //pass
                allExpectedTagsFound = true;
                break;
            }
        }
        try {
            Assert.assertTrue(allExpectedTagsFound, "All tags were not found together in a single request " + expectedTags);
            logPass("All tags were found together in a single request ");
            return true;
        } catch (AssertionError e) {
            myLog.trace("Could not find " + expectedTags);
            logFail("Could not find " + expectedTags.toString(), e.getMessage());
            return false;
        }
    }
    /**
     * Verify a List of expected tags are found within single request given a list of requests
     * @author Cognizant Technology CoE
     * @param harRequests
     * @param expectedTags
     * @return
     */
    public boolean verifySetOfNameValuePairExitsWithinRequestsMatches(List<HarRequest> harRequests, List<HarNameValuePair> expectedTags){
        boolean allExpectedTagsFound = false;
        myLog.testStep("Searching requests for " + expectedTags.toString() + "in " + harRequests.toString());
        //foreach request
        for(HarRequest request : harRequests) {
            int namesFound = 0;
            boolean valuesMatch = false;
            //for each expected
            List<HarNameValuePair> actualTags = request.getQueryString();
            myLog.trace("Looking for " + expectedTags.toString() + " in " + actualTags.toString());
            for(HarNameValuePair expectedTag : expectedTags) {
                //find the expected in the query strings
                for(HarNameValuePair actual : actualTags){
                    if(actual.getName().equals(expectedTag.getName())){
                        if (namesFound == 0){
                            valuesMatch = actual.getValue().matches(expectedTag.getValue());
                        }
                        valuesMatch &= actual.getValue().matches(expectedTag.getValue());
                        namesFound++;
                    }
                }
            }
            if (valuesMatch && namesFound==expectedTags.size()) {
                //pass
                allExpectedTagsFound = true;
                break;
            }
        }
        try {
            Assert.assertTrue(allExpectedTagsFound, "All tags were not found together in a single request " + expectedTags);
            logPass("All tags were found together in a single request ");
            return true;
        } catch (AssertionError e) {
            myLog.trace("Could not find " + expectedTags);
            logFail("Could not find " + expectedTags.toString(), e.getMessage());
            return false;
        }
    }

    private String getFormattedVPTestName(String testname) {
        return String.format("VP%02d %s", assertionCount, escapeTestName(testname));
    }

    private String escapeTestName(String testname) {
        return testname.replaceAll("\n", " ");
    }

    public String attachScreenshot(String screenshotName) {
        String screenShotLink = myLog.takeScreenShot(screenshotName, true);
        return myLog.logTcAssertion(assertionCount++, screenshotName, screenShotLink, Log.VERDICT.Pass);
    }

    public void reportError(String message) {
        //result.append(message);
        logError(message);
    }

    public void clearReport() {
        result.setLength(0);
    }

    public String toString() {
        return "Assertion";
    }
}
