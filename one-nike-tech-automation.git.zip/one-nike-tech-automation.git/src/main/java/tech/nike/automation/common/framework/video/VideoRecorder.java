
package tech.nike.automation.common.framework.video;

import org.monte.media.Format;
import org.monte.media.math.Rational;
import org.monte.screenrecorder.ScreenRecorder;
import tech.nike.automation.common.framework.core.Log;

import java.awt.*;
import java.io.File;

import static org.monte.media.VideoFormatKeys.*;

/**
 * Created by PSibb1 on 12/18/2016.
 */

public class VideoRecorder {
    private Log myLog;
    public void setLog(Log log) {
        myLog = log;
    }
    private ScreenRecorder screenRecorder;

    public void startRecording() {
        try {
            File file = new File("./target/videos");

            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            int width = screenSize.width;
            int height = screenSize.height;

            Rectangle captureSize = new Rectangle(0, 0, width, height);

            GraphicsConfiguration gc = GraphicsEnvironment
                    .getLocalGraphicsEnvironment()
                    .getDefaultScreenDevice()
                    .getDefaultConfiguration();

            this.screenRecorder = new SpecializedScreenRecorder(gc, captureSize,
                    new Format(MediaTypeKey, MediaType.FILE, MimeTypeKey, MIME_AVI),
                    new Format(MediaTypeKey, MediaType.VIDEO, EncodingKey, ENCODING_AVI_TECHSMITH_SCREEN_CAPTURE,
                            CompressorNameKey, ENCODING_AVI_TECHSMITH_SCREEN_CAPTURE,
                            DepthKey, 24, FrameRateKey, Rational.valueOf(15),
                            QualityKey, 1.0f,
                            KeyFrameIntervalKey, 15 * 60),
                    new Format(MediaTypeKey, MediaType.VIDEO, EncodingKey, "black",
                            FrameRateKey, Rational.valueOf(30)),
                    null, file, "MyVideo");
            this.screenRecorder.start();
        }catch(Exception ignore){

        }
    }

    public void stopRecording(){
        try {
            this.screenRecorder.stop();
        }catch(Exception e){
            myLog.logSeStep(e.getMessage());
        }
    }

    public String getMethodName(){
        StackTraceElement[] stacktrace = Thread.currentThread().getStackTrace();
        StackTraceElement e = stacktrace[1];//coz 0th will be getStackTrace so 1st
        String methodName = e.getMethodName();
        return methodName;
    }
}

