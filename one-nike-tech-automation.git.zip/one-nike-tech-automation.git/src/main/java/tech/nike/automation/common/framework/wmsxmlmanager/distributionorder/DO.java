package tech.nike.automation.common.framework.wmsxmlmanager.distributionorder;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

/**
 * Created by psibb1 on 3/4/2017.
 */
@XmlRootElement(name = "Message")
@XmlAccessorType(XmlAccessType.FIELD)
public class DO {

    @XmlElement(name = "DistributionOrderId")
    private String distributionOrderId = null;
    @XmlElement(name = "OrderType")
    private String orderType = null;
    @XmlElement(name = "DoFulfillmentStatus")
    private String doFulfillmentStatus = null;
    @XmlElement(name = "BusinessPartnerId")
    private String businessPartnerId = null;
    @XmlElement(name = "ProductionScheduleRefNbr")
    private String productionScheduleRefNbr = null;
    @XmlElement(name = "Priority")
    private String priority = null;
    @XmlElement(name = "ReferenceField1")
    private String referenceField1 = null;
    @XmlElement(name = "ReferenceField3")
    private String referenceField3 = null;
    @XmlElement(name = "CustomerName")
    private String customerName = null;
    @XmlElement(name = "OriginFacilityAliasId")
    private String originFacilityAliasId = null;
    @XmlElement(name = "PickupStartDttm")
    private String pickupStartDttm = null;
    @XmlElement(name = "PickupEndDttm")
    private String pickupEndDttm = null;
    @XmlElement(name = "DestinationFacilityAliasId")
    private String destinationFacilityAliasId = null;
    @XmlElement(name = "LpnCubingIndicator")
    private String lpnCubingIndicator = null;
    @XmlElement(name = "PrepackCubingIndicator")
    private String prepackCubingIndicator = null;
    @XmlElement(name = "BillToFacilityAliasId")
    private String billToFacilityAliasId = null;
    @XmlElement(name = "RouteType1")
    private String routeType1 = null;
    @XmlElement(name = "MarkFor")
    private String markFor = null;
    @XmlElement(name = "ARAcctNbr")
    private String aRAcctNbr = null;
    @XmlElement(name = "ProcessInfo")
    private List<ProcessInfo> processInfo = null;
    @XmlElement(name = "Comment")
    private List<Comment> comment = null;
    @XmlElement(name = "LineItem")
    private List<LineItem> lineItem = null;

    public String getDistributionOrderId() {
        return distributionOrderId;
    }

    public void setDistributionOrderId(String distributionOrderId) {
        this.distributionOrderId = distributionOrderId;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String distributionOrderId) {
        this.orderType = orderType;
    }

    public String getDoFulfillmentStatus() {
        return doFulfillmentStatus;
    }

    public void setDoFulfillmentStatus(String doFulfillmentStatus) {
        this.doFulfillmentStatus = doFulfillmentStatus;
    }

    public String getBusinessPartnerId() {
        return businessPartnerId;
    }

    public void setBusinessPartnerId(String businessPartnerId) {
        this.businessPartnerId = businessPartnerId;
    }

    public String getProductionScheduleRefNbr() {
        return productionScheduleRefNbr;
    }

    public void setProductionScheduleRefNbr(String productionScheduleRefNbr) {
        this.productionScheduleRefNbr = productionScheduleRefNbr;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getReferenceField1() {
        return referenceField1;
    }

    public void setReferenceField1(String referenceField1) {
        this.referenceField1 = referenceField1;
    }

    public String getReferenceField3() {
        return referenceField3;
    }

    public void setReferenceField3(String referenceField3) {
        this.referenceField3 = referenceField3;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getOriginFacilityAliasId() {
        return originFacilityAliasId;
    }

    public void setOriginFacilityAliasId(String originFacilityAliasId) {
        this.originFacilityAliasId = originFacilityAliasId;
    }

    public String getPickupStartDttm() {
        return pickupStartDttm;
    }

    public void setPickupStartDttm(String pickupStartDttm) {
        this.pickupStartDttm = pickupStartDttm;
    }

    public String getPickupEndDttm() {
        return pickupEndDttm;
    }

    public void setPickupEndDttm(String pickupEndDttm) {
        this.pickupEndDttm = pickupEndDttm;
    }

    public String getDestinationFacilityAliasId() {
        return destinationFacilityAliasId;
    }

    public void setDestinationFacilityAliasId(String destinationFacilityAliasId) {
        this.destinationFacilityAliasId = originFacilityAliasId;
    }

    public String getLpnCubingIndicator() {
        return lpnCubingIndicator;
    }

    public void setLpnCubingIndicator(String lpnCubingIndicator) {
        this.lpnCubingIndicator = lpnCubingIndicator;
    }

    public String getPrepackCubingIndicator() {
        return prepackCubingIndicator;
    }

    public void setPrepackCubingIndicator(String prepackCubingIndicator) {
        this.prepackCubingIndicator = prepackCubingIndicator;
    }

    public String getBillToFacilityAliasId() {
        return billToFacilityAliasId;
    }

    public void setBillToFacilityAliasId(String billToFacilityAliasId) {
        this.billToFacilityAliasId = billToFacilityAliasId;
    }

    public String getRouteType1() {
        return routeType1;
    }

    public void setRouteType1(String routeType1) {
        this.routeType1 = routeType1;
    }

    public String getMarkFor() {
        return markFor;
    }

    public void setMarkFor(String markFor) {
        this.markFor = markFor;
    }

    public String getaRAcctNbr() {
        return aRAcctNbr;
    }

    public void setaRAcctNbr(String aRAcctNbr) {
        this.aRAcctNbr = aRAcctNbr;
    }

    public List<ProcessInfo> getProcessInfo() {
        return processInfo;
    }

    public void setProcessInfo(List<ProcessInfo> processInfo) {
        this.processInfo = processInfo;
    }

    public List<Comment> getComment() {
        return comment;
    }

    public void setComment(List<Comment> comment) {
        this.comment = comment;
    }

    public List<LineItem> getLineItem() {
        return lineItem;
    }

    public void setLineItem(List<LineItem> comment) {
        this.lineItem = lineItem;
    }
}
