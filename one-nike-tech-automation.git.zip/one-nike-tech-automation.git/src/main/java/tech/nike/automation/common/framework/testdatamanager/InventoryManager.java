package tech.nike.automation.common.framework.testdatamanager;

import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import tech.nike.automation.common.framework.configuration.DBConnect;
import tech.nike.automation.common.framework.configuration.Envclient;
import tech.nike.automation.common.framework.core.SystemUtil;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class InventoryManager {
	static String dc = SystemUtil.getBaseDC();
    public static String DC_TYPE = dc; //HTLS-AT
    static Envclient getEnv = new Envclient(Envclient.Env.valueOf(dc));
    static String[] envName = getEnv.getEnvUrl();
	static String path = envName[4];
	private static final String NAMED_PARAMETER_JSON_SRC = path; //"/META-INF/ham_inventory_manager_named_queries.json";
    private static Logger logger = LoggerFactory.getLogger(InventoryManager.class);
    private static NamedProductQueries namedProductQueries;

	static {
        ObjectMapper mapper = new ObjectMapper();
		//File src = new File(NAMED_PARAMETER_JSON_SRC);
        mapper.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        InputStream srcAsStream = InventoryManager.class.getResourceAsStream(NAMED_PARAMETER_JSON_SRC);
		try {
			//namedProductQueries = mapper.readValue(src, QCNamedDataQueries.class);
			namedProductQueries = mapper.readValue(srcAsStream, NamedProductQueries.class);
		} catch (Exception e) {
			logger.error("Could not load file " + NAMED_PARAMETER_JSON_SRC, e);
		}
	}

    /**
     * method to add sql output and use it as object model
     * @param queryName
     * @return
     */
    public static List<ProductSummary> getItemNameByNamedQuery(String queryName) {
        List<ProductSummary> retval = null;
        List<ProductSummary> productSummaryList = new ArrayList<ProductSummary>();
        NamedProductQuery namedProductQuery = namedProductQueries.getNamedProductQueryByName(queryName);

        for(Query query : namedProductQuery.getQueries()) {
            Connection conn = null;
            PreparedStatement ps =  null;
            ResultSet rs = null;
            try {
                String queryStr = query.getQuery();
                /*if(params!=null) {
                    for(String key: params.keySet()) {
                        if(queryStr.contains(":"+key)) {
                            queryStr = queryStr.replace(":" + key, params.get(key));
                        }
                    }
                }*/
                conn = getDatabaseConnection();
                ps = conn.prepareStatement(queryStr);
                rs = ps.executeQuery();
                if(productSummaryList.isEmpty()) {
                    while(rs.next()) {
                        ProductSummary productSummary = new ProductSummary();
                        productSummary.setItemId(rs.getString("ITEM_NAME"));
                        //productSummary.setItemId(rs.getString("ITEM_BAR_CODE"));
                        productSummaryList.add(productSummary);
                    }
                }
                if(productSummaryList.size()==0) {
                    break;
                }
            } catch (Exception e) {
                logger.error("Could not execute query " + query.getQuery(), e);
            } finally {
                if(rs!=null) { try {rs.close();} catch (Exception e) {} }
                if(ps!=null) { try {ps.close();} catch (Exception e) {} }
                if(conn!=null) { try {conn.close();} catch (Exception e) {} }
            }
        }
        if(productSummaryList.size()>0) {
            retval = productSummaryList;
        }
        return retval;
    }

    /**
     * method to add sql output and use it as object model
     *
     * @param queryid
     * @return
     */
    public static List<ProductSummary> getTaskIDAndWaveNumberByQueryID(int index, String queryid) {
        List<ProductSummary> retval = null;
        List<ProductSummary> productSummaryList = new ArrayList<ProductSummary>();
        NamedProductQuery namedProductQuery = namedProductQueries.getNamedProductQueryById(queryid);

        for (Query query : namedProductQuery.getQueries()) {
            Connection conn = null;
            PreparedStatement ps = null;
            ResultSet rs = null;
            try {
                String queryStr = query.getQuery();
                /*if(params!=null) {
                    for(String key: params.keySet()) {
                        if(queryStr.contains(":"+key)) {
                            queryStr = queryStr.replace(":" + key, params.get(key));
                        }
                    }
                }*/
                conn = getDatabaseConnection();
                ps = conn.prepareStatement(queryStr);
                rs = ps.executeQuery();
                if (productSummaryList.isEmpty()) {
                    while (rs.next()) {
                        ProductSummary productSummary = new ProductSummary();
                        productSummary.settaskID(rs.getString("TASK_ID"));
                        productSummary.setWaveNumber(rs.getString("TASK_GENRTN_REF_NBR"));
                        productSummaryList.add(productSummary);
                    }
                }
                if (productSummaryList.size() == 0) {
                    break;
                }
            } catch (Exception e) {
                logger.error("Could not execute query " + query.getQuery(), e);
            } finally {
                if (rs != null) {
                    try {
                        rs.close();
                    } catch (Exception e) {
                    }
                }
                if (ps != null) {
                    try {
                        ps.close();
                    } catch (Exception e) {
                    }
                }
                if (conn != null) {
                    try {
                        conn.close();
                    } catch (Exception e) {
                    }
                }
            }
        }
        if (productSummaryList.size() > 0) {
            retval = productSummaryList;
        }
        return retval;
    }


    /**
     * method to add sql output and use it as object model
     *
     * @param queryid
     * @return
     */
    public static List<ProductSummary> getWaveNumberByQueryID(int index, String queryid) {
        List<ProductSummary> retval = null;
        List<ProductSummary> productSummaryList = new ArrayList<ProductSummary>();
        NamedProductQuery namedProductQuery = namedProductQueries.getNamedProductQueryById(queryid);

        for (Query query : namedProductQuery.getQueries()) {
            Connection conn = null;
            PreparedStatement ps = null;
            ResultSet rs = null;
            try {
                String queryStr = query.getQuery();
                /*if(params!=null) {
                    for(String key: params.keySet()) {
                        if(queryStr.contains(":"+key)) {
                            queryStr = queryStr.replace(":" + key, params.get(key));
                        }
                    }
                }*/
                conn = getDatabaseConnection();
                ps = conn.prepareStatement(queryStr);
                rs = ps.executeQuery();
                if (productSummaryList.isEmpty()) {
                    while (rs.next()) {
                        ProductSummary productSummary = new ProductSummary();
                        //productSummary.settaskID(rs.getString("TASK_ID"));
                        productSummary.setWaveNumber(rs.getString("TASK_GENRTN_REF_NBR"));
                        productSummaryList.add(productSummary);
                    }
                }
                if (productSummaryList.size() == 0) {
                    break;
                }
            } catch (Exception e) {
                logger.error("Could not execute query " + query.getQuery(), e);
            } finally {
                if (rs != null) {
                    try {
                        rs.close();
                    } catch (Exception e) {
                    }
                }
                if (ps != null) {
                    try {
                        ps.close();
                    } catch (Exception e) {
                    }
                }
                if (conn != null) {
                    try {
                        conn.close();
                    } catch (Exception e) {
                    }
                }
            }
        }
        if (productSummaryList.size() > 0) {
            retval = productSummaryList;
        }
        return retval;
    }


    /**
     * method to add sql output and use it as object model
     *
     * @param queryid
     * @return
     */
    public static List<ProductSummary> getDONumberByQueryID(int index, String queryid) {
        List<ProductSummary> retval = null;
        List<ProductSummary> productSummaryList = new ArrayList<ProductSummary>();
        NamedProductQuery namedProductQuery = namedProductQueries.getNamedProductQueryById(queryid);

        for (Query query : namedProductQuery.getQueries()) {
            Connection conn = null;
            PreparedStatement ps = null;
            ResultSet rs = null;
            try {
                String queryStr = query.getQuery();
                /*if(params!=null) {
                    for(String key: params.keySet()) {
                        if(queryStr.contains(":"+key)) {
                            queryStr = queryStr.replace(":" + key, params.get(key));
                        }
                    }
                }*/
                conn = getDatabaseConnection();
                ps = conn.prepareStatement(queryStr);
                rs = ps.executeQuery();
                if (productSummaryList.isEmpty()) {
                    while (rs.next()) {
                        ProductSummary productSummary = new ProductSummary();
                        //productSummary.settaskID(rs.getString("TASK_ID"));
                        productSummary.setDoNumber(rs.getString("TC_ORDER_ID"));
                        productSummaryList.add(productSummary);
                    }
                }
                if (productSummaryList.size() == 0) {
                    break;
                }
            } catch (Exception e) {
                logger.error("Could not execute query " + query.getQuery(), e);
            } finally {
                if (rs != null) {
                    try {
                        rs.close();
                    } catch (Exception e) {
                    }
                }
                if (ps != null) {
                    try {
                        ps.close();
                    } catch (Exception e) {
                    }
                }
                if (conn != null) {
                    try {
                        conn.close();
                    } catch (Exception e) {
                    }
                }
            }
        }
        if (productSummaryList.size() > 0) {
            retval = productSummaryList;
        }
        return retval;
    }

    /**
     * method to add sql output and use it as object model
     * @param queryName
     * @return
     */
    public static List<ProductSummary> getCustomerByQueryID(String queryName) {
        List<ProductSummary> retval = null;
        List<ProductSummary> productSummaryList = new ArrayList<ProductSummary>();
        NamedProductQuery namedProductQuery = namedProductQueries.getNamedProductQueryById("1");

        for(Query query : namedProductQuery.getQueries()) {
            Connection conn = null;
            PreparedStatement ps =  null;
            ResultSet rs = null;
            try {
                String queryStr = query.getQuery();
                /*if(params!=null) {
                    for(String key: params.keySet()) {
                        if(queryStr.contains(":"+key)) {
                            queryStr = queryStr.replace(":" + key, params.get(key));
                        }
                    }
                }*/
                conn = getDatabaseConnection();
                ps = conn.prepareStatement(queryStr);
                rs = ps.executeQuery();
                if(productSummaryList.isEmpty()) {
                    while(rs.next()) {
                        ProductSummary productSummary = new ProductSummary();
                        productSummary.setoriginFacilityAliasID(rs.getString("Business_Partner_id"));
                        //productSummary.setItemId(rs.getString("ITEM_BAR_CODE"));
                        productSummaryList.add(productSummary);
                    }
                }
                if(productSummaryList.size()==0) {
                    break;
                }
            } catch (Exception e) {
                logger.error("Could not execute query " + query.getQuery(), e);
            } finally {
                if(rs!=null) { try {rs.close();} catch (Exception e) {} }
                if(ps!=null) { try {ps.close();} catch (Exception e) {} }
                if(conn!=null) { try {conn.close();} catch (Exception e) {} }
            }
        }
        if (productSummaryList.size() > 0) {
            retval = productSummaryList;
        }
        return retval;
    }

    /**
     * method to return item detail for Reserve Location
     * @param queryName
     * @return
     */
    public static List<ProductSummary> getItemNameByReserveLoc(String queryName) {
        List<ProductSummary> retval = null;
        List<ProductSummary> productSummaryList = new ArrayList<ProductSummary>();
        NamedProductQuery namedProductQuery = namedProductQueries.getNamedProductQueryById(queryName);

        for(Query query : namedProductQuery.getQueries()) {
            Connection conn = null;
            PreparedStatement ps =  null;
            ResultSet rs = null;
            try {
                String queryStr = query.getQuery();
                /*if(params!=null) {
                    for(String key: params.keySet()) {
                        if(queryStr.contains(":"+key)) {
                            queryStr = queryStr.replace(":" + key, params.get(key));
                        }
                    }
                }*/
                conn = getDatabaseConnection();
                ps = conn.prepareStatement(queryStr);
                rs = ps.executeQuery();
                if (productSummaryList.isEmpty()) {
                    //if (rs.isBeforeFirst()) {
                    while (rs.next()) {
                        ProductSummary productSummary = new ProductSummary();
                        productSummary.setItemId(rs.getString("ITEM_NAME"));
                        productSummary.setItemQty(rs.getString("QTY"));
                        productSummary.setlocBarCode(rs.getString("LOCN_BRCD"));
                        productSummary.setcntryoforgn(rs.getString("CNTRY_OF_ORGN"));
                        productSummaryList.add(productSummary);
                    }
                }
                //}
                if (productSummaryList.size() == 0) {
                    break;
                }
            } catch (Exception e) {
                logger.error("Could not execute query " + query.getQuery(), e);
            } finally {
                if(rs!=null) { try {rs.close();} catch (Exception e) {} }
                if(ps!=null) { try {ps.close();} catch (Exception e) {} }
                if(conn!=null) { try {conn.close();} catch (Exception e) {} }
            }
        }
        if (productSummaryList.size() > 0) {
            retval = productSummaryList;
        }

        return retval;
    }

    private static Connection getDatabaseConnection() {
        return DBConnect.getDatabaseConnection();
    }
}