package tech.nike.automation.common.framework.qcrestapi;

import org.apache.commons.lang.NullArgumentException;
import tech.nike.automation.common.framework.configuration.QCDBConnect;
import tech.nike.automation.common.framework.core.Data;
import tech.nike.automation.common.framework.core.SystemUtil;
import tech.nike.automation.common.framework.core.Util;
import tech.nike.automation.common.framework.qcrestapi.qcdatamanager.DataSummary;
import tech.nike.automation.common.framework.qcrestapi.qcdatamanager.QCInventoryManager;
import tech.nike.automation.common.framework.tools.OSTools;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Map.Entry;


/**
 * ALM web service interaction.
 * Allows to open a connection to ALM REST web service through user authentication and
 * starting a session to use for further requests.
 *
 * @author Bjorn Weitzel (bjoern.weitzel@hp.com)
 * @version 21th November 2011
 * @company Hewlett-Packard Company
 */
public class ALMConnection extends AbstractALM {

    // Temporary error handler. For framework usage remove it and extends AbstractALM
    //public void errorHandler(Throwable t) {
    //	System.out.println("ERROR:"+t.getCause()+" - "+t.getMessage());
    //}

    /**
     * User to use for authentication
     */
    private String almUser = SystemUtil.getQCUser();
    /**
     * Password for almUser
     */
    private String almPassword = SystemUtil.getQCPassword();
    /**
     * Domain to be used
     */
    private String almDomain = SystemUtil.getQCDomain();
    /**
     * Project of almDomain to be used
     */
    private String almProject = SystemUtil.getQCProject();
    /**
     * URL of the ALM server
     */
    private String serverURL = SystemUtil.getQCUrl();
    /**
     * Port of the application server ALM is running on
     */
    private int serverPort = 8080;

    /**
     * User is authenticated
     */
    private boolean isAuthenticated = false;
    /**
     * User is connected
     */
    private boolean isConnected = false;

    /**
     * LWSSO cookie
     */
    private String cookieLWSSO_COOKIE_KEY = null;
    /**
     * QC session cookie
     */
    private String cookieQCSession = null;

    /**
     * XSRF-TOKEN  cookie
     */
    private String cookieX_XSRF_TOKEN = null;

    /**
     * ALM USER  cookie
     */
    private String cookieALMUSER = null;

    /**
     * JSESSIONID  cookie
     */
    private String cookieJSESSIONID = null;

    /**
     * Creates a connection to be used for interaction with ALM REST web service.
     */
    public ALMConnection() {
        super();
    }

    /**
     * Creates a connection to be used for interaction with ALM REST web service.
     *
     * @param almUser     ALM user to log on with
     * @param almPassword Password for almUser
     * @param almDomain   ALM domain to be used
     * @param almProject  ALM project to be used
     * @param serverURL   URL of the server ALM is running on
     * @param serverPort  Port of the application server ALM is running on
     */
    public ALMConnection(String almUser, String almPassword, String almDomain,
                         String almProject, String serverURL, int serverPort) {
        super();
        this.almUser = almUser;
        //decrypt the user provided encrypted password
        Data.EncryptedString es = new Data.EncryptedString(almPassword);
        String almPwd = es.getString();
        this.almPassword = almPwd;
        this.almDomain = almDomain;
        this.almProject = almProject;
        this.serverURL = serverURL;
        this.serverPort = serverPort;
    }


    /**
     * @return ALM user to be logged on with.
     */
    public String getAlmUser() {
        return this.almUser;
    }

    /**
     * @param almUser ALM user to be logged on with.
     */
    public void setAlmUser(String almUser) {
        if (this.isConnected)
            throw new IllegalStateException("Not possible to change an established connection.");
        this.almUser = almUser;
    }

    /**
     * @return ALM password for almUser to be used.
     */
    public String getAlmPassword() {
        return this.almPassword;
    }

    /**
     * @param almPassword Password for almUser to be used for login.
     */
    public void setAlmPassword(String almPassword) {
        if (this.isConnected)
            throw new IllegalStateException("Not possible to change an established connection.");
        //decrypt the user provided encrypted password
        Data.EncryptedString es = new Data.EncryptedString(almPassword);
        String almPwd = es.getString();
        this.almPassword = almPwd;
    }

    /**
     * @return ALM domain to be used.
     */
    public String getAlmDomain() {
        return this.almDomain;
    }

    /**
     * @param almDomain ALM domain to be used.
     */
    public void setAlmDomain(String almDomain) {
        if (this.isConnected)
            throw new IllegalStateException("Not possible to change an established connection.");
        this.almDomain = almDomain;
    }


    /**
     * @return ALM project to be used
     */
    public String getAlmProject() {
        return this.almProject;
    }

    /**
     * @param almProject Specifies the project to log on to
     */
    public void setAlmProject(String almProject) {
        if (this.isConnected)
            throw new IllegalStateException("Not possible to change an established connection.");
        this.almProject = almProject;
    }

    /**
     * @return URL of the server ALM is running on
     */
    public String getServerURL() {
        return this.serverURL;
    }

    /**
     * @param serverURL URL of the server ALM is running on
     */
    public void setServerURL(String serverURL) {
        if (this.isConnected)
            throw new IllegalStateException("Not possible to change an established connection.");
        this.serverURL = serverURL;
    }

    /**
     * @return Port of the application server ALM on the server
     */
    public int getServerPort() {
        return serverPort;
    }

    /**
     * @param serverPort Port of the application server ALM on the server
     */
    public void setServerPort(int serverPort) {
        if (this.isConnected)
            throw new IllegalStateException("Not possible to change an established connection.");
        this.serverPort = serverPort;
    }

    /**
     * @return True if authenticated against ALM
     */
    public boolean isAuthenticated() {
        return this.isAuthenticated;
    }

    /**
     * @return True if connection established
     */
    public boolean isConnected() {
        return this.isConnected;
    }

    /**
     * @return Assembled server URL based on serverUrl, serverPort and /qcbin/
     */
    public String buildBasicURL() {
        return this.serverURL + ":" + this.serverPort + "/qcbin/";
    }

    /**
     * @return Assembled server URL based on serverUrl, serverPort and /qcbin/ and domain+project
     */
    public String buildFullURL() {
        StringBuilder sb = new StringBuilder();
        sb.append(buildBasicURL());
        if (this.isConnected) {
            sb.append("rest/domains/" + this.almDomain + "/projects/" + this.almProject + "/");
        }
        return sb.toString();
    }


    /**
     * Authenticate against ALM web service
     *
     * @return True if authentication was successful
     */
    public boolean Authenticate() {
        if(isAuthenticated())
        // Check for already established connection
        if (this.isConnected)
           throw new IllegalStateException("Connection already established.");
        if (this.serverURL == null || this.serverPort == 0)
            throw new IllegalStateException("No server information set.");
        if (this.almUser == null || this.almPassword == null)
            throw new IllegalStateException("No user information set.");
        if (this.almDomain == null || this.almProject == null)
            throw new IllegalStateException("No ALM project information set.");

        String authPoint = buildFullURL() + "authentication-point/authenticate";
        HttpURLConnection con = null;
        // Prepare authentication request
        try {
            con = prepareHttpConnection(authPoint, "GET");
            byte[] authenticationBytes = (this.almUser + ":" + this.almPassword).getBytes("UTF-8");
            String encodedAuthentication = "Basic " + Base64Converter.encode(authenticationBytes);
            con.setRequestProperty("Authorization", encodedAuthentication);
            //con.addRequestProperty("Content-Type", "application/xml");
            //con.addRequestProperty("Accept", "application/xml");
        } catch (Exception e) {
            errorHandler(e);
        }
        Response res = getHTTPResponse(con);
        try {
            this.isAuthenticated = (res.getStatusCode() == HttpURLConnection.HTTP_OK);
            if (!this.isAuthenticated)
                return this.isAuthenticated;
            // Get LWSSO Cookie
            Iterable<String> newCookies = res.getResponseHeaders().get("Set-Cookie");
            if (newCookies != null) {
                for (String cookie : newCookies) {
                    //Light Weight Single Sign On (LWSSO)
                    if (cookie.startsWith("LWSSO")) {
                        this.cookieLWSSO_COOKIE_KEY = cookie;
                        break;
                    }
                }
            }
            con.disconnect();
        } catch (Exception e) {
            errorHandler(e);
        }

        return this.isAuthenticated;
    }

    /**
     * Establishes a web service session with ALM.
     *
     * @return Session started successfully
     */
    public boolean StartSession() {
        if (this.isConnected)
            throw new IllegalStateException("Connection already established.");
        if (!this.isAuthenticated)
            throw new IllegalStateException("Authenticate first");

        String sessionPoint = buildFullURL() + "rest/site-session";
        HttpURLConnection con = null;
        // Session assembling
        try {
            con = prepareHttpConnection(sessionPoint, "POST");
            con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded"); //application/x-www-form-urlencoded
            con.setRequestProperty("Content-Length", "0");
            //con.setRequestProperty("KeepAlive", "true");
            //con.setRequestProperty("AllowAutoRedirect", "true");
        } catch (Exception e) {
            errorHandler(e);
        }
        // Send authentication data and receive cookie
        Response res = getHTTPResponse(con);
        try {
            this.isConnected = (res.getStatusCode() == HttpURLConnection.HTTP_CREATED); //changed the HTTP_OK to CREATED
            if (!this.isConnected)
                return this.isConnected;

            // Get Session cookie
            Iterable<String> newCookies = res.getResponseHeaders().get("Set-Cookie");
            if (newCookies != null) {
                for (String cookie : newCookies) {
                    if (cookie.startsWith("QCSession")) {
                        this.cookieQCSession = cookie;
                        //https://softwaresupport.hpe.com/group/softwaresupport/search-result/-/facetsearch/document/KM01754222
                        //Cross-Site Request Forgery (XSRF)
                    }else if(cookie.startsWith("XSRF-TOKEN")) {
                        this.cookieX_XSRF_TOKEN = cookie;
                    }else if(cookie.startsWith("ALM_USER")){
                        this.cookieALMUSER = cookie;
                    }else if(cookie.startsWith("JSESSIONID")) {
                        this.cookieJSESSIONID = cookie;
                    }
                }
            }
            con.disconnect();
        } catch (Exception e) {
            errorHandler(e);
        }
        return this.isConnected;
    }

    /**
     * Ends the session with the web service.
     *
     * @return Closes the session on server side and restores connection object to initial status.
     * @throws Exception Connection or server error during logout request
     */
    public boolean Logout() throws Exception {
        String logoutPoint = buildBasicURL() + "/authentication-point/logout";
        HttpURLConnection con = null;
        Response res = null;
        try {
            con = prepareHttpConnection(logoutPoint, "GET");
            con.connect();
            res = retrieveHtmlResponse(con);
            // Zur�cksetzen der Verbindung
            this.almUser = null;
            this.almPassword = null;
            this.almDomain = null;
            this.almProject = null;
            this.serverURL = null;
            this.serverPort = 0;
            this.cookieLWSSO_COOKIE_KEY = null;
            this.cookieQCSession = null;
            this.cookieX_XSRF_TOKEN = null;
            this.cookieALMUSER = null;
            this.cookieJSESSIONID = null;
            this.isAuthenticated = false;
            this.isConnected = false;
        } catch (Exception e) {
            errorHandler(e);
            return false;
        }
        return (res.getStatusCode() == HttpURLConnection.HTTP_OK);
    }


    /**
     * @param entityType
     * @return
     */
    public String buildEntityCollectionUrl(String entityType) {
        return buildUrl("qcbin/rest/domains/" + almDomain + "/projects/" + almProject + "/" + entityType + "s");
    }

    /**
     * @param path on the server to use
     * @return a url on the server for the path parameter
     */
    public String buildUrl(String path) {
        return String.format("http://%1$s:%2$s/%3$s", serverURL.replace("http://", ""), serverPort, path);
    }

    /**
     * Getting a HTTP Response from a HTTPURLConnecion.
     *
     * @param con Connection to get the response from
     * @return Response of the connection attemt
     */
    private Response getHTTPResponse(HttpURLConnection con) {
        Response res = null;
        try {
            con.connect();
            res = retrieveHtmlResponse(con);
        } catch (Exception e) {
            errorHandler(e);
            res = new Response();
            res.setFailure(e);
        }
        return res;
    }

    /**
     * Reading and evaluation HTTP response
     *
     * @param con Already established HTTP URL connection awaiting a response
     * @return A response from the server to the previously submitted HTTP request
     * @throws Exception
     */
    private Response retrieveHtmlResponse(HttpURLConnection con) throws Exception {
        Response res = new Response();
        res.setStatusCode(con.getResponseCode());
        res.setResponseHeaders(con.getHeaderFields());
        InputStream inputStream;
        // Select the source of the input bytes, first try "regular" input.
        try {
            inputStream = con.getInputStream();
        } catch (Exception e) {
            inputStream = con.getErrorStream();
            res.setFailure(e);
        }
        // This takes the data from the stream and stores it in a byte[] inside the response.
        ByteArrayOutputStream container = new ByteArrayOutputStream();
        byte[] buf = new byte[1024];
        int read;
        while ((read = inputStream.read(buf, 0, 1024)) > 0) {
            container.write(buf, 0, read);
        }
        res.setResponseData(container.toByteArray());
        return res;
    }


    /**
     * @param url    Address of the connections destination
     * @param method HTTP method (GET, POST, etc.)
     * @return A prepared HTTPURLConnection
     */
    private HttpURLConnection prepareHttpConnection(String url, String method) {
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) new URL(url).openConnection();
            if (method.equalsIgnoreCase("post") | method.toLowerCase().equalsIgnoreCase("put")) {
                con.setRequestProperty("Content-Type", "application/xml");
                con.setRequestProperty("Accept", "application/xml");
                //con.setRequestProperty("KeepAlive", "true");
                //con.setRequestProperty("AllowAutoRedirect", "true");
            }
        } catch (Exception e) {
            errorHandler(e);
        }
        return prepareHttpConnection(con, method);
    }

    /**
     * @param url    Address of the connections destination
     * @param method HTTP method (GET, POST, etc.)
     * @return A prepared HTTPURLConnection
     */
    private HttpURLConnection prepareHttpConnectionAtt(String url, String method, String boundary) {
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) new URL(url).openConnection();
            if (method.equalsIgnoreCase("post") | method.toLowerCase().equalsIgnoreCase("put")) {
                con.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary); //exampleboundary
                con.setRequestProperty("Accept", "application/xml");
                //con.setRequestProperty("KeepAlive", "true");
                //con.setRequestProperty("AllowAutoRedirect", "true");
            }
        } catch (Exception e) {
            errorHandler(e);
        }
        return prepareHttpConnection(con, method);
    }

    /**
     * @param url    Address of the connections destination
     * @param method HTTP method (GET, POST, etc.)
     * @return A prepared HTTPURLConnection
     */
    private HttpURLConnection prepareHttpConnectionForAtt(String url, String method) {
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) new URL(url).openConnection();
            if (method.equalsIgnoreCase("post") | method.toLowerCase().equalsIgnoreCase("put")) {
                con.addRequestProperty("Content-Type", "application/octet-stream");
                con.addRequestProperty("Accept", "application/xml");
                //con.addRequestProperty("KeepAlive", "true");
                //con.addRequestProperty("AllowAutoRedirect", "true");
            }
        } catch (Exception e) {
            errorHandler(e);
        }
        return prepareHttpConnection(con, method);
    }


    /**
     * @param con    A connection to be prepared with request method and required cookies
     * @param method HTTP method (GET, POST, etc.)
     * @return A prepared HTTPURLConnection
     */
    private HttpURLConnection prepareHttpConnection(HttpURLConnection con, String method) {
        if (con == null)
            throw new NullArgumentException("No connection object.");
        // Set method and cookies if required
        try {
            con.setRequestMethod(method);
            if (this.isAuthenticated) {
                con.addRequestProperty("Cookie", this.cookieLWSSO_COOKIE_KEY);
            }
            if (this.isConnected) {
                con.addRequestProperty("Cookie", this.cookieQCSession);
                con.addRequestProperty("Cookie", this.cookieALMUSER);
                con.addRequestProperty("Cookie", this.cookieJSESSIONID);
                con.addRequestProperty("Cookie", this.cookieX_XSRF_TOKEN);
            }
        } catch (Exception e) {
            errorHandler(e);
        }
        return con;
    }


    /**
     * @param fieldMap Map consisting of values to be sent to the web service (key, value)
     * @return Entity object based on the given input values
     */
    private Entity BuildTestRunResultEntity(Map<String, String> fieldMap) {
        Entity entity = new Entity();
        Entity.Fields fields = new Entity.Fields();
        Entity.Fields.Field field ;
        Iterator<Entry<String, String>> headersIterator = fieldMap.entrySet().iterator();
        while (headersIterator.hasNext()) {
            Entry<String, String> header = headersIterator.next();
            field = new Entity.Fields.Field();
            field.setName(header.getKey());
            field.addValue(header.getValue());
            fields.addField(field);
        }
        entity.setFields(fields);
        entity.setType("run");
        return entity;
    }

    /**
     * @param fieldMap Map consisting of values to be sent to the web service (key, value)
     * @return Entity object based on the given input values
     */
    private Entity BuildTestTestInstanceResultEntity(Map<String, String> fieldMap) {
        Entity entity = new Entity();
        Entity.Fields fields = new Entity.Fields();
        Entity.Fields.Field field;
        Iterator<Entry<String, String>> headersIterator = fieldMap.entrySet().iterator();
        while (headersIterator.hasNext()) {
            Entry<String, String> header = headersIterator.next();
            field = new Entity.Fields.Field();
            field.setName(header.getKey());
            field.addValue(header.getValue());
            fields.addField(field);
        }
        entity.setFields(fields);
        entity.setType("test-instance");
        return entity;
    }

    /**
     * @return Current system date time
     */
    private String GetCurrentDateTime() {
        DateFormat dateFormat = new SimpleDateFormat("YYYY.MM.DD HH:mm:ss");
        Date date = new Date();
        return dateFormat.format(date);
    }

    /**
     * @return Current system date
     */
    private String GetCurrentDate() {
        DateFormat dateFormat = new SimpleDateFormat("YYYY-MM-DD HH:MM:SS");
        dateFormat.setTimeZone(TimeZone.getDefault());
        Date date = new Date();
        //return dateFormat.format(date);
        String exec_date = dateFormat.format(date).toString().substring(0, 10).trim();
        return exec_date;
    }

    /**
     * @return Current system time
     */
    private String GetCurrentTime() {
        DateFormat dateFormat = new SimpleDateFormat("DD-MMM-YY HH:MM:SS");
        dateFormat.setTimeZone(TimeZone.getDefault());
        Date date = new Date();
        //String exec_time = dateFormat.format(date).toString().substring(11, dateFormat.format(date).toString().length()).trim();
        String[] exec_time = dateFormat.format(date).toString().split(" ");
        return exec_time[1];
    }

    /**
     * @param test_id        ID of the design test from which the instance is derived
     * @param cycle_id       ID of the TestSet containing the instance
     * @param test_instance  Instance of the test from the execution grid
     * @param testcycl_id    Cycle id of the test instance
     * @param owner          User who initiated the test
     * @param status         Status (default: N/A, Blocked, Failed, No Run, Not Completed, Passed)
     * @param test_config_id ID of the configuration that was run
     * @return True if adding results has been successful
     */
    public boolean AddVAPITestRun(String test_id, String cycle_id, String test_instance,
                                  String testcycl_id, String owner, String status, String test_config_id) {
        boolean success = false;
        String resultPoint = buildFullURL() + "runs";
        HttpURLConnection con = null;
        byte[] data = null;

        // Add fields required to create a new result set for the test run
        Map<String, String> fieldMap = new HashMap<String, String>();
        fieldMap.put("test-id", test_id);  // ID of the design test from which the instance is derived
        fieldMap.put("cycle-id", cycle_id);  // ID of the TestSet containing the instance
        fieldMap.put("test-instance", test_instance); // Instance of the test from the execution grid
        fieldMap.put("testcycl-id", testcycl_id);  // Cycle id of the test instance

        fieldMap.put("name", "Run: " + GetCurrentDateTime()); // Name of the run
        fieldMap.put("owner", owner);  // User who performed the test
        fieldMap.put("subtype-id", "hp.qc.run.VAPI-XP-TEST");  // Subtype of the instance
        fieldMap.put("status", status);  // Status (default: N/A, Blocked, Failed, No Run, Not Completed, Passed)
        fieldMap.put("test-config-id", test_config_id);  // ID of the configuration that was run

        // Create entity based on the given information
        Entity entity = null;
        String entityXML = null;
        try {
            entity = BuildTestRunResultEntity(fieldMap);
            entityXML = EntityMarshallingUtils.unmarshal(Entity.class, entity).trim();
        } catch (Exception e) {
            errorHandler(e);
        }

        // Send the data to the REST web service
        try {
            con = prepareHttpConnection(resultPoint, "POST");
            con.setDoOutput(true);

            data = entityXML.getBytes();
            OutputStream out = con.getOutputStream();
            out.write(data);
            out.flush();
            out.close();
        } catch (Exception e) {
            errorHandler(e);
        }

        // Check response if submission was successful
        try {
            Response res = getHTTPResponse(con);
            success = res.getStatusCode() == HttpURLConnection.HTTP_CREATED;
            if (!success)
                throw new Exception(res.toString());
        } catch (Exception e) {
            errorHandler(e);
        }
        return success;
    }


    /**
     * method to update the test instance test case status to QC
     *
     * @param status              Status (default: N/A, Blocked, Failed, No Run, Not Completed, Passed
     * @param strParentFolderName parent test set folder name
     * @param strTestCaseName     name of the test case
     * @return True if adding results has been successful
     */
    public boolean updateQCTestStatus(String status, String strParentFolderName,
                                      String strTestSetName, String strTestCaseName) {
        boolean success = false;
        HttpURLConnection con = null ;
        byte[] data = null;
        Map<String, String> params = new HashMap<>();
        String queryname = params.put("queryid", "1");
        String testsetPath = params.put("testsetpath", strParentFolderName);
        String testsetname = params.put("testsetname", strTestSetName);
        String testcasename = params.put("testcasename", strTestCaseName);
        String[] arrElements = getALMLabInfo(params);
        //String[] arrElements = getALMInfo(strParentFolderName, TestSetName, strTestCaseName);
        String test_instance = arrElements[5];
        String owner = OSTools.getUsername().toUpperCase();
        String resultPoint = buildFullURL() + "test-instances/" + test_instance;

        // Add fields required to create a new result set for the test run
        Map<String, String> fieldMap = new HashMap<String, String>();
        fieldMap.put("exec-date", GetCurrentDate()); //test execution date
        fieldMap.put("exec-time", GetCurrentTime()); //test execution time
        fieldMap.put("status", status);  // Status (default: N/A, Blocked, Failed, No Run, Not Completed, Passed)
        fieldMap.put("owner", owner);  // User who performed the test

        // Create entity based on the given information
        Entity entity = null;
        String entityXML = null;
        try {
            entity = BuildTestTestInstanceResultEntity(fieldMap);
            entityXML = EntityMarshallingUtils.unmarshal(Entity.class, entity).trim();
        } catch (Exception e) {
            errorHandler(e);
        }
        // Send the data to the REST web service
        try {
            con = prepareHttpConnection(resultPoint, "PUT");
            con.setDoOutput(true);
            con.setDoInput(true);
            con.setUseCaches(false);
            con.setDefaultUseCaches(false);
            data = entityXML.getBytes();
            OutputStream out = con.getOutputStream();
            out.write(data);
            out.flush();
            out.close();
        } catch (Exception e) {
            errorHandler(e);
        }
        // Check response if submission was successful
        try {
            if(con == null){
                throw new NullArgumentException("No connection object.");
            }
            Response res = getHTTPResponse(con);
            success = res.getStatusCode() == HttpURLConnection.HTTP_OK;
            if (!success)
                throw new Exception(res.toString());
        } catch (Exception e) {
            errorHandler(e);
        }
        return success;
    }

    /**
     * method to update the run factory test case status to QC
     *
     * @param status              Status (default: N/A, Blocked, Failed, No Run, Not Completed, Passed)
     * @param duration            test execution duration
     * @param strParentFolderName parent test set folder name
     * @param strTestCaseName     name of the test case
     * @return True if adding results has been successful
     */
    public boolean updateQCRunTestStatus(String status, int duration, String strParentFolderName,
                                         String strTestSetName, String strTestCaseName, String strComment) {
        boolean success = false;
        HttpURLConnection con = null;
        byte[] data = null;
        Map<String, String> params = new HashMap<>();
        String queryname = params.put("queryid", "1");
        String testsetPath = params.put("testsetpath", strParentFolderName);
        String testsetname = params.put("testsetname", strTestSetName);
        String testcasename = params.put("testcasename", strTestCaseName);
        String[] arrElements = getALMLabInfo(params);
        //String[] arrElements = getALMInfo(strParentFolderName, strTestSetName, strTestCaseName);
        String runId = arrElements[0];
        String testId = arrElements[2];
        String testCycleId = arrElements[1];
        String testInstanceId = arrElements[5];
        String configId = arrElements[3];
        String machineName = OSTools.getUserMachineName();
        String resultPoint = buildFullURL() + "runs";//+runId;

        // Add fields required to create a new result set for the test run
        Map<String, String> fieldMap = new HashMap<String, String>();
        fieldMap.put("name", "Automated_Run_" + Util.randomNum(99999, 100000000)); //run name
        fieldMap.put("status", status);  // Status (default: N/A, Blocked, Failed, No Run, Not Completed, Passed)
        fieldMap.put("duration", String.valueOf(duration)); //test execution duration in seconds
        fieldMap.put("host", machineName); //host name
        fieldMap.put("comments", strComment); //comment about the execution, useful for failed tests
        fieldMap.put("test-id", testId);
        fieldMap.put("testcycl-id", testInstanceId);
        fieldMap.put("owner", OSTools.getUsername());
        fieldMap.put("test-instance", testInstanceId);
        fieldMap.put("test-config-id", configId);
        fieldMap.put("subtype-id", "hp.qc.run.MANUAL");

        // Create entity based on the given information
        Entity entity = null;
        String entityXML = null;
        try {
            entity = BuildTestRunResultEntity(fieldMap);
            entityXML = EntityMarshallingUtils.unmarshal(Entity.class, entity).trim();
        } catch (Exception e) {
            errorHandler(e);
        }
        // Send the data to the REST web service
        try {
            con = prepareHttpConnection(resultPoint, "POST");
            con.setDoOutput(true);
            con.setDoInput(true);
            con.setUseCaches(false);
            con.setDefaultUseCaches(false);
            data = entityXML.getBytes();
            OutputStream out = con.getOutputStream();
            out.write(data);
            out.flush();
            out.close();
        } catch (Exception e) {
            errorHandler(e);
        }
        // Check response if submission was successful
        try {
            if (con == null) {
                throw new NullArgumentException("No connection object.");
            }
            Response res = getHTTPResponse(con);
            success = res.getStatusCode() == HttpURLConnection.HTTP_OK | res.getStatusCode() == HttpURLConnection.HTTP_CREATED;
            if (!success)
                throw new Exception(res.toString());
        } catch (Exception e) {
            errorHandler(e);
        }
        return success;
    }


    /**
     * metod to add the attachment to test instance in test lab
     *
     * @param strParentFolderName
     * @param TestSetName
     * @param strTestCaseName
     * @param filepath
     * @param filename
     * @return
     */
    public boolean addAttachmentToTestInstance(String strParentFolderName,
                                               String TestSetName, String strTestCaseName, String filepath, String filename) {
        boolean success = false;
        HttpURLConnection con = null;
        byte[] fileContent = null;
        //get the file attachment
        try {
            if (filepath == null) {
                filepath = ".";
            } else if (filepath.isEmpty()) {
                filepath = ".";
            }
            File fileToAttach = new File(filepath + "\\" + filename);
            FileInputStream fis = new FileInputStream(fileToAttach);
            fileContent = new byte[(int) fileToAttach.length()];
            fis.read(fileContent);
            fis.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        String[] arrElements = getALMInfo(strParentFolderName, TestSetName, strTestCaseName);
        String runId = arrElements[0];
        String test_instance = arrElements[5];
        String resultPoint = buildFullURL() + "test-instances/" + test_instance + "/attachments";
        //String resultPoint = buildFullURL() + "runs/"+runId+"/attachments";

        // Send the data to the REST web service
        try {
            con = prepareHttpConnectionForAtt(resultPoint, "POST");
            con.setDoOutput(true);
            con.addRequestProperty("Content-Type", "application/octet-stream");
            con.addRequestProperty("Accept", "application/xml");
            con.addRequestProperty("Slug", filename);
            //con.addRequestProperty("override-existing-attachment", "y");
            OutputStream out = con.getOutputStream();
            out.write(fileContent);
            out.flush();
            out.close();
        } catch (Exception e) {
            errorHandler(e);
        }
        // Check response if submission was successful
        try {
            Response res = getHTTPResponse(con);
            success = res.getStatusCode() == HttpURLConnection.HTTP_CREATED;
            if (!success)
                throw new Exception(res.toString());
        } catch (Exception e) {
            errorHandler(e);
        }
        return success;
    }

    /**
     * method to get the ALM test suite details required to update test execution status and add attachment
     *
     * @param strTestSetPath
     * @param strTestSetName
     * @param strTestCaseName
     * @return
     */
    public String[] getALMInfo(String strTestSetPath, String strTestSetName, String strTestCaseName) {
        //local variables instantiation
        PreparedStatement statement = null;
        Connection connection = null;
        ResultSet result = null;
        String strEnv = "QC-PROD";
        String strCycleID = "";
        String strTestID = "";
        String strConfigID = "";
        String strTestInstance = "";
        String strRunID = "";
        String strTestCycleID = "";
        String[] getArrQL = null;
        String strQuery = "";
        try {
            connection = QCDBConnect.getQCDatabaseConnection(strEnv);
            System.setProperty("TEST_SET_PATH", strTestSetPath);
            System.setProperty("TEST_SET_NAME", strTestSetName);
            System.setProperty("TEST_CASE_NAME", strTestCaseName);
            getArrQL = QCQueries.getQuery("QCTestLab1");
            strQuery = getArrQL[0];
            statement = connection.prepareStatement(strQuery);
            /*statement.setString(1, strParentFolderName);
            statement.setString(2, strTestSetName);
            statement.setString(3, strTestCaseName);*/
            result = statement.executeQuery();
            //iterate the first result set data
            if (result.next()) {
                strRunID = result.getString("RN_RUN_ID"); //run id
                strCycleID = result.getString("CY_CYCLE_ID"); //CY_CYCLE_ID
                strTestID = result.getString("TS_TEST_ID"); //TS_TEST_ID
                strConfigID = result.getString("TC_TEST_CONFIG_ID"); //TC_TEST_CONFIG_ID
                strTestInstance = result.getString("TC_TEST_INSTANCE"); //Test instance
                strTestCycleID = result.getString("TC_TESTCYCL_ID"); //test cycle id
            }
            getArrQL = new String[]{strRunID, strCycleID, strTestID, strConfigID, strTestInstance, strTestCycleID};
        } catch (SQLException ignore) {
        } finally {
            try {
                result.close();
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return getArrQL;
    }

    /**
     * method to get the object values into an array
     * @param params
     * @return
     */
    public String[] getALMLabInfo(Map<String, String> params){
        String getArrData[];
        List<DataSummary> datalist = QCInventoryManager.getALMTestLabDetailsByQueryID(params);
        getArrData = new String[]{datalist.get(0).getRunId(), datalist.get(0).getCycleId(), datalist.get(0).getTestID(),
        datalist.get(0).getConfigId(), datalist.get(0).getTestInstance(), datalist.get(0).getTestCycleId()};
        return getArrData;
    }


    /*HTTP Return Codes
    Unless otherwise specified, these HTTP status codes are used:
    Code Cause
    200	OK
    201	Created
    400	Bad request. Syntax or format error
    400	Invalid list field value
    400	Invalid value type for field
    400	Required field missing
    400	Too many entities
    400	Unknown field name
    401	User not authenticated
    403	User not authorized to perform requested operation
    403	Blocked file type
    403	Lock failure
    403	Read-only field
    404	Resource not found
    404	Invalid filter expression
    405	Method not supported by resource
    406	Unsupported ACCEPT type
    409	Conflict with the current state of the resource.
    409	Partially successfully bulk operation
    415	Unsupported request content type
    500	Internal server error
    501	Not implemented*/
}