package tech.nike.automation.common.framework.almota;

import com.mercury.qualitycenter.otaclient.*;
import com4j.Com4jObject;
import tech.nike.automation.common.framework.tools.OSTools;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Created by PSibb1 on 3/30/2017.
 */
public class TestALMOTA {

    public static void main(String[] args) {
        results();
    }

    /**
     * method to update the test case status in ALM and attach the test results into ALM
     */
    public static void results() {
        String host;
        String port;
        String domain;
        String project;
        String user;
        String password;
        String testsetpath;
        String testsetname;
        String testcasename;
        String attachmentfilepath;
        //initiating the property file reading
        Properties almProperty = new Properties();
        try {
            almProperty.load(new FileInputStream(new File("src/main/resources/alm.properties").getAbsolutePath()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        //storing the values from the property file
        host = almProperty.getProperty("host");
        port = almProperty.getProperty("port");
        domain = almProperty.getProperty("domain");
        project = almProperty.getProperty("project");
        user = almProperty.getProperty("username");
        password = almProperty.getProperty("password");
        testsetpath = almProperty.getProperty("testsetpath");
        testsetname = almProperty.getProperty("testsetname");
        attachmentfilepath = almProperty.getProperty("attachmentfilepath");
        testcasename = almProperty.getProperty("testcasename");
        //attachment file path into variables
        Boolean blnFound;
        String fileName = new File(attachmentfilepath).getName();
        String folderName = new File(attachmentfilepath).getParent();
        //instantiation of the TD connection
        ITDConnection itd = ClassFactory.createTDConnection();
        itd.initConnectionEx("http://" + host + ":" + port + "/qcbin");
        System.out.println(itd.connected());
        //connect to the alm project
        itd.connectProjectEx(domain, project, user, password);
        System.out.println(itd.projectConnected());
        //To get the Test Set folder in Test Lab
        ITestSetTreeManager objTestSetTreeManager = (itd.testSetTreeManager()).queryInterface(ITestSetTreeManager.class);
        ITestSetFolder objTestSetFolder = (objTestSetTreeManager.nodeByPath(testsetpath)).queryInterface(ITestSetFolder.class);
        ;
        IList tsTestList = objTestSetFolder.findTestSets(null, true, null);
        //iterate to all the test sets
        for (int i = 1; i <= tsTestList.count(); i++) {
            Com4jObject comObj = (Com4jObject) tsTestList.item(i);
            ITestSet testset = comObj.queryInterface(ITestSet.class);
            if (testset.name().equalsIgnoreCase(testsetname)) {
                blnFound = true;
                //connect to test instance factory
                IBaseFactory obj2 = testset.tsTestFactory().queryInterface(IBaseFactory.class);
                IList tstestlist = obj2.newList("");
                //iterate through the test list
                for (Com4jObject obj3 : tstestlist) {
                    ITSTest tstest = obj3.queryInterface(ITSTest.class);
                    if (tstest.name().contentEquals("[1]" + testcasename)) {
                        System.out.println("TC found");
                        //connect to the run factory
                        IRunFactory runfactory = tstest.runFactory().queryInterface(IRunFactory.class);
                        IRun run = runfactory.addItem("Auto_Run").queryInterface(IRun.class);
                        run.status("Passed");
                        run.field("RN_COMMENTS", "PASSED");
                        run.field("RN_DURATION", "502");
                        run.field("RN_HOST", OSTools.getUserMachineName());
                        run.field("RN_TESTER_NAME", user);
                        //connect to attachment factory
                        IAttachmentFactory attachfac = tstest.attachments().queryInterface(IAttachmentFactory.class);
                        IAttachment attach = attachfac.addItem(fileName).queryInterface(IAttachment.class);
                        IExtendedStorage extAttach = attach.attachmentStorage().queryInterface(IExtendedStorage.class);
                        extAttach.clientPath(folderName);
                        extAttach.save(fileName, true);
                        attach.post();
                        attach.refresh();
                        run.post();
                        break;
                    }
                }
                if (blnFound) {
                    break;
                }
            }
        }
    }

    /**
     * method to read the properties file
     *
     * @return
     */
    public Properties readAlmProperties() {
        Properties almProperties = null;
        try {
            almProperties = new Properties();
            InputStream in = getClass().getClassLoader().getResourceAsStream("src/test/resources/alm.properties");
            almProperties.load(in);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return almProperties;
    }
}
