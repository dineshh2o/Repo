package tech.nike.automation.common.framework.tools;

import com.google.common.collect.ImmutableMap;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import tech.nike.automation.common.framework.core.Selenium;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

/**
 * Utility class to load a series of URLs at different resolutions and generate a report containing screenshots.
 * <p>
 * Intended use is for Visual QA validation of different browser/resolutions for formatting issues.
 *
 * @author Cognizant Technology CoE
 */

public class BrowserReport {

    private Map<String, ScreenshotMetaInfo> screenshots = new HashMap<String, ScreenshotMetaInfo>();
    private Set<String> browsers = new TreeSet<String>();
    private Set<String> pages = new TreeSet<String>();
    private Set<String> resolutions = new TreeSet<String>();


    /**
     * Call to gather screenshots across the listed resolutions for all the urls specified.
     * <p>
     * Expects that the Selenium is already referencing an open browser.
     * <p>
     * Call multiple times with different Selenium objects, pointing to different browsers, to get consolidated report.
     *
     * @param se          Selenium pointing to an open browser
     * @param baseUrl     Prepended to each page in the pages list
     * @param pages       List of urls to test
     * @param resolutions List of resolutions to test the urls at
     * @return true if successfully able to take screenshots for all urls and resolutions
     */

    public boolean captureScreenshots(Selenium se, String baseUrl, List<String> pages, List<String> resolutions) {
        this.pages.addAll(pages);
        this.resolutions.addAll(resolutions);
        for (String page : pages) {
            for (String resolution : resolutions) {
                se.browser.setBrowserSize(Integer.valueOf(resolution), 1000);
                se.util.sleep(1000);

                se.browser.openUrl(baseUrl + page);
                se.util.sleep(5000);
                String screenshotUrl = se.assertion.attachScreenshot("");
                ScreenshotMetaInfo screenshotMetaInfo = new ScreenshotMetaInfo(screenshotUrl, page, se.log.getBrowserName(), se.log.getBrowserVersion(), resolution);
                screenshots.put(screenshotMetaInfo.getKey(), screenshotMetaInfo);
                browsers.add(screenshotMetaInfo.getBrowser());
            }
        }
        return true;
    }

    /**
     * Create a html file on disk that shows all the screenshots taken at this point.
     *
     * @param baseUrl    The prefix for all the test page urls
     * @param outputFile The file to write the report out to.
     */

    public void createHtmlReport(String baseUrl, File outputFile) {
        try {
            // Setup a freemarker configuration object so we can load our ftl file
            Configuration freemarkerConfiguration = new Configuration();
            // Point the configuration object at the class path
            freemarkerConfiguration.setClassForTemplateLoading(this.getClass(), "/");
            // Create a template object from our browserReport.ftl
            Template freemarkerTemplate = freemarkerConfiguration.getTemplate("browserReport.ftl");

            // Process the template, passing in our arguments as a hashmap.
            // Writing to the specified output file
            BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));
            freemarkerTemplate.process(ImmutableMap.of("screenshots", screenshots, "browsers", browsers, "baseUrl", baseUrl, "pages", pages, "resolutions", resolutions), writer);
            writer.close();
        } catch (IOException e1) {
            e1.printStackTrace();
        } catch (TemplateException e) {
            e.printStackTrace();
        }
    }


    /**
     * Get the number of screenshots that will be in the generated report
     *
     * @return number of screenshots
     */

    public Integer getScreenshotCount() {
        return screenshots.size();
    }


/*
     * Property holder for the screenshots
     */

    public class ScreenshotMetaInfo {
        private String href;

        private String page;
        private String browserName;
        private String browserVersion;
        private String resolution;

        public ScreenshotMetaInfo(String href, String page, String browserName, String browserVersion, String resolution) {
            this.href = href;
            this.page = page;
            this.browserName = browserName;
            this.browserVersion = browserVersion;
            this.resolution = resolution;
        }

        public String getPage() {
            return page;
        }

        public String getBrowser() {
            return browserName + " - " + browserVersion;
        }

        public String getResolution() {
            return resolution;
        }

        public String getHref() {
            return href;
        }


        /**
         * Used in the freemarker template to load the specific page directly (without having to iterate looking for it).
         *
         * @return string representing the page/resolution/browser of this screenshot
         */

        public String getKey() {
            return String.format("%s%s%s", page, resolution, getBrowser());
        }
    }
}

