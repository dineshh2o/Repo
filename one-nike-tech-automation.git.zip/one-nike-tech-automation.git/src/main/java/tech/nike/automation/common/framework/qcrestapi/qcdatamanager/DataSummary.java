package tech.nike.automation.common.framework.qcrestapi.qcdatamanager;

import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Element;

import java.io.Serializable;

public class DataSummary implements Serializable {

	private static final long serialVersionUID = 1509286844442121684L;

	@Element (required=false)
	private String testSetFolderName;

	@Element (required=false)
	private String configId;

	@Element (required=false)
	private String runId;

	@Element (required=false)
	private String testCycleId;

	@Element (required=false)
	private String cycleId;

	@Element (required=false)
	private String testSetName;

	@Element (required=false)
	private String testCaseStatus;

	@Element (required=false)
	private String testHostName;

    @Element(required = false)
    private String testerName;

    @Element(required = false)
    private String dateOfExecution;

	@Element(required = false)
	private String timeOfExecution;

	@Element(required = false)
	private String runDuration;

	@Element(required = false)
	private String testInstance;

	@Element(required = false)
	private String testcasename;

	@Element(required = false)
	private String comment;

	@Element(required = false)
	private String duration;

	@Element(required = false)
	private String host;

	@Element(required = false)
	private String testId;

	@Attribute
	private String environment;
	public DataSummary() {
	}

	public String getTestSetFolderName() {
		return testSetFolderName;
	}
	public void setTestSetFolderName(String testSetFolderName) {
		this.testSetFolderName = testSetFolderName;
	}

	public String getConfigId() {
		return configId;
	}
	public void setConfigId(String configId) {
		this.configId = configId;
	}

	public String getRunId() {
		return runId;
	}
	public void setRunId(String runId) {
		this.runId = runId;
	}

	public String getTestCycleId() {
		return testCycleId;
	}
	public void setTestCycleId(String testCycleId) {
		this.testCycleId = testCycleId;
	}

	public String getCycleId() {
		return cycleId;
	}
	public void setCycleId(String cycleId) {
		this.cycleId = cycleId;
	}

	public String getTestSetName() {
		return testSetName;
	}
	public void setTestSetName(String testSetName) {
		this.testSetName = testSetName;
	}

	public String getTestCaseStatus() {
		return testCaseStatus;
	}
	public void setTestCaseStatus(String testCaseStatus) {
		this.testCaseStatus = testCaseStatus;
	}

	public String getTestHostName() {
		return testHostName;
	}
	public void setTestHostName(String testHostName) {this.testHostName = testHostName;	}

    public String getTesterName() {
        return testerName;
    }
    public void setTesterName(String testerName) {
        this.testerName = testerName;
    }

    public String getDateOfExecution() {
        return dateOfExecution;
    }
    public void setDateOfExecution(String dateOfExecution) {
        this.dateOfExecution = dateOfExecution;
    }

	public String getTimeOfExecution() {
		return timeOfExecution;
	}
	public void setTimeOfExecution(String timeOfExecution) {
		this.timeOfExecution = timeOfExecution;
	}

	public String getRunDuration() {
		return runDuration;
	}
	public void setRunDuration(String runDuration) {
		this.runDuration = runDuration;
	}

	public String getTestInstance() {
		return testInstance;
	}
	public void setTestInstance(String testInstance) {
		this.testInstance = testInstance;
	}

	public String getEnvironment() {
		return environment;
	}
	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public String getTestCase() {
		return testcasename;
	}
	public void setTestCase(String testcasename) {
		this.testcasename = testcasename;
	}

	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}

	public String getTestID() {
		return testId;
	}
	public void setTestId(String testId) {
		this.testId = testId;
	}
}