package tech.nike.automation.common.framework.configuration;

/**
 * Created by psibb1 on 3/18/2016.
 */
public class Envclient {
    Env testEnv;

    public Envclient(Env testEnv) {
        this.testEnv = testEnv;
    }

    public String[] getEnvUrl() {
        String strHost = null;
        String JSON_FILE = "";
        String[] arrConnections = null;

        switch (testEnv) {
            case x103:
                //application url
                strHost = "http://nke-lnx-apt-" + testEnv + ".nike.com:10000";
                // Database HLTS URL
                String HAM_AT_DB_URL = "jdbc:oracle:thin:@nke-lnx-dbt-x103:1521:wm1014x3";
                // database HTLS credentials
                String HAM_AT_USER = "READONLY_NIKEWM10642X3";
                String HAM_AT_PASS = "READONLY_NIKEWM10642X3";
                JSON_FILE = "/META-INF/ham_inventory_manager_named_queries.json";
                String SCHEMA_NAME = "NIKEWM10642X3";
                arrConnections = new String[]{strHost, HAM_AT_USER, HAM_AT_PASS, HAM_AT_DB_URL,JSON_FILE,SCHEMA_NAME};
                break;

            case d050:
                strHost = "http://nke-lnx-wms-" + testEnv + ".nike.com:10000";
                // database herentals url
                String HLTS_AT_DB_URL = "jdbc:oracle:thin:@nke-lnx-dbt-x103:1521:wm1014x2";
                // database herentals credentials
                String HLTS_AT_USER = "READONLY_NIKEWM1064AT";
                String HLTS_AT_PASS = "READONLY_NIKEWM1064AT";
                JSON_FILE = "/META-INF/herentals_inventory_manager_named_queries.json";
                SCHEMA_NAME = "NIKEWM1064AT";
                arrConnections = new String[]{strHost, HLTS_AT_USER, HLTS_AT_PASS, HLTS_AT_DB_URL, JSON_FILE, SCHEMA_NAME};
                break;

            case d065:
                //application url
                strHost = "http://nke-lnx-wms-" + testEnv + ".nike.com:10000";
                // database herentals url
                String HAM_ER_DB_URL = "jdbc:oracle:thin:@nke-lnx-wms-d067.nike.com:1521:W10642ER";
                // database herentals credentials
                String HAM_ER_USER = "READONLY_NIKEWM10642ER";
                String HAM_ER_PASS = "READONLY_NIKEWM10642ER";
                JSON_FILE = "/META-INF/ham_inventory_manager_named_queries.json";
                SCHEMA_NAME = "NIKEWM10642ER";
                arrConnections = new String[]{strHost, HAM_ER_USER, HAM_ER_PASS, HAM_ER_DB_URL, JSON_FILE, SCHEMA_NAME};
                break;

            case d052:
                //application url
                strHost = "http://nke-lnx-wms-" + testEnv + ".nike.com:10000";
                // database herentals url
                String HLTS_ER_DB_URL = "jdbc:oracle:thin:@nke-lnx-wms-d054:1521:wm1064er";
                // database herentals credentials
                String HLTS_ER_USER = "READONLY_NIKEWM1064ER";
                String HLTS_ER_PASS = "READONLY_NIKEWM1064ER";
                JSON_FILE = "/META-INF/herentals_inventory_manager_named_queries.json";
                SCHEMA_NAME = "NIKEWM1064ER";
                arrConnections = new String[]{strHost, HLTS_ER_USER, HLTS_ER_PASS, HLTS_ER_DB_URL, JSON_FILE, SCHEMA_NAME};
                break;

            case d001:
                //application url
                strHost = "http://nke-lnx-wma-" + testEnv + ".nike.com:10000";
                // database nalc url
                String NALC_ER_DB_URL = "jdbc:oracle:thin:@wc1014er.cz8mdzpqprux.us-east-1.rds.amazonaws.com:1521:WC1014ER";
                // database nalc credentials
                String NALC_ER_USER = "READONLY_NIKESUPPORT";// nikewm1014er
                String NALC_ER_PASS = "READONLY_NIKESUPPORT";
                JSON_FILE = "/META-INF/nalc_inventory_manager_named_queries.json";
                SCHEMA_NAME = "WMS";
                arrConnections = new String[]{strHost, NALC_ER_USER, NALC_ER_PASS, NALC_ER_DB_URL, JSON_FILE, SCHEMA_NAME};
                break;

            default:
                break;
        }
        return arrConnections;
    }

    public enum Env {
        x103, d050, d065, d052, d001
    }
}