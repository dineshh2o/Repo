package tech.nike.automation.common.framework.configuration;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import tech.nike.automation.common.framework.tools.DisableLogs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import static org.apache.log4j.Level.DEBUG;

/**
 * Created by psibb1 on 8/18/2016.
 */
public class QCDBConnect {
    public static Connection connection = null;
    private static Log logger = LogFactory.getLog(QCDBConnect.class);

    public static Connection getQCDatabaseConnection(String strEnvironment) {
        //reading db connection details
        DataBaseConfigurations db = new DataBaseConfigurations();
        //getting connections details for specific environment
        String[] arr = db.getDatabaseConnection(strEnvironment);
        //disable logging
        if (DEBUG.equals(true)) {
            DisableLogs.disableLogs();
        }
        System.out.println("-------- Oracle JDBC Connection Testing ------");

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException e) {
            System.out.println("Where is your Oracle JDBC Driver?");
            logger.trace(e.getMessage());
        }
        System.out.println("Oracle JDBC Driver Registered!");
        try {
            connection = DriverManager.getConnection(arr[2], arr[0], arr[1]);
        } catch (SQLException e) {
            System.out.println("Connection Failed! Check output console");
            logger.trace(e.getMessage());
        }
        if (connection != null) {
            System.out.println("You made it, take control of your QC database now!");
        } else {
            System.out.println("Failed to make connection!");
        }
        return connection;
    }
}