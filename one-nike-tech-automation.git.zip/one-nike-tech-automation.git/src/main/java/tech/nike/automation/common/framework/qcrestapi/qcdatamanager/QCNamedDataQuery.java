package tech.nike.automation.common.framework.qcrestapi.qcdatamanager;

import java.util.List;


public class QCNamedDataQuery {

    private String id, name, description;
    private List<QCQuery> queries;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<QCQuery> getQueries() {
		return queries;
	}
	public void setQueries(List<QCQuery> queries) {
		this.queries = queries;
	}
}