package tech.nike.automation.common.utils.parsers;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by psibb1 on 2/16/2017.
 */
public class JsonToMapParser implements DataToMapParser {

    private static final Log logger = LogFactory.getLog(JsonToMapParser.class);

    private Map<String, Object> map = null; // map holds resource returned

    /**
     * Public function, get map representation of the json file.
     *
     * @return HashMap of json file elements.
     */
    public HashMap<String, Object> getHashMap() {
        return ((HashMap<String, Object>) map);
    }

    public void parse(File f) throws IOException {
        FileReader reader = new FileReader(f);
        map = new HashMap<String, Object>();

        ObjectMapper mapper = new ObjectMapper();

        //convert JSON string to Map
        map = mapper.readValue(reader, new TypeReference<Map<String, Object>>() {
        });

        //parsing individual tests
        ArrayList<String> data = (ArrayList<String>) map.get("test");

        //parsing individual tests
        ArrayList<Object> testList = new ArrayList<Object>();

        //test values map for each test
        HashMap<String, Object> testValuesMap = new HashMap<String, Object>();

        for (String msg : data) {
            //finally put all the tests into the overall map
            for (int i = 0; i <= data.size(); i++) {
                String[] arr = msg.split(":");
                testValuesMap.put(arr[0], arr[1]);
            }
            testList.add(testValuesMap);
        }
        map.put("test", testList);
    }
}