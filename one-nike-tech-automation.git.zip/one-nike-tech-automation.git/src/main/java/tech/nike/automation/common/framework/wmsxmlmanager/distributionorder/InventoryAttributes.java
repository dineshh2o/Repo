package tech.nike.automation.common.framework.wmsxmlmanager.distributionorder;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by PSibb1 on 3/5/2017.
 */
@XmlRootElement(name = "InventoryAttributes")
@XmlAccessorType(XmlAccessType.FIELD)
public class InventoryAttributes {

    @XmlElement(name = "ItemAttribute1")
    private String itemAttribute1 = null;

    public String getItemAttribute1() {
        return itemAttribute1;
    }

    public void setItemAttribute1(String itemAttribute1) {
        this.itemAttribute1 = itemAttribute1;
    }
}
