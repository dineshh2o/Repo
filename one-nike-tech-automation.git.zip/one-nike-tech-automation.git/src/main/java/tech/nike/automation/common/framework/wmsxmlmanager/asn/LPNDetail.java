package tech.nike.automation.common.framework.wmsxmlmanager.asn;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

/**
 * Created by psibb1 on 3/4/2017.
 */
@XmlRootElement(name = "LPNDetail")
@XmlAccessorType(XmlAccessType.FIELD)
public class LPNDetail {

    @XmlElement(name = "ItemName")
    private String itemName = null;
    @XmlElement(name = "PurchaseOrderLineItemID")
    private String purchaseOrderLineItemID = null;
    @XmlElement(name = "LPNDetailQuantity")
    private List<LPNDetailQuanity> lpnDetailQuantity = null;
    @XmlElement(name = "InventoryAttributes")
    private List<InventoryAttributes> inventoryAttributes = null;

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getPurchaseOrderLineItemID() {
        return purchaseOrderLineItemID;
    }

    public void setPurchaseOrderLineItemID(String purchaseOrderLineItemID) {
        this.purchaseOrderLineItemID = purchaseOrderLineItemID;
    }

    public List<LPNDetailQuanity> getLPNDetailQuantity() {
        return lpnDetailQuantity;
    }

    public void setLPNDetailQuantity(List<LPNDetailQuanity> lpnDetailQuantity) {
        this.lpnDetailQuantity = lpnDetailQuantity;
    }

    public List<InventoryAttributes> getInventoryAttributes() {
        return inventoryAttributes;
    }

    public void setInventoryAttributes(List<InventoryAttributes> inventoryAttributes) {
        this.inventoryAttributes = inventoryAttributes;
    }
}
