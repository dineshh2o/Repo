package tech.nike.automation.common.framework.core;

public class Constants {

    //Assertions for logging in report
    public final static String VERIFICATION = "VERIFICATION:";
    public final static String TEST_STEP = "TEST STEP :";
    public final static String SE_STEP = "SE_STEP :";
    public final static String STEP = "STEP";
    public final static String TEST_SUMMARY = "Test Summary";
    public final static String VERIFICATIONS_PASSED = "Verifications Passed:";
    public final static String VERIFICATION_FAILED = "Verifications Failed:";


    public final static int HTTP_RESPONSE_STATUS = 200;

    // Select your Region dropdown values
    public final static String US = "US";
    public final static String EU = "EU";
    public final static String JP = "JP";
    public final static String CN = "CN";

    //Prodigy home page links
    public final static String THIS_WEEK = "This week";
    public final static String NEXT_WEEK = "Next week";
    public final static String THIS_MONTH = "This month";
    public final static String OUTFITTER_LINK = "OutFitter Admin Tool";
    //HTML tags and attributes
    public final static String GET_ATTRIBUTE_VALUE = "value";
    public final static String TITLE = "title";
    public final static String TR = "tr";
    public final static String TD = "td";
    public final static String OPTION = "option";
    //Page Titles
    public final static String OUTFITTER_PAGE_TITLE = "Outfitter Admin";
    //Prodigy search result page columns
    public static String COLUMN_1 = "Product Code";
    public static String COLUMN_2 = "Name";
    public static String COLUMN_3 = "Start Date";
    public static String COLUMN_4 = "C";
    public static String COLUMN_5 = "I";
    public static String COLUMN_6 = "A";
    public static String COLUMN_7 = "Status";
    public static String COLUMN_8 = "Price";

    public enum Country {
        US, EU, JP, CN
    }


}
