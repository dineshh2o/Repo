package tech.nike.automation.common.framework.wmsxmlmanager.distributionorder;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

/**
 * Created by psibb1 on 3/4/2017.
 */
@XmlRootElement(name = "LineItem")
@XmlAccessorType(XmlAccessType.FIELD)
public class LineItem {

    @XmlElement(name = "DoLineNbr")
    private String doLineNbr = null;
    @XmlElement(name = "ItemName")
    private String itemName = null;
    @XmlElement(name = "DoLineStatus")
    private String doLineStatus = null;
    @XmlElement(name = "ReferenceField1")
    private String referenceField1 = null;
    @XmlElement(name = "PrepackGroupCode")
    private String prepackGroupCode = null;
    @XmlElement(name = "PrepackQty")
    private String prepackQty = null;
    @XmlElement(name = "AssortmentNbr")
    private String assortmentNbr = null;
    @XmlElement(name = "Quantity")
    private List<Quantity> quantity = null;
    @XmlElement(name = "LineProcessInfo")
    private List<LineProcessInfo> lineProcessInfo = null;
    @XmlElement(name = "InventoryAttributes")
    private List<InventoryAttributes> inventoryAttributes = null;

    public String getDoLineNbr() {
        return doLineNbr;
    }

    public void setDoLineNbr(String doLineNbr) {
        this.doLineNbr = doLineNbr;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getDoLineStatus() {
        return doLineStatus;
    }

    public void setDoLineStatus(String doLineStatus) {
        this.doLineStatus = doLineStatus;
    }

    public String getReferenceField1() {
        return referenceField1;
    }

    public void setReferenceField1(String referenceField1) {
        this.referenceField1 = referenceField1;
    }

    public String getPrepackGroupCode() {
        return prepackGroupCode;
    }

    public void setPrepackGroupCode(String prepackGroupCode) {
        this.prepackGroupCode = prepackGroupCode;
    }

    public String getPrepackQty() {
        return prepackQty;
    }

    public void setPrepackQty(String prepackQty) {
        this.prepackQty = prepackQty;
    }

    public String getAssortmentNbr() {
        return prepackQty;
    }

    public void setAssortmentNbr(String assortmentNbr) {
        this.assortmentNbr = assortmentNbr;
    }

    public List<Quantity> getQuantity() {
        return quantity;
    }

    public void setQuantity(List<Quantity> quantity) {
        this.quantity = quantity;
    }

    public List<LineProcessInfo> getLineProcessInfo() {
        return lineProcessInfo;
    }

    public void setLineProcessInfo(List<LineProcessInfo> lineProcessInfo) {
        this.lineProcessInfo = lineProcessInfo;
    }

    public List<InventoryAttributes> getInventoryAttributes() {
        return inventoryAttributes;
    }

    public void setInventoryAttributes(List<InventoryAttributes> inventoryAttributes) {
        this.inventoryAttributes = inventoryAttributes;
    }
}
