package tech.nike.automation.common.framework.wmsxmlmanager.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by psibb1 on 3/3/2017.
 */
@XmlRootElement(name = "Header")
@XmlAccessorType(XmlAccessType.FIELD)

public class Header {

    /**
     * method applicable only for ASN
     */
    @XmlElement(name = "Reference_ID")
    private String ReferenceID = null;
    @XmlElement(name = "Message_Type")
    private String messageType = null;
    /**
     * method applicable only for distribution order
     */
    @XmlElement(name = "Destination")
    private String destination = null;
    /**
     * method applicable only for distribution order
     */
    @XmlElement(name = "External_Reference_ID")
    private String externalReferenceID = null;

    public String getReferenceID() {
        return ReferenceID;
    }

    public void setReferenceID(String ReferenceID) {
        this.ReferenceID = ReferenceID;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getExternalReferenceID() {
        return externalReferenceID;
    }

    public void setExternalReferenceID(String externalReferenceID) {
        this.externalReferenceID = externalReferenceID;
    }
}