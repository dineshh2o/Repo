package tech.nike.automation.common.framework.jmxmessaging;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Date;

/**
 * Created by PSibb1 on 1/17/2017.
 */
public class WMSMessaging {
    private Log logger = LogFactory.getLog(WMSMessaging.class);
    //public static final String HOST_NAME = null;

    /*public static void main(String[] args) {
        post201Message("PSIBB149981289122515");
    }*/

    /**
     * method to post the 201 message for Inbound process in WMS Manhattan
     * @param LPNNumber
     * @param port
     * @param message
     */
    public boolean postMessage(String LPNNumber, String Host, int port, String message) {
        boolean result = false;
        Socket clientSoc = null;
        String clientInput;
        try {
            clientSoc = new Socket(Host, port);
            BufferedReader inputReader = new BufferedReader(new InputStreamReader(clientSoc.getInputStream()));
            PrintWriter outStream = new PrintWriter(clientSoc.getOutputStream(), true);
            long st = new Date().getTime();
            long t = 0l;
            outStream.println((char) 2 + message + (char) 3);
            while (t < 900001l) {
                clientInput = inputReader.readLine();
                result = clientInput !=null;
                System.out.println( "RECEIVED: " + clientInput );
                if (clientInput != null) {
                    if (clientInput.contains("^") && (int) clientInput.charAt(0) == 2
                            && (int) clientInput.charAt(clientInput.length() - 1) == 3
                            && clientInput.substring(2, 5).equals("ACK")) {// 2^ACK^3
                        String messages = message;
                        break;
                    } else if (clientInput.contains("^") && (int) clientInput.charAt(0) == 2
                            && (int) clientInput.charAt(clientInput.length() - 1) == 3
                            && clientInput.substring(2, 5).equals("NAK")) {
                        System.out.println("WMS sent NAK... discarding message...");
                        break;
                    } else {
                        System.out.println("WMS didn't send either ACK or NAK... discarding message...");
                        break;
                    }
                }
                t = new Date().getTime() - st;
            }
            System.out.println("Connection closed from host..." + clientSoc.getInetAddress() + " Time: " + t);
            clientSoc.close();
            outStream.flush();
            outStream.close();
            result &= true;
        } catch (IOException e) {
            System.out.println(e.getMessage() + e.getStackTrace());
            logger.error(e.getMessage() + e.getStackTrace());
            result &= false;
            try {
                clientSoc.close();
                result &= false;
            } catch (IOException e1) {
                e1.printStackTrace();
                logger.error(e.getMessage() + e.getStackTrace());
                result &= false;
            }
            e.printStackTrace();
        }
        return result;
    }

    /**
     * wrapper method to post a message at port 20201 inbound wms message
     * @param lpnNumber
     */
    public boolean  post201Message(String lpnNumber, String Host){
        boolean result = false;
        String message = "CONTAINERSTATUS^" + lpnNumber + "^DIVERTED^ROUTINGREQ^UN^2690^^^GR110SC00";
        result = postMessage(lpnNumber, Host, 20201,message );
        return result;
    }

    /**
     * wrapper method to post message at port 20202 inbound wms message
     * @param lpnNumber
     */
    public boolean post202Message(String lpnNumber, String Host){
        boolean result = false;
        String message = "CONTAINERSTATUS^"+lpnNumber+"^DIVERTED^DIVERT^DS^2690^2400000001^^";
        result = postMessage(lpnNumber, Host, 20202,message );
        return result;
    }
}