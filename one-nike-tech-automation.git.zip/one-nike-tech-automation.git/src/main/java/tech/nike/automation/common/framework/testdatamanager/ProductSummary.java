package tech.nike.automation.common.framework.testdatamanager;

import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Element;

import java.io.Serializable;

public class ProductSummary implements Serializable {

	private static final long serialVersionUID = 1509286844442121684L;

	@Element (required=false)
	private String itemId;

	@Element (required=false)
	private String itemBarCode;

	@Element (required=false)
	private String itemName;

	@Element (required=false)
	private String itemQty;

	@Element (required=false)
	private String locBarCode;

	@Element (required=false)
	private String cntryoforgn;

	@Element (required=false)
	private String itemAttr;

	@Element (required=false)
	private String originFacilityAliasID;

    @Element(required = false)
    private String taskID;

    @Element(required = false)
    private String waveNumber;

    @Element(required = false)
    private String doNumber;

	@Attribute
	private String environment;
	public ProductSummary() {
	}

	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public String getItemBarCode() {
		return itemBarCode;
	}
	public void setItemBarCode(String itemBarCode) {
		this.itemBarCode = itemBarCode;
	}

	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemQty() {
		return itemQty;
	}
	public void setItemQty(String itemQty) {
		this.itemQty = itemQty;
	}

	public String getlocBarCode() {
		return locBarCode;
	}
	public void setlocBarCode(String locBarCode) {
		this.locBarCode = locBarCode;
	}

	public String getcntryoforgn() {
		return cntryoforgn;
	}
	public void setcntryoforgn(String cntryoforgn) {
		this.cntryoforgn = cntryoforgn;
	}

	public String getitemAttr() {
		return itemAttr;
	}
	public void setitemAttr(String itemAttr) {
		this.itemAttr = itemAttr;
	}

	public String getoriginFacilityAliasID() {
		return originFacilityAliasID;
	}
	public void setoriginFacilityAliasID(String originFacilityAliasID) {
		this.originFacilityAliasID = originFacilityAliasID;
	}

    public String gettaskID() {
        return taskID;
    }
    public void settaskID(String taskID) {
        this.taskID = taskID;
    }

    public String getWaveNumber() {
        return waveNumber;
    }
    public void setWaveNumber(String waveNumber) {
        this.waveNumber = waveNumber;
    }

    public String getDoNumber() {
        return doNumber;
    }

    public void setDoNumber(String doNumber) {
        this.doNumber = doNumber;
    }
}