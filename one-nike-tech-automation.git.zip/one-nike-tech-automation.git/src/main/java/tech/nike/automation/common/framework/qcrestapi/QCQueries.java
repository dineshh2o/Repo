package tech.nike.automation.common.framework.qcrestapi;

/**
 * Created by PSibb1 on 12/15/2016.
 */
public class QCQueries {
    public static String[] getQuery(String strTestCaseName) {
        String[] arrSQL = {};
        switch (strTestCaseName) {
            case "QCTestLab":
                String sql1 = "Select TestsetFOLDER, TestSetName, TestPlan_Test_ID, TestPlanPath, TestName, " +
                        "TestInstanceStatus, ExecutionDuration from ( SELECT " +
                        //"Test Set Folder Name"
                        "e.CF_ITEM_NAME, " +
                        //Config ID
                        "f.TC_TEST_CONFIG_ID, " +
                        //as "CycleID"
                        "c.CY_CYCLE_ID, " +
                        //"Test Set Name"
                        "c.CY_CYCLE, " +
                        // "QC Test ID",
                        "b.TS_TEST_ID, " +
                        //"Test Case Name"
                        "b.TS_NAME " +
                        "FROM qc_views.qc_tao_bpt_test b, qc_views.qc_tao_bpt_cycle c,qc_views.qc_tao_bpt_run d,qc_views.qc_tao_bpt_cyclefold e, " +
                        "(select CF_ITEM_PATH from qc_views.qc_tao_bpt_cyclefold  where CF_ITEM_NAME like ?) col1 , qc_views.qc_tao_bpt_testcycl f " +
                        "where " +
                        "c.CY_CYCLE_ID = d.RN_CYCLE_ID " +
                        "and d.RN_TEST_ID = b.TS_TEST_ID " +
                        "and e.CF_ITEM_ID = c.CY_FOLDER_ID " +
                        "and f.TC_CYCLE_ID = c.cy_cycle_id " +
                        "and f.TC_TEST_ID = b.TS_TEST_ID " +
                        "and d.RN_HOST IS NOT NULL " +
                        "and d.RN_TESTER_NAME IS NOT NULL " +
                        "and INSTR(e.CF_ITEM_PATH,col1.CF_ITEM_PATH,1) > 0 " +
                        "and b.ts_type <> 'QUICKTEST_TEST' " +
                        "and b.TS_NAME = ? " +
                        "ORDER BY e.CF_ITEM_NAME, b.TS_NAME ASC";
                arrSQL = new String[]{sql1};
                break;
            case "QCTestLab1":
                String sql2 = "SELECT " +
                        //Test Set Folder Nam
                        "e.CF_ITEM_NAME,  " +
                        //Config ID
                        "f.TC_TEST_CONFIG_ID, " +
                        //RunID
                        "d.RN_RUN_ID, " +
                        //Test Cycle ID
                        "f.TC_TESTCYCL_ID, " +
                        //CycleID
                        "c.CY_CYCLE_ID, " +
                        //Test Set Name
                        "c.CY_CYCLE, " +
                        //QC Test ID
                        "b.TS_TEST_ID, " +
                        //Test Case Name
                        "b.TS_NAME, " +
                        //Test Case Status
                        "f.TC_STATUS, " +
                        //Test Host Name
                        "d.RN_HOST, " +
                        //Tester Name
                        "d.RN_TESTER_NAME, " +
                        //Date of Execution
                        "f.TC_EXEC_DATE, " +
                        //Execution Time
                        "f.TC_EXEC_TIME, " +
                        //Run Duration in Seconds
                        "d.RN_DURATION, " +
                        //Test Instance
                        "f.TC_TEST_INSTANCE " +
                        "FROM qc_views.qc_tao_bpt_test b, qc_views.qc_tao_bpt_cycle c,qc_views.qc_tao_bpt_run d,qc_views.qc_tao_bpt_cyclefold e, qc_views.qc_tao_bpt_testcycl f, " +
                        "(select TABLEPATH.PTH, in_cy.CY_CYCLE_ID  from (select in_cf.CF_ITEM_ID, sys_connect_by_path (in_cf.CF_ITEM_NAME, '\\') PTH   " +
                        "from qc_views.qc_tao_bpt_cyclefold in_cf connect by prior in_cf.CF_ITEM_ID = in_cf.CF_FATHER_ID start with in_cf.CF_FATHER_ID = 0 ) TABLEPATH  " +
                        "left join qc_views.qc_tao_bpt_cycle in_cy on (in_cy.CY_FOLDER_ID = TABLEPATH.CF_ITEM_ID)) TestSetPath " +
                        "where " +
                        "c.CY_CYCLE_ID = d.RN_CYCLE_ID " +
                        "and d.RN_TEST_ID = b.TS_TEST_ID " +
                        "and e.CF_ITEM_ID = c.CY_FOLDER_ID " +
                        "and f.TC_CYCLE_ID = c.cy_cycle_id " +
                        "and f.TC_TEST_ID = b.TS_TEST_ID " +
                        "and b.ts_type <> 'QUICKTEST_TEST' " +
                        "and TestSetPath.CY_CYCLE_ID = c.CY_CYCLE_ID " +
                        "and TestSetPath.PTH = '" + System.getProperty("TEST_SET_PATH") + "'" +
                        " and c.CY_CYCLE = '" + System.getProperty("TEST_SET_NAME") + "'" +
                        " and b.TS_NAME = '" + System.getProperty("TEST_CASE_NAME") + "' Order by d.RN_RUN_ID desc";

                arrSQL = new String[]{sql2};
                break;
        }
        return arrSQL;
    }
}
