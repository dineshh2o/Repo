package tech.nike.automation.common.framework.wmsxmlmanager.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

/**
 * Created by psibb1 on 3/3/2017.
 */
@XmlRootElement(name = "tXML")
@XmlAccessorType(XmlAccessType.FIELD)

public class tXML {

    @XmlElement(name = "Header")
    private List<Header> header = null;
    @XmlElement(name = "Message")
    private List<Message> message = null;

    public List<Header> getHeaders() {
        return header;
    }

    public void setHeader(List<Header> header) {
        this.header = header;
    }

    public List<Message> getMessage() {
        return message;
    }

    public void setMessage(List<Message> message) {
        this.message = message;
    }
}
