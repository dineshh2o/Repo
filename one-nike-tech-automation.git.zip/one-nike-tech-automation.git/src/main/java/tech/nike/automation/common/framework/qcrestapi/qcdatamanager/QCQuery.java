package tech.nike.automation.common.framework.qcrestapi.qcdatamanager;

public class QCQuery {

	private String database, query;

	public String getDatabase() {
		return database;
	}

	public void setDatabase(String database) {
		this.database = database;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

}
