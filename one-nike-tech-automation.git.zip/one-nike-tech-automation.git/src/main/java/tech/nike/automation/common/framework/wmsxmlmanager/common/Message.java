package tech.nike.automation.common.framework.wmsxmlmanager.common;

import tech.nike.automation.common.framework.wmsxmlmanager.asn.ASN;
import tech.nike.automation.common.framework.wmsxmlmanager.distributionorder.DO;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

/**
 * Created by psibb1 on 3/3/2017.
 */
@XmlRootElement(name = "Message")
@XmlAccessorType(XmlAccessType.FIELD)

public class Message {

    /**
     * method applicable only for asn
     */
    @XmlElement(name = "ASN")
    private List<ASN> asn = null;
    /**
     * method applicable only for distribution order
     */
    @XmlElement(name = "DistributionOrder")
    private List<DO> distributionOrder = null;

    public List<ASN> getASN() {
        return asn;
    }

    public void setASN(List<ASN> asn) {
        this.asn = asn;
    }

    public List<DO> getDistributionOrder() {
        return distributionOrder;
    }

    public void setDistributionOrder(List<DO> distributionOrder) {
        this.distributionOrder = distributionOrder;
    }
}
