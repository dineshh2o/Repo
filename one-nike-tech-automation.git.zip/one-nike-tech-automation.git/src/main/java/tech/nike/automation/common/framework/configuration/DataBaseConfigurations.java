package tech.nike.automation.common.framework.configuration;

/**
 * Created by PSibb1 on 8/15/2016.
 */
public class DataBaseConfigurations {

    /**
     * This class is unused currently, all the configuration details are taken up used from Envclient class
     * @param strSite
     * @return
     */
    public String[] getDatabaseConnection(String strSite) {
        String[] arrConnections = {};
        switch (strSite) {
            case "QC-PROD":
                // Database HLTS URL
                String QC_DB_URL = "jdbc:oracle:thin:@nke-lnx-ALM-p001:1521:prdqc125";

                // Database HTLS credentials
                String QC_DB_USER = "qc_reports";
                String QC_DB_PASS = "reports";
                arrConnections = new String[]{QC_DB_USER, QC_DB_PASS, QC_DB_URL};
                break;
        }
        return arrConnections;
    }
}