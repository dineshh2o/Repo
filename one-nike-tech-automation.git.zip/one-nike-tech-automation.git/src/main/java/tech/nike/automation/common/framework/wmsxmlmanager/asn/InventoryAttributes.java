package tech.nike.automation.common.framework.wmsxmlmanager.asn;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by psibb1 on 3/4/2017.
 */
@XmlRootElement(name = "LPNDetail")
@XmlAccessorType(XmlAccessType.FIELD)
public class InventoryAttributes {

    @XmlElement(name = "ItemAttribute1")
    private String itemAttribute1 = null;
    @XmlElement(name = "CountryofOrigin")
    private String countryofOrigin = null;

    public String getItemAttribute1() {
        return itemAttribute1;
    }

    public void setItemAttribute1(String itemAttribute1) {
        this.itemAttribute1 = itemAttribute1;
    }

    public String getCountryofOrigin() {
        return countryofOrigin;
    }

    public void setCountryofOrigin(String countryofOrigin) {
        this.countryofOrigin = countryofOrigin;
    }
}
