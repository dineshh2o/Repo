package tech.nike.automation.common.framework.testdatamanager;

import java.util.List;

public class NamedProductQueries {

	private List<NamedProductQuery> namedProductQueries;

	public List<NamedProductQuery> getNamedProductQueries() {
		return namedProductQueries;
	}

	public void setNamedProductQueries(List<NamedProductQuery> namedProductQueries) {
		this.namedProductQueries = namedProductQueries;
	}

	public NamedProductQuery getNamedProductQueryById(String id) {
		NamedProductQuery retval = null;
		if(namedProductQueries!=null) {
			for(NamedProductQuery namedProductQuery: namedProductQueries) {
				if(id.toUpperCase().equals(namedProductQuery.getId().toUpperCase())) {
					retval=namedProductQuery;
					break;
				}
 			}
		}
		return retval;
	}
	
	public NamedProductQuery getNamedProductQueryByName(String name) {
		NamedProductQuery retval = null;
		if(namedProductQueries!=null) {
			for(NamedProductQuery namedProductQuery: namedProductQueries) {
				if(name.toUpperCase().equals(namedProductQuery.getName().toUpperCase())) {
					retval=namedProductQuery;
					break;
				}
 			}
		}
		return retval;
	}
}