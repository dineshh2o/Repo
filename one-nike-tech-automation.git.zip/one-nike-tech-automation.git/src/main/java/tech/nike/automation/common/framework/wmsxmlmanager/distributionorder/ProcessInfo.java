package tech.nike.automation.common.framework.wmsxmlmanager.distributionorder;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by psibb1 on 3/4/2017.
 */
@XmlRootElement(name = "ProcessInfo")
@XmlAccessorType(XmlAccessType.FIELD)
public class ProcessInfo {

    @XmlElement(name = "RefTextField1")
    private String refTextField1 = null;
    @XmlElement(name = "RefTextField2")
    private String refTextField2 = null;
    @XmlElement(name = "RefTextField3")
    private String refTextField3 = null;
    @XmlElement(name = "RefTextField5")
    private String refTextField5 = null;
    @XmlElement(name = "RefTextField6")
    private String refTextField6 = null;
    @XmlElement(name = "RefTextField7")
    private String refTextField7 = null;
    @XmlElement(name = "RefTextField8")
    private String refTextField8 = null;
    @XmlElement(name = "RefTextField9")
    private String refTextField9 = null;
    @XmlElement(name = "RefTextField10")
    private String refTextField10 = null;

    public String getRefTextField1() {
        return refTextField1;
    }

    public void setRefTextField1(String refTextField1) {
        this.refTextField1 = refTextField1;
    }

    public String getRefTextField2() {
        return refTextField2;
    }

    public void setRefTextField2(String refTextField2) {
        this.refTextField2 = refTextField2;
    }

    public String getRefTextField3() {
        return refTextField3;
    }

    public void setRefTextField3(String refTextField3) {
        this.refTextField3 = refTextField3;
    }

    public String getRefTextField5() {
        return refTextField5;
    }

    public void setRefTextField5(String refTextField5) {
        this.refTextField5 = refTextField5;
    }

    public String getRefTextField6() {
        return refTextField6;
    }

    public void setRefTextField6(String refTextField6) {
        this.refTextField6 = refTextField6;
    }

    public String getRefTextField7() {
        return refTextField7;
    }

    public void setRefTextField7(String refTextField7) {
        this.refTextField7 = refTextField7;
    }

    public String getRefTextField8() {
        return refTextField8;
    }

    public void setRefTextField8(String refTextField8) {
        this.refTextField8 = refTextField8;
    }

    public String getRefTextField9() {
        return refTextField9;
    }

    public void setRefTextField9(String refTextField9) {
        this.refTextField9 = refTextField9;
    }

    public String getRefTextField10() {
        return refTextField10;
    }

    public void setRefTextField10(String refTextField10) {
        this.refTextField10 = refTextField10;
    }
}
