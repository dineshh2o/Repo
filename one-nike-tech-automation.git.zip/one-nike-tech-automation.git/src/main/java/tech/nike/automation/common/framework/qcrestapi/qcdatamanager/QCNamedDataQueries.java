package tech.nike.automation.common.framework.qcrestapi.qcdatamanager;

import java.util.List;

public class QCNamedDataQueries {

	private List<QCNamedDataQuery> qcNamedDataQueries;

	public List<QCNamedDataQuery> getQcNamedDataQueries() {
		return qcNamedDataQueries;
	}

	public void setQcNamedDataQueries(List<QCNamedDataQuery> qcNamedDataQueries) {
		this.qcNamedDataQueries = qcNamedDataQueries;
	}

	public QCNamedDataQuery getNamedDataQueryById(String id) {
		QCNamedDataQuery retval = null;
		if(qcNamedDataQueries !=null) {
			for(QCNamedDataQuery namedProductQuery: qcNamedDataQueries) {
				if(id.toUpperCase().equals(namedProductQuery.getId().toUpperCase())) {
					retval=namedProductQuery;
					break;
				}
 			}
		}
		return retval;
	}

	public QCNamedDataQuery getNamedDataQueryByName(String name) {
		QCNamedDataQuery retval = null;
		if(qcNamedDataQueries !=null) {
			for(QCNamedDataQuery namedProductQuery: qcNamedDataQueries) {
				if(name.toUpperCase().equals(namedProductQuery.getName().toUpperCase())) {
					retval=namedProductQuery;
					break;
				}
 			}
		}
		return retval;
	}
}