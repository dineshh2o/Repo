package tech.nike.automation.common.framework.tools;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import tech.nike.automation.common.framework.utils.FlatFileGenerator;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
//http://javarevisited.blogspot.com/2015/07/how-to-solve-javalangclassnotfoundexception-sun.jdbc.odbc.jdbcodbcdriver.html
//http://www.codereye.com/2009/09/converting-resultset-to-excel-table-in.html
//http://codoid.com/fillo/

/**
 * Created by psibb1 on 9/11/2016.
 */
public class UFTExcelAdaptorAPI {

    public static String EXCEL_FIL_NAME = "C:/WMOS_FRAMEWORK/Test_Data.xls";
    public static String NALC_OB_DATA = "C:/WMOS_FRAMEWORK/NALC_OutBound_Dependency.xlsx";
    public static String NALC_LOG_FILE_PATH = "NALC_OutBound_Log.txt";
    Fillo fillo = new Fillo();
    com.codoid.products.fillo.Connection connection = null;

    /**
     * method to get the data from excel adaptor
     */
    //public void main(String args[]) {
    public boolean getTestData() {
        boolean result = true;
        try {
            connection = fillo.getConnection(EXCEL_FIL_NAME);
            String strQuery = "select TD_Test_Name,TD_Test_Case_ID,TD_Distribution_Order from Test_Data";
            Recordset rs = connection.executeQuery(strQuery);
            while (rs.next()) {
                System.out.println(rs.getField("TD_Test_Name") + " "
                        + rs.getField("TD_Test_Case_ID") + " " + rs.getField("TD_Distribution_Order"));
            }
            connection.close();
            result &= true;
        } catch (FilloException e) {
            connection.close();
            e.printStackTrace();
        }
        return result;
    }


    /**
     * method to update the excel with set of values corresponding to attributes like
     *
     * @param strTestCaseName
     */
    public void updateTestData(String strTestCaseName) {
        try {
            connection = fillo.getConnection(EXCEL_FIL_NAME);
            String strDO = System.getProperty("DO_NUMBERS");
            String strQuery = "Update Test_Data Set TD_Distribution_Order = '" + strDO + "' where TD_Test_Case_ID = '" + strTestCaseName + "' ";
            connection.executeUpdate(strQuery);
            connection.close();
        } catch (FilloException e) {
            e.printStackTrace();
            connection.close();
        }
    }

    public List<String> getDependentTestCase(String strTestCaseName) {
        try {
            List<String> strDependentTestCase = new ArrayList<>();

            connection = fillo.getConnection(NALC_OB_DATA);

            String strQuery = "SELECT Test_Case_Name FROM NALC_OutBound_Dependency where DependentIntTestCase = '" + strTestCaseName + "' ";
            Recordset rs = connection.executeQuery(strQuery);
            while (rs.next()) {
                strDependentTestCase.add(rs.getField("Test_Case_Name"));
            }
            connection.close();
            return strDependentTestCase;
        } catch (FilloException e) {
            e.printStackTrace();
            connection.close();
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    public void updateExcelSheet(Map<String, Object> testdata, Map<String, Object> intData) {
        //<xmlfilepath><![CDATA[D:\25-09-2016\nike-tech-wms-sql\target\NALC\NALC_XML\OB_1014_PW03AT_HP_08_SW_INT1_CARTON_FROM_CARTON_RESERVES.xml]]></xmlfilepath>
        String op = "";
        String strTestCaseName = "";
        String strDO = System.getProperty("DO_NUMBERS");
        String strTaskId = "";
        String strItemNames = "";

        if (System.getProperty("INT_FOUND").equalsIgnoreCase("yes")) {
            String tcName = testdata.get("xmlfilepath").toString();
            strTestCaseName = tcName.substring(tcName.lastIndexOf("\\") + 1, tcName.indexOf(".xml"));
            Set<String> name = new HashSet<>();
            List<String> names = new ArrayList<>();
            int j = 0;

            for (Map.Entry<String, Object> info : intData.entrySet()) {
                names = (ArrayList<String>) info.getValue();
                String temp = "";
                for (j = 0; j < names.size() - 1; j++) {
                    if (names.size() == 1)
                        break;
                    temp = temp + names.get(j) + ",";
                }
                temp = temp + names.get(j);
                if (info.getKey().equalsIgnoreCase("Task ID")) {
                    strTaskId = temp;
                } else if (info.getKey().equalsIgnoreCase("Item Names")) {
                    strItemNames = temp;
                }
                op = op + info.getKey() + ":" + temp + "\n";
            }
        } else
            op = "INT Not generated";
        try {

            try {
                FlatFileGenerator.createFlatFile(NALC_LOG_FILE_PATH);
                List<String> strDependentTestCases = getDependentTestCase(strTestCaseName);
                connection = fillo.getConnection(EXCEL_FIL_NAME);
                strDO = System.getProperty("DO_NUMBERS");

                DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
                //get current date time with Date()
                Date date = new Date();

                FlatFileGenerator.appendDataToFlatFile("------------------------------------------------------ \n");
                FlatFileGenerator.appendDataToFlatFile("Execution Date time : " + dateFormat.format(date) + " \n");
                FlatFileGenerator.appendDataToFlatFile("Test Case Name " + strTestCaseName + "\n");
                FlatFileGenerator.appendDataToFlatFile("------------------------------------------------------ \n");
                FlatFileGenerator.appendDataToFlatFile("DO Num : " + strDO + " \n");
                FlatFileGenerator.appendDataToFlatFile("Item Name : " + strItemNames + " \n");
                FlatFileGenerator.appendDataToFlatFile("Task Id : " + strTaskId + " \n");

                String strQuery = "Update Test_Data Set TD_Distribution_Order = '" + strDO + "' " +
                        ", TD_TASKID = '" + strTaskId + "'" +
                        ", TD_TaskID = '" + strTaskId + "'" +
                        ", TD_ITEM_NAME = '" + strItemNames + "'" +
                        " where TD_Test_Case_ID = '" + strTestCaseName + "' ";
                connection.executeUpdate(strQuery);

                //Updating the same value to dependent test cases
                FlatFileGenerator.appendDataToFlatFile("Dependent Test Case Name \n");
                FlatFileGenerator.appendDataToFlatFile("------------------------------------------------------\n");
                for (String strDependentTestCase : strDependentTestCases) {
                    String strQuery1 = "Update Test_Data Set TD_Distribution_Order = '" + strDO + "' " +
                            ", TD_TASKID = '" + strTaskId + "'" +
                            ", TD_TaskID = '" + strTaskId + "'" +
                            ", TD_ITEM_NAME = '" + strItemNames + "'" +
                            " where TD_Test_Case_ID = '" + strDependentTestCase + "' ";
                    connection.executeUpdate(strQuery1);
                    System.out.println("Dependent Test Case Updated: " + strDependentTestCase);
                    FlatFileGenerator.appendDataToFlatFile("   " + strDependentTestCase + " \n");
                }
                FlatFileGenerator.closeFlatFile();
                connection.close();
            } catch (FilloException e) {
                e.printStackTrace();
                connection.close();
                FlatFileGenerator.closeFlatFile();
            }
        } catch (Exception e) {
            e.printStackTrace();
            connection.close();
        }
    }
}