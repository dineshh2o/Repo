package tech.nike.automation.common.framework.tools;

/**
 * Created by PSibb1 on 8/20/2016.
 */

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.awt.image.BufferedImage;
import java.util.concurrent.TimeUnit;

public class CaptureScreenshot {

    //public static void captureFullScreen() {
    public static void main(String[] a) {
        ExtentReports extent = new ExtentReports("C\\AVideo", true);
        //starting - test
        ExtentTest test = extent.startTest("SampleTest", "Test reporting format");
        WebDriver driver;
        System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chromedriver.exe");
        //System.setProperty("webdriver.ie.driver", "C:\\selenium\\IEDriverServer.exe");
        driver = new ChromeDriver();
        // driver = new InternetExplorerDriver();
        // maximize the browser window
        driver.manage().window().maximize();
        test.log(LogStatus.PASS, "Browser invoked successfully");
        driver.get("http://zero.nike.com");
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        test.log(LogStatus.PASS, "User navigated to application home page successfully");
        // This code will capture screenshot of current screen
        BufferedImage image = null;
        /*try {
            image = new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
            // This will store screenshot on Specific location
            ImageIO.write(image, "png", new File("C:\\AVideo\\CurrentScreenshot.png"));
        } catch (AWTException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }*/
        driver.close();
    }
}