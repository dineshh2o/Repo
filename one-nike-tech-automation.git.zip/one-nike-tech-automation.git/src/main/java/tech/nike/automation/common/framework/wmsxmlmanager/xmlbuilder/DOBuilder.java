package tech.nike.automation.common.framework.wmsxmlmanager.xmlbuilder;

import org.apache.commons.logging.LogFactory;
import tech.nike.automation.common.framework.core.Log;

/**
 * Created by psibb1 on 3/8/2017.
 */
public class DOBuilder {

    private Log myLog = (Log) LogFactory.getLog(DOBuilder.class);


}
