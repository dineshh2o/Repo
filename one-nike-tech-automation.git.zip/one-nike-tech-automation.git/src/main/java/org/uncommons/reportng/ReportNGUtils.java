//=============================================================================
// Copyright 2006-2010 Daniel W. Dyer
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//=============================================================================
package org.uncommons.reportng;

import com.google.common.collect.ImmutableList;
import org.testng.*;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Utility class that provides various helper methods that can be invoked
 * from a Velocity template.
 *
 * @author Cognizant Technology CoE
 */
public class ReportNGUtils {
    private static final NumberFormat DURATION_FORMAT = new DecimalFormat("#0.000");
    private static final Comparator<ITestNGMethod> METHOD_COMPARATOR = new TestMethodComparator();
    private static final Comparator<ITestResult> RESULT_COMPARATOR = new TestResultComparator();
    private static final Comparator<IClass> CLASS_COMPARATOR = new TestClassComparator();

    /**
     * Returns true if this TestResult has an iteration attribute.
     *
     * @param testResult TestResult to check
     * @return True if has iteration attribute, else false
     */
    public static boolean hasIterationCount(ITestResult testResult) {
        return testResult.getAttribute("iteration") != null;
    }

    /**
     * Returns the Iteration count of this TestResult
     *
     * @param testResult TestResult to get iteration count of
     * @return Iteration count of testResult, or -1 if TestResult doesn't have an iteration count
     */
    public static int getIterationCount(ITestResult testResult) {
        if (hasIterationCount(testResult)) {
            return (Integer) testResult.getAttribute("iteration");
        }
        return -1;
    }

    public static String getArguments(ITestResult result) {
        Object[] arguments = result.getParameters();
        List<String> argumentStrings = new ArrayList<String>(arguments.length);
        for (Object argument : arguments) {
            argumentStrings.add(renderArgument(argument));
        }
        return commaSeparate(argumentStrings);
    }

    /**
     * Decorate the string representation of an argument to give some
     * hint as to its type (e.g. render Strings in double quotes).
     *
     * @param argument The argument to render.
     * @return The string representation of the argument.
     */
    private static String renderArgument(Object argument) {
        if (argument == null) {
            return "null";
        } else if (argument instanceof String) {
            return "\"" + argument + "\"";
        } else if (argument instanceof Character) {
            return "\'" + argument + "\'";
        } else {
            return argument.toString();
        }
    }

    /**
     * Takes a list of Strings and combines them into a single comma-separated
     * String.
     *
     * @param strings The Strings to combine.
     * @return The combined, comma-separated, String.
     */
    private static String commaSeparate(Collection<String> strings) {
        StringBuilder buffer = new StringBuilder();
        Iterator<String> iterator = strings.iterator();
        while (iterator.hasNext()) {
            String string = iterator.next();
            buffer.append(string);
            if (iterator.hasNext()) {
                buffer.append(", ");
            }
        }
        return buffer.toString();
    }

    /**
     * Returns a comma delimited string of the contents of an array
     *
     * @param objects Object[] you want to format as string
     * @return String version of Object[]
     */
    public static String arrayToString(Object[] objects) {
        StringBuilder buffer = new StringBuilder();
        Iterator<Object> iterator = Arrays.asList(objects).iterator();
        while (iterator.hasNext()) {
            Object argument = iterator.next();
            String argumentAsString;
            if (argument == null) {
                argumentAsString = "null";
            } else if (argument instanceof String) {
                argumentAsString = "\"" + argument + "\"";
            } else if (argument instanceof Character) {
                argumentAsString = "\'" + argument + "\'";
            } else {
                argumentAsString = argument.toString();
            }
            buffer.append(argumentAsString);
            if (iterator.hasNext())
                buffer.append(", ");
        }
        return buffer.toString();
    }

    /**
     * Returns the aggregate of the elapsed times for each test result.
     *
     * @param context The test results.
     * @return The sum of the test durations.
     */
    public long getDuration(ITestContext context) {
        long duration = getDuration(context.getPassedConfigurations().getAllResults());
        duration += getDuration(context.getPassedTests().getAllResults());
        // You would expect skipped tests to have durations of zero, but apparently not.
        duration += getDuration(context.getSkippedConfigurations().getAllResults());
        duration += getDuration(context.getSkippedTests().getAllResults());
        duration += getDuration(context.getFailedConfigurations().getAllResults());
        duration += getDuration(context.getFailedTests().getAllResults());
        return duration;
    }

    /**
     * Gets a sorted TestResults collection for a given TestContext
     *
     * @param context TestContext to build from
     * @return sorted TestsResults collection
     */
    public TestResults getTestResults(ITestContext context) {
        return new TestResults(context);
    }

    /**
     * Returns the css class for the result element
     *
     * @param result result you want to display
     * @return css class to add to result element
     */
    public String getResultClass(ITestResult result) {
        switch (result.getStatus()) {
            case ITestResult.SUCCESS:
                return "succeeded";
            case ITestResult.FAILURE:
                return "failed";
            case ITestResult.SKIP:
                return "skipped";
        }
        return "";
    }

    /**
     * Returns the aggregate of the elapsed times for each test result.
     *
     * @param results A set of test results.
     * @return The sum of the test durations.
     */
    public long getDuration(Set<ITestResult> results) {
        long duration = 0;
        for (ITestResult result : results) {
            duration += (result.getEndMillis() - result.getStartMillis());
        }
        return duration;
    }

    public String formatDuration(long startMillis, long endMillis) {
        long elapsed = endMillis - startMillis;
        return formatDuration(elapsed);
    }

    public String formatDuration(long elapsed) {
        double seconds = (double) elapsed / 1000;
        return DURATION_FORMAT.format(seconds);
    }

    /**
     * Group test methods by class and sort alphabetically.
     */
    public SortedMap<IClass, List<ITestResult>> sortByTestClass(Set<ITestResult> results) {
        SortedMap<IClass, List<ITestResult>> sortedResults = new TreeMap<IClass, List<ITestResult>>(CLASS_COMPARATOR);
        for (ITestResult result : results) {
            List<ITestResult> resultsForClass = sortedResults.get(result.getTestClass());
            if (resultsForClass == null) {
                resultsForClass = new ArrayList<ITestResult>();
                sortedResults.put(result.getTestClass(), resultsForClass);
            }
            int index = Collections.binarySearch(resultsForClass, result, RESULT_COMPARATOR);
            if (index < 0) {
                index = Math.abs(index + 1);
            }
            resultsForClass.add(index, result);
        }
        return sortedResults;
    }

    /**
     * Sorts groups alphabetically and also sorts methods within groups alphabetically
     * (class name first, then method name).  Also eliminates duplicate entries.
     */
    public SortedMap<String, SortedSet<ITestNGMethod>> sortGroups(Map<String, Collection<ITestNGMethod>> groups) {
        SortedMap<String, SortedSet<ITestNGMethod>> sortedGroups = new TreeMap<String, SortedSet<ITestNGMethod>>();
        for (Map.Entry<String, Collection<ITestNGMethod>> entry : groups.entrySet()) {
            SortedSet<ITestNGMethod> methods = new TreeSet<ITestNGMethod>(METHOD_COMPARATOR);
            methods.addAll(entry.getValue());
            sortedGroups.put(entry.getKey(), methods);
        }
        return sortedGroups;
    }

    /**
     * Convert a Throwable into a list containing all of its causes.
     *
     * @param t The throwable for which the causes are to be returned.
     * @return A (possibly empty) list of {@link Throwable}s.
     */
    public List<Throwable> getCauses(Throwable t) {
        List<Throwable> causes = new LinkedList<Throwable>();
        Throwable next = t;
        while (next.getCause() != null) {
            next = next.getCause();
            causes.add(next);
        }
        return causes;
    }

    /**
     * Retrieves all log messages associated with a particular test result.
     *
     * @param result Which test result to look-up.
     * @return A list of log messages.
     */
    public List<String> getTestOutput(ITestResult result) {
        return Reporter.getOutput(result);
    }

    public List<OutputNode> batchOutput(List<String> lines) {
        List<OutputNode> topLevelNodes = new ArrayList<OutputNode>();

        OutputNode currentTestStepNode = null;
        OutputNode currentSeStepNode = null;
        for (String line : lines) {
            switch (OutputLineType.detectType(line)) {
                case summary:
                case testStep:
                    currentTestStepNode = new OutputNode(line);
                    topLevelNodes.add(currentTestStepNode);
                    break;
                case seStep:
                    if (currentTestStepNode == null) {
                        currentTestStepNode = new OutputNode(null);
                        topLevelNodes.add(currentTestStepNode);
                    }
                    currentSeStepNode = new OutputNode(line);
                    currentTestStepNode.addChild(currentSeStepNode);
                    break;
                case assertion:
                case traceStep:
                case plain:
                    if (currentTestStepNode == null) {
                        currentTestStepNode = new OutputNode(null);
                        topLevelNodes.add(currentTestStepNode);
                    }
                    if (currentSeStepNode == null) {
                        currentSeStepNode = new OutputNode(null);
                        currentTestStepNode.addChild(currentSeStepNode);
                    }
                    OutputNode newLine = new OutputNode(line);
                    if (PassFail.detectType(line) == PassFail.fail || PassFail.detectType(line) == PassFail.error) {
                        currentTestStepNode.flagError();
                        currentSeStepNode.flagError();
                        newLine.flagError();
                    }
                    currentSeStepNode.addChild(newLine);
                    break;
                default:
                    throw new UnsupportedOperationException();
            }
        }
        return topLevelNodes;
    }

    /**
     * Retieves the output from all calls to {@link org.testng.Reporter#log(String)}
     * across all tests.
     *
     * @return A (possibly empty) list of log messages.
     */
    public List<String> getAllOutput() {
        return Reporter.getOutput();
    }

    public boolean hasArguments(ITestResult result) {
        return result.getParameters().length > 0;
    }

    /**
     * @param result The test result to be checked for dependent groups.
     * @return True if this test was dependent on any groups, false otherwise.
     */
    public boolean hasDependentGroups(ITestResult result) {
        return result.getMethod().getGroupsDependedUpon().length > 0;
    }

    /**
     * @return A comma-separated string listing all dependent groups.  Returns an
     * empty string it there are no dependent groups.
     */
    public String getDependentGroups(ITestResult result) {
        String[] groups = result.getMethod().getGroupsDependedUpon();
        return commaSeparate(Arrays.asList(groups));
    }

    /**
     * @param result The test result to be checked for dependent methods.
     * @return True if this test was dependent on any methods, false otherwise.
     */
    public boolean hasDependentMethods(ITestResult result) {
        return result.getMethod().getMethodsDependedUpon().length > 0;
    }

    /**
     * @return A comma-separated string listing all dependent methods.  Returns an
     * empty string it there are no dependent methods.
     */
    public String getDependentMethods(ITestResult result) {
        String[] methods = result.getMethod().getMethodsDependedUpon();
        return commaSeparate(Arrays.asList(methods));
    }

    public boolean hasSkipException(ITestResult result) {
        return result.getThrowable() instanceof SkipException;
    }

    public String getSkipExceptionMessage(ITestResult result) {
        return hasSkipException(result) ? result.getThrowable().getMessage() : "";
    }

    public boolean hasGroups(ISuite suite) {
        return !suite.getMethodsByGroups().isEmpty();
    }

    /**
     * Replace any angle brackets, quotes, apostrophes or ampersands with the
     * corresponding XML/HTML entities to avoid problems displaying the String in
     * an XML document.  Assumes that the String does not already contain any
     * entities (otherwise the ampersands will be escaped again).
     *
     * @param s The String to escape.
     * @return The escaped String.
     */
    public String escapeString(String s) {
        if (s == null) {
            return null;
        }

        StringBuilder buffer = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            buffer.append(escapeChar(s.charAt(i)));
        }
        return buffer.toString();
    }

    /**
     * Converts a char into a String that can be inserted into an XML document,
     * replacing special characters with XML entities as required.
     *
     * @param character The character to convert.
     * @return An XML entity representing the character (or a String containing
     * just the character if it does not need to be escaped).
     */
    private String escapeChar(char character) {
        switch (character) {
            case '<':
                return "&lt;";
            case '>':
                return "&gt;";
            case '"':
                return "&quot;";
            case '\'':
                return "&apos;";
            case '&':
                return "&amp;";
            default:
                return String.valueOf(character);
        }
    }

    /**
     * Works like {@link #escapeString(String)} but also replaces line breaks with
     * &lt;br /&gt; tags and preserves significant whitespace.
     *
     * @param s The String to escape.
     * @return The escaped String.
     */
    public String escapeHTMLString(String s) {
        if (s == null) {
            return null;
        }

        StringBuilder buffer = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            switch (ch) {
                case ' ':
                    // All spaces in a block of consecutive spaces are converted to
                    // non-breaking space (&nbsp;) except for the last one.  This allows
                    // significant whitespace to be retained without prohibiting wrapping.
                    char nextCh = i + 1 < s.length() ? s.charAt(i + 1) : 0;
                    buffer.append(nextCh == ' ' ? "&nbsp;" : " ");
                    break;
                case '\n':
                    buffer.append("<br/>\n");
                    break;
                default:
                    buffer.append(escapeChar(ch));
            }
        }
        return buffer.toString();
    }

    /**
     * TestNG returns a compound thread ID that includes the thread name and its numeric ID,
     * separated by an 'at' sign.  We only want to use the thread name as the ID is mostly
     * unimportant and it takes up too much space in the generated report.
     *
     * @param threadId The compound thread ID.
     * @return The thread name.
     */
    public String stripThreadName(String threadId) {
        if (threadId == null) {
            return null;
        } else {
            int index = threadId.lastIndexOf('@');
            return index >= 0 ? threadId.substring(0, index) : threadId;
        }
    }

    /**
     * Find the earliest start time of the specified methods.
     *
     * @param methods A list of test methods.
     * @return The earliest start time.
     */
    public long getStartTime(List<IInvokedMethod> methods) {
        long startTime = System.currentTimeMillis();
        for (IInvokedMethod method : methods) {
            startTime = Math.min(startTime, method.getDate());
        }
        return startTime;
    }

    public long getEndTime(ISuite suite, IInvokedMethod method, List<IInvokedMethod> methods) {
        boolean found = false;
        for (IInvokedMethod m : methods) {
            if (m == method) {
                found = true;
            }
            // Once a method is found, find subsequent method on same thread.
            else if (found && m.getTestMethod().getId().equals(method.getTestMethod().getId())) {
                return m.getDate();
            }
        }
        return getEndTime(suite, method);
    }

    /**
     * Returns the timestamp for the time at which the suite finished executing.
     * This is determined by finding the latest end time for each of the individual
     * tests in the suite.
     *
     * @param suite The suite to find the end time of.
     * @return The end time (as a number of milliseconds since 00:00 1st January 1970 UTC).
     */
    private long getEndTime(ISuite suite, IInvokedMethod method) {
        // Find the latest end time for all tests in the suite.
        for (Map.Entry<String, ISuiteResult> entry : suite.getResults().entrySet()) {
            ITestContext testContext = entry.getValue().getTestContext();
            for (ITestNGMethod m : testContext.getAllTestMethods()) {
                if (method == m) {
                    return testContext.getEndDate().getTime();
                }
            }
            // If we can't find a matching test method it must be a configuration method.
            for (ITestNGMethod m : testContext.getPassedConfigurations().getAllMethods()) {
                if (method == m) {
                    return testContext.getEndDate().getTime();
                }
            }
            for (ITestNGMethod m : testContext.getFailedConfigurations().getAllMethods()) {
                if (method == m) {
                    return testContext.getEndDate().getTime();
                }
            }
        }
        throw new IllegalStateException("Could not find matching end time.");
    }


    private enum OutputLineType {
        testStep("class=test-step"),
        traceStep("class=trace-step"),
        seStep("class=se-step"),
        assertion("class=assertion"),
        summary("class=summary"),
        plain(null);

        String matcher;

        OutputLineType(String matcher) {
            this.matcher = matcher;
        }

        public static OutputLineType detectType(String line) {
            for (OutputLineType outputLineType : values()) {
                if (outputLineType.matcher != null && line.contains(outputLineType.matcher))
                    return outputLineType;
            }
            return plain;
        }
    }


    private enum PassFail {
        pass("class='pass-screenshot'"),
        fail("class='fail-screenshot'"),
        error("class='error-screenshot'"),
        plain(null);

        String matcher;

        PassFail(String matcher) {
            this.matcher = matcher;
        }

        public static PassFail detectType(String line) {
            for (PassFail passFail : values()) {
                if (passFail.matcher != null && line.contains(passFail.matcher))
                    return passFail;
            }
            return plain;
        }
    }

    public static class OutputNode {
        public String line;
        public List<OutputNode> children;
        public boolean hasError;

        public OutputNode(String line) {
            this.line = line;
            this.children = new ArrayList<OutputNode>();
            this.hasError = false;
        }

        public void addChild(OutputNode childNode) {
            children.add(childNode);
        }

        public boolean isHasChildren() {
            return !children.isEmpty();
        }

        public List<OutputNode> getChildren() {
            return ImmutableList.copyOf(children);
        }

        public String getLine() {
            return line;
        }

        public String getLineWithPlaceholders() {
            // <img src='" + couchAttachmentUrl + "'>
            Pattern p = Pattern.compile("<img src=['\"](http://[^/]+/test_results/[^'\"]+)['\"]>");
            Matcher m = p.matcher(line);
            StringBuffer sb = new StringBuffer();
            while (m.find()) {
                m.appendReplacement(sb, "<span class='imgplaceholder' data-src='$1'>Loading...</span>");
            }
            m.appendTail(sb);
            return sb.toString();
        }

        public boolean isHasError() {
            return hasError;
        }

        public void flagError() {
            hasError = true;
        }

        @Override
        public String toString() {
            return "OutputNode{"
                    + children.size() +
                    ", " + hasError +
                    ", '" + line + '\'' +
                    '}';
        }
    }

}
