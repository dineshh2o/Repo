package org.uncommons.reportng;

import org.apache.log4j.Logger;
import org.junit.internal.AssumptionViolatedException;
import org.junit.runner.Description;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import org.junit.runner.notification.RunListener;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.*;
import java.io.File;
import java.io.IOException;

public class PerformanceRunListener extends RunListener {

    // add additional 1 seconds on average time to create warning message.
    private static final int additionalDurationMillis = 1000;
    // xml node values
    private static final String performanceElemName = "performance";
    private static final String testElemName = "test";
    private static final String testNameAttrName = "name";
    private static final String testTimeStampAttrName = "timestamp";
    private static final String testRuntimeElemName = "runtime";
    private static final String fileAttrName = "file";
    Logger logger = Logger.getLogger(this.getClass().getName());
    Document document;

    private long startTime = 0;
    private boolean isTestFailing;
    private String className;
    private long runTimeThreshold;
    private boolean isActivate;

    /**
     * Called before any tests have been run.
     *
     * @param description describes the tests to be run
     */
    @Override
    public void testRunStarted(Description description) throws Exception {
        isActivate = System.getProperty("report.performance.activate").equals("true");
    }

    /**
     * Called when all tests have finished
     *
     * @param result the summary of the test run, including all the tests that failed
     */
    @Override
    public void testRunFinished(Result result) throws Exception {
        logger.debug("testRunFinished:: runCount: " + result.getRunCount() + " runTime: " + result.getRunTime());
        if (isActivate)
            this.writeXML();
    }

    /**
     * Called when an atomic test is about to be started.
     *
     * @param description the description of the test that is about to be run
     *                    (generally a class and method name)
     */
    @Override
    public void testStarted(Description description) throws Exception {
        if (isActivate) {
            if (className == null) {
                className = description.getClassName();
            } else if (!className.equals(description.getClassName())) {
                // This is new class, so we are saving the xml document with
                // old class information.
                this.writeXML();
                className = description.getClassName();
                // set document as null, so we open up the new xml for this class.
                document = null;
            }

            startTime = System.currentTimeMillis();
            isTestFailing = false;
            runTimeThreshold = this.getPastAverageRuntime(description.getMethodName());
        }
    }

    /**
     * Called when an atomic test has finished, whether the test succeeds or fails.
     *
     * @param description the description of the test that just ran
     */
    @Override
    public void testFinished(Description description) throws Exception {
        logger.debug("testFinished:: className: " +
                description.getClassName() + "method: " + description.getMethodName());
        if (isActivate) {
            if (!this.isTestFailing) {
                long runtime = System.currentTimeMillis() - startTime;
                this.logRunTime(description.getMethodName(), runtime);
                if (this.runTimeThreshold > 0) { // if there is no history, skip it.
                    long threshold = this.runTimeThreshold + additionalDurationMillis;
                    if (threshold < runtime) {

                        logger.warn(
                                "Test " + description.getMethodName() +
                                        " took much longer than past average runtime." +
                                        " Please check your test" +
                                        " => threshold: " + this.runTimeThreshold +
                                        " runtime: " + runtime
                        );

                    }
                }
            }
        }
    }

    /**
     * Called when an atomic test fails.
     *
     * @param failure describes the test that failed and the exception that was thrown
     */
    @Override
    public void testFailure(Failure failure) throws Exception {

    }

    /**
     * Called when an atomic test flags that it assumes a condition that is
     * false
     *
     * @param failure describes the test that failed and the
     *                {@link AssumptionViolatedException} that was thrown
     */
    @Override
    public void testAssumptionFailure(Failure failure) {
        isTestFailing = true;
    }

    private long getPastAverageRuntime(String methodName) {

        Document doc = this.getLogDoc();
        XPathFactory xPathfactory = XPathFactory.newInstance();
        XPath xpath = xPathfactory.newXPath();
        long average = 0;
        try {
            XPathExpression expr = xpath.compile(
                    "/" + performanceElemName + "/" + testElemName
                            + "[@" + testNameAttrName + "='" + methodName + "']/"
                            + testRuntimeElemName + "/text()"
            );
            NodeList nl = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
            int count = nl.getLength();
            if (count > 0) {
                for (int i = 0; i < nl.getLength(); i++) {

                    Node node = nl.item(i);
                    long value = Long.parseLong(node.getTextContent());
                    average += value;

                }
                average /= count;
            }
        } catch (XPathExpressionException e) {
            e.printStackTrace();
        }
        return average;
    }

    private void logRunTime(String methodName, long runtime) {
        Document doc;
        long timestamp = System.currentTimeMillis();
        try {
            doc = this.getLogDoc();

            Element testElem = doc.createElement(testElemName);
            Attr nameAttr = doc.createAttribute(testNameAttrName);
            nameAttr.setValue(methodName);
            testElem.setAttributeNode(nameAttr);
            Attr timestampAttr = doc.createAttribute(testTimeStampAttrName);
            timestampAttr.setValue(String.valueOf(timestamp));
            testElem.setAttributeNode(timestampAttr);

            Element runtimeElem = doc.createElement(testRuntimeElemName);
            runtimeElem.appendChild(doc.createTextNode(String.valueOf(runtime)));
            testElem.appendChild(runtimeElem);
            doc.getDocumentElement().appendChild(testElem);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void writeXML() {
        // Write the content into xml file
        try {
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            DOMSource source = new DOMSource(this.getLogDoc());
            String filename = getLogFilePath(this.className);
            StreamResult result = new StreamResult(filename);

            transformer.transform(source, result);
        } catch (TransformerException tfe) {
            tfe.printStackTrace();
        }
    }

    private String getLogFilePath(String className) {
        String path = System.getProperty("report.performance.dir");
        File reportDir = new File(path);
        if (!reportDir.exists()) {
            boolean result = reportDir.mkdirs();
            if (!result) {
                logger.warn("Cannot create the performance report folder: " + reportDir.getAbsolutePath());
            }
        }
        return path + "/" + className + ".xml";
    }

    private Document getLogDoc() {

        if (document != null) {
            return document;
        }

        String filePath = this.getLogFilePath(className);
        File file = new File(filePath);

        if (file.exists()) {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db;
            try {
                db = dbf.newDocumentBuilder();
                document = db.parse(new File(filePath));

            } catch (ParserConfigurationException e) {
                e.printStackTrace();
            } catch (SAXException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            document = this.createXML(className);
        }
        return document;

    }

    /**
     * <performance file=smoke_test.java>
     * <test name="test_name[iteration]" timestamp="0000">
     * <runtime>2.32<\runtime>
     * <\test>
     * <test name="test_name[iteration]" timestamp="0000">
     * <runtime>2.32<\runtime>
     * <\test>
     * <\performance>
     */
    private Document createXML(String className) {
        Document doc = null;
        try {
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = docFactory.newDocumentBuilder();

            // root elements
            doc = documentBuilder.newDocument();
            Element rootElement = doc.createElement(performanceElemName);
            Attr attr = doc.createAttribute(fileAttrName);
            attr.setValue(className);
            rootElement.setAttributeNode(attr);
            doc.appendChild(rootElement);

        } catch (ParserConfigurationException pce) {
            pce.printStackTrace();
        }
        return doc;
    }

}
