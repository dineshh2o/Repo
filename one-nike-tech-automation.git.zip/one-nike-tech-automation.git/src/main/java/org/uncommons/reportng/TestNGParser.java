package org.uncommons.reportng;


import com.google.common.base.Joiner;
import org.apache.commons.io.FileUtils;
import org.testng.*;
import org.testng.xml.XmlSuite;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collection;
import java.util.List;


/**
 * TestNG Test Parser Listener
 * This listener uses the TestNG TestRunner to loop through all the tests and
 * generate a text output file "report.txt" in the ITestContext.getOutputDirectory
 * The report format is CSV with "Test Name, Description, class, groups"
 * <p>
 * This listener uses the SkipException to take advantage of the TestNG runner
 * looping through all the tests and gathering the necessary data for reporting
 * Tests are skipped on purpose to generate the test list.
 */
public class TestNGParser implements IInvokedMethodListener, IReporter {

    /**
     * Force the test to skip
     *
     * @param method
     * @param testResult
     */
    @Override
    public void beforeInvocation(IInvokedMethod method, ITestResult testResult) {

        // force test skip to finish with reporting
        throw new SkipException("Force test to skip");
    }

    /**
     * Mandatory interface; not used by this listener.
     */
    @Override
    public void afterInvocation(IInvokedMethod method, ITestResult testResult) {
        // DO NOTHING
    }

    /**
     * Generate a test report of all tests.
     *
     * @param xmlSuites
     * @param iSuites
     * @param s
     */
    @Override
    public void generateReport(List<XmlSuite> xmlSuites, List<ISuite> iSuites, String s) {

        StringBuilder builder = new StringBuilder();
        builder.append("Test Name,Description,Class,Groups\n");
        String outputDir = new String();

        // loop through all nested suites gathering skipped tests.  The beforeInvocation() method
        // forces the tests to skip, hence gather results *only* for skipped tests
        for (ISuite suite : iSuites) {
            String suiteName = suite.getName();
            //Getting the results for the said suite
            for (ISuiteResult result : suite.getResults().values()) {
                ITestContext tc = result.getTestContext();
                outputDir = tc.getOutputDirectory();
                Collection<ITestNGMethod> skippedTests = tc.getSkippedTests().getAllMethods();

                // Report the Test Name, description, group, filename; enclose each
                // parameter in double-quotes to account for embedded commas
                for (ITestNGMethod test : skippedTests) {

                    String methodName = test.getMethodName();
                    String description = test.getDescription();
                    String groups = Joiner.on(",").join(test.getGroups());
                    String className = test.getRealClass().getName();

                    builder.append("\"" + methodName + "\",");
                    builder.append("\"" + description + "\",");
                    builder.append("\"" + className + "\",");
                    builder.append("\"" + groups + "\"\n");
                }
            }
        }

        // Dump to output file; use the outputDir used by the suite file
        try {
            File file = new File(outputDir + "/report.txt");
            FileUtils.forceMkdir(new File(outputDir));
            file.createNewFile();
            FileWriter outputStream = new FileWriter(file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter(outputStream);
            bw.write(builder.toString());
            bw.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}

