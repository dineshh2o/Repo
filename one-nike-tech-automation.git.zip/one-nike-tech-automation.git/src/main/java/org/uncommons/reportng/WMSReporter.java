package org.uncommons.reportng;

/**
 * Created by psibb1 on 1/19/2017.
 */

import com.relevantcodes.extentreports.*;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import tech.nike.automation.common.framework.core.Log;
import tech.nike.automation.common.framework.core.Selenium;

import java.io.File;

/**
 * Created by psibb1 on 1/19/2017.
 */


public class WMSReporter implements ITestListener {
    private ExtentReports reporter = new ExtentReports(System.getProperty("user.dir") +
            "/target/ExtentReports/ExtentReportsTestNG.html", true, DisplayOrder.NEWEST_FIRST, NetworkMode.ONLINE);
    private ExtentTest testReporter;
    Selenium se;
    Log log;

    public WMSReporter(){
        super();
    }


    @Override
    public void onTestStart(ITestResult result) {
        testReporter = reporter.startTest(result.getMethod().getMethodName(), "Some description");
        testReporter.log(LogStatus.INFO, "Starting test " + result.getMethod().getMethodName());
        reporter.addSystemInfo("Environment", "AT");
        reporter.assignProject("WMS DEMO");
        reporter.loadConfig(new File(System.getProperty("user.dir")+"/extent-config.xml"));
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        testReporter.log(LogStatus.INFO, result.getName());
        testReporter.log(LogStatus.PASS, "Test PASSED");
        if (result.getStatus() == ITestResult.SUCCESS) {
            String screenshot_path = captureScreenShot(se.myDriver, result.getName());
            String image = testReporter.addScreenCapture(screenshot_path);
            testReporter.log(LogStatus.PASS, "Title verification", image);
        }
        //reporter.endTest(testReporter);
        reporter.flush();
    }

    @Override
    public void onTestFailure(ITestResult iTestResult) {
        testReporter.log(LogStatus.FAIL, "Test Failed");
        testReporter.log(LogStatus.INFO, iTestResult.getName());
        testReporter.log(LogStatus.INFO, iTestResult.getThrowable());
        if (iTestResult.getStatus() == ITestResult.FAILURE) {
            String screenshot_path = captureScreenShot(se.myDriver, iTestResult.getName());
            String image = testReporter.addScreenCapture(screenshot_path);
            testReporter.log(LogStatus.FAIL, "Title verification", image);
        }
        //reporter.endTest(testReporter);
        reporter.flush();

    }

    @Override
    public void onTestSkipped(ITestResult iTestResult) {
        testReporter.log(LogStatus.FAIL, "Test Skipped");
        testReporter.log(LogStatus.INFO, iTestResult.getName());
    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult iTestResult) {

    }

    @Override
    public void onStart(ITestContext iTestContext) {

    }

    @Override
    public void onFinish(ITestContext context) {
        reporter.close();
    }


    // Other interface methods

    public static String captureScreenShot(WebDriver driver, String screenShotName) {
        try {
            TakesScreenshot ts = (TakesScreenshot) driver;
            File source = ts.getScreenshotAs(OutputType.FILE);
            String dest = new File("/target/ExtentReportsTestNG/").getAbsolutePath()+ screenShotName + ".png";
            File destination = new File(dest);
            FileUtils.copyFile(source, destination);
            System.out.println("Screen Shot taken");
            return dest;
        } catch (Exception e) {
            System.out.println("Exception while taking screen shot" + e.getMessage());
            return e.getMessage();
        }
    }
}

