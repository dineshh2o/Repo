package tech.nike.automation.wms.feature.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import tech.nike.automation.common.page.Page;

import java.util.List;

/**
 * Created by PSibb1 on 1/14/2017.
 */
public class WMSMessageQueuePage extends Page {

    public By txtEndPointName = By.cssSelector("[id='dataForm:filterId:field1value1'][type='text']");
    public By lstStatus = By.cssSelector("select[id='dataForm:filterId:field3value1']");
    public By btnApply = By.id("dataForm:filterId:filterIdapply");
    public By imgBackButton = By.id("backImage");
    public By imgQuickFilter = By.cssSelector("[id='filterId_fltrExpCol'][type='image']");
    public By txtStatusChangedFrom = By.id("as_bas3_in");
    public By txtStatusChangedTo = By.id("as_bas4_in");
    /*Search results locators*/
    public By lblMessageID = By.cssSelector("[id$='messageID_Column_Param_Text']");
    public By lblEndPointName = By.cssSelector("[id$='endPointName_Column_Param_Text']");
    public By lblWhenStatusChangedHeader = By.id("dataForm:clMessageListDataTable:whenStatusChanged_Header_Text");
    public By lblEventName = By.cssSelector("[id$='eventName_Column_Param_Text']");
    public By lblStatus = By.cssSelector("[id$='statusChanged_Column_Param_Text']");
    public By lblSourceUri = By.cssSelector("[id$='sourceURI_Column_Param_Text']");
    /*message info locators*/
    public By lblMessageInfo = By.id("dataForm:messageData");
    public By lblWhenStatusChanged = By.id("dataForm:whenStatusChanged");


    /**
     * method to search by end point name
     *
     * @param endPointName
     * @return
     */
    public boolean searchByEndPointName(String endPointName) {
        boolean result = false;
        //verify if the required field was displayed
        result = se.element.waitForElementToBeClickable(txtEndPointName);
        se.element.requireIsDisplayed("End Point Name text field", txtEndPointName);
        //enter the end point name
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtEndPointName, endPointName);
        //verify if required field was displayed
        se.element.requireIsDisplayed("Apply button", btnApply);
        //verify if the apply button was clickable
        result &= se.element.isClickable(btnApply);
        //click on the apply button
        se.element.clickElement(btnApply);
        //asynchronous page load
        se.element.waitBySleep(5000);
        //wait for the element to be displayed
        result &= se.myDriver.findElement(lblWhenStatusChangedHeader).isDisplayed();
        //verify search results displayed
        List<WebElement> endpoints = se.myDriver.findElements(lblEndPointName);
        result &= endpoints.size() > 0;
        for (WebElement point : endpoints) {
            String dispEndPointName = point.getText().trim();
            if (endPointName.equalsIgnoreCase(dispEndPointName)) {
                result &= true;
            } else {
                result &= false;
            }
        }
        return result;
    }

    /**
     * method to click column When Status Changed to sort records
     *
     * @return
     */
    public boolean sortByWhenStatusChanged() {
        boolean result = false;
        //verify if the required field was displayed
        se.element.requireIsDisplayed("When Status Changed column name", lblWhenStatusChangedHeader);
        //click on the column name to sort
        //to allow  click
        se.element.clickElement(lblWhenStatusChangedHeader);
        //asynchronous page load
        se.element.waitBySleep(3000);
        result = se.element.waitForElementIsDisplayed(lblWhenStatusChangedHeader);
        //to allow  click
        se.element.clickElement(lblWhenStatusChangedHeader);
        //asynchronous page load
        se.element.waitBySleep(3000);
        //wait for the table to be displayed
        result &= se.element.waitForElementIsDisplayed(lblWhenStatusChangedHeader);
        return result;
    }

    /**
     * method to verify the messaged by source uri and message info
     *
     * @param sourceUri
     * @param strLPN
     * @return
     */
    public String verifyMessagesBySourceUri(String sourceUri, String strLPN) {
        String timeStamp = "";
        int index = 0;
        //verify if the required field is displayed
        List<WebElement> uris = se.myDriver.findElements(lblSourceUri);
        if (uris.size() > 0)
            for (WebElement uri : uris) {
                //to avoid stable element exception
                uris = se.myDriver.findElements(lblSourceUri);
                String dispUri = uri.getText().trim();
                if (sourceUri.equalsIgnoreCase(dispUri)) {
                    //to allow double click
                    se.element.doubleClickElement(uri, 2);
                    /*Actions act = new Actions(se.myDriver);
                    act.moveToElement(uri).doubleClick().build().perform();*/
                    //wait for the message info to display
                    se.element.waitForElementIsDisplayed(lblMessageInfo);
                    String dispMessage = se.element.getText(lblMessageInfo).trim();
                    if (dispMessage.contains(strLPN)) {
                        timeStamp = se.element.getAttribute(lblWhenStatusChanged, "value").trim();
                        /*se.element.isClickable(imgBackButton);
                        //click on the back button and verify next message
                        se.element.clickElement(imgBackButton);
                        //asynchronous page load if not stale element exception is displayed
                        se.element.waitBySleep(20000);
                        //verify if the user navigated to previous screen
                        se.element.waitForElementIsDisplayed(txtEndPointName);*/
                        se.log.testStep("Verified the message "+dispMessage+ " successfully");
                        break;
                    } else {
                        //navigate back to previous screen if the messages don't match
                        se.element.isClickable(imgBackButton);
                        //click on the back button and verify next message
                        se.element.clickElement(imgBackButton);
                        //asynchronous page load if not stale element exception is displayed
                        se.element.waitBySleep(20000);
                        //verify if the user navigated to previous screen
                        se.element.waitForElementIsDisplayed(uri);
                        uris = se.myDriver.findElements(lblSourceUri);
                        uri = uris.get(index);
                    }
                }
                index = index + 1;
            }
        return timeStamp;
    }

    /**
     * method to get perform quick by When status changed from  & to where to = (from + 1 minute)
     *
     * @param endPointName
     * @param timeStamp
     * @return
     */
    public boolean quickSearchByTimeStampAndEndPointName(String endPointName, String timeStamp) {
        boolean result = false;
        //verify if required field was displayed
        se.element.requireIsDisplayed("Quick Filter field", imgQuickFilter);
        //verify if the quick filter button is clickable
        result = se.element.isClickable(imgQuickFilter);
        //click on the quick filter
        se.element.clickElement(imgQuickFilter);
        //asynchronous page load
        se.element.waitBySleep(3000);
        //wait for the when status change date field was displayed
        result &= se.element.waitForElementIsDisplayed(txtStatusChangedFrom);
        //enter the from date
        //result &= verifyEnteredTextIsCorrectlyDisplayed(txtStatusChangedFrom, timeStamp);
        //enter to the to date as from date + 1 minute
        //result &= verifyEnteredTextIsCorrectlyDisplayed(txtStatusChangedTo, Util.getWMSDateStamp(timeStamp, 1));
        //enter the end point name
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtEndPointName, endPointName);
        //veriyf if the apply button is clickable
        result &= se.element.isClickable(btnApply);
        //click on the apply button
        se.element.clickElement(btnApply);
        //asynchronous page load
        se.element.waitBySleep(5000);
        List<WebElement> rows = se.myDriver.findElements(lblEndPointName);
        result &= rows.size() >= 1;
        return result;
    }

    /**
     * method to verify the destination location info in the messages
     *
     * @param location
     * @return
     */
    public boolean verifyDestinationLocationByLocationID(String location, String strLPN) {
        boolean result = false;
        String destLoc = "";
        //verify if the required fields are displayed
        se.element.requireIsDisplayed("End Point Name in the search results", lblEndPointName);
        List<WebElement> rows = se.element.getElements(lblEndPointName);
        for (WebElement row : rows) {
            //to allow double click
            se.element.doubleClickElement(row, 2);
            /*Actions act = new Actions(se.myDriver);
            act.moveToElement(row).doubleClick().build().perform();*/
            //asynchronous page load
            se.element.waitBySleep(5000);
            //wait for the message info to display
            result = se.element.waitForElementIsDisplayed(lblMessageInfo);
            String dispMessage = se.element.getAttribute(lblMessageInfo, "value").trim();
            if (dispMessage.contains(location) && dispMessage.contains(strLPN)) {
                se.log.testStep("Verify the destination message "+dispMessage+" successfully");
                result &= true;
                /*se.element.isClickable(imgBackButton);
                //click on the back button and verify next message
                se.element.clickElement(imgBackButton);
                //asynchronous page load if not stale element exception is displayed
                se.element.waitBySleep(20000);
                //verify if the user navigated to previous screen
                se.element.waitForElementIsDisplayed(txtEndPointName);
                rows = se.myDriver.findElements(lblEndPointName);
                row = rows.get(index);*/
                break;
            } else {
                result &= false;
                break;
            }
        }
        return result;
    }
}