package tech.nike.automation.wms.feature.page;

import org.openqa.selenium.By;
import tech.nike.automation.common.page.Page;

/**
 * Created by PSibb1 on 1/16/2017.
 */
public class WMSVerifyASNsPage extends Page {

    /**
     * Locators
     */
    public By lblASNNumber = By.id("dataForm:asnValueInput");
    public By lblShippedUnits = By.id("dataForm:lva:dataTable:0:shunits5");
    public By lblReceivedUnits = By.id("dataForm:lva:dataTable:0:unitsSh5");
    public By lblVariance = By.id("dataForm:lva:dataTable:0:variance5");
    public By btnVerifyASN = By.cssSelector("[value='Verify ASN'][type='button']");


    /**
     * method to verify the ASN details by ASN number
     *
     * @param strASNNumber
     * @return
     */
    public String[] verifyASNDetails(String strASNNumber) {
        String shippedUnits;
        String receivedUnits;
        String variance;
        String[] arrItems = null;
        se.element.waitForElementIsDisplayed(lblASNNumber);
        String dispASN = se.element.getText(lblASNNumber).trim();
        if (dispASN.equalsIgnoreCase(strASNNumber)) {
            //Verify if the required field was displayed
            se.element.requireIsDisplayed("Shipped units text", lblShippedUnits);
            shippedUnits = se.element.getText(lblShippedUnits).trim();
            if (shippedUnits.length() > 0) {
                se.log.seStep("Shipped units was displayed as " + shippedUnits);
            }
            receivedUnits = se.element.getText(lblReceivedUnits).trim();
            if (receivedUnits.length() > 0) {
                se.log.seStep("Received units was displayed as " + receivedUnits);
            }
            variance = se.element.getText(lblVariance).trim();
            if (variance.length() > 0) {
                se.log.seStep("Variance units was displayed as " + variance);
            }
            arrItems = new String[]{shippedUnits, receivedUnits, variance};
        }
        return arrItems;
    }

    /**
     * method to navigate back to ASN screen
     * @return
     */
    public boolean navigateToASNScreen(){
        boolean result = false;
        //verify required was displayed
        se.element.requireIsDisplayed("Verify ASN button", btnVerifyASN);
        //verify if the Verify ASN button is clickable
        result = se.element.isClickable(btnVerifyASN);
        //click on the Verify ASN button
        se.element.clickElement(btnVerifyASN);
        return result;
    }
}