package tech.nike.automation.wms.feature.page;

import org.openqa.selenium.By;

/**
 * Created by psibb1 on 7/5/2016.
 */
public enum SystemCodeValidationType {

    NONE(
            "---None---",
            "-1"
    ),
    SYSTEM_CODE (
            "System Code",
            "S"
    );

    final String sysCode;
    final String value;


    SystemCodeValidationType(String sysCode, String value){
        this.sysCode = sysCode;
        this.value = value;
    }

    public String getValType(){
        return sysCode;
    }

    public String getValue(){
        return value;
    }
    public By getValTypeLocator(){
        return By.cssSelector(String.format("#ansEditStyle_23dc_1 [value = '%s']",this.value));
    }
}
