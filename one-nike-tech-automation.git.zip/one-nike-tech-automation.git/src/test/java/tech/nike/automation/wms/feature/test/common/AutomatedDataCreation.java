package tech.nike.automation.wms.feature.test.common;

import org.testng.annotations.Test;
import tech.nike.automation.common.framework.BaseTest;
import tech.nike.automation.common.framework.core.Browser;
import tech.nike.automation.common.framework.core.CommonBaseTest;
import tech.nike.automation.common.framework.core.Selenium;
import tech.nike.automation.common.utils.NikePageFactory;
import tech.nike.automation.common.utils.UpdateSyntheticXml;
import tech.nike.automation.wms.feature.page.WMSHomePage;
import tech.nike.automation.wms.feature.page.WMSLoginPage;

import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Created by psibb1 on 1/18/2017.
 */
public class AutomatedDataCreation extends BaseTest{
    UpdateSyntheticXml synData = new UpdateSyntheticXml();
    /**
     * Method to prepare xml data
     * @param se        : driver type used for test
     * @param params    : external file data parameters
     */
    @Test(description = "Test data generation", dataProvider = "browserXml", groups = {"indev"}, timeOut = 900000)
    @CommonBaseTest.TestData(fileName = "wms/testdata/ham/haminputdata.xml")
    public void verifyAutomatedDataPrepForSingleASN(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {

        //read input data from parametrized xml file
        String strUrl = (String) params.get("environment");

        //update synthetic xml file before posting
        se.assertion.verifyTrue("Pre-Requisite: Test data preparation",
                synData.updateSingleSkuASNDetailsInXML(params));

        //Garbage collection of failed steps
        testTearDown(se);
    }

    /**
     * Method to prepare xml data
     * @param se        : driver type used for test
     * @param params    : external file data parameters
     */
    @Test(description = "Test data generation", dataProvider = "browserXml", groups = {"indev"}, timeOut = 900000)
    @CommonBaseTest.TestData(fileName = "wms/testdata/herentals/herentalsinputdata.xml")
    public void verifyAutomatedDataPrepForMultiASN(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {

        //read input data from parametrized xml file
        String strUrl = (String) params.get("environment");

        //update synthetic xml file before posting
        se.assertion.verifyTrue("Pre-Requisite: Test data preparation",
                synData.updateMultipleSkuASNDetailsInXML(3, params));

        //Garbage collection of failed steps
        testTearDown(se);
    }


    /**
     * Method to prepare xml data
     * @param se        : driver type used for test
     * @param params    : external file data parameters
     */
    @Test(description = "Test data generation", dataProvider = "browserXml", groups = {"indev"}, timeOut = 900000)
    @CommonBaseTest.TestData(fileName = "wms/testdata/herentals/herinputdata.xml")
    public void verifyAutomatedDataPrepForMultiASNLPNITEMSingleShip(Browser.Browsers myBrowser,
                                                                    Selenium se, Map<String, Object> params) {

        //read input data from parametrized xml file
        String strUrl = (String) params.get("environment");

        //update synthetic xml file before posting
        se.assertion.verifyTrue("Pre-Requisite: Test data preparation",
                synData.updateOnlyASNDetailsInXML(params));

        //update synthetic xml file before posting
        se.assertion.verifyTrue("Pre-Requisite: Test data preparation",
                synData.updateMultipleSku18LPNDetailsInXML(17, 7, params));

        //Garbage collection of failed steps
        testTearDown(se);
    }

    /**
     * Method to post synthetic data into WMS
     *
     * @param myBrowser : browser type used for test
     * @param se        : driver type used for test
     * @param params    : external file data parameters
     */
    @Test(description = "post xml data in wms", dataProvider = "browserXml", groups = {"indev"},
            timeOut = 900000)
    @TestData(fileName = "wms/testdata/herentals/herentalsinputdata.xml")
    public void verifyPostXML(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);

        //read input data from parametrized xml file
        String strUrl = (String) params.get("environment");

        //invoke browser
        se.myDriver.get(strUrl);
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //verify user login to WMS
        se.assertion.verifyTrue("User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));

        //verify post xml is successful
        se.assertion.verifyTrue("post xml", wmsHomePageObject.verifyPostXML(params));

        //verify sign-out from wms
        se.assertion.verifyTrue("User clicked on sign-out", wmsHomePageObject.verifyAndClickSignOut());

        //verify sign-out from wms
        se.assertion.verifyTrue("user confirmed to sign-out", wmsHomePageObject.verifyAndClickConfirmSignOut());

        //Garbage collection of failed steps
        testTearDown(se);
    }
}