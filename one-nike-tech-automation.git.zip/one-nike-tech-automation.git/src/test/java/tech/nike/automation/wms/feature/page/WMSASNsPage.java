package tech.nike.automation.wms.feature.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import tech.nike.automation.common.page.Page;

import java.util.List;

/**
 * Created by PSibb1 on 1/16/2017.
 */
public class WMSASNsPage extends Page{
    /**
     * Locators
     */
    public By txtASNNumber = By.cssSelector("[alt='Find ASN'][type='text']");
    public By btnApply = By.cssSelector("[id*='apply'][title='Apply'][type='button'][style='cursor:pointer']");
    /*search result locators*/
    public By chkASNNumber = By.cssSelector("[type='checkbox'][id*='dataForm:ASNList_entityListView:dataTable']");
    public By lblASNNumber = By.cssSelector("[id$='TCASNIdString']");
    public By lblASNStatus = By.cssSelector("[id$='ASNStatusValueString']");
    public By btnView = By.id("dataForm:ASNList_commandbutton_View");
    public By btnMore = By.id("soheaderbuttonsmoreButton");
    /*menu locator under more */
    public By lnkVerifyASN = By.id("CTO_ASNList_VerifyASN_more");


    /**
     * method to search an ASN number by ASN number
     * @param strASNNumber
     * @return
     */
    public boolean searchByASNNumber(String strASNNumber){
        boolean result = false;
        //verify if required field was displayed
        se.element.requireIsDisplayed("ASN text field", txtASNNumber);
        //verify if the ASN text field was clickable
        result = se.element.isClickable(txtASNNumber);
        //enter asn number
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtASNNumber,strASNNumber);
        //verify if apply button was displayed
        se.element.requireIsDisplayed("Apply button", btnApply);
        //verify if the apply button was clickable
        result &= se.element.isClickable(btnApply);
        //click the apply button
        se.element.clickElement(btnApply);
        //wait for the results to be displayed
        result&= se.element.waitForElementIsDisplayed(chkASNNumber);
        return result ;
    }

    /**
     * select an ASN number for ASN list by ASN Number
     * @param ASNNumber
     * @return
     */
    public boolean selectASNNumber(String ASNNumber){
        boolean result = false;
        int index = 0;
        List<WebElement> asns = se.element.getElements(lblASNNumber);
        List<WebElement> askChecks = se.element.getElements(chkASNNumber);
        result = asns.size() > 0;
        for(WebElement asn:asns){
            String dispASN = asn.getText().trim();
            if(dispASN.equalsIgnoreCase(ASNNumber)){
                askChecks.get(index).click();
                se.log.testStep("Selected ASN "+ ASNNumber+" successfully");
                break;
            }
            index = index + 1;
        }
        return result ;
    }

    /**
     * method to navigate to Verify ASN details screen
     * @return
     */
    public boolean navigateToVerifyASN(){
        boolean result = false;
        //verify if required was displayed
        se.element.requireIsDisplayed("More button", btnMore);
        //verify if the more button was clickable
        result = se.element.isClickable(btnMore);
        //click on the More button
        se.element.clickElement(btnMore);
        //verify if the required field was displayed
        se.element.requireIsDisplayed("Verify ASN link", lnkVerifyASN);
        //click on the Verify ASN link
        se.element.clickElement(lnkVerifyASN);
        return result ;
    }

    /**
     * method to verify the ASN status after the VerifyASN is completed
     * @param strASN
     * @return
     */
    public boolean verifyASNStatusByASNNumber(String strASN, String status){
        boolean result = false;
        int index = 0;
        //wait for the page load
        result = se.element.waitForElementIsDisplayed(txtASNNumber);
        List<WebElement> asns = se.element.getElements(lblASNNumber);
        List<WebElement> rows = se.element.getElements(lblASNStatus);
        result &= rows.size() > 0;
        for(WebElement row :rows){
            String dispASN = asns.get(index).getText().trim();
            if(dispASN.equalsIgnoreCase(strASN)){
                String dispStatus = row.getText().trim();
                result &= dispStatus.equalsIgnoreCase(status);
                se.log.testStep("Verified the status of the ASN "+dispASN+" to be "+dispStatus);
                break;
            }
        }
        return result ;
    }

    /**
     * method to navigate to Verify ASN details screen
     * @return
     */
    public boolean clickViewASN(){
        boolean result = false;
        //verify if required was displayed
        se.element.requireIsDisplayed("View button", btnView);
        //verify if the more button was clickable
        result = se.element.isClickable(btnView);
        //click on the More button
        se.element.clickElement(btnView);
        return result ;
    }
}