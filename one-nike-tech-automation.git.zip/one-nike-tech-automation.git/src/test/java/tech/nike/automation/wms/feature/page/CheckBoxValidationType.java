package tech.nike.automation.wms.feature.page;

import org.openqa.selenium.By;

/**
 * Created by PSibb1 on 6/13/2016.
 */
public enum CheckBoxValidationType {
    NONE(
            "---None---",
            "-1",
            null,
            null
    ),
    ALPHA_NUMERIC (
            "Alpha Numeric",
            "A",
            "Y",
            "N"
    ),
    NUMERIC_ONLY (
            "Numeric Only",
            "N",
            "1",
            "0"
    ),
    YN_FLAG (
            "Y/N Flag",
            "F",
            null,
            null
    );

    final String valType;
    final String value;
    final String fieldOne;
    final String fieldTwo;


    CheckBoxValidationType(String valType, String value, String fieldOne, String fieldTwo){
        this.valType = valType;
        this.value = value;
        this.fieldOne = fieldOne;
        this.fieldTwo = fieldTwo;
    }

    public String getValType(){
        return valType;
    }

    public String getFieldOne(){
        return fieldOne;
    }

    public String getFieldTwo(){
        return fieldTwo;
    }

    public By getValTypeLocator (){
        return By.cssSelector(String.format("#ansEditStyle_1dc_1 [value = '%s']",this.value));
    }

    public By getFieldOneLocator() {
        String checkBoxVal = this.name();
        if (checkBoxVal.contains("ALPHA_NUMERIC")) {
            return By.id("quesType_1Adc_1");
        } else {
            return By.id("ansValidFrom_1Ndc_1");
        }
    }

     public By getFieldTwoLocator() {
         String checkBoxVal = this.name();
         if (checkBoxVal.contains("ALPHA_NUMERIC")) {
             return By.id("quesType_2Adc_1");
         } else {
             return By.id("ansValidTo_1Ndc_1");
         }
    }
}