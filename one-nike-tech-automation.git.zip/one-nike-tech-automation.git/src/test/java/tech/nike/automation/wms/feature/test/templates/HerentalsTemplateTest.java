package tech.nike.automation.wms.feature.test.templates;

import org.testng.annotations.Test;
import tech.nike.automation.common.framework.BaseTest;
import tech.nike.automation.common.framework.core.Browser;
import tech.nike.automation.common.framework.core.Selenium;
import tech.nike.automation.common.utils.NikePageFactory;
import tech.nike.automation.wms.feature.page.WMSHomePage;
import tech.nike.automation.wms.feature.page.WMSLoginPage;
import tech.nike.automation.wms.feature.page.WMSRunWaveTemplatesPage;
import tech.nike.automation.wms.feature.page.WMSShipWaveTemplatePage;
import tech.nike.automation.wms.feature.page.WMSTemplateRulePage;

import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Created by psibb1 on 6/23/2016.
 */
public class HerentalsTemplateTest extends BaseTest {

    /**
     * Test method to create a new routing wave template and verify the same
     *
     * @param myBrowser
     * @param se
     * @param params
     */
    @Test(description = "Add new routing wave template1: Routing Wave - BIG Non-Promo for Herentals DC", dataProvider = "browserXml",
            groups = {"refresh"}, timeOut = 900000, singleThreaded = true)
    @TestData(fileName = "templates/herentals/Herentals-00 Routing Wave - BIG Non-Promo - Auto.xml")
    public void createHerentalsRoutingWaveTemplate1(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSShipWaveTemplatePage wmsWaveTempPageObject =
                NikePageFactory.initElements(se.myDriver, WMSShipWaveTemplatePage.class);
        WMSRunWaveTemplatesPage wmsRunWavePageObject =
                NikePageFactory.initElements(se.myDriver, WMSRunWaveTemplatesPage.class);
        WMSTemplateRulePage wmsWaveRulePageObject =
                NikePageFactory.initElements(se.myDriver, WMSTemplateRulePage.class);

        //read input data from parametrized xml file
        String strUrl = (String)params.get("environment");

        //invoke browser
        se.myDriver.get(strUrl);
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //verify user login to WMS
        se.assertion.verifyTrue("User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));

        //verify navigate to system codes page
        se.assertion.verifyTrue("navigate to ship wave templates",
                wmsHomePageObject.menuNavigation("Configuration", "Ship Wave Templates"));

        //verify add template with/without special instructions
        se.assertion.verifyTrue("add a new template", wmsWaveTempPageObject.createANewShipWaveTemplate(params));

        //verify if the template with/without special instructions
        se.assertion.verifyTrue("verify the template", wmsWaveTempPageObject.verifyANewShipWaveTemplate(params));

        //verify delete a template
        //se.assertion.verifyTrue("delete a template", wmsWaveTempPageObject.deleteShipWaveTemplate(params));

        //verify navigate to Run waves
        se.assertion.verifyTrue("navigate to run waves",
                wmsHomePageObject.menuNavigation("Distribution", "Run Waves"));

        //navigate to run waves
        se.assertion.verifyTrue("navigate to run waves page", wmsRunWavePageObject.navigateToRunWaves(params));

        //add task criteria
        //se.assertion.verifyTrue("add task criteria", wmsWaveRulePageObject.addTaskCriteria(params));

        //navigate capacities
        se.assertion.verifyTrue("navigate capacities", wmsWaveRulePageObject.navigateToCapacities());

        //add capacities
        se.assertion.verifyTrue("add capacities", wmsWaveRulePageObject.addCapacities(params));

        //Creating new rule
        se.assertion.verifyTrue("Creation of New Rule", wmsWaveRulePageObject.addNewRules(params));

        //Garbage collection of failed steps
        testTearDown(se);
    }
    /**
     * Test method to create a new routing wave template and verify the same
     *
     * @param myBrowser
     * @param se
     * @param params
     */
    @Test(description = "Add new routing wave template2: Routing Wave - BIG Promo for Herentals DC", dataProvider = "browserXml",
            groups = {"refresh"}, timeOut = 900000, singleThreaded = true)
    @TestData(fileName = "templates/herentals/Herentals-00 Routing Wave - BIG Promo.xml")
    public void createHerentalsRoutingWaveTemplate2(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSShipWaveTemplatePage wmsWaveTempPageObject =
                NikePageFactory.initElements(se.myDriver, WMSShipWaveTemplatePage.class);
        WMSRunWaveTemplatesPage wmsRunWavePageObject =
                NikePageFactory.initElements(se.myDriver, WMSRunWaveTemplatesPage.class);
        WMSTemplateRulePage wmsWaveRulePageObject =
                NikePageFactory.initElements(se.myDriver, WMSTemplateRulePage.class);

        //read input data from parametrized xml file
        String strUrl = (String)params.get("environment");

        //invoke browser
        se.myDriver.get(strUrl);
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //verify user login to WMS
        se.assertion.verifyTrue("User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));

        //verify navigate to system codes page
        se.assertion.verifyTrue("navigate to ship wave templates",
                wmsHomePageObject.menuNavigation("Configuration", "Ship Wave Templates"));

        //verify add template with/without special instructions
        se.assertion.verifyTrue("add a new template", wmsWaveTempPageObject.createANewShipWaveTemplate(params));

        //verify if the template with/without special instructions
        se.assertion.verifyTrue("verify the template", wmsWaveTempPageObject.verifyANewShipWaveTemplate(params));

        //verify delete a template
        //se.assertion.verifyTrue("delete a template", wmsWaveTempPageObject.deleteShipWaveTemplate(params));

        //verify navigate to Run waves
        se.assertion.verifyTrue("navigate to run waves",
                wmsHomePageObject.menuNavigation("Distribution", "Run Waves"));

        //navigate to run waves
        se.assertion.verifyTrue("navigate to run waves page", wmsRunWavePageObject.navigateToRunWaves(params));

        //add task criteria
        //se.assertion.verifyTrue("add task criteria", wmsWaveRulePageObject.addTaskCriteria(params));

        //navigate capacities
        se.assertion.verifyTrue("navigate capacities", wmsWaveRulePageObject.navigateToCapacities());

        //add capacities
        se.assertion.verifyTrue("add capacities", wmsWaveRulePageObject.addCapacities(params));

        //Creating new rule
        se.assertion.verifyTrue("Creation of New Rule", wmsWaveRulePageObject.addNewRules(params));

        //Garbage collection of failed steps
        testTearDown(se);
    }

    /**
     * Test method to create a new routing wave template and verify the same
     *
     * @param myBrowser
     * @param se
     * @param params
     */
    @Test(description = "Add new routing wave template3: Routing Wave - 4 Hourly Promo for Herentals DC", dataProvider = "browserXml",
            groups = {"refresh"}, timeOut = 900000, singleThreaded = true)
    @TestData(fileName = "templates/herentals/Herentals-00 Routing Wave - 4 Hourly Promo - Auto.xml")
    public void createHamRoutingWaveTemplate3(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSShipWaveTemplatePage wmsWaveTempPageObject =
                NikePageFactory.initElements(se.myDriver, WMSShipWaveTemplatePage.class);
        WMSRunWaveTemplatesPage wmsRunWavePageObject =
                NikePageFactory.initElements(se.myDriver, WMSRunWaveTemplatesPage.class);
        WMSTemplateRulePage wmsWaveRulePageObject =
                NikePageFactory.initElements(se.myDriver, WMSTemplateRulePage.class);

        //read input data from parametrized xml file
        String strUrl = (String)params.get("environment");

        //invoke browser
        se.myDriver.get(strUrl);
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //verify user login to WMS
        se.assertion.verifyTrue("User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));

        //verify navigate to system codes page
        se.assertion.verifyTrue("navigate to ship wave templates",
                wmsHomePageObject.menuNavigation("Configuration", "Ship Wave Templates"));

        //verify add template with/without special instructions
        se.assertion.verifyTrue("add a new template", wmsWaveTempPageObject.createANewShipWaveTemplate(params));

        //verify if the template with/without special instructions
        se.assertion.verifyTrue("verify the template", wmsWaveTempPageObject.verifyANewShipWaveTemplate(params));

        //verify delete a template
        //se.assertion.verifyTrue("delete a template", wmsWaveTempPageObject.deleteShipWaveTemplate(params));

        //verify navigate to Run waves
        se.assertion.verifyTrue("navigate to run waves",
                wmsHomePageObject.menuNavigation("Distribution", "Run Waves"));

        //navigate to run waves
        se.assertion.verifyTrue("navigate to run waves page", wmsRunWavePageObject.navigateToRunWaves(params));

        //add task criteria
        //se.assertion.verifyTrue("add task criteria", wmsWaveRulePageObject.addTaskCriteria(params));

        //navigate capacities
        se.assertion.verifyTrue("navigate capacities", wmsWaveRulePageObject.navigateToCapacities());

        //add capacities
        se.assertion.verifyTrue("add capacities", wmsWaveRulePageObject.addCapacities(params));

        //Creating new rule
        se.assertion.verifyTrue("Creation of New Rule", wmsWaveRulePageObject.addNewRules(params));

        //Garbage collection of failed steps
        testTearDown(se);
    }
    /**
     * Test method to create a new routing wave template and verify the same
     *
     * @param myBrowser
     * @param se
     * @param params
     */
    @Test(description = "Add new routing wave template4: Routing Wave - 4 Hr Non-Promo for Herentals DC", dataProvider = "browserXml",
            groups = {"refresh"}, timeOut = 900000, singleThreaded = true)
    @TestData(fileName = "templates/herentals/Herentals-00 Routing Wave - 4 Hr Non-Promo - Auto.xml")
    public void createHerentalsRoutingWaveTemplate4(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSShipWaveTemplatePage wmsWaveTempPageObject =
                NikePageFactory.initElements(se.myDriver, WMSShipWaveTemplatePage.class);
        WMSRunWaveTemplatesPage wmsRunWavePageObject =
                NikePageFactory.initElements(se.myDriver, WMSRunWaveTemplatesPage.class);
        WMSTemplateRulePage wmsWaveRulePageObject =
                NikePageFactory.initElements(se.myDriver, WMSTemplateRulePage.class);

        //read input data from parametrized xml file
        String strUrl = (String)params.get("environment");

        //invoke browser
        se.myDriver.get(strUrl);
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //verify user login to WMS
        se.assertion.verifyTrue("User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));

        //verify navigate to system codes page
        se.assertion.verifyTrue("navigate to ship wave templates",
                wmsHomePageObject.menuNavigation("Configuration", "Ship Wave Templates"));

        //verify add template with/without special instructions
        se.assertion.verifyTrue("add a new template", wmsWaveTempPageObject.createANewShipWaveTemplate(params));

        //verify if the template with/without special instructions
        se.assertion.verifyTrue("verify the template", wmsWaveTempPageObject.verifyANewShipWaveTemplate(params));

        //verify delete a template
        //se.assertion.verifyTrue("delete a template", wmsWaveTempPageObject.deleteShipWaveTemplate(params));

        //verify navigate to Run waves
        se.assertion.verifyTrue("navigate to run waves",
                wmsHomePageObject.menuNavigation("Distribution", "Run Waves"));

        //navigate to run waves
        se.assertion.verifyTrue("navigate to run waves page", wmsRunWavePageObject.navigateToRunWaves(params));

        //add task criteria
        //se.assertion.verifyTrue("add task criteria", wmsWaveRulePageObject.addTaskCriteria(params));

        //navigate capacities
        se.assertion.verifyTrue("navigate capacities", wmsWaveRulePageObject.navigateToCapacities());

        //add capacities
        se.assertion.verifyTrue("add capacities", wmsWaveRulePageObject.addCapacities(params));

        //Creating new rule
        se.assertion.verifyTrue("Creation of New Rule", wmsWaveRulePageObject.addNewRules(params));

        //Garbage collection of failed steps
        testTearDown(se);
    }

    /**
     * Test method to create a new picking wave template and verify the same
     *
     * @param myBrowser
     * @param se
     * @param params
     */
    @Test(description = "Add new picking wave template1: Pick Wave - Automation Testing for Herentals DC", dataProvider = "browserXml",
            groups = {"refresh"}, timeOut = 900000, singleThreaded = true)
    @TestData(fileName = "templates/herentals/Herentals-02 Pick Wave - Automation Testing.xml")
    public void createHerentalsPickingWaveTemplate1(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSShipWaveTemplatePage wmsWaveTempPageObject =
                NikePageFactory.initElements(se.myDriver, WMSShipWaveTemplatePage.class);
        WMSRunWaveTemplatesPage wmsRunWavePageObject =
                NikePageFactory.initElements(se.myDriver, WMSRunWaveTemplatesPage.class);
        WMSTemplateRulePage wmsWaveRulePageObject =
                NikePageFactory.initElements(se.myDriver, WMSTemplateRulePage.class);

        //read input data from parametrized xml file
        String strUrl = (String)params.get("environment");

        //invoke browser
        se.myDriver.get(strUrl);
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //verify user login to WMS
        se.assertion.verifyTrue("User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));

        //verify navigate to system codes page
        se.assertion.verifyTrue("navigate to ship wave templates",
                wmsHomePageObject.menuNavigation("Configuration", "Ship Wave Templates"));

        //verify add template with/without special instructions
        se.assertion.verifyTrue("add a new template", wmsWaveTempPageObject.createANewShipWaveTemplate(params));

        //verify if the template with/without special instructions
        se.assertion.verifyTrue("verify the template", wmsWaveTempPageObject.verifyANewShipWaveTemplate(params));

        //verify delete a template
        //se.assertion.verifyTrue("delete a template", wmsWaveTempPageObject.deleteShipWaveTemplate(params));

        //verify navigate to Run waves
        se.assertion.verifyTrue("navigate to run waves",
                wmsHomePageObject.menuNavigation("Distribution", "Run Waves"));

        //navigate to run waves
        se.assertion.verifyTrue("navigate to run waves page", wmsRunWavePageObject.navigateToRunWaves(params));

        //add task criteria
        se.assertion.verifyTrue("add task criteria", wmsWaveRulePageObject.addTaskCriteria(params));

        //navigate capacities
        se.assertion.verifyTrue("navigate capacities", wmsWaveRulePageObject.navigateToCapacities());

        //add capacities
        se.assertion.verifyTrue("add capacities", wmsWaveRulePageObject.addCapacities(params));

        //Creating new rule
        se.assertion.verifyTrue("Creation of New Rule", wmsWaveRulePageObject.addNewRules(params));

        //Garbage collection of failed steps
        testTearDown(se);
    }

    /**
     * Test method to create a new picking wave template and verify the same
     *
     * @param myBrowser
     * @param se
     * @param params
     */
    @Test(description = "Add new picking wave template2: Pick Wave - Hourly Non-Promo for Herentals DC", dataProvider = "browserXml",
            groups = {"refresh"}, timeOut = 900000, singleThreaded = true)
    @TestData(fileName = "templates/herentals/Herentals-2 Pick Wave - Hourly Non-Promo.xml")
    public void createHerentalsPickingWaveTemplate2(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSShipWaveTemplatePage wmsWaveTempPageObject =
                NikePageFactory.initElements(se.myDriver, WMSShipWaveTemplatePage.class);
        WMSRunWaveTemplatesPage wmsRunWavePageObject =
                NikePageFactory.initElements(se.myDriver, WMSRunWaveTemplatesPage.class);
        WMSTemplateRulePage wmsWaveRulePageObject =
                NikePageFactory.initElements(se.myDriver, WMSTemplateRulePage.class);

        //read input data from parametrized xml file
        String strUrl = (String)params.get("environment");

        //invoke browser
        se.myDriver.get(strUrl);
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //verify user login to WMS
        se.assertion.verifyTrue("User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));

        //verify navigate to system codes page
        se.assertion.verifyTrue("navigate to ship wave templates",
                wmsHomePageObject.menuNavigation("Configuration", "Ship Wave Templates"));

        //verify add template with/without special instructions
        se.assertion.verifyTrue("add a new template", wmsWaveTempPageObject.createANewShipWaveTemplate(params));

        //verify if the template with/without special instructions
        se.assertion.verifyTrue("verify the template", wmsWaveTempPageObject.verifyANewShipWaveTemplate(params));

        //verify delete a template
        //se.assertion.verifyTrue("delete a template", wmsWaveTempPageObject.deleteShipWaveTemplate(params));

        //verify navigate to Run waves
        se.assertion.verifyTrue("navigate to run waves",
                wmsHomePageObject.menuNavigation("Distribution", "Run Waves"));

        //navigate to run waves
        se.assertion.verifyTrue("navigate to run waves page", wmsRunWavePageObject.navigateToRunWaves(params));

        //add task criteria
        se.assertion.verifyTrue("add task criteria", wmsWaveRulePageObject.addTaskCriteria(params));

        //navigate capacities
        se.assertion.verifyTrue("navigate capacities", wmsWaveRulePageObject.navigateToCapacities());

        //add capacities
        se.assertion.verifyTrue("add capacities", wmsWaveRulePageObject.addCapacities(params));

        //Creating new rule
        se.assertion.verifyTrue("Creation of New Rule", wmsWaveRulePageObject.addNewRules(params));

        //Garbage collection of failed steps
        testTearDown(se);
    }

    /**
     * Test method to create a new picking wave template and verify the same
     *
     * @param myBrowser
     * @param se
     * @param params
     */
    @Test(description = "Add new picking wave template3: Pick Wave - Automation template for Herentals DC", dataProvider = "browserXml",
            groups = {"refresh"}, timeOut = 900000, singleThreaded = true)
    @TestData(fileName = "templates/herentals/Herentals-02 Automation Routing Wave Template.xml")
    public void createHerentalsPickingWaveTemplate3(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSShipWaveTemplatePage wmsWaveTempPageObject =
                NikePageFactory.initElements(se.myDriver, WMSShipWaveTemplatePage.class);
        WMSRunWaveTemplatesPage wmsRunWavePageObject =
                NikePageFactory.initElements(se.myDriver, WMSRunWaveTemplatesPage.class);
        WMSTemplateRulePage wmsWaveRulePageObject =
                NikePageFactory.initElements(se.myDriver, WMSTemplateRulePage.class);

        //read input data from parametrized xml file
        String strUrl = (String) params.get("environment");

        //invoke browser
        se.myDriver.get(strUrl);
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //verify user login to WMS
        se.assertion.verifyTrue("User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));

        //verify navigate to system codes page
        se.assertion.verifyTrue("navigate to ship wave templates",
                wmsHomePageObject.menuNavigation("Configuration", "Ship Wave Templates"));

        //verify add template with/without special instructions
        se.assertion.verifyTrue("add a new template", wmsWaveTempPageObject.createANewShipWaveTemplate(params));

        //verify if the template with/without special instructions
        se.assertion.verifyTrue("verify the template", wmsWaveTempPageObject.verifyANewShipWaveTemplate(params));

        //verify delete a template
        //se.assertion.verifyTrue("delete a template", wmsWaveTempPageObject.deleteShipWaveTemplate(params));

        //verify navigate to Run waves
        se.assertion.verifyTrue("navigate to run waves",
                wmsHomePageObject.menuNavigation("Distribution", "Run Waves"));

        //navigate to run waves
        se.assertion.verifyTrue("navigate to run waves page", wmsRunWavePageObject.navigateToRunWaves(params));

        //add task criteria
        se.assertion.verifyTrue("add task criteria", wmsWaveRulePageObject.addTaskCriteria(params));

        //navigate capacities
        se.assertion.verifyTrue("navigate capacities", wmsWaveRulePageObject.navigateToCapacities());

        //add capacities
        se.assertion.verifyTrue("add capacities", wmsWaveRulePageObject.addCapacities(params));

        //Creating new rule
        se.assertion.verifyTrue("Creation of New Rule", wmsWaveRulePageObject.addNewRules(params));

        //Garbage collection of failed steps
        testTearDown(se);
    }
}