package tech.nike.automation.wms.feature.test.reference;

        /* *
        * Created by PSibb1 on 1/15/2017.
        * */


public class ReferenceTesting {

    /*public static void main(String[] args){
        *//*String text = "DEST^20DigitLPNID^^^312492-167-9^CN^01000^^^6^^24-00-000-0-01^2400000001^^1000^^^^^N^N";
        String [] arr = text.split("^^");
        System.out.println(arr[0]+":"+ arr[1]);


        String val = "06.000";
        val = val.substring(0, val.indexOf("."));
        System.out.println("integer value qty:"+ Integer.parseInt(val));
        Socket s =null;
        try
        {
            s = new Socket("10.216.202.154", 20101);
            PrintWriter out = new PrintWriter(s.getOutputStream(), true);
            String message = "whatever you want..";
            out.print((char)2+ message +(char)3);
            out.flush();
            out.close();
        }
        catch (IOException e) {e.printStackTrace();}finally{try{if(s!=null){s.close();}}catch(IOException e){}}*//*
        String url = "http://nke-lnx-wma-d001.wms.nike.com:10000/"; //"http://nke-lnx-apt-x103.nike.com:10000/"; //http://nke-lnx-wma-d001.wms.nike.com:10000
        url= url.substring(url.lastIndexOf("-")+1);
        url = url.substring(0,4).trim();
        System.out.println(url);

    }*/
}
