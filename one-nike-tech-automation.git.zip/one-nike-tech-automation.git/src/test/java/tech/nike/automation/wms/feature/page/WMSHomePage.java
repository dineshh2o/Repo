package tech.nike.automation.wms.feature.page;

import org.openqa.selenium.By;
import tech.nike.automation.common.framework.utils.XMLUpdateHelper;
import tech.nike.automation.common.page.Page;

import java.util.Map;
import java.util.concurrent.TimeUnit;

public class WMSHomePage extends Page {

    /**
     * Locators
     */
    public By lnkMenu = By.id("phMenu");
    /* for reference to use the link text
    public By lnkmenu1 = By.xpath("//a[contains(text(),'Tools')]");
     */
    public By lnkSignOut = By.linkText("Sign Out");
    public By btnConfirmSignOut = By.id("SignoutOK");
    public By btnChooseFile = By.id("dataForm:uploadedFileID");
    public By btnSendMessage = By.id("dataForm:postMessageCmdId");
    public By lblPageTitle = By.id("dataForm:hLabel");
    public By lblPostXMlPageTitle = By.id("dataForm:page_header_panel_text");
    public By lblResultXML = By.id("dataForm:resultString");

    public By getLinkText(String strLinkText) {
        return By.linkText(strLinkText);
    }

    /**
     * Method to verify links by names on wms menus
     *
     * @param strTabName
     * @return
     */
    public boolean verifyLinkByName(String strTabName) {
        //wait for the element() to display
        se.element.requireIsDisplayed(strTabName + " link ", getLinkText(strTabName));
        //wait for the element() to be visible
        boolean result = se.element.isVisible(getLinkText(strTabName));
        //wait for the element() to be clickable
        result &= se.element.waitForElementToBeClickable(getLinkText(strTabName));
        return result;
    }

    /**
     * Method will allow user to select a wms menu option after navigating into a menu tab
     *
     * @return
     */
    public boolean selectMenu(String strTabMenuName, String strLinkName) {
        //verify if the main menu is displayed and clickable
        boolean result = verifyLinkByName(strTabMenuName);
        //click on the main link
        se.element.clickElement(getLinkText(strTabMenuName));
        //wait for page load to complete
        se.myDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        //verify if the secondary link was displayed
        result &= verifyLinkByName(strLinkName);
        //click on the secondary link
        se.element.clickElement(getLinkText(strLinkName));
        //report the click sign-out event on to the html report
        se.log.logTestStep("user successfully navigated to " + strTabMenuName + " and then into " + strLinkName);
        return result;
    }

    /**
     * Method to verify and click on the sign-out button
     *
     * @return
     */
    public boolean verifyAndClickSignOut() {
        //verify if the sign-out element() was displayed
        se.element.requireIsDisplayed("Sign-out link", lnkSignOut);
        //verify if the sign-out element() was visible
        boolean result = se.element.isVisible(lnkSignOut);
        //verify if the sign-out element() was clickable
        result &= se.element.waitForElementToBeClickable(lnkSignOut);
        //click on the sign-out element()
        se.element.clickElement(lnkSignOut);
        //report the click sign-out event on to the html report
        se.log.logSeStep("clicked on the sign-out element() successfully");
        return result;
    }

    /**
     * Method to verify and click on confirm sign-out
     *
     * @return
     */
    public boolean verifyAndClickConfirmSignOut() {
        //verify if the OK element() was displayed
        se.element.requireIsDisplayed("Confirm Sign-out button", btnConfirmSignOut);
        //verify if the OK element() was visible
        boolean result = se.element.isVisible(btnConfirmSignOut);
        //verify if the OK element() was clickable
        result &= se.element.waitForElementToBeClickable(btnConfirmSignOut);
        //click on the OK element()
        se.element.clickElement(btnConfirmSignOut);
        //report the click event on the html report
        se.log.logTestStep("clicked on the confirm sign-out element() successfully");
        return result;
    }

    /**
     * Method to verify and post XML file using ifse option
     *
     * @return
     */
    public boolean verifyPostXML(Map<String, Object> testdata) {
        String strXMLFilePath = (String) testdata.get("xmlfilename");
        //get the path of the xml file that was updated
        XMLUpdateHelper xmlHelper = new XMLUpdateHelper();
        String filefullPath = xmlHelper.getFilePath();
        //wait for page load to complete
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        boolean result = menuNavigation("Integration", "Post Message");
        //wait for page load to complete
        se.myDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        //wait for the page title to be displayed
        result &= se.element.waitForElement(lblPostXMlPageTitle);
        //verify page title
        String lblTitleText = se.element.getText(lblPostXMlPageTitle).trim();
        se.log.logTestStep("expected title POST MESSAGE, but actual was " + lblTitleText);
        result &= se.assertion.verifyEquals("verify the post message page title", lblTitleText, "Post Message");
        //verify if the required field was displayed
        result &= se.element.waitForElement(btnChooseFile);
        //set the path of the xml file to upload
        se.myDriver.findElement(btnChooseFile).sendKeys(filefullPath + strXMLFilePath);
        //wait for file upload to complete
        se.myDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        //report the click event on the html report
        se.log.logTestStep("entered the file path successfully");
        //verify if the send button was displayed
        result &= se.element.waitForElement(btnSendMessage);
        //click send button to post the xml file
        se.element.clickElement(btnSendMessage);
        //verify if the XMl text area was displayed
        se.element.requireIsDisplayed("XML text area", lblResultXML);
        String resultXML = se.element.getText(lblResultXML);
        //validate the error message
        if (resultXML.contains("CDATA")) {
            result = false;
            //report the click event on the html report
            se.log.logTestStep("xml posting failed");
        } else {
            result = true;
            //report the click event on the html report
            se.log.logTestStep("xml posting was successful");
        }
        return result;
    }

    /**
     * Method to navigate to system menu
     *
     * @return
     */
    public boolean menuNavigation(String strPrimaryMenu, String strSecondaryMenu) {
        //verify if the menu link was displayed
        se.element.requireIsDisplayed("Main Menu link", lnkMenu);
        //verify if the menu link was visible
        boolean result = se.element.isVisible(lnkMenu);
        //verify if the menu link was clickable
        result &= se.element.waitForElementToBeClickable(lnkMenu);
        //click on the menu link
        se.element.clickElement(lnkMenu);
        //report the click event on the html report
        se.log.logTestStep("clicked on menu link successfully");
        //verify and click on navigation links
        result &= selectMenu(strPrimaryMenu, strSecondaryMenu);
        //wait for page load to complete
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        return result;
    }
}