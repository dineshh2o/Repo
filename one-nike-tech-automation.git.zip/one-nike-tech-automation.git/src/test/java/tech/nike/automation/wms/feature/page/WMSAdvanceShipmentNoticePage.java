package tech.nike.automation.wms.feature.page;

import org.openqa.selenium.By;
import tech.nike.automation.common.page.Page;

/**
 * Created by Nchou7 on 1/24/2017.
 */
public class WMSAdvanceShipmentNoticePage extends Page {

    /**
     * Locators
     */
    public By lblASNNumber = By.xpath("//*[@id=\"dataForm:ASN_Details_ASN_TCASNIdString\"]");
    public By tabLPN = By.xpath("//*[@id=\"ASNDetailLPNsTab_lnk\"]");

    /**
     * method to verify the ASN details by ASN number
     *
     * @param strASNNumber
     * @return
     */
    public boolean verifyASNDetails(String strASNNumber) {
        boolean retval = false;
        retval &= se.element.waitForElementIsDisplayed(lblASNNumber);
        String dispASN = se.element.getText(lblASNNumber).trim();
        if (dispASN.equalsIgnoreCase(strASNNumber)) {
            //Verify if the required field was displayed
            se.element.requireIsDisplayed("Tab LPN", tabLPN);
            retval &= se.element.clickElement(tabLPN);
            se.element.waitBySleep(20000);
        }
        return  retval ;
    }
}