package tech.nike.automation.wms.feature.page;

import org.openqa.selenium.By;

/**
 * Created by PSibb1 on 6/13/2016.
 */
public enum EditBoxValidationType {
    NONE(
            "---None---",
            "-1",
            null,
            null
    ),
    ALPHA_NUMERIC (
            "Alpha Numeric",
            "A",
            "Y",
            "N"
    ),
    NUMERIC_ONLY (
            "Numeric Only",
            "N",
            "1",
            "0"
    );

    final String valType;
    final String value;
    final String fieldOne;
    final String fieldTwo;


    EditBoxValidationType(String valType, String value, String fieldOne, String fieldTwo){
        this.valType = valType;
        this.value = value;
        this.fieldOne = fieldOne;
        this.fieldTwo = fieldTwo;
    }

    public String getValType(){
        return valType;
    }

    public String getFieldOne(){
        return fieldOne;
    }

    public String getFieldTwo(){
        return fieldTwo;
    }

    public By getValTypeLocator (){
        return By.cssSelector(String.format("#ansEditStyle_2dc_1 [value = '%s']",this.value));
    }

    public By getFieldOneLocator() { return By.id("ansValidFrom_2Ndc_1"); }

     public By getFieldTwoLocator() { return By.id("ansValidTo_2Ndc_1"); }

}