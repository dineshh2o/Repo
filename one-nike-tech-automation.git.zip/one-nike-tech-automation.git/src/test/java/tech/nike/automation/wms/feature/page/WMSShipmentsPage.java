package tech.nike.automation.wms.feature.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import tech.nike.automation.common.page.Page;

import java.util.List;

/**
 * Created by PSibb1 on 1/13/2017.
 */
public class WMSShipmentsPage extends Page {

    /**
     * Locators
     */
    public By txtShipmentId = By.cssSelector("[alt='Find Shipment'][type='text']");
    public By btnAppy = By.cssSelector("[id*='quickFilterGroupButton_mainButton']>input");
    /*Search results table locators*/
    public By chkResults = By.cssSelector(".tbl_checkBox.advtbl_col.advtbl_body_col>input[type='checkbox']");
    public By txtShipID = By.cssSelector("[id*='ShpList_ShpId_Link_Param_Out']");
    public By txtShipStatus = By.cssSelector("[id*='ShpList_ShpStatus_Output']");
    public By txtFacility = By.cssSelector("[id*='ShpList_OrgInf_Output']");
    public By txtDestination = By.cssSelector("[id*='ShpList_DestInf_Output']");
    public By btnMore = By.cssSelector("[id$='moreButton']");
    public By lnkInititateShipment = By.id("ShipmentList_InitiateShipment_more");
    public By txtOverLayInfo = By.cssSelector(".overlayinfo.-icons_info");
    public By btnCloseOverLayInfo = By.cssSelector(".pop_close>img[src='/lps/resources/common/images/close.gif']");

    /**
     * method to search by shipment id on Shipments screen
     *
     * @param shipID
     * @return
     */
    public boolean searchByShipmentID(String shipID) {
        boolean result = false;
        //verify if the required field was displayed
        se.element.requireIsDisplayed("Shipment Search field", txtShipmentId);
        //verify if shipment id field is clickable
        result = se.element.isClickable(txtShipmentId);
        //enter shipment id to search
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtShipmentId, shipID);
        //verify is apply button is clickable
        /*result &= se.element.isClickable(btnAppy);*/
        result &= se.element.hoverAndClick(btnAppy, btnAppy);
        //click on the apply button
        //se.element.clickElement(btnAppy);
        se.element.waitBySleep(7000);
        List<WebElement> checks = se.element.getElements(chkResults);
        result &= checks.size() > 0;
        return result;
    }

    /**
     * method to verify the shipment search results
     *
     * @param shipID
     * @return
     */
    public boolean verifyShipmentSearchResults(String shipID) {
        boolean result = false;
        String dispShipID;
        String dispShipStatus;
        //verify if the search results are displayed
        List<WebElement> checks = se.element.getElements(chkResults);
        List<WebElement> shipLbls = se.element.getElements(txtShipID);
        List<WebElement> shipStatuses = se.element.getElements(txtShipStatus);
        result = checks.size() > 0;
        for (int i = 0; i <= checks.size(); i++) {
            dispShipID = shipLbls.get(i).getText().trim();
            dispShipStatus = shipStatuses.get(i + 1).getText().trim();
            if (shipID.equals(dispShipID) && dispShipStatus.contains("In Transit")) {
                checks.get(i).click();
                result &= true;
                se.log.testStep("Selected the matching shipment " + dispShipID);
                break;
            }
        }
        return result;
    }

    /**
     * method to inititate shipment and verify if it is successful
     *
     * @return
     */
    public boolean inititateShipment(String shipID) {
        boolean result = false;
        //verify if the required field was displayed
        se.element.requireIsDisplayed("More button", btnMore);
        //verify if the more button was clickable
        result = se.element.isClickable(btnMore);
        //click on the More button
        se.element.clickElement(btnMore);
        se.log.testStep("Clicked on the More button");
        //verify if required was displayed
        se.element.requireIsDisplayed("Inititate Shipment link", lnkInititateShipment);
        //click on the Inititate Shipment
        se.element.clickElement(lnkInititateShipment);
        se.log.testStep("Clicked on the Inititate Shipment button");
        //wait for asynchronous page load
        se.element.waitBySleep(5000);
        //wait for the element to be displayed
        result &= se.element.waitForElementIsDisplayed(txtOverLayInfo);
        String message = se.element.getText(txtOverLayInfo).trim();
        result &= message.contains("success");
        se.log.testStep("Message :" + message + " was displayed");
        //click on close the overlay info
        se.element.clickElement(btnCloseOverLayInfo);
        result &= verifyShipmentSearchResults(shipID);
        return result;
    }

    /**
     * wrapper method merge both search shipment and verify shipment results
     *
     * @param ShipID
     * @return
     */
    public boolean searchAndVerifyShipment(String ShipID) {
        boolean result = false;
        result = searchByShipmentID(ShipID);
        result &= verifyShipmentSearchResults(ShipID);
        return result;
    }
}