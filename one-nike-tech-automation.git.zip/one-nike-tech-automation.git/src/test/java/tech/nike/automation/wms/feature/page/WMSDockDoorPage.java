package tech.nike.automation.wms.feature.page;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import tech.nike.automation.common.page.Page;

import java.util.List;

/**
 * Created by PSibb1 on 1/15/2017.
 */
public class WMSDockDoorPage extends Page {

    public By txtDock = By.cssSelector("[alt='Find Dock'][type='text']");
    public By btnApply = By.id("dataForm:listView:filterId:filterIdapply");
    public By chkDock = By.cssSelector("[id^='checkAll_c'][type='checkbox']");
    public By txtPageInput = By.id("dataForm:listView:dataTable:pager:pageInput");
    public By lblPagination = By.cssSelector(".pagerNoWrap:nth-child(2)");

    public By getStatusLocator(int index) {
        return By.id("dataForm:listView:dataTable:" + index + ":out5");
    }

    public By getDockDoorNumber(int i) {
        return By.id("dataForm:listView:dataTable:" + i + ":out4");
    }

    /**
     * method to get the dock door status
     *
     * @return
     */
    public String getOpenDockDoorByType(String dockDoorType) {
        int index = 0;
        boolean blnFlag = false;
        String dockStatus = "";
        //verify if the required field was displayed
        se.element.requireIsDisplayed("Dock text field", txtDock);
        //verify if the dock text field was clickable
        se.element.isClickable(txtDock);
        //enter the Dock value
        verifyEnteredTextIsCorrectlyDisplayed(txtDock, dockDoorType);
        //verify if the apply button was clickable
        se.element.isClickable(btnApply);
        //click on the apply button
        se.element.clickElement(btnApply);
        //asynchronous page load
        se.element.waitBySleep(5000);
        List<WebElement> rows = se.element.getElements(chkDock);
        int pages = getNumberOfPages();
        for (int i = 1; i <= pages; i++) {
            for (WebElement row : rows) {
                String status = se.element.getElement(getStatusLocator(index)).getText().trim();
                if (status.equalsIgnoreCase("OPEN")) {
                    String dockDoor = se.element.getElement(getDockDoorNumber(index)).getText().trim();
                    dockStatus = dockDoor;
                    blnFlag = true;
                    break;
                }
                index = index + 1;
            }
            //verify if the page input is clickable
            if ((blnFlag) && (se.element.isClickable(txtPageInput) == false) | pages <= 20) {
                break;
            } else {
                se.element.enterText(txtPageInput, Integer.toString(i));
                se.element.enterText(txtPageInput, Keys.ENTER);
                se.element.waitBySleep(2000);
            }
        }
        return dockStatus;
    }

    /**
     * method to get the number of pages available for navigation
     *
     * @return
     */
    public int getNumberOfPages() {
        int pageCount = 0;
        //verify if the required field was displayed
        se.element.requireIsDisplayed("Pagination text", lblPagination);
        String text = se.element.getText(lblPagination).trim();
        String[] arrText = text.split(" ");
        pageCount = Integer.parseInt(arrText[4]);
        return pageCount;
    }
}