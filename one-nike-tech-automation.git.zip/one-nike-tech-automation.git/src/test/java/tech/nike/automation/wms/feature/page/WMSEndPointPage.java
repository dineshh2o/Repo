package tech.nike.automation.wms.feature.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import tech.nike.automation.common.page.Page;

import java.util.List;

/**
 * Created by PSibb1 on 1/14/2017.
 */
public class WMSEndPointPage extends Page {

    /**
     * Locators
     */
    public By txtEndPointName = By.cssSelector("[id^='dataForm:endPointFilter'][type='text']");
    public By lstDeviceType = By.cssSelector("select[id^='dataForm:endPointFilter']");
    public By chkEndPointList = By.cssSelector("[id$='endPointListDataTable'][type='checkbox']");
    public By lblEndPointName = By.cssSelector("[id$='endPointName_Column_Param_Text']");
    public By lblDeviceType = By.cssSelector("[id$='endPointProtocol_Column_Param_Text']");
    public By lblDirection = By.cssSelector("[id$='endPointDirection_Column_Param_Text']");
    public By lblDescription = By.cssSelector("[id$='endPointDescription_Column_Param_Text']");
    public By btnStart = By.cssSelector("[id$='epStart_CmdId'][type='submit']");
    public By btnStop = By.cssSelector("[id$='epStop_CmdId'][type='submit']");
    public By btnApply = By.cssSelector("[id$='endPointFilterapply'][type='submit']");


    /**
     * method to search an end point by end point name
     *
     * @param endPointName
     * @return
     */
    public boolean searchEndPointByName(String endPointName) {
        boolean result = false;
        //verify if the mandatory field was displayed
        se.element.requireIsDisplayed("End Point Name text field", txtEndPointName);
        //verify if the end point name text field was clickable
        result = se.element.isClickable(txtEndPointName);
        //enter the end point name to search
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtEndPointName, endPointName);
        //verify is the required field was displayed
        se.element.requireIsDisplayed("Apply button", btnApply);
        //verify if the apply button was clickable
        result &= se.element.isClickable(btnApply);
        //click on the apply button
        se.element.clickElement(btnApply);
        //asynchronous page load
        se.element.waitBySleep(3000);
        //wait for the table to display searched record
        List<WebElement> endpoints = se.myDriver.findElements(txtEndPointName);
        result &= endpoints.size() > 0;
        for (WebElement endPoint : endpoints) {
            String dispEndPointName = endPoint.getAttribute("value").trim();
            if (endPointName.equalsIgnoreCase(dispEndPointName)) {
                se.log.seStep(endPointName + " end point was displayed in the list of end points");
                result &= true;
                break;
            } else {
                se.log.seStep(endPointName + " end point was not displayed in the list of " +
                        "end points or user entered end point is incorrect");
                result &= false;
            }
        }
        return result;
    }

    /**
     * method to search and start an end point by name
     *
     * @param endPointName
     * @return
     */
    public boolean startEndPointByName(String endPointName) {
        boolean result = false;
        result = searchEndPointByName(endPointName);
        //verify if the end point has been stopped
        if (getEndPointStatus(endPointName).equalsIgnoreCase("Stopped")) {
            //click on the start button
            se.element.clickElement(btnStart);
            se.log.seStep("Started the end point " + endPointName);
            result &= true;
        } else {
            se.log.seStep(endPointName + " end point was already started");
            result &= true;
        }
        //wait for the page load
        se.element.waitForPageLoad();
        //verify if the end point was started
        result &= getEndPointStatus(endPointName).equalsIgnoreCase("Started");
        return result;
    }


    /**
     * method to search and stop an end point by name
     *
     * @param endPointName
     * @return
     */
    public boolean stopEndPointByName(String endPointName) {
        boolean result = false;
        result = searchEndPointByName(endPointName);
        //verify if the end point has been stopped
        if (getEndPointStatus(endPointName).equalsIgnoreCase("Started")) {
            //stop the end point
            se.element.clickElement(btnStop);
            se.log.seStep("Stopped the end point " + endPointName);
            result &= true;
        } else {
            se.log.seStep(endPointName + "  end point was stopped already");
            result &= true;
        }
        se.element.waitForPageLoad();
        //verify if the end point was stopped
        result &= getEndPointStatus(endPointName).equalsIgnoreCase("Stopped");
        return result;
    }

    /**
     * method to check the status of the end point
     *
     * @param endPointName
     * @return
     */
    public String getEndPointStatus(String endPointName) {
        if (se.element.isClickable(btnStop) == false) {
            se.log.seStep(endPointName + " end point has been started");
            return "Stopped";
        } else {
            se.log.seStep(endPointName + " end point has been stopped");
            return "Started";
        }
    }
}