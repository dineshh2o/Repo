package tech.nike.automation.wms.feature.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import tech.nike.automation.common.page.Page;

import java.util.List;

/**
 * Created by PSibb1 on 1/14/2017.
 */
public class WMSiLPNsPage extends Page {
    /**
     * Locators
     */
    public By txtLPN = By.cssSelector("[alt='Find iLPN'][type='text']");

    /*search results locators*/
    public By lblLPN = By.cssSelector("[id$='LPNList_Outbound_Link_NameText_param_out']");
    public By chkLPN = By.cssSelector("[id*='LPNListInOutboundMain'][type='checkbox']");
    public By lblSKU = By.cssSelector("[id*='Case_LPN_With_PO_LPN_POLine_Item_param_out']");
    public By lblQty = By.cssSelector("[id*='CTO_LPNListTPM_LPN_Qty_param_out']");
    public By lblLPNSizeType = By.cssSelector("[id$='LPNList_Inbound_LPNSizeType_param_out']");
    public By lblStatus = By.cssSelector("[id$='LPNList_Outbound_lpnStatusId_param_out']");
    public By lblLPNFacilityStatus = By.cssSelector("[id$='LPNList_Outbound_lpnFacilityStatus_param_out']");
    public By btnApply = By.cssSelector("[title='Apply'][type='button'][style='cursor:pointer']");
    public By btnView = By.id("LPNListInboundMain_commandbutton_view");
    /*LPN details*/
    public By lblLPNFacStatus = By.id("dataForm:LPNCommonHeader_LPNFacilityStatus_outputText");
    public By lblStatusAfterPutaway = By.id("dataForm:LPNCommonHeader_LPNStatus_outputText");
    public By lnkHeader = By.id("LPN_Header_Tab_lnk");
    public By lblCurrentLocation = By.id("dataForm:ViewLPNInbound_Header_CurrentLocation_Text");


    /**
     * method to search and verify LPN results
     *
     * @param strLPN
     * @return
     */
    public boolean searchByLPN(String strLPN) {
        boolean result = false;
        //verify if the required field was dsiplayed
        se.element.requireIsDisplayed("LPN text field", txtLPN);
        //verify if the LPN field is clickable
        result = se.element.isClickable(txtLPN);
        //enter lpn number to search
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtLPN, strLPN);
        //verify if the required field was displayed
        se.element.requireIsDisplayed("Apply button", btnApply);
        //verify if the apply button is clickable
        result &= se.element.isClickable(btnApply);
        //click on the apply button
        se.element.clickElement(btnApply);
        //asynchronous page load
        se.element.waitBySleep(3000);
        List<WebElement> lpns = se.myDriver.findElements(lblLPN);
        result &= lpns.size() > 0;
        for (WebElement lpn : lpns) {
            String dispLPN = lpn.getText().trim();
            if (dispLPN.equalsIgnoreCase(strLPN)) {
                se.log.testStep("Search by LPM number " + strLPN + " was successful");
                result &= true;
            } else {
                result &= false;
            }
        }
        return result;
    }

    /**
     * method to select and LPN by LPN number
     *
     * @param strLPN
     * @return
     */
    public boolean selectLPNByLPNNumber(String strLPN) {
        boolean result = false;
        int index = 0;
        List<WebElement> lpns = se.myDriver.findElements(lblLPN);
        List<WebElement> checks = se.myDriver.findElements(chkLPN);
        result = lpns.size() > 0;
        for (WebElement lpn : lpns) {
            String dispLPN = lpn.getText().trim();
            if (dispLPN.equalsIgnoreCase(strLPN)) {
                checks.get(index).click();
                se.log.testStep(dispLPN + "  lpn number was successfully selected");
                result &= true;
                break;
            } else {
                result &= false;
            }
            index = index + 1;
        }
        return result;
    }

    /**
     * method to search and view the LPN details by LPN number
     *
     * @param strLPN
     * @return
     */
    public boolean viewLPNInfoByLPNNumber(String strLPN) {
        boolean result = false;
        //verify if the required was displayed
        se.element.requireIsDisplayed("View button", btnView);
        //verify if the view button was clickable
        result = se.element.isClickable(btnView);
        //click on the view button
        se.element.clickElement(btnView);
        //wait for the page load
        result &= se.element.waitForElementIsDisplayed(lblStatusAfterPutaway);
        //get the displayed status
        String dispStatus = se.element.getText(lblStatusAfterPutaway).trim();
        String dispFacStatus = se.element.getText(lblLPNFacStatus).trim();
        result &= (dispStatus.equalsIgnoreCase("In-Stock") && dispFacStatus.equalsIgnoreCase("Putaway"));
        if (result) {
            se.log.testStep("LPN " + strLPN + " details was verified for Status " + dispStatus + " and facility status " + dispFacStatus);
        } else {
            se.log.testStep("Failed to verify LPN " + strLPN + " details as Status was "
                    + dispStatus + " and facility status " + dispFacStatus + " , not as expected");
        }
        return result;
    }

    /**
     * wrapper method to search, select and verify the LPN details by LPN number
     *
     * @param strLPNNumber
     * @return
     */
    public boolean verifyLPNDetails(String strLPNNumber, String location) {
        boolean result = false;
        result = searchByLPN(strLPNNumber);
        result &= selectLPNByLPNNumber(strLPNNumber);
        result &= viewLPNInfoByLPNNumber(strLPNNumber);
        result &= verifyHeaderLocation(location);
        return result;
    }

    /**
     * method to navigate to header tab and verify the current location
     *
     * @param location
     * @return
     */
    public boolean verifyHeaderLocation(String location) {
        boolean result = false;
        String loc = "";
        //verify if the required field was displayed
        se.element.requireIsDisplayed("Header link", lnkHeader);
        //verify if the header tab is clickable
        result = se.element.isClickable(lnkHeader);
        //click on the header tab link
        se.element.clickElement(lnkHeader);
        //wait for the current location to be displayed
        result &= se.element.waitForElementIsDisplayed(lblCurrentLocation);
        if (result) {
            loc = se.element.getText(lblCurrentLocation).replaceAll("-", "").trim();
            if (loc.equals(location)) {
                result &= true;
                se.log.testStep("Current Location was displayed as expected:" + loc);
            } else {
                se.log.testStep("Current Location was displayed as expected:" + loc + " , not as expected");
                result &= false;
            }
        }
        return result;
    }
}