package tech.nike.automation.wms.feature.page;

import org.openqa.selenium.By;
import tech.nike.automation.common.framework.testdatamanager.InventoryManager;
import tech.nike.automation.common.framework.testdatamanager.ProductSummary;
import tech.nike.automation.common.page.Page;

import java.util.List;

/**
 * Created by PSibb1 on 9/21/2016.
 */
public class WMSDistributionOrdersPage extends Page {
    public By txtDistributionOrderNumber = By.cssSelector("[id*='DistributionOrderlist'][alt='Find Distribution Order']");
    public By lstStatus = By.cssSelector("span.msdstattext");
    public By btnApply = By.cssSelector("[id$='DistributionOrderlist1apply']");
    public By lblDistributionOrder = By.cssSelector("[id$='DOList_DOId_Link_Param_Out']");
    public By lblFulfillmentStatus = By.cssSelector("[id*='DOList_OrderFulfillmentStatus']");
    public By btnRefresh = By.cssSelector("[id$='DOList_MainListTable_rfsh_but']");
    public By chkDO = By.name("dataForm:DOList_entityListView:DOList_MainListTable_checkAll");
    public By btnMore = By.id("j_id140moreButton");
    public By btnCancel = By.id("DO_List_Cancel_Order_button");
    public By btnAccept = By.id("softCheckAcceptButton");
    public By btnConfirm = By.id("rmButton_1Confirm1_167271101");

    /**
     * method to search for the distribution orders in DO screen
     *
     * @param testdata
     * @return
     */
    public boolean searchForDO(String[] testdata) {
        boolean result = true;
        //verify if the Do number search field was displayed
        se.element.requireIsDisplayed("Distribution Order Number", txtDistributionOrderNumber);
        //verify if the status field was displayed
        se.element.requireIsDisplayed("Fulfillment Status dropdown", lstStatus);
        //verify if the DO number is clickable
        result &= se.element.isClickable(txtDistributionOrderNumber);
        //enter the DO numbers
        se.element.sendKeys(txtDistributionOrderNumber, testdata);
        //verify if apply button was displayed
        se.element.requireIsDisplayed("Apply button", btnApply);
        //click on the apply button
        se.element.clickElement(btnApply);
        //wait until the page load is completed
        se.element.waitForPageLoad();
        return result;
    }

    /**
     * method to search for the distribution orders in DO screen
     *
     * @param testdata
     * @return
     */
    public boolean searchForDO(String testdata) {
        boolean result = true;
        //verify if the Do number search field was displayed
        se.element.requireIsDisplayed("Distribution Order Number", txtDistributionOrderNumber);
        //verify if the status field was displayed
        se.element.requireIsDisplayed("Fulfillment Status dropdown", lstStatus);
        //verify if the DO number is clickable
        result &= se.element.isClickable(txtDistributionOrderNumber);
        //enter the DO numbers
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtDistributionOrderNumber, testdata);
        //se.element.sendKeys(txtDistributionOrderNumber, testdata);
        //verify if apply button was displayed
        se.element.requireIsDisplayed("Apply button", btnApply);
        //click on the apply button
        se.element.clickElement(btnApply);
        //wait until the page load is completed
        se.element.waitForPageLoad();
        return result;
    }

    /**
     * verify the DO status is released
     *
     * @return
     */
    public boolean verifyDOStatus() {
        boolean result = true;
        //wait for the page load to complete
        se.element.explicitWait(3000);
        //iterate for the DO status to complete
        for (int i = 0; i <= 60; i++) {
            if (!se.element.getElements(lblFulfillmentStatus).get(1).getText().equalsIgnoreCase("Released")) {
                se.element.clickElement(btnRefresh);
                se.element.explicitWait(3000);
            }
        }
        return result;
    }


    /**
     * //Method to get task from database and then perform Undo on wave application page
     *
     * @param
     * @return
     */
    public boolean verifyDOCleanupHavingPackedAndStagedStatus() {
        boolean result = false;
        String strDoNumber = null;
        int index = 20;
        List<ProductSummary> ps = InventoryManager.getDONumberByQueryID(0, "5");
        ps.size();
        System.out.println("DO IDs record count " + ps.size());
        Integer intLength = ps.size();
        //hold the value of i in temp variable
        Integer tempi = 0;
        for (int i = 0; i < intLength; i++) {
            strDoNumber = ps.get(i).getDoNumber();
            se.element.waitBySleep(5000);
            // Method to search task id on task application
            result = searchForDO(strDoNumber);
            // Method to select task id on task application
            result &= selectDONumber(strDoNumber);
            // Method to Cancel the task
            result &= cancelDO();
            // Method to verify wave is in cancelled status on task page
            result &= verifyDOCancelledStatus();
        }
        return result;
    }

    /**
     * method to select the task by DO ID
     *
     * @return
     */
    public boolean selectDONumber(String strDoNumber) {
        boolean result = false;
        //wait for the element to get visible
        se.element.waitBySleep(2000);

        result = se.element.waitForElementToBeClickable(chkDO);
        if (result) {
            //click task check box button
            se.element.clickElement(chkDO);
            //report user name to html report
            se.log.logSeStep("task check box was checked successfully");
        }
        return result;
    }

    /**
     * Method to click on Cancel button on WMS application DO page
     *
     * @param
     * @return
     */
    public boolean cancelDO() {
        boolean result = false;
        //wait for the element() to display
        se.element.waitBySleep(2000);
        se.element.requireIsDisplayed("Cancel Task field", btnMore);
        //wait for the element to be clickable
        result = se.element.waitForElementToBeClickable(btnMore);
        //click task check box button
        se.element.clickElement(btnMore);
        //report user name to html report
        se.log.logSeStep("More button was clicked successfully");
        se.element.waitBySleep(2000);
        se.element.clickElement(btnCancel);
        //report user name to html report
        se.log.logSeStep("Cancel button was clicked successfully");

        // Click the OK button on the pop up
        se.myDriver.switchTo().alert().accept();
        se.element.waitBySleep(2000);

        if (se.element.exists(btnConfirm)) {
            se.element.clickElement(btnConfirm);
            //report user name to html report
            se.log.logSeStep("Confirm button was clicked successfully");
        }

        // If Accept button appears then click on accept button
        if (se.element.exists(btnAccept)) {
            //click task check box button
            se.element.clickElement(btnAccept);
            //report user name to html report
            se.log.logSeStep("Accept button is clicked successfully");
        }

        return result;
    }

    /**
     * verify the DO status is released
     *
     * @return
     */
    public boolean verifyDOCancelledStatus() {
        boolean result = true;
        //wait for the page load to complete
        se.element.explicitWait(3000);
        //iterate for the DO status to complete
        for (int i = 0; i <= 60; i++) {
            if (!se.element.getElements(lblFulfillmentStatus).get(1).getText().equalsIgnoreCase("Canceled")) {
                se.element.clickElement(btnRefresh);
                se.element.explicitWait(3000);
            }
        }
        return result;
    }

    /**
     * //Method to get task from database and then perform Undo on wave application page
     *
     * @param
     * @return
     */
    public boolean verifyDOCleanupHavingReleasedAndDCAllocatedAndInPackingStatus() {
        boolean result = false;
        String strDoNumber = null;
        int index = 20;
        List<ProductSummary> ps = InventoryManager.getDONumberByQueryID(0, "6");
        ps.size();
        System.out.println("DO IDs record count " + ps.size());
        Integer intLength = ps.size();
        //hold the value of i in temp variable
        Integer tempi = 0;
        for (int i = 0; i < intLength; i++) {
            strDoNumber = ps.get(i).getDoNumber();
            se.element.waitBySleep(5000);
            // Method to search task id on task application
            result = searchForDO(strDoNumber);
            // Method to select task id on task application
            result &= selectDONumber(strDoNumber);
            // Method to Cancel the task
            result &= cancelDO();
            // Method to verify wave is in cancelled status on task page
            result &= verifyDOCancelledStatus();
        }
        return result;
    }

}