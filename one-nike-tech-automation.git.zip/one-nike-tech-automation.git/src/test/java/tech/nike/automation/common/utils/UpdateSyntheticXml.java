package tech.nike.automation.common.utils;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import tech.nike.automation.common.framework.testdatamanager.InventoryManager;
import tech.nike.automation.common.framework.testdatamanager.ProductSummary;
import tech.nike.automation.common.framework.utils.WmsXmlDynamicTagDataHelper;
import tech.nike.automation.common.framework.utils.XMLUpdateHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * Created by PSibb1 on 1/11/2017.
 */
public class UpdateSyntheticXml extends XMLUpdateHelper {
    private Log logger = LogFactory.getLog(UpdateSyntheticXml.class);

    /**
     * method to get the ASN numbers into an array
     *
     * @return
     */
    public static ArrayList<String> getASNs() {
        ArrayList<String> arr = new ArrayList<String>();
        for (int i = 0; i <= 1; i++) {
            WmsXmlDynamicTagDataHelper dataHelper = new WmsXmlDynamicTagDataHelper();
            arr.add(dataHelper.getASNNumber());
        }
        return arr;
    }

    /**
     * method to update the single sku XML file
     * @param data
     * @return
     */
    public boolean updateSingleSkuASNDetailsInXML(Map<String, Object> data) {
        boolean res = false;
        List<ProductSummary> ps = InventoryManager.getItemNameByNamedQuery("single_sku_no_qa_check");
        List<ProductSummary> ps1 = InventoryManager.getCustomerByQueryID("customer_id");
        try {
            WmsXmlDynamicTagDataHelper dataHelper = new WmsXmlDynamicTagDataHelper();
            String asn = dataHelper.getASNNumber();
            String fileName = (String) data.get("xmlfilename");
            String qtyval = (String) data.get("qty");
            Map<String, Object> testinput = new HashMap<String, Object>();
            testinput.put("xmlfilename", fileName);
            testinput.put("ASNID", asn);
            testinput.put("Reference_ID",asn);
            testinput.put("Quantity", qtyval);
            testinput.put("ShippedAsnQuantity", qtyval);
            testinput.put("OriginalQuantity", qtyval);
            testinput.put("ItemName", ps.get(0).getItemId());
            testinput.put("LPNID", dataHelper.getLPNNumber());
            testinput.put("CountryofOrigin", "CN");
            testinput.put("OriginFacilityAliasID", ps1.get(0).getoriginFacilityAliasID());
            updateUniqueItemWithMultipleTags(testinput);
            res = true;
        }catch(Exception e){
            logger.error(e.getMessage() + e.getStackTrace());
            res &= false;
        }
        return res;
    }

    /**
     * method to update the single sku XML file
     * @param data
     * @return
     */
    public boolean updateOnlyASNDetailsInXML(Map<String, Object> data) {
        boolean res = false;
        List<ProductSummary> ps1 = InventoryManager.getCustomerByQueryID("customer_id");
        String cust_id = ps1.get(0).getoriginFacilityAliasID();
        try {
            for(int i=0;i<=1;i++) {
                WmsXmlDynamicTagDataHelper dataHelper = new WmsXmlDynamicTagDataHelper();
                String asn = dataHelper.getASNNumber();
                String fileName = (String) data.get("xmlfilename");
                Map<String, Object> testinput = new HashMap<String, Object>();
                testinput.put("xmlfilename", fileName);
                testinput.put("ASNID", asn);
                testinput.put("Reference_ID",asn);
                testinput.put("OriginFacilityAliasID", cust_id);
                updateUniqueItemWithMultipleTags(i, testinput);
                res = true;
            }
        }catch(Exception e){
            logger.error(e.getMessage() + e.getStackTrace());
            res &= false;
        }
        return res;
    }

    /**
     * method to update multiple sku xml file
     * @param numberOfItems
     * @param data
     * @return
     */
    public boolean updateMultipleSkuASNDetailsInXML(int numberOfItems, Map<String, Object> data) {
        boolean res = false;
        List<ProductSummary> ps = InventoryManager.getItemNameByNamedQuery("initiate_shipment_multiasn");
        List<ProductSummary> ps1 = InventoryManager.getCustomerByQueryID("customer_id");
        String cust_id = ps1.get(0).getoriginFacilityAliasID();
        try {
            for(int i= 0; i<numberOfItems; i++) {
                WmsXmlDynamicTagDataHelper dataHelper = new WmsXmlDynamicTagDataHelper();
                String asn = dataHelper.getASNNumber();
                String fileName = (String) data.get("xmlfilename");
                String qtyval = (String) data.get("qty");
                String[] qty = qtyval.split(",");
                Map<String, Object> testinput = new HashMap<String, Object>();
                testinput.put("xmlfilename", fileName);
                testinput.put("ASNID", asn);
                testinput.put("Reference_ID",asn);
                testinput.put("Quantity", qty[i]);
                testinput.put("ShippedAsnQuantity", qty[i]);
                testinput.put("OriginalQuantity", qty[i]);
                testinput.put("ItemName", ps.get(i).getItemId());
                testinput.put("LPNID", dataHelper.getLPNNumber());
                testinput.put("CountryofOrigin", "CN");
                testinput.put("OriginFacilityAliasID", cust_id);
                updateUniqueItemWithMultipleTags(i, testinput);
                res = true;
            }
        }catch(Exception e){
            logger.error(e.getMessage() + e.getStackTrace());
            res &= false;
        }
        return res;
    }

    /**
     * method to update multiple sku xml file with 18 lpn
     * @param numberOfItems
     * @param data
     * @return
     */
    public boolean updateMultipleSku18LPNDetailsInXML(int numberOfItems, int index, Map<String, Object> data) {
        boolean res = false;
        String qtyval = (String) data.get("qty");
        String fileName = (String) data.get("xmlfilename");
        List<ProductSummary> ps = InventoryManager.getItemNameByNamedQuery("initiate_shipment_multiasn");
        try {
            for(int j=0;j<=1;j++) {
                WmsXmlDynamicTagDataHelper dataHelper = new WmsXmlDynamicTagDataHelper();
                String itemName = ps.get(j).getItemId();
                String asn = getASNs().get(j);
                if(j==0) {
                    for (int i = 0; i <= numberOfItems; i++) {
                        Map<String, Object> testinput = new HashMap<String, Object>();
                        testinput.put("xmlfilename", fileName);
                        testinput.put("LPNSizeType", "B10");
                        testinput.put("Quantity", qtyval);
                        testinput.put("ShippedAsnQuantity", qtyval);
                        testinput.put("OriginalQuantity", qtyval);
                        testinput.put("ItemName", itemName);
                        testinput.put("LPNID", dataHelper.getLPNNumber());
                        testinput.put("CountryofOrigin", "CN");
                        updateUniqueItemWithMultipleTags(i, testinput);
                        res = true;
                    }
                }else{
                    for (int i = 0; i <= index; i++) {
                        Map<String, Object> testinput = new HashMap<String, Object>();
                        testinput.put("xmlfilename", fileName);
                        testinput.put("LPNSizeType", "B4");
                        testinput.put("Quantity", qtyval);
                        testinput.put("ShippedAsnQuantity", qtyval);
                        testinput.put("OriginalQuantity", qtyval);
                        testinput.put("ItemName", itemName);
                        testinput.put("LPNID", dataHelper.getLPNNumber());
                        testinput.put("CountryofOrigin", "CN");
                        updateUniqueItemWithMultipleTags(18+i,testinput);
                        res = true;
                    }
                }
            }
        }catch(Exception e){
            logger.error(e.getMessage() + e.getStackTrace());
            res &= false;
        }
        return res;
    }

    public String updateASNDetailsInXML_INT2(int numberOfItems, Map<String, Object> data) {
        String strlocBarCode = "";
        String strQueryID = (String) data.get("queryid");
        WmsXmlDynamicTagDataHelper dataHelper = new WmsXmlDynamicTagDataHelper();
        String asn = dataHelper.getASNNumber();
        List<ProductSummary> ps = InventoryManager.getItemNameByReserveLoc(strQueryID);
        List<ProductSummary> ps1 = InventoryManager.getCustomerByQueryID("customer_id");
        String ASNfileName = (String) data.get("xmlfilename");
        strlocBarCode = ps.get(0).getlocBarCode();
        String qtyval = ps.get(0).getItemQty();
        Map<String, Object> testinput = new HashMap<String, Object>();
        testinput.put("xmlfilename", ASNfileName);
        testinput.put("ASNID", asn);
        testinput.put("Reference_ID",asn);
        testinput.put("Quantity",qtyval);
        testinput.put("ShippedAsnQuantity", qtyval);
        testinput.put("OriginalQuantity", qtyval);
        testinput.put("ItemName", ps.get(0).getItemId());
        testinput.put("CountryofOrigin", ps.get(0).getcntryoforgn());
        testinput.put("LPNID", dataHelper.getLPNNumber());
        testinput.put("OriginFacilityAliasID", ps1.get(0).getoriginFacilityAliasID());
        try {
            for(int i= 0; i<numberOfItems; i++) {
                testinput.remove("LPNID");
                testinput.put("LPNID", dataHelper.getLPNNumber());
                updateUniqueItemWithMultipleTags(i, testinput);

            }
        }catch(Exception e){
            logger.error(e.getMessage() + e.getStackTrace());
        }
        return strlocBarCode;
    }
}