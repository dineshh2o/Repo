package tech.nike.automation.wms.feature.test.templates;

import org.testng.annotations.Test;
import tech.nike.automation.common.framework.BaseTest;
import tech.nike.automation.common.framework.core.Browser;
import tech.nike.automation.common.framework.core.Selenium;
import tech.nike.automation.common.utils.NikePageFactory;
import tech.nike.automation.wms.feature.page.*;

import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Created by psibb1 on 6/23/2016.
 */
public class HamTemplateTest extends BaseTest {

    /**
     * Test method to create a new routing wave template and verify the same
     *
     * @param myBrowser
     * @param se
     * @param params
     */
    @Test(description = "Add new routing wave template1: BIG Non-Promo - Auto for Ham DC", dataProvider = "browserXml",
            groups = {"refresh"}, timeOut = 900000, singleThreaded = true)
    @TestData(fileName = "templates/ham/HAM-00 Routing Wave - BIG Non-Promo - Auto.xml")
    public void createHamRoutingWaveTemplate1(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSShipWaveTemplatePage wmsWaveTempPageObject =
                NikePageFactory.initElements(se.myDriver, WMSShipWaveTemplatePage.class);
        WMSRunWaveTemplatesPage wmsRunWavePageObject =
                NikePageFactory.initElements(se.myDriver, WMSRunWaveTemplatesPage.class);
        WMSTemplateRulePage wmsWaveRulePageObject =
                NikePageFactory.initElements(se.myDriver, WMSTemplateRulePage.class);

        //read input data from parametrized xml file
        String strUrl = (String) params.get("environment");

        //invoke browser
        se.myDriver.get(strUrl);
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //verify user login to WMS
        se.assertion.verifyTrue("User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));

        //verify navigate to system codes page
        se.assertion.verifyTrue("navigate to ship wave templates",
                wmsHomePageObject.menuNavigation("Configuration", "Ship Wave Templates"));

        //verify add template with/without special instructions
        se.assertion.verifyTrue("add a new template", wmsWaveTempPageObject.createANewShipWaveTemplate(params));

        //verify if the template with/without special instructions
        //se.assertion.verifyTrue("verify the template", wmsWaveTempPageObject.verifyANewShipWaveTemplate(params));

        //verify delete a template
        //se.assertion.verifyTrue("delete a template", wmsWaveTempPageObject.deleteShipWaveTemplate(params));

        //verify navigate to Run waves
        se.assertion.verifyTrue("navigate to run waves",
                wmsHomePageObject.menuNavigation("Distribution", "Run Waves"));

        //navigate to run waves
        se.assertion.verifyTrue("navigate to run waves page", wmsRunWavePageObject.navigateToRunWaves(params));

        //add task criteria
        //se.assertion.verifyTrue("add task criteria", wmsWaveRulePageObject.addTaskCriteria(params));

        //navigate capacities
        se.assertion.verifyTrue("navigate capacities", wmsWaveRulePageObject.navigateToCapacities());

        //add capacities
        se.assertion.verifyTrue("add capacities", wmsWaveRulePageObject.addCapacities(params));

        //Creating new rule
        se.assertion.verifyTrue("Creation of New Rule", wmsWaveRulePageObject.addNewRules(params));

        //Garbage collection of failed steps
        testTearDown(se);
    }
    /**
     * Test method to create a new routing wave template and verify the same
     *
     * @param myBrowser
     * @param se
     * @param params
     */
    @Test(description = "Add new routing wave template2: Routing Wave - BIG Promo for Ham DC", dataProvider = "browserXml",
            groups = {"refresh"}, timeOut = 900000, singleThreaded = true)
    @TestData(fileName = "templates/ham/HAM-00 Routing Wave - BIG Promo.xml")
    public void createHamRoutingWaveTemplate2(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSShipWaveTemplatePage wmsWaveTempPageObject =
                NikePageFactory.initElements(se.myDriver, WMSShipWaveTemplatePage.class);
        WMSRunWaveTemplatesPage wmsRunWavePageObject =
                NikePageFactory.initElements(se.myDriver, WMSRunWaveTemplatesPage.class);
        WMSTemplateRulePage wmsWaveRulePageObject =
                NikePageFactory.initElements(se.myDriver, WMSTemplateRulePage.class);

        //read input data from parametrized xml file
        //String strUrl = (String)params.get("environment");

        //invoke browser
        //se.myDriver.get(strUrl);
        //se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //verify user login to WMS
        se.assertion.verifyTrue("User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));

        //verify navigate to system codes page
        se.assertion.verifyTrue("navigate to ship wave templates",
                wmsHomePageObject.menuNavigation("Configuration", "Ship Wave Templates"));

        //verify add template with/without special instructions
        se.assertion.verifyTrue("add a new template", wmsWaveTempPageObject.createANewShipWaveTemplate(params));

        //verify if the template with/without special instructions
        se.assertion.verifyTrue("verify the template", wmsWaveTempPageObject.verifyANewShipWaveTemplate(params));

        //verify delete a template
        //se.assertion.verifyTrue("delete a template", wmsWaveTempPageObject.deleteShipWaveTemplate(params));

        //verify navigate to Run waves
        se.assertion.verifyTrue("navigate to run waves",
                wmsHomePageObject.menuNavigation("Distribution", "Run Waves"));

        //navigate to run waves
        se.assertion.verifyTrue("navigate to run waves page", wmsRunWavePageObject.navigateToRunWaves(params));

        //add task criteria
        //se.assertion.verifyTrue("add task criteria", wmsWaveRulePageObject.addTaskCriteria(params));

        //navigate capacities
        se.assertion.verifyTrue("navigate capacities", wmsWaveRulePageObject.navigateToCapacities());

        //add capacities
        se.assertion.verifyTrue("add capacities", wmsWaveRulePageObject.addCapacities(params));

        //Creating new rule
        se.assertion.verifyTrue("Creation of New Rule", wmsWaveRulePageObject.addNewRules(params));

        //Garbage collection of failed steps
        testTearDown(se);
    }

    /**
     * Test method to create a new routing wave template and verify the same
     *
     * @param myBrowser
     * @param se
     * @param params
     */
    @Test(description = "Add new routing wave template3: Routing Wave - 4 Hourly Promo for Ham DC", dataProvider = "browserXml",
            groups = {"refresh"}, timeOut = 900000, singleThreaded = true)
    @TestData(fileName = "templates/ham/HAM-00 Routing Wave - 4 Hourly Promo - Auto.xml")
    public void createHamRoutingWaveTemplate3(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSShipWaveTemplatePage wmsWaveTempPageObject =
                NikePageFactory.initElements(se.myDriver, WMSShipWaveTemplatePage.class);
        WMSRunWaveTemplatesPage wmsRunWavePageObject =
                NikePageFactory.initElements(se.myDriver, WMSRunWaveTemplatesPage.class);
        WMSTemplateRulePage wmsWaveRulePageObject =
                NikePageFactory.initElements(se.myDriver, WMSTemplateRulePage.class);

        //read input data from parametrized xml file
        //String strUrl = (String)params.get("environment");

        //invoke browser
        //se.myDriver.get(strUrl);
        //se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //verify user login to WMS
        se.assertion.verifyTrue("User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));

        //verify navigate to system codes page
        se.assertion.verifyTrue("navigate to ship wave templates",
                wmsHomePageObject.menuNavigation("Configuration", "Ship Wave Templates"));

        //verify add template with/without special instructions
        se.assertion.verifyTrue("add a new template", wmsWaveTempPageObject.createANewShipWaveTemplate(params));

        //verify if the template with/without special instructions
        se.assertion.verifyTrue("verify the template", wmsWaveTempPageObject.verifyANewShipWaveTemplate(params));

        //verify delete a template
        //se.assertion.verifyTrue("delete a template", wmsWaveTempPageObject.deleteShipWaveTemplate(params));

        //verify navigate to Run waves
        se.assertion.verifyTrue("navigate to run waves",
                wmsHomePageObject.menuNavigation("Distribution", "Run Waves"));

        //navigate to run waves
        se.assertion.verifyTrue("navigate to run waves page", wmsRunWavePageObject.navigateToRunWaves(params));

        //add task criteria
        //se.assertion.verifyTrue("add task criteria", wmsWaveRulePageObject.addTaskCriteria(params));

        //navigate capacities
        se.assertion.verifyTrue("navigate capacities", wmsWaveRulePageObject.navigateToCapacities());

        //add capacities
        se.assertion.verifyTrue("add capacities", wmsWaveRulePageObject.addCapacities(params));

        //Creating new rule
        se.assertion.verifyTrue("Creation of New Rule", wmsWaveRulePageObject.addNewRules(params));

        //Garbage collection of failed steps
        testTearDown(se);
    }
    /**
     * Test method to create a new routing wave template and verify the same
     *
     * @param myBrowser
     * @param se
     * @param params
     */
    @Test(description = "Add new routing wave template4: Routing Wave - 4 Hr Non-Promo for Ham DC", dataProvider = "browserXml",
            groups = {"refresh"}, timeOut = 900000, singleThreaded = true)
    @TestData(fileName = "templates/ham/HAM-00 Routing Wave - 4 Hr Non-Promo - Auto.xml")
    public void createHamRoutingWaveTemplate4(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSShipWaveTemplatePage wmsWaveTempPageObject =
                NikePageFactory.initElements(se.myDriver, WMSShipWaveTemplatePage.class);
        WMSRunWaveTemplatesPage wmsRunWavePageObject =
                NikePageFactory.initElements(se.myDriver, WMSRunWaveTemplatesPage.class);
        WMSTemplateRulePage wmsWaveRulePageObject =
                NikePageFactory.initElements(se.myDriver, WMSTemplateRulePage.class);

        //read input data from parametrized xml file
        //String strUrl = (String)params.get("environment");

        //invoke browser
        //se.myDriver.get(strUrl);
        //se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //verify user login to WMS
        se.assertion.verifyTrue("User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));

        //verify navigate to system codes page
        se.assertion.verifyTrue("navigate to ship wave templates",
                wmsHomePageObject.menuNavigation("Configuration", "Ship Wave Templates"));

        //verify add template with/without special instructions
        se.assertion.verifyTrue("add a new template", wmsWaveTempPageObject.createANewShipWaveTemplate(params));

        //verify if the template with/without special instructions
        se.assertion.verifyTrue("verify the template", wmsWaveTempPageObject.verifyANewShipWaveTemplate(params));

        //verify delete a template
        //se.assertion.verifyTrue("delete a template", wmsWaveTempPageObject.deleteShipWaveTemplate(params));

        //verify navigate to Run waves
        se.assertion.verifyTrue("navigate to run waves",
                wmsHomePageObject.menuNavigation("Distribution", "Run Waves"));

        //navigate to run waves
        se.assertion.verifyTrue("navigate to run waves page", wmsRunWavePageObject.navigateToRunWaves(params));

        //add task criteria
        //se.assertion.verifyTrue("add task criteria", wmsWaveRulePageObject.addTaskCriteria(params));

        //navigate capacities
        se.assertion.verifyTrue("navigate capacities", wmsWaveRulePageObject.navigateToCapacities());

        //add capacities
        se.assertion.verifyTrue("add capacities", wmsWaveRulePageObject.addCapacities(params));

        //Creating new rule
        se.assertion.verifyTrue("Creation of New Rule", wmsWaveRulePageObject.addNewRules(params));

        //Garbage collection of failed steps
        testTearDown(se);
    }

    /**
     * Test method to create a new routing wave template and verify the same
     *
     * @param myBrowser
     * @param se
     * @param params
     */
    @Test(description = "Add new routing wave template1: Pick Wave - Automation Testing for Ham DC", dataProvider = "browserXml",
            groups = {"refresh"}, timeOut = 900000, singleThreaded = true)
    @TestData(fileName = "templates/ham/HAM-02 Pick Wave - Automation Testing.xml")
    public void createHamPickingWaveTemplate1(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSShipWaveTemplatePage wmsWaveTempPageObject =
                NikePageFactory.initElements(se.myDriver, WMSShipWaveTemplatePage.class);
        WMSRunWaveTemplatesPage wmsRunWavePageObject =
                NikePageFactory.initElements(se.myDriver, WMSRunWaveTemplatesPage.class);
        WMSTemplateRulePage wmsWaveRulePageObject =
                NikePageFactory.initElements(se.myDriver, WMSTemplateRulePage.class);

        //read input data from parametrized xml file
        //String strUrl = (String)params.get("environment");

        //invoke browser
        //se.myDriver.get(strUrl);
        //se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //verify user login to WMS
        se.assertion.verifyTrue("User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));

        //verify navigate to system codes page
        se.assertion.verifyTrue("navigate to ship wave templates",
                wmsHomePageObject.menuNavigation("Configuration", "Ship Wave Templates"));

        //verify add template with/without special instructions
        se.assertion.verifyTrue("add a new template", wmsWaveTempPageObject.createANewShipWaveTemplate(params));

        //verify if the template with/without special instructions
        se.assertion.verifyTrue("verify the template", wmsWaveTempPageObject.verifyANewShipWaveTemplate(params));

        //verify delete a template
        //se.assertion.verifyTrue("delete a template", wmsWaveTempPageObject.deleteShipWaveTemplate(params));

        //verify navigate to Run waves
        se.assertion.verifyTrue("navigate to run waves",
                wmsHomePageObject.menuNavigation("Distribution", "Run Waves"));

        //navigate to run waves
        se.assertion.verifyTrue("navigate to run waves page", wmsRunWavePageObject.navigateToRunWaves(params));

        //add task criteria
        se.assertion.verifyTrue("add task criteria", wmsWaveRulePageObject.addTaskCriteria(params));

        //navigate capacities
        se.assertion.verifyTrue("navigate capacities", wmsWaveRulePageObject.navigateToCapacities());

        //add capacities
        se.assertion.verifyTrue("add capacities", wmsWaveRulePageObject.addCapacities(params));

        //Creating new rule
        se.assertion.verifyTrue("Creation of New Rule", wmsWaveRulePageObject.addNewRules(params));

        //Garbage collection of failed steps
        testTearDown(se);
    }

    /**
     * Test method to create a new routing wave template and verify the same
     *
     * @param myBrowser
     * @param se
     * @param params
     */
    @Test(description = "Add new routing wave template2: Pick Wave - Hourly Non-Promo for Ham DC", dataProvider = "browserXml",
            groups = {"refresh"}, timeOut = 900000, singleThreaded = true)
    @TestData(fileName = "templates/ham/HAM-2 Pick Wave - Hourly Non-Promo.xml")
    public void createHamPickingWaveTemplate2(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSShipWaveTemplatePage wmsWaveTempPageObject =
                NikePageFactory.initElements(se.myDriver, WMSShipWaveTemplatePage.class);
        WMSRunWaveTemplatesPage wmsRunWavePageObject =
                NikePageFactory.initElements(se.myDriver, WMSRunWaveTemplatesPage.class);
        WMSTemplateRulePage wmsWaveRulePageObject =
                NikePageFactory.initElements(se.myDriver, WMSTemplateRulePage.class);

        //read input data from parametrized xml file
        //String strUrl = (String)params.get("environment");

        //invoke browser
        //se.myDriver.get(strUrl);
        //se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //verify user login to WMS
        se.assertion.verifyTrue("User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));

        //verify navigate to system codes page
        se.assertion.verifyTrue("navigate to ship wave templates",
                wmsHomePageObject.menuNavigation("Configuration", "Ship Wave Templates"));

        //verify add template with/without special instructions
        se.assertion.verifyTrue("add a new template", wmsWaveTempPageObject.createANewShipWaveTemplate(params));

        //verify if the template with/without special instructions
        se.assertion.verifyTrue("verify the template", wmsWaveTempPageObject.verifyANewShipWaveTemplate(params));

        //verify delete a template
        //se.assertion.verifyTrue("delete a template", wmsWaveTempPageObject.deleteShipWaveTemplate(params));

        //verify navigate to Run waves
        se.assertion.verifyTrue("navigate to run waves",
                wmsHomePageObject.menuNavigation("Distribution", "Run Waves"));

        //navigate to run waves
        se.assertion.verifyTrue("navigate to run waves page", wmsRunWavePageObject.navigateToRunWaves(params));

        //add task criteria
        se.assertion.verifyTrue("add task criteria", wmsWaveRulePageObject.addTaskCriteria(params));

        //navigate capacities
        se.assertion.verifyTrue("navigate capacities", wmsWaveRulePageObject.navigateToCapacities());

        //add capacities
        se.assertion.verifyTrue("add capacities", wmsWaveRulePageObject.addCapacities(params));

        //Creating new rule
        se.assertion.verifyTrue("Creation of New Rule", wmsWaveRulePageObject.addNewRules(params));

        //Garbage collection of failed steps
        testTearDown(se);
    }

    /**
     * Test method to create a new routing wave template and verify the same
     *
     * @param myBrowser
     * @param se
     * @param params
     */
    @Test(description = "Add new routing wave template3: Pick Wave - Hourly for Ham DC", dataProvider = "browserXml",
            groups = {"refresh"}, timeOut = 900000, singleThreaded = true)
    @TestData(fileName = "templates/ham/HAM-2 Pick Wave - Hourly.xml")
    public void createHamPickingWaveTemplate3(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSShipWaveTemplatePage wmsWaveTempPageObject =
                NikePageFactory.initElements(se.myDriver, WMSShipWaveTemplatePage.class);
        WMSRunWaveTemplatesPage wmsRunWavePageObject =
                NikePageFactory.initElements(se.myDriver, WMSRunWaveTemplatesPage.class);
        WMSTemplateRulePage wmsWaveRulePageObject =
                NikePageFactory.initElements(se.myDriver, WMSTemplateRulePage.class);

        //read input data from parametrized xml file
        //String strUrl = (String)params.get("environment");

        //invoke browser
        //se.myDriver.get(strUrl);
        //se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //verify user login to WMS
        se.assertion.verifyTrue("User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));

        //verify navigate to system codes page
        se.assertion.verifyTrue("navigate to ship wave templates",
                wmsHomePageObject.menuNavigation("Configuration", "Ship Wave Templates"));

        //verify add template with/without special instructions
        se.assertion.verifyTrue("add a new template", wmsWaveTempPageObject.createANewShipWaveTemplate(params));

        //verify if the template with/without special instructions
        se.assertion.verifyTrue("verify the template", wmsWaveTempPageObject.verifyANewShipWaveTemplate(params));

        //verify delete a template
        //se.assertion.verifyTrue("delete a template", wmsWaveTempPageObject.deleteShipWaveTemplate(params));

        //verify navigate to Run waves
        se.assertion.verifyTrue("navigate to run waves",
                wmsHomePageObject.menuNavigation("Distribution", "Run Waves"));

        //navigate to run waves
        se.assertion.verifyTrue("navigate to run waves page", wmsRunWavePageObject.navigateToRunWaves(params));

        //add task criteria
        se.assertion.verifyTrue("add task criteria", wmsWaveRulePageObject.addTaskCriteria(params));

        //navigate capacities
        se.assertion.verifyTrue("navigate capacities", wmsWaveRulePageObject.navigateToCapacities());

        //add capacities
        se.assertion.verifyTrue("add capacities", wmsWaveRulePageObject.addCapacities(params));

        //Creating new rule
        se.assertion.verifyTrue("Creation of New Rule", wmsWaveRulePageObject.addNewRules(params));

        //Garbage collection of failed steps
        testTearDown(se);
    }
}