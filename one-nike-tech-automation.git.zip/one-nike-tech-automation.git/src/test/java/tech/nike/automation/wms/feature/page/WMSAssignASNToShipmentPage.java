package tech.nike.automation.wms.feature.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import tech.nike.automation.common.page.Page;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Created by PSibb1 on 1/12/2017.
 */
public class WMSAssignASNToShipmentPage extends Page {
    /**
     * Locators
     */
    public By txtASN = By.cssSelector("[alt='Find ASN'][type='text']");
    public By btnApplyASN = By.id("dataForm:ASN_filterId:ASN_filterIdapply");
    public By txtShipment = By.cssSelector("[alt='Find Shipment'][type='text']");
    public By btnApplyShipment = By.id("dataForm:Ship_filterId:Ship_filterIdapply");
    public By chkASN = By.cssSelector("[title='ASN'][type='checkbox']");
    public By chkShipment = By.cssSelector("[title='Shipment'][type='checkbox']");
    public By imgMoveRight = By.cssSelector("[id='move_right']>input");
    public By imgMoveLeft = By.cssSelector("[id='move_left']>input");
    public By btnCreateShipmentID = By.cssSelector("[value='Create Shipment ID'][type='button']");
    public By btnSave = By.cssSelector("[value='Save'][type='button']");
    public By btnDeleteShipment = By.cssSelector("[value='Delete/Cancel Shipment'][type='button']");
    public By btnReset = By.cssSelector("[value='Reset'][type='button']");
    public By lblASN = By.cssSelector("[title='ASN'][type='checkbox']+span");
    public By lblShipment = By.cssSelector("[title='Shipment'][type='checkbox']+span");
    public By imgCollapsedShipment = By.cssSelector(".rich-tree-node-handleicon-collapsed");
    public By imgExpandedShipment = By.cssSelector(".rich-tree-node-handleicon-expanded");
    /*create shipment ID locators*/
    public By txtCreatShipmentID = By.cssSelector(".pop_body.-pdlg_dbg>table>tbody>tr>td:nth-child(2)>[id^='dataForm:shipmentId']");
    public By btnGenerate = By.cssSelector(".pop_body.-pdlg_dbg>table>tbody>tr>td:nth-child(3)>[value='Generate'][type='button']");
    public By btnOK = By.cssSelector(".pop_body.-pdlg_dbg>table>tbody>tr>td:nth-child(3)>[value='OK'][type='button']");
    public By btnCancel = By.cssSelector(".pop_body.-pdlg_dbg>table>tbody>tr>td:nth-child(3)>[value='Cancel'][type='button']");
    public By txtChildASN = By.cssSelector("#atablee2 > tbody > tr > td:nth-child(2)");


    /**
     * method to filter records by ASN number
     *
     * @param strASNNumber
     * @return
     */
    public boolean filterASN(String strASNNumber) {
        boolean result = false;
        //wait for the element to be displayed
        result = se.element.waitForElementToBeClickable(txtASN);
        //checked if required ASN search field was displayed
        se.element.requireIsDisplayed("ASN search field", txtASN);
        //verify if the element is visible
        result &= se.element.isVisible(txtASN);
        //enter the ASN number
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtASN, strASNNumber);
        //verify if the apply button is displayed
        se.element.requireIsDisplayed("Apply button", btnApplyASN);
        //verify if the apply button is clickable
        result &= se.element.waitForElementToBeClickable(btnApplyASN);
        //click on the apply button
        se.element.clickElement(btnApplyASN);
        return result;
    }

    /**
     * method to select already filtered ASN number
     *
     * @return
     */
    public boolean selectASNNumber(String strASNNumber) {
        boolean result = false;
        //wait for the element to be displayed
        result = se.element.waitForElementToBeClickable(chkASN, 10);
        //checked if required ASN search field was displayed
        se.element.requireIsDisplayed("ASN checkbox field", chkASN);
        //select the user specified checkbox
        se.element.clickElement(chkASN);
        //add a qc step logging
        se.log.testStep("Selected ASN number " + strASNNumber);
        return result;
    }

    /**
     * method to verify already filtered ASN number status
     *
     * @return
     */
    public boolean verifyASNNumberStatus(String strASNNumber) {
        boolean result = false;
        //wait for the element to be displayed
        result = se.element.waitForElementToBeClickable(chkASN);
        //checked if required ASN search field was displayed
        se.element.requireIsDisplayed("ASN checkbox field", chkASN);
        //verify the status of selected ASN number
        result &= se.element.isVisible(lblASN);
        String strASNStatus = se.element.getText(lblASN).trim();
        if (!strASNStatus.contains("InTransit")) {
            result = false;
        } else {
            se.log.testStep("Verified the ASN Number " + strASNNumber + " " +
                    "status on the Assign ASN to Shipment screen, status was found to be in " + strASNStatus);
        }
        return result;
    }

    /**
     * wrapper method to check the asn status on Assign ASN to Shipment screen
     *
     * @param strASNNumber
     * @return
     */
    public boolean verifyASNStatus(String strASNNumber) {
        boolean result = false;
        result = filterASN(strASNNumber);
        result &= selectASNNumber(strASNNumber);
        result &= verifyASNNumberStatus(strASNNumber);
        result &= verifyVisibleShipmentsStatuses();
        return result;
    }

    /**
     * method to verify shipment status on Assign ASN to Shipment screen
     *
     * @return
     */
    public boolean verifyVisibleShipmentsStatuses() {
        boolean result = false;
        int index = 0;
        //get list of all the shipment checkboxes into a list
        List<WebElement> shipChecks = se.element.getElements(lblShipment);
        //verify if at least one shipment checkbox is displayed
        result = shipChecks.get(0).isDisplayed();
        for (WebElement check : shipChecks) {
            //check if the shipment checkbox is displayed
            result &= check.isDisplayed();
            //verify the status of each visible individual shipment checkbox status
            String strShipStatus = check.getText().trim();
            String newShipNumber = strShipStatus.substring(0, strShipStatus.indexOf("(")).trim();
            if (!strShipStatus.contains("In Transit")) {
                result &= false;
            } else {
                se.log.seStep("Verified the Shipment status of shipment " + newShipNumber + " " +
                        "at position " + index + "  status as " + strShipStatus);
            }
            index = index + 1;
        }
        return result;
    }

    /**
     * method to generate to shipment id
     *
     * @return
     */
    public String generateShipmentID() {
        //verify if the Create shipment id button is displayed
        se.element.requireIsDisplayed("Create Shipment ID", btnCreateShipmentID);
        //verify if the create shipment if button is clickable
        se.element.isClickable(btnCreateShipmentID);
        //click on the create shipment id button
        se.element.clickElement(btnCreateShipmentID);
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        //verify if the create shipment table was displayed
        se.element.requireIsDisplayed("Create Shipment ID", txtCreatShipmentID);
        //verify if the create shipment id is clickable
        se.element.isClickable(txtCreatShipmentID);
        //qc step logging
        se.log.testStep("Create Shipment ID dialog was displayed successfully");
        //verify generate button displayed
        se.element.requireIsDisplayed("Generate", btnGenerate);
        //verify if generate shipment id is clickable
        se.element.isClickable(btnGenerate);
        //generate shipment id
        se.element.clickElement(btnGenerate);
        //wait till some text appear on the shipment id text field assuming it is minimum 4
        se.element.waitForTextLengthIsGreaterThanByAttributeValue(txtCreatShipmentID, 3);
        String genShipmentID = se.element.getAttribute(txtCreatShipmentID, "value").trim();
        //verify if the length of generated shipment id > 0
        if (genShipmentID.length() != 0) {
            //update the generated shipment id to xml file for later use in test case
               /* XMLUpdateHelper.addXmlTagWithValueToXmlFile(
                        new File("/Users/psibb1/workspace/nike-tech-selenium-templates/src/test/resources/wms/testdata/herentalsinputdata.xml").getAbsolutePath(),
                        "shipmentid", genShipmentID);*/
        } else {
            se.log.testStep("Shipment number was null, hence test failed");
        }
        return genShipmentID;
    }

    /**
     * method to already selected assign asn to shipment by shipment id
     *
     * @param strShipmentID
     * @return
     */
    public boolean selectGeneratedShipment(String strShipmentID) {
        boolean result = false;
        int index = 0;
        String strShipStatus;
        String newShipNumber;
        //verify if the required field was displayed
        se.element.requireIsDisplayed("OK button", btnOK);
        //verify if the Ok button is clickable
        result = se.element.waitForElementToBeClickable(btnOK, 5);
        //click on the ok button
        se.element.clickElement(btnOK);
        //this wait is needed as the application is loading asynchronously
        se.element.waitBySleep(2000);
        se.element.waitUntilCountChanges(lblShipment);
        se.log.testStep("Clicked on the OK button");
        //Verify if the new shipment has been added under the shipment list
        //get list of all the shipment checkboxes into a list
        List<WebElement> shipChecksAfter = se.myDriver.findElements(lblShipment);
        List<WebElement> chkShips = se.element.getElements(chkShipment);
        //verify new shipment checkbox is displayed
        // for (int i = 0; i <= shipChecksAfter.size(); i++) {
        for (WebElement we : shipChecksAfter) {
            result &= we != null;
            result &= we.isDisplayed();
            //verify the status of each visible individual shipment checkbox status
            strShipStatus = we.getText().trim();
            newShipNumber = strShipStatus.substring(0, strShipStatus.indexOf("(")).trim();
            if (strShipmentID.equals(newShipNumber)) {
                //select the shipment checkbox
                chkShips.get(index).click();
                se.log.testStep(newShipNumber + " shipment id was selected");
                result &= true;
                break;
            }
            index = index + 1;
        }
        return result;
    }

    /**
     * method to assign asn to shipment and verify asn is displayed under shipment
     *
     * @param strShipmentID
     * @return
     */
    public boolean assignASNToShipment(String strASNNumber, String strShipmentID) {
        boolean result = false;
        int index = 0;
        String strASN;
        boolean blnFlag = false;
        result = selectGeneratedShipment(strShipmentID);
        se.element.hoverAndClick(imgMoveRight, imgMoveRight);
        /*if(se.myDriver.toString().contains("InternetExplorer")){

        }else {
            //verify if the right arrow is clickable
            result &= se.element.isClickable(imgMoveRight);
            //click on the right arrow
            se.element.clickElement(imgMoveRight);
        }*/
        //wait for asynchronous page load
        se.element.waitBySleep(3000);
        se.log.testStep("Clicked on the right arrow");
        //verify if the ASN is under the shipment
        List<WebElement> shipChecks = se.myDriver.findElements(lblShipment);
        List<WebElement> expandButtons = se.myDriver.findElements(imgCollapsedShipment);
        //verify new shipment checkbox is displayed
        result &= shipChecks.get(0).isDisplayed();
        for (WebElement check : shipChecks) {
            //check if the shipment checkbox is displayed
            result &= check.isDisplayed();
            //verify the status of each visible individual shipment checkbox status
            String strShipStatus = check.getText().trim();
            String newShipNumber = strShipStatus.substring(0, strShipStatus.indexOf("(")).trim();
            if (strShipmentID.equals(newShipNumber)) {
                //wait for asynchronous page load
                se.element.waitBySleep(3000);
                //verify if the expand button is enabled
                result &= expandButtons.get(index).isEnabled();
                se.element.hoverAndClick(expandButtons.get(index), expandButtons.get(index));
                /*if(se.myDriver.toString() == "InternetExplorer") {
                    Actions ob = new Actions(se.myDriver);
                    ob.moveToElement(expandButtons.get(index)).click().build().perform();
                    ob.release();
                }else {
                    //expand the shipment Id to find the ASN associated
                    expandButtons.get(index).click();
                }*/
                //wait for asynchronous page load
                se.element.waitBySleep(3000);
                //verify if the ASN number is displayed under the shipment id
                List<WebElement> childs = se.myDriver.findElements(txtChildASN);
                for (WebElement child : childs) {
                    strASN = child.getText().trim();
                    if (strASNNumber.equalsIgnoreCase(strASN)) {
                        result &= true;
                        se.log.testStep(strASNNumber + " ASN was associated to shipment ID "
                                + strShipmentID + " successfully");
                        blnFlag = true;
                        break;
                    }
                }
            }
            if (blnFlag) {
                break;
            }
            index = index + 1;
        }
        return result;
    }

    /**
     * method to save the asn assigned to shipment
     *
     * @return
     */
    public boolean saveShipment(String shipId) {
        boolean result = false;
        int index = 0;
        boolean blnFlag = false;
        //verify if the required field was displayed
        se.element.requireIsDisplayed("Save button", btnSave);
        //verify if the save button was clickable
        result = se.element.isClickable(btnSave);
        //click on the save button
        se.element.clickElement(btnSave);
        //wait due to asynchronous page load
        se.element.waitBySleep(5000);
        se.log.testStep("Clicked on the Save button");
        //verify if new shipment saved with Status, Pickup Facility, Delivery Facility values
        //get list of all the shipment checkboxes into a list
        List<WebElement> shipChecks = se.element.getElements(lblShipment);
        //verify if at least one shipment checkbox is displayed
        result = shipChecks.get(0).isDisplayed();
        for (WebElement check : shipChecks) {
            //check if the shipment checkbox is displayed
            result &= check.isDisplayed();
            //verify the status of each visible individual shipment checkbox status
            String strShipStatus = check.getText().trim();
            String newShipNumber = strShipStatus.substring(0, strShipStatus.indexOf("(")).trim();
            String[] newStatus = strShipStatus.split(", ");
            if (shipId.equals(newShipNumber) && strShipStatus.contains("In Transit") && newStatus.length == 3) {
                se.log.seStep("Verified the Shipment status of shipment " + newShipNumber + " " +
                        "at position " + index + "  status as " + strShipStatus + " Pickup Facility " + newStatus[1] +
                        " Delivery Facility " + newStatus[2]);
                blnFlag = true;
                break;
            }
            index = index + 1;
        }
        if (blnFlag) {
            result &= blnFlag;
        }
        return result;
    }
}