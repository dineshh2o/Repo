package tech.nike.automation.wms.feature.test.inbound.ham;

import org.testng.annotations.Test;
import tech.nike.automation.common.framework.BaseTest;
import tech.nike.automation.common.framework.core.Browser;
import tech.nike.automation.common.framework.core.Selenium;
import tech.nike.automation.common.framework.jmxmessaging.WMSMessaging;
import tech.nike.automation.common.framework.utils.XMLUpdateHelper;
import tech.nike.automation.common.utils.NikePageFactory;
import tech.nike.automation.common.utils.UpdateSyntheticXml;
import tech.nike.automation.wms.feature.page.*;

import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Created by PSibb1 on 1/12/2017.
 */
public class Inbound extends BaseTest {
    UpdateSyntheticXml syndata = new UpdateSyntheticXml();
    XMLUpdateHelper xmlHelper = new XMLUpdateHelper();
    /**
     * Method to post synthetic data into WMS
     *
     * @param myBrowser : browser type used for test
     * @param se        : driver type used for test
     * @param params    : external file data parameters
     */
    @Test(description = "IB_1064NDC_RECV_Auto_NoPall_HP_7_ASN_InitShpmnt_ExistItem_SingleSKU_NoQACheck_EndShipment",
            dataProvider = "browserXml", groups = {"poc"}, timeOut = 900000)
    @TestData(fileName = "wms/testdata/ham/haminputdata.xml")
    public void singleSKU_NoQACheck_EndShipment(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSAssignASNToShipmentPage wmsAssignASNToShipPageObject = NikePageFactory.initElements(se.myDriver,
                WMSAssignASNToShipmentPage.class);
        WMSShipmentsPage wmsShipmentsPage = NikePageFactory.initElements(se.myDriver, WMSShipmentsPage.class);
        WMSEndPointPage wmsEndPointPage = NikePageFactory.initElements(se.myDriver, WMSEndPointPage.class);
        WMSMessageQueuePage wmsMessagePage = NikePageFactory.initElements(se.myDriver, WMSMessageQueuePage.class);
        WMSiLPNsPage wmsiLpnsPage = NikePageFactory.initElements(se.myDriver, WMSiLPNsPage.class);
        WMSDockDoorPage wmsDockDoorPage = NikePageFactory.initElements(se.myDriver, WMSDockDoorPage.class);
        WMSRFLoginPage wmsRFLoginPage = NikePageFactory.initElements(se.myDriver, WMSRFLoginPage.class);
        WMSRFHomePage wmsRFHomePage = NikePageFactory.initElements(se.myDriver, WMSRFHomePage.class);
        WMSASNsPage wmsASNPage = NikePageFactory.initElements(se.myDriver, WMSASNsPage.class);
        WMSVerifyASNsPage wmsVerifyASNPage = NikePageFactory.initElements(se.myDriver, WMSVerifyASNsPage.class);
        WMSMessaging wmsmessage = new WMSMessaging();

        //read input data from test data xml file
        String strUrl = (String) params.get("environment");
        String strEndPointName1 = (String)params.get("endpointname1");
        String strEndPointName2 = (String)params.get("endpointname2");
        String strLocation = "2400000001";
        String syntheticXMlFileName = (String)params.get("xmlfilename");
        String hostName = strUrl.replace("http://", " ");
        hostName = hostName.substring(0, hostName.indexOf(".")).trim();

        //update synthetic xml file before posting
        se.assertion.verifyTrue("Step0: Pre-Requisite: Test data preparation",
                syndata.updateSingleSkuASNDetailsInXML(params));

        //read input from the synthetic xml file
        String strASNNumber = xmlHelper.getValueByTagName(syntheticXMlFileName, "ASNID");
        String strLPNNumber = xmlHelper.getValueByTagName(syntheticXMlFileName, "LPNID");
        String strSku = xmlHelper.getValueByTagName(syntheticXMlFileName, "ItemName");
        String strQty = xmlHelper.getValueByTagName(syntheticXMlFileName, "Quantity");
        strQty = strQty.substring(0, strQty.indexOf("."));
        String strCountryOfOrigin = xmlHelper.getValueByTagName(syntheticXMlFileName, "CountryofOrigin");
        String strItemAttribute = xmlHelper.getValueByTagName(syntheticXMlFileName, "ItemAttribute1");
        //String strSourceUri = "file:///nike/manh/scope/wms/interface/inbound/mhe/containerstatus/CS71-"+strLPNNumber+"-1.dat";
        String strSourceUri = "tcp://*:20201";
        String strmessage1 = "CONTAINERSTATUS^"+strLPNNumber+"^DIVERTED^ROUTINGREQ^UN^2690^^^GR120SC00";
        String strmessage2 = "DEST^"+strASNNumber+"^^^"+strSku+"^"+strCountryOfOrigin+"^"+strItemAttribute+"^^^"
                +Integer.parseInt(strQty)+"^^24-00-000-0-01^"+strLocation+"^^1000^^^^^N^N";

        //invoke browser
        //se.myDriver.get(strUrl);
        //se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //verify user login to WMS
        se.assertion.verifyTrue("Step1a: User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));

        //verify post xml is successful
        se.assertion.verifyTrue("Step1b: post xml", wmsHomePageObject.verifyPostXML(params));

       //select menu assign asn to shipment
        se.assertion.verifyTrue("Step2a: Navigate to Assign ASN to Shipment screen",
                wmsHomePageObject.menuNavigation("Distribution","Assign ASN to Shipment"));

        //verify ASN status
        se.assertion.verifyTrue("Step2b: Verify ASN status",
                wmsAssignASNToShipPageObject.verifyASNStatus(strASNNumber));

        //verify create shipment ID
        String shipmentID =  wmsAssignASNToShipPageObject.generateShipmentID();
        se.assertion.verifyTrue("Step3&4: Verify creation of shipment id", shipmentID.length()!=0);

        //verify assign asn to shipment
        se.assertion.verifyTrue("Step5,6,7&8: Verify assign asn to shipment id",
                wmsAssignASNToShipPageObject.assignASNToShipment(strASNNumber,shipmentID));

        //verify save shipment
        se.assertion.verifyTrue("Step9&10: Verify new shipment saved with Status, P" +
                        "ickup Facility, Delivery Facility values",
                wmsAssignASNToShipPageObject.saveShipment(shipmentID));

        //select shipments menu
        se.assertion.verifyTrue("Step11: Navigate to Shipments screen",
                wmsHomePageObject.menuNavigation("Distribution","Shipments"));

        //verify Inititate Shipment
        se.assertion.verifyTrue("Step12: Search and verify shipment results",
                wmsShipmentsPage.searchAndVerifyShipment(shipmentID));

        //verify Inititate Shipment
        se.assertion.verifyTrue("Step13,14&15: Verify Inititate Shipment",
                wmsShipmentsPage.inititateShipment(shipmentID));

        //select Device Integration Framework menu and navigate to End point list
        se.assertion.verifyTrue("Step16a: Navigate to End point list screen",
                wmsHomePageObject.menuNavigation("Device Integration Framework",
                        "End Point List"));

        //start and end point by name
        se.assertion.verifyTrue("Step16b: Start and end point "+strEndPointName1,
                wmsEndPointPage.startEndPointByName(strEndPointName1));

        //start and end point by name
        se.assertion.verifyTrue("Step16b: Start and end point "+strEndPointName2,
                wmsEndPointPage.startEndPointByName(strEndPointName2));

        //post a jmx message at port 20201
        se.assertion.verifyTrue("Step17: Post a jmx message at port 20201",
                wmsmessage.post201Message(strLPNNumber, hostName));

        //select Device Integration Framework menu and navigate to Message Queue
        se.assertion.verifyTrue("Step18: Navigate to Message Queue screen",
                wmsHomePageObject.menuNavigation("Device Integration Framework",
                        "Message Queue"));

        //search by end point name
        se.assertion.verifyTrue("Step19: Search by end point name "+strEndPointName1,
                wmsMessagePage.searchByEndPointName(strEndPointName1));

        //sort by status change column
        se.assertion.verifyTrue("Step20: Sort by status change column",
                wmsMessagePage.sortByWhenStatusChanged());

        //verify message queue by source uri and message info
        String whenStatusChanged = wmsMessagePage.verifyMessagesBySourceUri(strSourceUri, strLPNNumber);
        se.assertion.verifyTrue("Step21&22: Verify message queue by source uri and message info",
                whenStatusChanged.length() > 0);

        //select Device Integration Framework menu and navigate to Message Queue
        se.assertion.verifyTrue("Step23: Navigate to Message Queue screen",
                wmsHomePageObject.menuNavigation("Device Integration Framework",
                        "Message Queue"));

        //search message queue by using quick filter & When status changed
        /*se.assertion.verifyTrue("Step24: Verify message queue by using quick filter When status changed",
                wmsMessagePage.quickSearchByTimeStampAndEndPointName(strEndPointName2, whenStatusChanged));*/

        //select Device Integration Framework menu and navigate to Message Queue
        /*se.assertion.verifyTrue("Step24a: Navigate to Message Queue screen",
                wmsHomePageObject.menuNavigation("Device Integration Framework",
                        "Message Queue"));*/

        //search by end point name
        se.assertion.verifyTrue("Step24b: Search by end point name "+strEndPointName2,
                wmsMessagePage.searchByEndPointName(strEndPointName2));

        //verify the destination ID and location bar code
        se.assertion.verifyTrue("Step25: Verify the destination ID and location bar code ",
                wmsMessagePage.verifyDestinationLocationByLocationID(strLocation, strLPNNumber));

        //select Device Integration Framework menu and navigate to End point list
        se.assertion.verifyTrue("Step26a: Navigate to End point list screen",
                wmsHomePageObject.menuNavigation("Device Integration Framework",
                        "End Point List"));

        //start and end point by name
        se.assertion.verifyTrue("Step26b: Start and end point "+strEndPointName2,
                wmsEndPointPage.startEndPointByName(strEndPointName2));

        //post a jmx message at port 20202
        se.assertion.verifyTrue("Step26c: Post a jmx message at port 20202",
                wmsmessage.post202Message(strLPNNumber, hostName));

        //select Distribution menu and iLPNs
        se.assertion.verifyTrue("Step28: Select Distribution menu and iLPNs",
                wmsHomePageObject.menuNavigation("Distribution","iLPNs"));

        //verify the LPN details
        se.assertion.verifyTrue("Step29,30,31&32: Verify LPN "+strLPNNumber+" details in iLPN details screen",
                wmsiLpnsPage.verifyLPNDetails(strLPNNumber, strLocation));

        //select Distribution menu and Dock Door
        se.assertion.verifyTrue("Step33: Select Distribution menu and Dock Door",
                wmsHomePageObject.menuNavigation("Distribution","Dock Door"));

        //get open inbound dock door
        String openINBDockDoor = wmsDockDoorPage.getOpenDockDoorByType("INB");
        se.assertion.verifyTrue("Step34&35: Search and select a open INB dock door",
                openINBDockDoor.length()>0 );

        //select Distribution menu and Dock Door
        se.assertion.verifyTrue("Step36a: Select RF menu and RF Menu",
                wmsHomePageObject.menuNavigation("RF","RF Menu"));

        //verify user login to WMS
        se.assertion.verifyTrue("Step36b: User Logged into WMS RF screen",
                wmsRFLoginPage.verifyRFWMSLogin(params));

        //verify if user selected the RF menu
        se.assertion.verifyTrue("Step37: Select Receiving from the main menu",
                wmsRFHomePage.selectMenuOptionByName("RECEIVING"));

        //verify if user selected the RF menu
        se.assertion.verifyTrue("Step38: Select BLIND from the RECEIVING  menu options",
                wmsRFHomePage.selectMenuOptionContainsName("END SHIPMENT"));//BLIND

        //enter dock door number captured from step35
        se.assertion.verifyTrue("Step39: Enter dock door number "+openINBDockDoor+" captured from step35",
                wmsRFHomePage.enterRFDockDoor(openINBDockDoor));

        //enter ASN number in RF screen
        se.assertion.verifyTrue("Step40: Enter Shipment ID number in RF screen "+shipmentID,
                wmsRFHomePage.enterRFShipmentNumber(shipmentID));

        //enter ASN number in RF screen
        se.assertion.verifyTrue("Step41: Click on the End shipment ",
                wmsRFHomePage.clickEndShipment());

        //navigate back to WMS UI
        se.myDriver.get(strUrl);
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //select Distribution menu and ASNs
        se.assertion.verifyTrue("Step43: Select Distribution menu and ASNs",
                wmsHomePageObject.menuNavigation("Distribution","ASNs"));

        //search by ASN number in ASN screen
        se.assertion.verifyTrue("Step44: Search for ASN "+strASNNumber+" number in ASN screen",
                wmsASNPage.searchByASNNumber(strASNNumber));

        //select and ASN in ASN screen
        se.assertion.verifyTrue("Step45a: Select an ASN "+strASNNumber+" on ASN screen",
                wmsASNPage.selectASNNumber(strASNNumber));

        //navigate to verify ASN
        se.assertion.verifyTrue("Step45b: Navigate to Verify ASN",
                wmsASNPage.navigateToVerifyASN());

        //verify the ASN details in Verify ASN screen
        String[] arr =  wmsVerifyASNPage.verifyASNDetails(strASNNumber);
        se.assertion.verifyTrue("Step45c: Verify the ASN details in Verify ASN screen",arr.length > 2);

        //navigate to ASN screen
        se.assertion.verifyTrue("Step46: Verify the ASN details in Verify ASN screen",
                wmsVerifyASNPage.navigateToASNScreen());

        //verify the ASN status after verify ASN
        se.assertion.verifyTrue("Step47: Verify the ASN details in Verify ASN screen",
                wmsASNPage.verifyASNStatusByASNNumber(strASNNumber, "Receiving Verified"));

       //verify sign-out from wms
        se.assertion.verifyTrue("Step48-Logout: User clicked on sign-out",
                wmsHomePageObject.verifyAndClickSignOut());

        //verify sign-out from wms
        se.assertion.verifyTrue("Step49-ConfirmLogout: User confirmed to sign-out",
                wmsHomePageObject.verifyAndClickConfirmSignOut());

        //Garbage collection of failed steps
        testTearDown(se);
    }
}