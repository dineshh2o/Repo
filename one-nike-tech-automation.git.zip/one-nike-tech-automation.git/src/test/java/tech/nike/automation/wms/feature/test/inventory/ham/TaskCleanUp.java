package tech.nike.automation.wms.feature.test.inventory.ham;

import org.testng.annotations.Test;
import tech.nike.automation.common.framework.BaseTest;
import tech.nike.automation.common.framework.core.Browser;
import tech.nike.automation.common.framework.core.Selenium;
import tech.nike.automation.common.framework.testdatamanager.InventoryManager;
import tech.nike.automation.common.framework.testdatamanager.ProductSummary;
import tech.nike.automation.common.utils.NikePageFactory;
import tech.nike.automation.wms.feature.page.*;

import java.util.List;
import java.util.Map;

/**
 * Created by psibb1 on 1/19/2017.
 */
public class TaskCleanUp extends BaseTest {

    /**
     * Method to get task from database and then perform cancellation on task application page
     *
     * @param myBrowser : browser type used for test
     * @param se        : driver type used for test
     * @param params    : external file data parameters
     */
    @Video(recording = false)
    @QCLogging(reportALM = false)
    @Test(description = "Clean of open tasks for herentals DC",
            dataProvider = "browserXml", groups = {"cleanup"}, timeOut = 3600000)
    @TestData(fileName = "inventory/haminventoryData.xml")
    public void taskCleanUpCancel(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSTasksPage wmsTasksPage = NikePageFactory.initElements(se.myDriver, WMSTasksPage.class);

        //read input data from test data xml file
        String strUrl = (String) params.get("erenvironment");
        String syntheticXMlFileName = (String) params.get("xmlfilename");

        // WMS Login to the application
        se.assertion.verifyTrue("Step1: verify user login", wmsLoginPageObject.verifyWMSLogin(params));

        //select menu Tasks
        se.assertion.verifyTrue("Step2: Navigate to Task page",
                wmsHomePageObject.menuNavigation("Distribution", "Tasks"));

        //Method to get task from database and then perform cancellation on task application page
        se.assertion.verifyTrue("Step2: Navigate to Task page",
                wmsTasksPage.verifyTaskCleanup());

        //Garbage collection of failed steps
        testTearDown(se);
    }

    /**
     * Method to get task from database and then perform cancellation on task application page after Accept button
     *
     * @param myBrowser : browser type used for test
     * @param se        : driver type used for test
     * @param params    : external file data parameters
     */
    @Video(recording = false)
    @QCLogging(reportALM = false)
    @Test(description = "Clean of open tasks for herentals DC",
            dataProvider = "browserXml", groups = {"cleanup"}, timeOut = 3600000)
    @TestData(fileName = "inventory/haminventoryData.xml")
    public void taskCleanUpCancelAccept(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSTasksPage wmsTasksPage = NikePageFactory.initElements(se.myDriver, WMSTasksPage.class);

        //read input data from test data xml file
        String strUrl = (String) params.get("erenvironment");
        String syntheticXMlFileName = (String) params.get("xmlfilename");

        // WMS Login to the application
        se.assertion.verifyTrue("Step1: verify user login", wmsLoginPageObject.verifyWMSLogin(params));

        //select menu Tasks
        se.assertion.verifyTrue("Step2: Navigate to Task page",
                wmsHomePageObject.menuNavigation("Distribution", "Tasks"));

        //Method to get task from database and then perform cancellation on task application page after Accept button
        se.assertion.verifyTrue("Step2: Navigate to Task page",
                wmsTasksPage.verifyTaskCleanupCancelAccept());

        //Garbage collection of failed steps
        testTearDown(se);
    }

    /**
     * Method to get task from database and then perform Undo on wave application page
     *
     * @param myBrowser : browser type used for test
     * @param se        : driver type used for test
     * @param params    : external file data parameters
     */
    @Video(recording = false)
    @QCLogging(reportALM = false)
    @Test(description = "Clean of open tasks for herentals DC",
            dataProvider = "browserXml", groups = {"cleanup"}, timeOut = 3600000)
    @TestData(fileName = "inventory/haminventoryData.xml")
    public void taskCleanUpUsingWavePage(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSWavesPage wmsWavesPage = NikePageFactory.initElements(se.myDriver, WMSWavesPage.class);

        //read input data from test data xml file
        String strUrl = (String) params.get("erenvironment");
        String syntheticXMlFileName = (String) params.get("xmlfilename");

        // WMS Login to the application
        se.assertion.verifyTrue("Step1: verify user login", wmsLoginPageObject.verifyWMSLogin(params));

        //select menu Tasks
        se.assertion.verifyTrue("Step2: Navigate to Wave page",
                wmsHomePageObject.menuNavigation("Distribution", "Waves"));

        //Method to get task from database and then perform Undo on wave application page
        se.assertion.verifyTrue("Step2: Navigate to Wave page",
                wmsWavesPage.verifyTaskCleanupUsingWavePage());

        //Garbage collection of failed steps
        testTearDown(se);
    }

    /**
     * Method to Cancel DOs having status id 150
     *
     * @param myBrowser : browser type used for test
     * @param se        : driver type used for test
     * @param params    : external file data parameters
     */
    @Video(recording = false)
    @QCLogging(reportALM = false)
    @Test(description = "Clean of open tasks for herentals DC",
            dataProvider = "browserXml", groups = {"cleanup"}, timeOut = 3600000)
    @TestData(fileName = "inventory/haminventoryData.xml")
    public void cancelDOsHavingPackedAndStagedStatus(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSWavesPage wmsWavesPage = NikePageFactory.initElements(se.myDriver, WMSWavesPage.class);
        WMSDistributionOrdersPage wmsDistributionOrdersPage = NikePageFactory.initElements(se.myDriver, WMSDistributionOrdersPage.class);

        //read input data from test data xml file
        String strUrl = (String) params.get("erenvironment");
        //String syntheticXMlFileName = (String) params.get("xmlfilename");

        // WMS Login to the application
        se.assertion.verifyTrue("Step1: verify user login", wmsLoginPageObject.verifyWMSLogin(params));

        //select menu Tasks
        se.assertion.verifyTrue("Step2: Navigate to DO page",
                wmsHomePageObject.menuNavigation("Distribution", "Distribution Orders"));

        //Method to get DO from database and then perform Cancellation on DO application page
        se.assertion.verifyTrue("Step3: Navigate to DO page",
                wmsDistributionOrdersPage.verifyDOCleanupHavingPackedAndStagedStatus());

        //Garbage collection of failed steps
        testTearDown(se);
    }

    /**
     * Method to Cancel DOs having status id 150
     *
     * @param myBrowser : browser type used for test
     * @param se        : driver type used for test
     * @param params    : external file data parameters
     */
    @Video(recording = false)
    @QCLogging(reportALM = false)
    @Test(description = "Clean of open tasks for herentals DC",
            dataProvider = "browserXml", groups = {"cleanup"}, timeOut = 3600000)
    @TestData(fileName = "inventory/haminventoryData.xml")
    public void cancelDOsHavingReleasedAndDCAllocatedAndInPackingStatus(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSWavesPage wmsWavesPage = NikePageFactory.initElements(se.myDriver, WMSWavesPage.class);
        WMSDistributionOrdersPage wmsDistributionOrdersPage = NikePageFactory.initElements(se.myDriver, WMSDistributionOrdersPage.class);

        //read input data from test data xml file
        String strUrl = (String) params.get("erenvironment");
        //String syntheticXMlFileName = (String) params.get("xmlfilename");

        // WMS Login to the application
        se.assertion.verifyTrue("Step1: verify user login", wmsLoginPageObject.verifyWMSLogin(params));

        //select menu Tasks
        se.assertion.verifyTrue("Step2: Navigate to DO page",
                wmsHomePageObject.menuNavigation("Distribution", "Distribution Orders"));

        //Method to get DO from database and then perform Cancellation on DO application page
        se.assertion.verifyTrue("Step3: Navigate to DO page",
                wmsDistributionOrdersPage.verifyDOCleanupHavingReleasedAndDCAllocatedAndInPackingStatus());

        //Garbage collection of failed steps
        testTearDown(se);
    }
}