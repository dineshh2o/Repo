package tech.nike.automation.wms.feature.test.inbound.herentals;

import org.testng.annotations.Test;
import tech.nike.automation.common.framework.BaseTest;
import tech.nike.automation.common.framework.core.Browser;
import tech.nike.automation.common.framework.core.Selenium;
import tech.nike.automation.common.framework.utils.XMLUpdateHelper;
import tech.nike.automation.common.utils.NikePageFactory;
import tech.nike.automation.common.utils.UpdateSyntheticXml;
import tech.nike.automation.wms.feature.page.*;

import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Created by psibb1 on 1/18/2017.
 */
public class HerentalsInbound extends BaseTest {
    UpdateSyntheticXml syndata = new UpdateSyntheticXml();
    XMLUpdateHelper xmlHelper = new XMLUpdateHelper();
    /**
     * Method to prepare xml data
     * @param se        : driver type used for test
     * @param params    : external file data parameters
     */
    @Test(description = "To validate the Initiate shipment Updates for a shipment with Multiple ASNs",
            dataProvider = "browserXml", groups = {"poc"}, timeOut = 900000)
    @TestData(fileName = "wms/testdata/herentals/herentalsinputdata.xml")
    @Video(recording = false)
    @QCLogging(reportALM = false)
    public void verifyInititateShipmentMultiASN(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSAssignASNToShipmentPage wmsAssignASNToShipPageObject = NikePageFactory.initElements(se.myDriver,
                WMSAssignASNToShipmentPage.class);
        WMSShipmentsPage wmsShipmentsPage = NikePageFactory.initElements(se.myDriver, WMSShipmentsPage.class);
        WMSASNsPage wmsASNPage = NikePageFactory.initElements(se.myDriver, WMSASNsPage.class);

        //read input data from test data xml file
        //String strUrl = (String) params.get("environment");
        String syntheticXMlFileName = (String)params.get("xmlfilename");

        //update synthetic xml file before posting
        se.assertion.verifyTrue("Step0: Pre-Requisite: Test data preparation",
                syndata.updateMultipleSkuASNDetailsInXML(3, params));

        //read input from the synthetic xml file
        String strASNNumber1 = xmlHelper.getValueByTagName(syntheticXMlFileName, 0, "ASNID");
        String strASNNumber2 = xmlHelper.getValueByTagName(syntheticXMlFileName, 1, "ASNID");
        String strASNNumber3 = xmlHelper.getValueByTagName(syntheticXMlFileName, 2, "ASNID");

        //invoke browser
       /* se.myDriver.get(strUrl);
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);*/

        //verify user login to WMS
        se.assertion.verifyTrue("Step1a: User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));

        //verify post xml is successful
        se.assertion.verifyTrue("Step1b: post xml", wmsHomePageObject.verifyPostXML(params));

        //select menu assign asn to shipment
        se.assertion.verifyTrue("Step2a: Navigate to Assign ASN to Shipment screen",
                wmsHomePageObject.menuNavigation("Distribution","Assign ASN to Shipment"));

        //verify ASN status
        se.assertion.verifyTrue("Step2b: Verify ASN status",
                wmsAssignASNToShipPageObject.verifyASNStatus(strASNNumber1));

        //verify create shipment ID
        String shipmentID1 =  wmsAssignASNToShipPageObject.generateShipmentID();
        se.assertion.verifyTrue("Step3&4: Verify creation of shipment id", shipmentID1.length()!=0);

        //verify assign asn to shipment
        se.assertion.verifyTrue("Step5,6,7&8: Verify assign asn to shipment id",
                wmsAssignASNToShipPageObject.assignASNToShipment(strASNNumber1,shipmentID1));

        //verify save shipment
        se.assertion.verifyTrue("Step9&10: Verify new shipment saved with Status, P" +
                        "ickup Facility, Delivery Facility values",
                wmsAssignASNToShipPageObject.saveShipment(shipmentID1));

        //select menu assign asn to shipment
        se.assertion.verifyTrue("Step2a Repeat1: Navigate to Assign ASN to Shipment screen",
                wmsHomePageObject.menuNavigation("Distribution","Assign ASN to Shipment"));

        //verify ASN status
        se.assertion.verifyTrue("Step2b Repeat1: Verify ASN status",
                wmsAssignASNToShipPageObject.verifyASNStatus(strASNNumber2));

        //verify create shipment ID
        String shipmentID2 =  wmsAssignASNToShipPageObject.generateShipmentID();
        se.assertion.verifyTrue("Step3&4 Repeat1: Verify creation of shipment id", shipmentID2.length()!=0);

        //verify assign asn to shipment
        se.assertion.verifyTrue("Step5,6,7&8 Repeat1: Verify assign asn to shipment id",
                wmsAssignASNToShipPageObject.assignASNToShipment(strASNNumber2,shipmentID2));

        //verify save shipment
        se.assertion.verifyTrue("Step9&10 Repeat1: Verify new shipment saved with Status, P" +
                        "ickup Facility, Delivery Facility values",
                wmsAssignASNToShipPageObject.saveShipment(shipmentID2));

        //select menu assign asn to shipment
        se.assertion.verifyTrue("Step2a Repeat2: Navigate to Assign ASN to Shipment screen",
                wmsHomePageObject.menuNavigation("Distribution","Assign ASN to Shipment"));

        //verify ASN status
        se.assertion.verifyTrue("Step2b Repeat2: Verify ASN status",
                wmsAssignASNToShipPageObject.verifyASNStatus(strASNNumber3));

        //verify create shipment ID
        String shipmentID3 =  wmsAssignASNToShipPageObject.generateShipmentID();
        se.assertion.verifyTrue("Step3&4 Repeat2: Verify creation of shipment id", shipmentID3.length()!=0);

        //verify assign asn to shipment
        se.assertion.verifyTrue("Step5,6,7&8 Repeat2: Verify assign asn to shipment id",
                wmsAssignASNToShipPageObject.assignASNToShipment(strASNNumber3,shipmentID3));

        //verify save shipment
        se.assertion.verifyTrue("Step9&10 Repeat2: Verify new shipment saved with Status, P" +
                        "ickup Facility, Delivery Facility values",
                wmsAssignASNToShipPageObject.saveShipment(shipmentID3));

        //select shipments menu
        se.assertion.verifyTrue("Step11: Navigate to Shipments screen",
                wmsHomePageObject.menuNavigation("Distribution","Shipments"));

        //verify Inititate Shipment
        se.assertion.verifyTrue("Step12: Search and verify shipment results",
                wmsShipmentsPage.searchAndVerifyShipment(shipmentID1));

        //verify Inititate Shipment
        se.assertion.verifyTrue("Step13,14&15: Verify Inititate Shipment",
                wmsShipmentsPage.inititateShipment(shipmentID1));

        //select shipments menu
        se.assertion.verifyTrue("Step11 Repeat1: Navigate to Shipments screen",
                wmsHomePageObject.menuNavigation("Distribution","Shipments"));

        //verify Inititate Shipment
        se.assertion.verifyTrue("Step12 Repeat1: Search and verify shipment results",
                wmsShipmentsPage.searchAndVerifyShipment(shipmentID2));

        //verify Inititate Shipment
        se.assertion.verifyTrue("Step13,14&15 Repeat1: Verify Inititate Shipment",
                wmsShipmentsPage.inititateShipment(shipmentID2));

        //select shipments menu
        se.assertion.verifyTrue("Step11 Repeat2: Navigate to Shipments screen",
                wmsHomePageObject.menuNavigation("Distribution","Shipments"));

        //verify Inititate Shipment
        se.assertion.verifyTrue("Step12 Repeat2: Search and verify shipment results",
                wmsShipmentsPage.searchAndVerifyShipment(shipmentID3));

        //verify Inititate Shipment
        se.assertion.verifyTrue("Step13,14&15 Repeat2: Verify Inititate Shipment",
                wmsShipmentsPage.inititateShipment(shipmentID3));

        //select Distribution menu and ASNs
        se.assertion.verifyTrue("Step17: Select Distribution menu and ASNs",
                wmsHomePageObject.menuNavigation("Distribution","ASNs"));

        //search by ASN number in ASN screen
        se.assertion.verifyTrue("Step18a: Search for ASN "+strASNNumber1+" number in ASN screen",
                wmsASNPage.searchByASNNumber(strASNNumber1));

        //verify the ASN status by ASN number
        se.assertion.verifyTrue("Step18b: Verify the ASN status",
                wmsASNPage.verifyASNStatusByASNNumber(strASNNumber1, "InTransit"));

        //select Distribution menu and ASNs
        se.assertion.verifyTrue("Step17 Repeat1: Select Distribution menu and ASNs",
                wmsHomePageObject.menuNavigation("Distribution","ASNs"));

        //search by ASN number in ASN screen
        se.assertion.verifyTrue("Step18a Repeat1: Search for ASN "+strASNNumber2+" number in ASN screen",
                wmsASNPage.searchByASNNumber(strASNNumber2));

        //verify the ASN status by ASN number
        se.assertion.verifyTrue("Step18b Repeat1: Verify the ASN status",
                wmsASNPage.verifyASNStatusByASNNumber(strASNNumber2, "InTransit"));

        //select Distribution menu and ASNs
        se.assertion.verifyTrue("Step17 Repeat2: Select Distribution menu and ASNs",
                wmsHomePageObject.menuNavigation("Distribution","ASNs"));

        //search by ASN number in ASN screen
        se.assertion.verifyTrue("Step18a Repeat2: Search for ASN "+strASNNumber3+" number in ASN screen",
                wmsASNPage.searchByASNNumber(strASNNumber3));

        //verify the ASN status by ASN number
        se.assertion.verifyTrue("Step18b Repeat2: Verify the ASN status",
                wmsASNPage.verifyASNStatusByASNNumber(strASNNumber3, "InTransit"));

        //Garbage collection of failed steps
        testTearDown(se);
    }

    /**
     * Method to prepare xml data
     * @param se        : driver type used for test
     * @param params    : external file data parameters
     */
    @Test(description = "To validate Receiving of a multiple iLPN in an ASN and sorted to a single pallet " +
            "to a single item level 1 Pallet and Mixed Pallet location",
            dataProvider = "browserXml", groups = {"indev"}, timeOut = 900000)
    @TestData(fileName = "wms/testdata/herentals/herinputdata.xml")
    @Video(recording = false)
    @QCLogging(reportALM = false)
    public void verifyMultiple_ASN_LPN_ITEM_SingleShip(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSAssignASNToShipmentPage wmsAssignASNToShipPageObject = NikePageFactory.initElements(se.myDriver,
                WMSAssignASNToShipmentPage.class);
        WMSShipmentsPage wmsShipmentsPage = NikePageFactory.initElements(se.myDriver, WMSShipmentsPage.class);
        WMSASNsPage wmsASNPage = NikePageFactory.initElements(se.myDriver, WMSASNsPage.class);

        //read input data from test data xml file
        String strUrl = (String) params.get("environment");
        String syntheticXMlFileName = (String)params.get("xmlfilename");

        //update synthetic xml file before posting
        se.assertion.verifyTrue("Pre-Requisite: Test data preparation",
                syndata.updateOnlyASNDetailsInXML(params));

        //read input from the synthetic xml file
        String strASNNumber1 = xmlHelper.getValueByTagName(syntheticXMlFileName, 0, "ASNID");
        String strASNNumber2 = xmlHelper.getValueByTagName(syntheticXMlFileName, 1, "ASNID");
        String strASNNumber3 = xmlHelper.getValueByTagName(syntheticXMlFileName, 2, "ASNID");

        //update synthetic xml file before posting
        se.assertion.verifyTrue("Pre-Requisite: Test data preparation",
                syndata.updateMultipleSku18LPNDetailsInXML(17, 7, params));

        //invoke browser
        se.myDriver.get(strUrl);
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //Garbage collection of failed steps
        testTearDown(se);
    }
}