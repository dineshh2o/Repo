package tech.nike.automation.wms.feature.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import tech.nike.automation.common.framework.core.SystemUtil;
import tech.nike.automation.common.framework.core.Util;
import tech.nike.automation.common.framework.testdatamanager.InventoryManager;
import tech.nike.automation.common.framework.testdatamanager.ProductSummary;
import tech.nike.automation.common.framework.tools.UFTExcelAdaptorAPI;
import tech.nike.automation.common.page.Page;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Created by psibb1 on 3/22/2017.
 */
public class WMSTasksPage extends Page {
    public By lblTaskId = By.cssSelector("[id$='taskIdVal']");
    public By lnkItemType = By.cssSelector("[id$='ItemBOMDetailsListEV_item_popup_button']");
    public By lblTaskType = By.cssSelector(".advtbl_row>.advtbl_col.advtbl_body_col:nth-child(4)>[id*='dataForm:lview:dataTable']");
    public By lblInvNeedType = By.cssSelector("[id$='descVal_InventoryNeedType']");
    public By lblHeaderStatus = By.cssSelector("[id*='dataForm:lview:dataTable:'][id*=':statusVal']");
    public By lblPriority = By.cssSelector("[id*='dataForm:lview:dataTable:'][id*=':descVal3']");
    /* reading Task page locatores */
    public By txtTaskId = By.id("dataForm:lview:filterId:field1value1");
    public By btnTaskApply = By.id("dataForm:lview:filterId:filterIdapply");
    public By chkTask = By.name("dataForm:lview:dataTable_checkAll");
    public By btnTaskCancel = By.cssSelector("[value='Cancel Task'][type='button']");
    public By lblTaskStatus = By.cssSelector("[id$='statusVal']");
    public By btnAccept = By.id("softCheckAcceptButton");


    List<String> arrItemNames = new ArrayList<String>();
    List<String> arrTaskIds = new ArrayList<String>();
    List<String> arrTaskTypes = new ArrayList<String>();
    List<String> arrInvNeedTypes = new ArrayList<String>();
    List<String> arrHeaderStatus = new ArrayList<String>();
    List<String> arrPriority = new ArrayList<String>();
    Map<String, Object> completeData = new TreeMap<>();
    int i = 0;

    /**
     * method to get the task details from the Task page from a selected pick wave number
     *
     * @return
     */
    public boolean getTaskDetails(Map<String, Object> testdata) {
        boolean result = true;
        //verify if the task ids are listed

        result &= se.element.getElements(lblTaskId).size() > 0;
        if (se.element.getElements(lblTaskId).size() > 0) {
            List<WebElement> taskIDs = se.element.getElements(lblTaskId);
            List<WebElement> itemTypes = se.element.getElements(lnkItemType);
            List<WebElement> taskTypes = se.element.getElements(lblTaskType);
            List<WebElement> invNeedTypes = se.element.getElements(lblInvNeedType);
            List<WebElement> headerStatus = se.element.getElements(lblHeaderStatus);
            List<WebElement> priority = se.element.getElements(lblPriority);
            //iterate all the records and capture the task Id, item names, task type and inventory need types
            for (int i = 0; i <= taskIDs.size() - 1; i++) {
                arrTaskIds.add(taskIDs.get(i).getText().trim());
                arrTaskTypes.add(taskTypes.get(i).getText().trim());
                arrHeaderStatus.add(headerStatus.get(i).getText().trim());
                arrPriority.add(priority.get(i).getText().trim());
                arrItemNames.add(itemTypes.get(i).getText().trim());
                se.element.hover(invNeedTypes.get(i));
                /*Actions actions = new Actions(getDriver());
                actions.moveToElement(invNeedTypes.get(i));
                actions.perform();*/
                arrInvNeedTypes.add(invNeedTypes.get(i).getText().trim());
            }
            System.setProperty("INT_FOUND", "Yes");
            completeData.put("Task ID", arrTaskIds);
            completeData.put("Task Type", arrTaskTypes);
            completeData.put("Header Status", arrHeaderStatus);
            completeData.put("Priority", arrPriority);
            completeData.put("Item Names", arrItemNames);
            completeData.put("Inventory Need Type", arrInvNeedTypes);

            se.log.logTestStep("************" + arrTaskIds + "****************");
            se.log.logTestStep("************" + arrTaskTypes + "************");
            se.log.logTestStep("************" + arrHeaderStatus + "************");
            se.log.logTestStep("************" + arrPriority + "************");
            se.log.logTestStep("************" + arrItemNames + "************");
            se.log.logTestStep("************" + arrInvNeedTypes + "************");
        } else
            System.setProperty("INT_FOUND", "No");
        UFTExcelAdaptorAPI reporter = new UFTExcelAdaptorAPI();
        //System.out.println ("Test Case Exist in test data xls : " + reporter.getTestData());
        reporter.updateExcelSheet(testdata, completeData);
        return result;
    }

    /**
     * Method to enter multiple task ID on WMS application task page
     *
     * @param strTaskId
     * @return
     */
    public boolean searchByTaskID(String strTaskId) {

        // Verify for the task id text box is displayed and enter the task id
        //wait for the element() to display
        boolean result = false;
        se.element.requireIsDisplayed("Task ID field", txtTaskId);
        //wait for the element to get visible
        result = se.element.isVisible(txtTaskId);
        result &= se.element.waitForElementToBeClickable(txtTaskId);
        //strTaskId = (String) testdata.get("taskid");
        //verify if the task id field was displayed and enter the test id
        if (result) {
            result &= verifyEnteredTextIsCorrectlyDisplayed(txtTaskId, strTaskId);
            se.log.logSeStep("task id was entered successfully");
        }

        // Verify the apply button is displayed and click on apply button
        //wait for the element() to display
        se.element.requireIsDisplayed("Task Apply field", btnTaskApply);
        //wait for the element to get visible
        result &= se.element.isVisible(btnTaskApply);
        result &= se.element.waitForElementToBeClickable(btnTaskApply);
        if (result) {
            //click task apply button
            se.element.clickElement(btnTaskApply);
            se.element.waitBySleep(2000);
            //report user name to html report
            se.log.logSeStep("task apply button was clicked successfully");
        }
        // Verify the task id overall check box is displayed and click on check box field
        //wait for the element() to display
        se.element.requireIsDisplayed("Task Check box field", chkTask);
        return result;
    }

    /**
     * method to select the task by task ID
     *
     * @return
     */
    public boolean selectTaskId(String strTaskId) {
        boolean result = false;
        //wait for the element to get visible
        se.element.waitBySleep(2000);

        result = se.element.waitForElementToBeClickable(chkTask);
        if (result) {
            //click task check box button
            se.element.clickElement(chkTask);
            //report user name to html report
            se.log.logSeStep("task check box was checked successfully");
        }
        return result;
    }

    /**
     * Method to click on Cancel button and verify the CANCELLED task status on WMS application task page
     *
     * @param
     * @return
     */
    public boolean cancelTask() {
        boolean result = false;
        //wait for the element() to display
        se.element.waitBySleep(2000);
        se.element.requireIsDisplayed("Cancel Task field", btnTaskCancel);
        //wait for the element to be clickable
        result = se.element.waitForElementToBeClickable(btnTaskCancel);
        //click task check box button
        se.element.clickElement(btnTaskCancel);
        //report user name to html report
        se.log.logSeStep("task cancel button was checked successfully");

        // Click the OK button on the pop up
        se.myDriver.switchTo().alert().accept();
        se.element.waitBySleep(3000);

        // If Accept button appears then click on accept button
        if (se.element.exists(btnAccept)) {
            //click task check box button
            se.element.clickElement(btnAccept);
            //report user name to html report
            se.log.logSeStep("Accept button is clicked successfully");
        }

        return result;
    }

    /**
     * Method to check the CANCELLED status of the tasks
     *
     * @param
     * @return
     */
    public boolean verifyTaskStatus(String strTaskID) {

        //wait for the table to display searched record
        //to split the string which contains the comma seperated taskId's
        String[] arrIds = strTaskID.split(",");
        boolean result = false;
        List<WebElement> tasksStatus = se.element.getElements(lblTaskStatus);
        List<WebElement> ids = se.element.getElements(lblTaskId);
        int index = 0;
        for (WebElement we : tasksStatus) {
            String id = ids.get(index).getText().trim();
            System.out.println("Task ID " + id);
            String status = we.getText().trim();
            System.out.println("status " + status);
            if (status.equalsIgnoreCase("Cancelled") && id.equalsIgnoreCase(arrIds[index])) {
                //report user name to html report
                se.log.logSeStep(status + " Task was cancelled successfully");
            } else {
                se.log.logSeStep(status + "  task was not in cancelled state");
            }
            index = index + 1;
        }
        return result;
    }

    /**
     * //Method to get task from database and then perform cancellation on task application page
     *
     * @param
     * @return
     */
    public boolean verifyTaskCleanup() {
        boolean result = false;
        String strTaskID = null;
        int index = 20;
        List<ProductSummary> ps = InventoryManager.getTaskIDAndWaveNumberByQueryID(0, "2");
        ps.size();
        System.out.println("taskID's record count " + ps.size());
        Integer intLength = ps.size();
        //hold the value of i in temp variable
        Integer tempi = 0;
        for (int j = 1; j <= (int) Math.ceil((double) intLength / 20); j++) {
            //More efficient version using mutable  StringBuffer
            StringBuffer output = new StringBuffer(intLength);
            int i = 0;
            for (i = 0; i < 20; i++) {
                if (i + tempi != intLength) {
                    output.append(ps.get(i + tempi).gettaskID() + ",");
                } else {
                    break;
                }
            }
            tempi = i * j;
            strTaskID = output.toString().replaceFirst(".$", "");
            se.element.waitBySleep(5000);
            // Method to search task id on task application
            result = searchByTaskID(strTaskID);
            // Method to select task id on task application
            result &= selectTaskId(strTaskID);
            // Method to Cancel the task
            result &= cancelTask();
            // Method to verify task is in cancelled status on task page
            result &= verifyTaskStatus(strTaskID);
        }
        return result;
    }

    /**
     * //Method to get task from database and then perform cancellation on task application page after Accept button
     *
     * @param
     * @return
     */
    public boolean verifyTaskCleanupCancelAccept() {
        boolean result = false;
        String strTaskID = null;
        int index = 20;
        List<ProductSummary> ps = InventoryManager.getTaskIDAndWaveNumberByQueryID(0, "3");
        ps.size();
        System.out.println("taskID's record count " + ps.size());
        Integer intLength = ps.size();
        //hold the value of i in temp variable
        Integer tempi = 0;
        for (int j = 1; j <= (int) Math.ceil((double) intLength / 20); j++) {
            //More efficient version using mutable  StringBuffer
            StringBuffer output = new StringBuffer(intLength);
            int i = 0;
            for (i = 0; i < 20; i++) {
                if (i + tempi != intLength) {
                    output.append(ps.get(i + tempi).gettaskID() + ",");
                } else {
                    break;
                }
            }
            tempi = i * j;
            strTaskID = output.toString().replaceFirst(".$", "");
            se.element.waitBySleep(5000);
            // Method to search task id on task application
            result = searchByTaskID(strTaskID);
            // Method to select task id on task application
            result &= selectTaskId(strTaskID);
            // Method to Cancel the task
            result &= cancelTask();
            // Method to verify task is in cancelled status on task page
            result &= verifyTaskStatus(strTaskID);
        }
        return result;
    }
}
