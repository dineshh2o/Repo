package tech.nike.automation.wms.feature.test.reference;

import org.testng.annotations.Test;
import tech.nike.automation.common.framework.BaseTest;
import tech.nike.automation.common.framework.core.Browser;
import tech.nike.automation.common.framework.core.Selenium;
import tech.nike.automation.common.framework.testdatamanager.InventoryManager;
import tech.nike.automation.common.framework.testdatamanager.ProductSummary;
import tech.nike.automation.common.utils.NikePageFactory;
import tech.nike.automation.wms.feature.page.WMSHomePage;
import tech.nike.automation.wms.feature.page.WMSLoginPage;

import java.util.List;
import java.util.Map;

/**
 * Created by psibb1 on 6/23/2016.
 */
public class QCTest extends BaseTest {

    /**
     * Test method to create a new test and verify the same
     *
     * @param myBrowser
     * @param se
     * @param params
     */
    @Test(description = "WMS Menu Navigation", dataProvider = "browserXml", groups = {"indev"}, timeOut = 900000)
    @TestData(fileName = "reference/inputdata.xml")
    @Video(recording = false)
    @QCLogging(reportALM = false)
    public void IB_1064_NDC_PRE_RECV_HP_Inbound_Shipment_Generation_POC(Browser.Browsers myBrowser,
                                                                        Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);

        //read input data from parametrized xml file
        //String strUrl = (String) params.get("url");
        //invoke browser
        //se.myDriver.get(strUrl);
        //se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        // ASNBuilder asnBuilder = new ASNBuilder();
        //asnBuilder.setASN(params);

        List<ProductSummary> ps = InventoryManager.getCustomerByQueryID("customer_id");
        ps.get(0).getoriginFacilityAliasID();

        //verify user login to WMS
        se.assertion.verifyTrue("User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));

        //verify navigate to system codes page
        //se.assertion.verifyTrue("navigate to ship wave templates",
        //       wmsHomePageObject.menuNavigation("Configuration", "Ship Wave Templates"));

        //Garbage collection of failed steps
        testTearDown(se);
    }
}
