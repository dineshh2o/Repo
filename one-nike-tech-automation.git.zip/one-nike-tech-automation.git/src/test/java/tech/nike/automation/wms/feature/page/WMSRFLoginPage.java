package tech.nike.automation.wms.feature.page;

import org.openqa.selenium.By;
import tech.nike.automation.common.framework.core.Data;
import tech.nike.automation.common.page.Page;

import java.util.Map;

/**
 * Created by PSibb1 on 1/16/2017.
 */
public class WMSRFLoginPage extends Page{

    public By txtRFLoginUserName = By.name("j_username");
    public By txtRFLoginPassword = By.name("j_password");
    public By btnRFEnter = By.cssSelector("[type='submit'][value='Enter']");



    /**
     * Method to verify if the user name field was visible
     *
     * @return
     */
    public boolean verifyUserNameDisplay() {
        //wait for the element() to display
        se.element.requireIsDisplayed("User Name field", txtRFLoginUserName);
        //wait for the element to get visible
        boolean result = se.element.isVisible(txtRFLoginUserName);
        result &= se.element.waitForElementToBeClickable(txtRFLoginUserName);
        return result;
    }

    /**
     * Method to verify if password field was visible
     *
     * @return
     */
    public boolean verifyPasswordDisplay() {
        //wait for the element() to display
        se.element.requireIsDisplayed("Password field", txtRFLoginPassword);
        //wait for the element to get visible
        boolean result = se.element.isVisible(txtRFLoginPassword);
        result &= se.element.waitForElementToBeClickable(txtRFLoginPassword);
        return result;
    }

    /**
     * Method to verify if enter button was visible and clickable
     *
     * @return
     */
    public boolean verifyEnterButtonDisplay() {
        se.element.requireIsDisplayed("Enter button", btnRFEnter);
        //wait for the element() to get visible
        boolean result = se.element.isVisible(btnRFEnter);
        //wait for the element() to become clickable
        result &= se.element.waitForElementToBeClickable(btnRFEnter);
        return result;
    }

    /**
     * Method to verify and enter the user name
     *
     * @param testdata
     * @return
     */
    public boolean verifyAndEnterLoginUserName(Map<String, Object> testdata) {
        String strUserName = (String) testdata.get("username");
        //verify if the user name field was displayed
        boolean result = se.assertion.verifyTrue("Verify user name field was displayed on RF Login Page",
                verifyUserNameDisplay());
        if (result) {
            result &= verifyEnteredTextIsCorrectlyDisplayed(txtRFLoginUserName, strUserName);
        }
        return result;
    }

    /**
     * Method to verify and enter password
     *
     * @param testdata
     * @return
     */
    public boolean verifyAndEnterLoginPassword(Map<String, Object> testdata) {
        String strPassword = (String) testdata.get("password");
        //decrypt the user provided encrypted password
        Data.EncryptedString es = new Data.EncryptedString(strPassword);
        strPassword = es.getString();
        //verify if the password field was displayed
        boolean result = se.assertion.verifyTrue("Verify wms login password field was displayed on RF Login Page",
                verifyPasswordDisplay());
        if (result) {
            result &= verifyEnteredPasswordIsCorrectlyDisplayed(txtRFLoginPassword, strPassword);
        }
        return result;
    }

    /**
     * Method to verify and click sign in button
     *
     * @return
     */
    public boolean verifyAndClickEnter() {
        //verify if the enter field was displayed
        boolean result = se.assertion.verifyTrue("Verify wms enter field was displayed on RF Login Page",
                verifyEnterButtonDisplay());
        if (result) {
            //click enter field
            se.element.clickElement(btnRFEnter);
            //report user name to html report
            se.log.logSeStep("Enter button was clicked successfully");
        }
        return result;
    }

    /**
     * Method to login to wms RF application
     *
     * @param testdata
     * @return
     */
    public boolean verifyRFWMSLogin(Map<String, Object> testdata) {
        String strUName = (String) testdata.get("username");
        String strPwd = (String) testdata.get("password");
        boolean result = verifyAndEnterLoginUserName(testdata);
        result &= verifyAndEnterLoginPassword(testdata);
        result &= verifyAndClickEnter();
        //report user name to html report
        se.log.logSeStep("user " + strUName.toUpperCase().trim() + "  RF sign-in was successfully");
        return result;
    }
}