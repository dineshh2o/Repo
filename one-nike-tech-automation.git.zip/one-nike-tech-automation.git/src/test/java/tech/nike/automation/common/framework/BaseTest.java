package tech.nike.automation.common.framework;


import tech.nike.automation.common.framework.core.CommonBaseTest;
import tech.nike.automation.common.framework.core.SystemUtil;

public abstract class BaseTest extends CommonBaseTest {

    /**
     * Convenience method for getting base url
     *
     * @return
     * @author Cognizant Technology CoE
     */
    public String getBaseUrl() {
        return SystemUtil.getBaseUrl();
    }

    /**
     * Convenience method for getting locale
     *
     * @return
     * @author Cognizant Technology CoE
     */
    public String getLocale() {
        return SystemUtil.getLocale();
    }

    /**
     * Convenience method for getting WMS url
     *
     * @return
     * @author Cognizant Technology CoE
     */
    public String getBaseWmsUrl() {
        return SystemUtil.getWmsBaseUrl();
    }


}
