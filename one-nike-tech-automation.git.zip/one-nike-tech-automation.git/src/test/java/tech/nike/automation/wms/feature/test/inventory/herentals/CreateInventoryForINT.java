package tech.nike.automation.wms.feature.test.inventory.herentals;

import org.testng.annotations.Test;
import tech.nike.automation.common.framework.BaseTest;
import tech.nike.automation.common.framework.core.Browser;
import tech.nike.automation.common.framework.core.Selenium;
import tech.nike.automation.common.framework.utils.XMLUpdateHelper;
import tech.nike.automation.common.utils.NikePageFactory;
import tech.nike.automation.common.utils.UpdateSyntheticXml;
import tech.nike.automation.wms.feature.page.*;

import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Created by psibb1 on 1/19/2017.
 */
public class CreateInventoryForINT extends BaseTest {
    UpdateSyntheticXml syndata = new UpdateSyntheticXml();
    XMLUpdateHelper xmlHelper = new XMLUpdateHelper();
    /**
     * Method to post synthetic data into WMS
     *
     * @param myBrowser : browser type used for test
     * @param se        : driver type used for test
     * @param params    : external file data parameters
     */
    @Test(description = "Creation of item inventory for INT2 task creation for outbound automation test case execution",
            dataProvider = "browserXml", groups = {"indev"}, timeOut = 900000)
    @TestData(fileName = "inventory/herentalsinventoryData.xml")
    public void create_Inventory_For_INT2(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSAssignASNToShipmentPage wmsAssignASNToShipPageObject = NikePageFactory.initElements(se.myDriver,
                WMSAssignASNToShipmentPage.class);
        WMSShipmentsPage wmsShipmentsPage = NikePageFactory.initElements(se.myDriver, WMSShipmentsPage.class);
        WMSDockDoorPage wmsDockDoorPage = NikePageFactory.initElements(se.myDriver, WMSDockDoorPage.class);
        WMSRFLoginPage wmsRFLoginPage = NikePageFactory.initElements(se.myDriver, WMSRFLoginPage.class);
        WMSRFHomePage wmsRFHomePage = NikePageFactory.initElements(se.myDriver, WMSRFHomePage.class);
        WMSASNsPage wmsASNPage = NikePageFactory.initElements(se.myDriver, WMSASNsPage.class);
        WMSItemInventoryByLocation wmsItemInvByLoc = NikePageFactory.initElements(se.myDriver,WMSItemInventoryByLocation.class);
        WMSAdvanceShipmentNoticePage wmsAdvShipNotice = NikePageFactory.initElements(se.myDriver,WMSAdvanceShipmentNoticePage.class);

        //read input data from test data xml file
        String strUrl = (String) params.get("erenvironment");
        String syntheticXMlFileName = (String)params.get("xmlfilename");
        String shipmentID = "";
        int lpnCnt = 0;
        String strLPNNo = "";
        String strLocBarCode = "";
        XMLUpdateHelper xmlHelper = new XMLUpdateHelper();


        //Get the LPN Tag Count from the XML
        lpnCnt = xmlHelper.getTagNameCount(syntheticXMlFileName, "LPN");

        //update synthetic xml file before posting
        strLocBarCode = syndata.updateASNDetailsInXML_INT2(lpnCnt, params);
        //verify create Location Bar Code
        se.assertion.verifyTrue("Pre-Requisite: Test data preparation with verify Location BarCode",
                strLocBarCode.length()!=0);

        //String strQty = XMLUpdateHelper.getValueByTagName(syntheticXMlFileName,"Quantity");
        String strASNNumber = xmlHelper.getValueByTagName(syntheticXMlFileName, "ASNID");
        String strItemName = xmlHelper.getValueByTagName(syntheticXMlFileName, 0, "ItemName");

        //invoke browser
        se.myDriver.get(strUrl);
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //verify user login to WMS
        se.assertion.verifyTrue("Step1: User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));

        //select menu tem Inventory By Location
        se.assertion.verifyTrue("Step 1a: Navigate to Item Inventory By Location screen",
                wmsHomePageObject.menuNavigation("Distribution","Item Inventory by Location"));

        //verify Item Inventory at Reserve Location
        se.assertion.verifyTrue("Step 1b Search Item Inventory at Reserve Location",
                wmsItemInvByLoc.searchByItemForReserveLocation(strItemName));


        //verify post xml is successful
        se.assertion.verifyTrue("Step 2a post xml", wmsHomePageObject.verifyPostXML(params));

        //se.element.explicitWait(5000);

        //select menu assign asn to shipment
        se.assertion.verifyTrue("Step2a: Navigate to Assign ASN to Shipment screen",
                wmsHomePageObject.menuNavigation("Distribution","Assign ASN to Shipment"));

        //verify ASN status
        se.assertion.verifyTrue("Step2b: Verify ASN status",
                wmsAssignASNToShipPageObject.verifyASNStatus(strASNNumber));

        //verify create shipment ID
        shipmentID =  wmsAssignASNToShipPageObject.generateShipmentID();
        se.assertion.verifyTrue("Step3&4: Verify creation of shipment id", shipmentID.length()!=0);

        //verify assign asn to shipment
        se.assertion.verifyTrue("Step5,6,7&8: Verify assign asn to shipment id",
                wmsAssignASNToShipPageObject.assignASNToShipment(strASNNumber,shipmentID));

        //verify save shipment
        se.assertion.verifyTrue("Step9&10: Verify new shipment saved with Status, P" +
                        "ickup Facility, Delivery Facility values",
                wmsAssignASNToShipPageObject.saveShipment(shipmentID));

        //select shipments menu
        se.assertion.verifyTrue("Step11: Navigate to Shipments screen",
                wmsHomePageObject.menuNavigation("Distribution","Shipments"));

        //verify Inititate Shipment
        se.assertion.verifyTrue("Step12: Search and verify shipment results",
                wmsShipmentsPage.searchAndVerifyShipment(shipmentID));

        //verify Inititate Shipment
        se.assertion.verifyTrue("Step13,14&15: Verify Inititate Shipment",
                wmsShipmentsPage.inititateShipment(shipmentID));

        //select Distribution menu and Dock Door
        se.assertion.verifyTrue("Step16: Select Distribution menu and Dock Door",
                wmsHomePageObject.menuNavigation("Distribution","Dock Door"));

        //get open inbound dock door
        String openINBDockDoor = wmsDockDoorPage.getOpenDockDoorByType("IN");
        se.assertion.verifyTrue("Step17: Search and select a open INB dock door",
                openINBDockDoor.length()>0 );

        //select RF - RF Menu
        se.assertion.verifyTrue("Step36a: Select RF menu and RF Menu",
                wmsHomePageObject.menuNavigation("RF","RF Menu"));

        //verify user login to WMS RF Screen
        se.assertion.verifyTrue("Step36b: User Logged into WMS RF screen",
                wmsRFLoginPage.verifyRFWMSLogin(params));

        //verify if user selected the RF menu
        se.assertion.verifyTrue("Step37: Select Receiving from the main menu",
                wmsRFHomePage.selectMenuOptionByName("RECEIVING"));

        //verify if user selected the RF menu
        se.assertion.verifyTrue("Step38: Select RECT AND SORT from the RECEIVING  menu options",
                wmsRFHomePage.selectMenuOptionContainsName("RECV AND SORT"));
        //enter dock door number captured from step35
        se.assertion.verifyTrue("Step39: Enter dock door number "+openINBDockDoor+" captured from step35",
                wmsRFHomePage.enterRFDockDoor(openINBDockDoor));

        //enter Shipment number in RF screen
        se.assertion.verifyTrue("Step40: Enter Shipment number in RF screen "+shipmentID,
                wmsRFHomePage.enterRFShipmentNumber(shipmentID));

        //enter LPN Number one by one in RF Scren
        for (int cnt = 0; cnt < lpnCnt; cnt++) {
            strLPNNo = xmlHelper.getValueByTagName(syntheticXMlFileName, cnt, "LPNID");
            se.assertion.verifyTrue("Step 41: Enter LPN Number in RF Screen " + strLPNNo,
                    wmsRFHomePage.enterRFReceiveLPNNumber(strLPNNo));
            se.element.explicitWait(1000);
        }

        //verify if user Click Accept/Proceed Button
        se.assertion.verifyTrue("Step41: click on Accept/Proceed Button",
                wmsRFHomePage.clickAceept_Proceed_Button());

        //verify if user Click Form Exit Button
        se.assertion.verifyTrue("Step42: click on Exit Button",
                wmsRFHomePage.clickForm_Exit_Button());

        //verify if user Click Main Menu Button
        se.assertion.verifyTrue("Step43: click on Main Menu Button",
                wmsRFHomePage.clickForm_MainMenu_Button());

        //verify if user selected the RF menu
        se.assertion.verifyTrue("Step44: Select Putaway from the main menu",
                wmsRFHomePage.selectMenuOptionByName("PUTAWAY"));

        //verify if user selected the RF menu
        se.assertion.verifyTrue("Step45: Select LOCATE ILPN from the PUTAWAY  menu options",
                wmsRFHomePage.selectMenuOptionContainsName("LOCATE ILPN"));

        lpnCnt = 1;
        for (int cnt = 0; cnt < lpnCnt; cnt++) {
            strLPNNo = xmlHelper.getValueByTagName(syntheticXMlFileName, cnt, "LPNID");
            //enter LPN Number in LOCATE ILPN
            se.assertion.verifyTrue("Step 46: Enter LPN Number in RF - put AwayScreen " + strLPNNo,
                    wmsRFHomePage.enterLPNinPutAway(strLPNNo));

            //verify if user Click Accept/Proceed Button
            //se.assertion.verifyTrue("Step47: click on PutAway Accept and Proceed Button",
            //       wmsRFHomePage.clickPutAway_Container_AcceptProceed_Button());

            //enter ReserveLocation BarCode in RF Scren
            se.assertion.verifyTrue("Step 48: Enter ReserveLocation BarCode in PutAway RF Screen " +
                            strLocBarCode,
                    wmsRFHomePage.enterPutAwayReserveLocation(strLocBarCode));

            //verify if user Click Accept/Proceed Button
            se.assertion.verifyTrue("Step47: click on PutAway Accept and Proceed Button",
                    wmsRFHomePage.clickPutAway_Container_AcceptProceed_Button());
        }

        //verify if user Click Exit Button
        se.assertion.verifyTrue("Step49: click on PutAway Exit Button",
                wmsRFHomePage.clickPutAway_Container_Exit_Button());

        //verify if user Click Exit Button
        se.assertion.verifyTrue("Step50: click on Exit Button",
                wmsRFHomePage.exitRFScreen());

        //invoke browser
        se.myDriver.get(strUrl);
        //se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //select menu ASN
        se.assertion.verifyTrue("Step 101a: Navigate to ASN screen",
                wmsHomePageObject.menuNavigation("Distribution","ASNs"));

        //Enter ASN and Search ASN
        se.assertion.verifyTrue("Step 101a: Enter ASN and Search ASN",
                wmsASNPage.searchByASNNumber(strASNNumber));

        //Select the ASN No from the list
        se.assertion.verifyTrue("Step 101a: Select the ASN No from the list",
                wmsASNPage.selectASNNumber(strASNNumber));

        //Select the ASN No from the list
        se.assertion.verifyTrue("Step 101a: Click on View Button",
                wmsASNPage.clickViewASN());

        //View Advance Shipment Notice Page and Click LPN Tab
        se.assertion.verifyTrue("Step 101a. Verify Advance Shipment Notice Page",
                wmsAdvShipNotice.verifyASNDetails(strASNNumber));

        //select menu Item Inventory By Location
        se.assertion.verifyTrue("Step 101a: Navigate to Item Inventory by Location screen",
                wmsHomePageObject.menuNavigation("Distribution","Item Inventory by Location"));

        //verify Item Inventory at Reserve Location
        se.assertion.verifyTrue("Step 101b Search by Item for Reserve Location",
                wmsItemInvByLoc.searchByItemForReserveLocation(strItemName));

        se.assertion.verifyTrue("Logout",wmsHomePageObject.verifyAndClickSignOut());
    }
}