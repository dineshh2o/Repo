package tech.nike.automation.wms.feature.test.config;

import org.testng.annotations.Test;
import tech.nike.automation.common.framework.BaseTest;
import tech.nike.automation.common.framework.core.Browser;
import tech.nike.automation.common.framework.core.Selenium;
import tech.nike.automation.common.utils.NikePageFactory;
import tech.nike.automation.wms.feature.page.WMSHomePage;
import tech.nike.automation.wms.feature.page.WMSLoginPage;
import tech.nike.automation.wms.feature.page.WMSSystemCodesPage;

import java.util.Map;
import java.util.concurrent.TimeUnit;


public class WMSConfigDemoTest extends BaseTest {

    /**
     * Method to add new system code ID
     *
     * @param myBrowser : browser type used for test
     * @param se        : driver type used for test
     * @param params    : external file data parameters
     */
    @Video(recording = true)
    @Test(description = "Add New System code, Code ID, Parameters and verify the same",
            dataProvider = "browserXml", groups = {"demo"}, timeOut = 400000)
    @TestData(fileName = "config/wmsConfigDemoData.xml")
    public void createSystemCodeAndAddCodeIDWithParams(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSSystemCodesPage wmsSysCodePageObject = NikePageFactory.initElements(se.myDriver, WMSSystemCodesPage.class);

        // parameters from the xml file
        String strURL = (String) params.get("environment");
        //new system code fields
        String strCodeType = (String) params.get("newcodeidcodetype");

        //invoke application
        se.myDriver.get(strURL);
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //verify user login to WMS
        se.assertion.verifyTrue("User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));

        //verify navigate to system codes page
        se.assertion.verifyTrue("navigate to system codes",
                wmsHomePageObject.menuNavigation("Configuration", "System Codes"));

        //verify add a new code id
        se.assertion.verifyTrue("add a new code Id", wmsSysCodePageObject.addNewCodeType(params));

        //verify search for system code
        se.assertion.verifyTrue("search for system code", wmsSysCodePageObject.searchSystemCodes(strCodeType));

        //verify select record type
        se.assertion.verifyTrue("select record type", wmsSysCodePageObject.selectRecordType());

        //verify add a code id
        se.assertion.verifyTrue("add a code Id", wmsSysCodePageObject.addACodeId(params, "Add"));

        //navigate to parameters page
        se.assertion.verifyTrue("add parameters for record type",
                wmsSysCodePageObject.addParametersToSystemCode(params));

        //verify navigate to system codes page
        se.assertion.verifyTrue("navigate to system codes",
                wmsHomePageObject.menuNavigation("Configuration", "System Codes"));

        //verify the system code details were successfully added
        se.assertion.verifyTrue("verify the system code details were successfully added",
                wmsSysCodePageObject.verifySystemCode(params));

        //verify select record type
        se.assertion.verifyTrue("select record type", wmsSysCodePageObject.selectRecordType());

        //verify select record type
        se.assertion.verifyTrue("navigate to code id", wmsSysCodePageObject.navigateToCodeId());

        //verify code ID was added successfully
        se.assertion.verifyTrue("verify the code id was successfully added", wmsSysCodePageObject.verifyCodeId(params));

        //verify navigate to parameters
        se.assertion.verifyTrue("navigate to parameters", wmsSysCodePageObject.navigateToParameters());

        //verify parameters were added successfully
        se.assertion.verifyTrue("verify the parameters were successfully added",
                wmsSysCodePageObject.verifyParameters(params));

        //verify navigate to system codes page
        se.assertion.verifyTrue("navigate to system codes",
                wmsHomePageObject.menuNavigation("Configuration", "System Codes"));

        //verify if the code Id was created successfully and verify delete was successful
        se.assertion.verifyTrue("search for new code id created and verify deleted successfully",
                wmsSysCodePageObject.deleteCodeType(strCodeType));

        //verify sign-out from wms
        se.assertion.verifyTrue("User clicked on sign-out", wmsHomePageObject.verifyAndClickSignOut());

        //verify sign-out from wms
        se.assertion.verifyTrue("user confirmed to sign-out", wmsHomePageObject.verifyAndClickConfirmSignOut());

        //Garbage collection of failed steps
        testTearDown(se);
    }

    /**
     * Method to update the existing system codes
     *
     * @param myBrowser : browser type used for test
     * @param se        : driver type used for test
     * @param params    : external file data parameters
     */
    @Test(description = "Update existing Code Id of a system code and verify the same",
     dataProvider = "browserXml", groups = {"indev"}, timeOut = 200000)
    @TestData(fileName = "wmsconfig/wmsConfigDemoData.xml")
    public void updateCodeIds(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSSystemCodesPage wmsSysCodePageObject = NikePageFactory.initElements(se.myDriver, WMSSystemCodesPage.class);

        // Get user credentials from the xml file
        String strSystemCode = (String) params.get("systemcode");
        String strSearchCodeId = (String) params.get("searchcodeid");
        String strURL = (String) params.get("environment");

        //invoke application
        se.myDriver.get(strURL);
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //verify user login to WMS
        se.assertion.verifyTrue("User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));

        //verify navigate to system codes page
        se.assertion.verifyTrue("navigate to system codes",
                wmsHomePageObject.menuNavigation("Configuration", "System Codes"));

        //verify search for system code
        se.assertion.verifyTrue("search for system code", wmsSysCodePageObject.searchSystemCodes(strSystemCode));

        //verify select record type
        se.assertion.verifyTrue("select a record type", wmsSysCodePageObject.selectRecordType());

        //verify add a code id
        se.assertion.verifyTrue("add a code Id", wmsSysCodePageObject.addACodeId(params, "update"));

        //verify navigate to system codes page
        se.assertion.verifyTrue("navigate to system codes",
                wmsHomePageObject.menuNavigation("Configuration", "System Codes"));

        //verify search for system code
        se.assertion.verifyTrue("search for system code", wmsSysCodePageObject.searchSystemCodes(strSystemCode));

        //verify select record type
        se.assertion.verifyTrue("select a record type", wmsSysCodePageObject.selectRecordType());

        //verify navigate to code id
        se.assertion.verifyTrue("navigate to code id for verification", wmsSysCodePageObject.navigateToCodeId());

        //select code ID to verify
        se.assertion.verifyTrue("select code id for verification", wmsSysCodePageObject.selectCodeId(strSearchCodeId));

        //verify code Id was save successfully
        se.assertion.verifyTrue("verify code Id was save successfully", wmsSysCodePageObject.verifyCodeId(params));

        //verify sign-out from wms
        se.assertion.verifyTrue("User clicked on sign-out", wmsHomePageObject.verifyAndClickSignOut());

        //verify sign-out from wms
        se.assertion.verifyTrue("user confirmed to sign-out", wmsHomePageObject.verifyAndClickConfirmSignOut());

        //Garbage collection of failed steps
        testTearDown(se);
    }

    /**
     * Method to update the existing system codes
     *
     * @param myBrowser : browser type used for test
     * @param se        : driver type used for test
     * @param params    : external file data parameters
     */
    @Test(description = "Add new Code Id to a system code and verify the same",
     dataProvider = "browserXml", groups = {"indev"}, timeOut = 200000)
    @TestData(fileName = "wmsconfig/wmsConfigDemoData.xml")
    public void addCodeIdToSystemCode(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSSystemCodesPage wmsSysCodePageObject = NikePageFactory.initElements(se.myDriver, WMSSystemCodesPage.class);

        // Get user credentials from the xml file
        String strSystemCode = (String) params.get("systemcode");
        String strNewCodeId = (String) params.get("newcodeid");
        String strURL = (String) params.get("environment");

        //invoke application
        se.myDriver.get(strURL);
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //verify user login to WMS
        se.assertion.verifyTrue("User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));

        //verify navigate to system codes page
        se.assertion.verifyTrue("navigate to system codes",
                wmsHomePageObject.menuNavigation("Configuration", "System Codes"));

        //verify search for system code
        se.assertion.verifyTrue("search for system code", wmsSysCodePageObject.searchSystemCodes(strSystemCode));

        //verify select record type
        se.assertion.verifyTrue("select a record type", wmsSysCodePageObject.selectRecordType());

        //verify add a code id
        se.assertion.verifyTrue("add a code Id", wmsSysCodePageObject.addACodeId(params, "add"));

        //verify navigate to system codes page
        se.assertion.verifyTrue("navigate to system codes",
                wmsHomePageObject.menuNavigation("Configuration", "System Codes"));

        //verify search for system code
        se.assertion.verifyTrue("search for system code", wmsSysCodePageObject.searchSystemCodes(strSystemCode));

        //verify select record type
        se.assertion.verifyTrue("select a record type", wmsSysCodePageObject.selectRecordType());

        //verify navigate to code id
        se.assertion.verifyTrue("navigate to code id for verification", wmsSysCodePageObject.navigateToCodeId());

        //select code ID to verify
        se.assertion.verifyTrue("select code id for verification", wmsSysCodePageObject.selectCodeId(strNewCodeId));

        //verify code Id was save successfully
        se.assertion.verifyTrue("verify code Id was save successfully", wmsSysCodePageObject.verifyCodeId(params));

        //verify sign-out from wms
        se.assertion.verifyTrue("User clicked on sign-out", wmsHomePageObject.verifyAndClickSignOut());

        //verify sign-out from wms
        se.assertion.verifyTrue("user confirmed to sign-out", wmsHomePageObject.verifyAndClickConfirmSignOut());

        //Garbage collection of failed steps
        testTearDown(se);
    }
}