package tech.nike.automation.wms.feature.page;

import org.openqa.selenium.By;
import tech.nike.automation.common.page.Page;

/**
 * Created by Nchou7 on 1/24/2017.
 */
public class WMSItemInventoryByLocation extends Page {

    /**
     * Locators
     */
    public By txtItemName = By.xpath("//*[@id=\"dataForm:listView:filterId:itemLookUpId\"]");
    public By cmbLocationClass = By.xpath ("//*[@id=\"dataForm:listView:filterId:field1value1\"]");
    public By btnAppy = By.xpath("//*[@id=\"dataForm:listView:filterId:filterId_quickFilterGroupButton_mainButton\"]");
    public By txtDisplayLocation = By.id("//*[@id=\"dataForm:listView:filterId:locationLookUpId\"]");

    /**
     * method to search by Item Name for Reserve Location
     *
     * @param ItemName
     * @return
     */
    public boolean searchByItemForReserveLocation(String ItemName) {
        boolean result = false;

        //verify if the required field was displayed
        se.element.requireIsDisplayed("Item Name Search field", txtItemName);
        //verify if Item Name field is clickable
        result = se.element.isClickable(txtItemName);
        //enter ItemName to search
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtItemName, ItemName);

        result &= se.element.isVisible(cmbLocationClass);
        result &= se.element.selectElement(cmbLocationClass,"Reserve");
        //verify is apply button is clickable
        result &= se.element.isClickable(btnAppy);
        //click on the apply button
        se.element.clickElement(btnAppy);
        se.element.waitBySleep(20000);
        //List<WebElement> checks = se.element.getElements(chkResults);
        //result &= checks.size() > 0;
        return result;
    }


}