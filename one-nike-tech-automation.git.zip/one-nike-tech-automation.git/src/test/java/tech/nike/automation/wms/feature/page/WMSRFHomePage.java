package tech.nike.automation.wms.feature.page;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import tech.nike.automation.common.page.Page;

import java.util.List;

/**
 * Created by PSibb1 on 1/16/2017.
 */
public class WMSRFHomePage extends Page{
    public By btnClearCache = By.cssSelector("[title='CTRL-K Clear Menu Cache']");
    public By btnExit = By.cssSelector("[title='Ctrl-X Exit']");
    public By btnMainMenu = By.cssSelector("[title='Ctrl-B =Main Menu']");
    public By imgIEMenuInfo = By.cssSelector("[type='image'][src='/lps/resources/menu/ribbon/images/about.gif']");
    public By btnMenuOptions = By.cssSelector(".menubutton");
    public By txtDockDoor = By.id("DockInp");
    public By txtASNNumber = By.id("shipinpId");
    public By txtLPNNumber = By.id("lpninput");
    public By txtShipmentID = By.id("loadinid");
    public By btnEndShipment = By.id("rfbtn_dataForm:endAsn_btn");

    public By btnAcceptProceed = By.id ("rfbtn_dataForm:InfoAcceptKey");
    public By btnFormExit = By.id("rfbtn_dataForm:exit_btn");
    public By btnFormMainMenu = By.id("rfbtn_dataForm:b51");
    public By txtPutAwayLPNNumber = By.id("containerEntryUserDirected");
    public By txtPutAwayRlocid = By.id("subLocationEntryUserDirected_Input");
    public By btnPutAwayContainerAcceptProceed =  By.id("rfbtn_dataForm:SCEAcceptKey");
    public By btnPutAwayContainerExit = By.id ("rfbtn_dataForm:cr43");
    public By lblLPNNumberAdded = By.id ("dataForm:Custloadinid11") ;
    public By lblInformation = By.xpath("//*[@id=\"dataForm\"]/div[2]/text()[2]");


    /**
     * method to verify if the main menu was displayed and visible
     * @return
     */
    public boolean verifyMenuInfoDisplay(){
        boolean result = false;
        //verify if the required field was displayed
        String browserType = se.myDriver.toString();
        if(browserType.contains("InternetExplorer")){
            se.element.requireIsDisplayed("Menu Info button", imgIEMenuInfo);
            //verify if the info image was clickable
            result = se.element.isClickable(imgIEMenuInfo);
            //click on the info image
            se.element.clickElement(imgIEMenuInfo);
        }
        se.element.requireIsDisplayed("Main Menu button", btnMainMenu);
        result = se.element.isClickable(btnMainMenu);
        return result;
    }

    /**
     * method to clear the RF menu cache
     * @return
     */
    public boolean clearRFMenuCache(){
        boolean result = false;
        //verify if required was displayed
        se.element.requireIsDisplayed("Clear Menu Cache button", btnClearCache);
        //verify if clear menu cache was clickable
        result = se.element.isClickable(btnClearCache);
        //click on the clear menu cache
        se.element.clickElement(btnClearCache);
        //wait for the page load
        result &= se.element.waitForElementIsDisplayed(btnMainMenu);
        se.log.seStep("Successfully cleared RF menu cache");
        return result;
    }

    /**
     * method to select a menu options from RF main menu screen by full name
     * @param menuName
     * @return
     */
    public boolean selectMenuOptionByName(String menuName){
        boolean result = false;
        result = verifyMenuInfoDisplay();
        result &= clearRFMenuCache();
        //verify if the required field was displayed
        List<WebElement> menuOptions = se.element.getElements(btnMenuOptions);
        result = menuOptions.size() > 0;
        for(WebElement menu:menuOptions){
            String strMenu = menu.getText().trim();
            if(strMenu.equalsIgnoreCase(menuName)) {
                menu.click();
                se.log.testStep(strMenu + " was menu was successfully selected");
                result &= true;
                break;
            }
        }
        return result;
    }

    /**
     * method to select a menu options from RF main menu screen by partial name
     * @param menuName
     * @return
     */
    public boolean selectMenuOptionContainsName(String menuName){
        boolean result = false;
        result = verifyMenuInfoDisplay();
        result &= clearRFMenuCache();
        //verify if the required field was displayed
        List<WebElement> menuOptions = se.element.getElements(btnMenuOptions);
        result = menuOptions.size() > 0;
        for(WebElement menu:menuOptions){
            String strMenu = menu.getText().trim();
            if(strMenu.contains(menuName.toUpperCase()) | strMenu.contains(menuName.toLowerCase())){
                menu.click();
                se.log.testStep(strMenu + " was menu was successfully selected");
                result &= true;
                break;
            }
        }
        return result;
    }

    /**
     * method to enter the dock door number and press keyboard enter
     * @param dockDoor
     * @return
     */
    public boolean enterRFDockDoor(String dockDoor){
        boolean result = false;
        se.element.requireIsDisplayed("Dock Door text field", txtDockDoor);
        result = verifyEnteredTextIsCorrectlyDisplayed(txtDockDoor, dockDoor);
        //click the enter key
        result&= se.element.enterText(txtDockDoor, Keys.ENTER);
        return result;
    }

    /**
     * method to enter the ASN number and press keyboard enter
     * @param strASN
     * @return
     */
    public boolean enterRFASNNumber(String strASN){
        boolean result = false;
        se.element.requireIsDisplayed("ASN text field", txtASNNumber);
        result = verifyEnteredTextIsCorrectlyDisplayed(txtASNNumber, strASN);
        //click the enter key
        result&= se.element.enterText(txtASNNumber, Keys.ENTER);
        return result;
    }

    /**
     * method to enter the ASN number and press keyboard enter
     * @param strLPN
     * @return
     */
    public boolean enterRFLPNNumber(String strLPN){
        boolean result = false;
        se.element.requireIsDisplayed("LPN text field", txtLPNNumber);
        result = verifyEnteredTextIsCorrectlyDisplayed(txtLPNNumber, strLPN);
        //click the enter key
        result&= se.element.enterText(txtLPNNumber, Keys.ENTER);
        return result;
    }


    /**
     * method to enter the ASN number and press keyboard enter
     * @param strShipId
     * @return
     */
    public boolean enterRFShipmentNumber(String strShipId){
        boolean result = false;
        se.element.requireIsDisplayed("Shipment ID text field", txtShipmentID);
        result = verifyEnteredTextIsCorrectlyDisplayed(txtShipmentID, strShipId);
        //click the enter key
        result&= se.element.enterText(txtShipmentID, Keys.ENTER);
        return result;
    }

    /**
     * method to click on End shipment in RF screen
     * @return
     */
    public boolean clickEndShipment(){
        boolean result = false;
        se.element.requireIsDisplayed("End Shipment button", btnEndShipment);
        result = se.element.isClickable(btnEndShipment);
        //click the enter key
        se.element.clickElement(btnEndShipment);
        //verify if the exit button was displayed
        exitRFScreen();
        //verify if the exit button was displayed
        exitRFScreen();
        return result;
    }


    /**
     * method to click on the exit button on on Rf screen
     * @return
     */
    public boolean exitRFScreen(){
        boolean result = false;
        //verify if the required field was displayed
        String browserType = se.myDriver.toString();
        if(browserType.contains("InternetExplorer")){
            se.element.requireIsDisplayed("Menu Info button", imgIEMenuInfo);
            //verify if the info image was clickable
            result = se.element.isClickable(imgIEMenuInfo);
            //click on the info image
            se.element.clickElement(imgIEMenuInfo);
        }
        //verify if the exit button was displayed
        result &= se.element.isClickable(btnExit);
        //click on the exit button
        se.element.clickElement(btnExit);
        return result;
    }

    /**
     * method to click on the Accept/Proceed button on on Rf screen
     * @return
     */
    public boolean clickAceept_Proceed_Button(){
        boolean result = false;
        //verify if the required field was displayed
        String browserType = se.myDriver.toString();
        if(browserType.contains("InternetExplorer")){
            se.element.requireIsDisplayed("Menu Info button", imgIEMenuInfo);
            //verify if the info image was clickable
            result = se.element.isClickable(imgIEMenuInfo);
            //click on the info image
            se.element.clickElement(imgIEMenuInfo);
        }
        //verify if the exit button was displayed
        result &= se.element.isClickable(btnAcceptProceed);
        //click on the exit button
        se.element.clickElement(btnAcceptProceed);
        return result;
    }

    /**
     * method to click on the Form Exit button on on Rf screen
     * @return
     */
    public boolean clickForm_Exit_Button(){
        boolean result = false;
        //verify if the exit button was displayed
        result &= se.element.isClickable(btnFormExit);
        //click on the exit button
        se.element.clickElement(btnFormExit);
        return result;
    }

    /**
     * method to click on the Put Away Container Accept/Proceed button on on Rf screen
     * @return
     */
    public boolean clickPutAway_Container_AcceptProceed_Button(){
        boolean result = false;

        //verify if the exit button was displayed
        result &= se.element.isClickable(btnPutAwayContainerAcceptProceed);

        //click on the Accept Proceed button
        se.element.clickElement(btnPutAwayContainerAcceptProceed);
        return result;

    }

    /**
     * method to click on the Put Away Container Accept/Proceed button on on Rf screen
     * @return
     */
    public boolean clickPutAway_Container_Exit_Button(){
        boolean result = false;
        //verify if the exit button was displayed
        result &= se.element.isClickable(btnPutAwayContainerExit);
        //click on the exit button
        se.element.clickElement(btnPutAwayContainerExit);
        return result;
    }

    /**
     * method to click on the Form Main Menu button on on Rf screen
     * @return
     */
    public boolean clickForm_MainMenu_Button(){
        boolean result = false;
        //verify if the exit button was displayed
        result &= se.element.isClickable(btnFormMainMenu);
        //click on the exit button
        se.element.clickElement(btnFormMainMenu);
        return result;
    }

    /**
     * method to enter the LPN number and press keyboard enter
     * @param strLPN
     * @return
     */
    public boolean enterLPNinPutAway(String strLPN){
        boolean result = false;
        WebElement eltxtLPNNumer= se.element.getElement(txtPutAwayLPNNumber);

        eltxtLPNNumer.sendKeys("");
        eltxtLPNNumer.sendKeys(strLPN);

        return result;
    }
    /**
     * method to enter the Reserve Location BarCode and press keyboard enter
     * @param strRLoc
     * @return
     */
    public boolean enterPutAwayReserveLocation(String strRLoc){
        boolean result = false;
        result = verifyEnteredTextIsCorrectlyDisplayed(txtPutAwayRlocid, strRLoc);
        //click the enter key
        result&= se.element.enterText(txtPutAwayRlocid, Keys.ENTER);
        return result;
    }

    /**
     * method to enter the LPN number and press keyboard enter
     * @param strLPN
     * @return
     */
    public boolean enterRFReceiveLPNNumber(String strLPN){
        boolean result = false;
        WebElement eltxtLPNNumer= se.element.getElement(txtLPNNumber);

        eltxtLPNNumer.sendKeys("");
        eltxtLPNNumer.sendKeys(strLPN);
        //result = se.element.clearText(txtLPNNumber);
        //result = se.element.enterText(txtLPNNumber, strLPN);
        //click the enter key
        //result&= se.element.enterText(txtLPNNumber, Keys.ENTER);

        return result;
    }

    /**
     * method to Verify whether the Pallatized information displayed
     * @param strmsg
     * @return boolean
     */
    public boolean validatePallatiezinfo(String strmsg){
        boolean result = false;
        String strInformation = "";
        WebElement elelblinfo= se.element.getElement(lblInformation);

        if (elelblinfo.isDisplayed()) {
            strInformation = elelblinfo.getText();
            result = true;
        }
        return result;
    }

}