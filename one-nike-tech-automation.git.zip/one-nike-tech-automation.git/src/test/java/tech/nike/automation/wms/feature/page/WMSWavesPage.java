package tech.nike.automation.wms.feature.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import tech.nike.automation.common.framework.testdatamanager.InventoryManager;
import tech.nike.automation.common.framework.testdatamanager.ProductSummary;
import tech.nike.automation.common.framework.tools.UFTExcelAdaptorAPI;
import tech.nike.automation.common.page.Page;
import tech.nike.automation.wms.feature.page.WMSTasksPage;

import java.util.List;

/**
 * Created by PSibb1 on 9/20/2016.
 */
public class WMSWavesPage extends Page {
    public By txtWaveStatus = By.xpath("//span[text()[contains(.,'Ship wave completed')]]");
    public By btnRefresh = By.id("dataForm:listView:dataTable:dataTable_rfsh_but");
    public By btnMore = By.cssSelector("[id$='moreButton']");
    public By txtWaveNumber = By.cssSelector("[type='text'][alt='Find Ship Wave number']");
    public By btnApply = By.id("dataForm:listView:filterId:filterIdapply");
    public By lblWaveDescription = By.cssSelector("[id$='edit']");
    public By chkWave = By.cssSelector("[type='checkbox'][id^='checkAll_c']");
    public By btnTasks = By.cssSelector("ul.fotop > li > a[id*='Tasks']");
    public By btnLPNs = By.cssSelector("ul.fotop > li > a[id*='LPNs']");
    public By lblWaveNumber = By.cssSelector("[id$='shipWaveNbr']");
    public By btnUndoWave = By.cssSelector("[value='Undo Wave']");
    public By txtWaveStatusCancelled = By.xpath("//span[text()[contains(.,'Ship wave cancelled')]]");

    /**
     * method to wait for the status wave to show as completed
     *
     * @return
     */
    public boolean verifyWaveStatus() {
        boolean result = true;
        //wait for the page load to complete
        se.element.explicitWait(5000);
        //iterate for the DO status to complete
        for (int i = 0; i < 20 && se.element.getElements(txtWaveStatus).size() == 0; i++) {
            se.element.clickElement(btnRefresh);
        }
        return result;
    }

    /**
     * method to search for wave number in waves page
     *
     * @param strWaveNumber
     * @return
     */
    public boolean searchByWaveNumber(String strWaveNumber) {
        boolean result = true;
        //verify if the search by wave number field was displayed
        se.element.requireIsDisplayed("Wave Number", txtWaveNumber);
        //verify if the wave number field was clickable
        result &= se.element.isClickable(txtWaveNumber);
        //clear the field and enter the text
        se.element.getElement(txtWaveNumber).clear();
        //enter the wave number and search
        se.element.sendKeys(txtWaveNumber, strWaveNumber);
        System.out.println("Wave No.: " + strWaveNumber);
        //verify if the apply button was displayed
        se.element.requireIsDisplayed("Apply", btnApply);
        //verify if the apply button was clickable
        result &= se.element.isClickable(btnApply);
        //click on the apply button
        se.element.clickElement(btnApply);
        se.element.explicitWait(3000);
        return result;
    }

    /**
     * method to select the wave number
     *
     * @param strWaveNumber
     * @return
     */
    public boolean selectWaveNumber(String strWaveNumber) {
        boolean result = true;
        //verify if the wave checkbo field was displayed
        result &= se.element.getNumberOfElements(chkWave) > 0;
        int chkWaves = se.element.getNumberOfElements(chkWave);
        //iterate through the wave numbers to find the required wave
        for (int i = 0; i <= chkWaves; i++) {
            String strWaveNum = se.element.getElements(lblWaveNumber).get(i).getText().trim();
            if (strWaveNum.equals(strWaveNumber)) {
                se.element.getElements(chkWave).get(i).click();
                se.element.explicitWait(2000);
                break;
            }
        }
        return result;
    }

    /**
     * method to verify the task generated
     *
     * @return
     */
    public boolean verifyTask() {
        boolean result = true;
        //verify if the more button was displayed
        se.element.requireIsDisplayed("wave more button", btnMore);
        //verify if the more button was clickable
        result &= se.element.isClickable(btnMore);
        //click on the more button
        se.element.clickElement(btnMore);
        //verify if the task button was displayed
        List<WebElement> tasks = se.element.getElements(btnTasks);
        se.element.requireIsDisplayed("Task button", tasks.get(4));
        //click on the Tasks
        tasks.get(4).click();
        se.element.explicitWait(3000);
        return result;
    }

    /**
     * method to get the shipping Id from the wave number
     *
     * @return
     */
    public boolean navigateToLPNs() {
        boolean result = true;
        //verify if the more button was displayed
        se.element.requireIsDisplayed("wave more button", btnMore);
        //verify if the more button was clickable
        result &= se.element.isClickable(btnMore);
        //click on the more button
        se.element.clickElement(btnMore);
        //verify if the LPNs button was displayed
        se.element.requireIsDisplayed("LPN's button", btnLPNs);
        //click on the LPN's button
        se.element.clickElement(btnLPNs);
        se.element.explicitWait(3000);
        return result;
    }


    /**
     * //Method to get task from database and then perform Undo on wave application page
     *
     * @param
     * @return
     */
    public boolean verifyTaskCleanupUsingWavePage() {
        boolean result = false;
        String strWaveNumber = null;
        int index = 20;
        List<ProductSummary> ps = InventoryManager.getWaveNumberByQueryID(0, "4");
        ps.size();
        System.out.println("Wave IDs record count " + ps.size());
        Integer intLength = ps.size();
        //hold the value of i in temp variable
        Integer tempi = 0;
        for (int i = 0; i < intLength; i++) {
            strWaveNumber = ps.get(i).getWaveNumber();
            se.element.waitBySleep(5000);
            // Method to search task id on task application
            result = searchByWaveNumber(strWaveNumber);
            // Method to select task id on task application
            result &= selectWaveNumber(strWaveNumber);
            // Method to Cancel the task
            result &= cancelWave();
            // Method to verify wave is in cancelled status on task page
            result &= verifyWaveStatus(strWaveNumber);
        }
        return result;
    }

    /**
     * Method to click on Cancel button and verify the CANCELLED task status on WMS application task page
     *
     * @param
     * @return
     */
    public boolean cancelWave() {
        boolean result = false;
        //wait for the element() to display
        se.element.waitBySleep(2000);
        se.element.requireIsDisplayed("Cancel Task field", btnUndoWave);
        //wait for the element to be clickable
        result = se.element.waitForElementToBeClickable(btnUndoWave);
        //click task check box button
        se.element.clickElement(btnUndoWave);
        //report user name to html report
        se.log.logSeStep("task cancel button was checked successfully");
        // Click the OK button on the pop up
        se.myDriver.switchTo().alert().accept();
        //se.element.waitBySleep(3000);
        se.myDriver.switchTo().alert().accept();
        se.element.waitBySleep(2000);
        se.element.clickElement(btnApply);
        se.element.explicitWait(2000);
        se.element.clickElement(btnApply);
        se.element.explicitWait(2000);
        return result;
    }


    /**
     * Method to check the CANCELLED status of the waves
     *
     * @param
     * @return
     */
    public boolean verifyWaveStatus(String strWaveNumber) {

        //wait for the table to display searched record
        //to split the string which contains the comma seperated taskId's
        //String[] arrIds = strWaveNumber.split(",");
        boolean result = false;
        List<WebElement> waveStatus = se.element.getElements(txtWaveStatusCancelled);
        List<WebElement> ids = se.element.getElements(lblWaveNumber);
        int index = 0;
        for (WebElement we : waveStatus) {
            String id = ids.get(index).getText().trim();
            System.out.println("Wave ID " + id);
            String status = we.getText().trim();
            System.out.println("status " + status);
            if (status.equalsIgnoreCase("Ship wave cancelled") && id.equalsIgnoreCase(strWaveNumber.trim())) {
                //report user name to html report
                se.log.logSeStep(status + " Wave was cancelled successfully");
            } else {
                se.log.logSeStep(status + " Wave was not in cancelled state");
            }
            index = index + 1;
        }
        return result;
    }
}