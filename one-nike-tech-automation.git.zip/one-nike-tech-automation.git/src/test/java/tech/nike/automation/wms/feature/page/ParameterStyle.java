package tech.nike.automation.wms.feature.page;

import org.openqa.selenium.By;

/**
 * Created by PSibb1 on 6/13/2016.
 */
public enum ParameterStyle {
    NONE (
            "---None---",
            "-1"
    ),
    CHECK_BOX (
            "Check box",
            "CKBX"
    ),
    EDIT_BOX (
            "Edit box",
            "EDIT"
    ),
    SYSTEM_CODE (
            "System code",
            "DDDW"
    );

    private final String style;
    private final String value;

    private ParameterStyle (String style, String value) {
        this.style = style;
        this.value = value;
    }

    public String getStyle(){
        return style;
    }

    public String getValue(){
        return value;
    }
    public By getParamStyleLocator(){
        return By.cssSelector(String.format("#editStyledc_1 [value = '%s']",this.value));
    }

}
