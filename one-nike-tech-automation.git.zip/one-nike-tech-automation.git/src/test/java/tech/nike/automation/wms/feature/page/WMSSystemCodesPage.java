package tech.nike.automation.wms.feature.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import tech.nike.automation.common.page.Page;
import tech.nike.automation.common.utils.NikePageFactory;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Created by PSibb1 on 6/1/2016.
 */
public class WMSSystemCodesPage extends Page {

    //locators
    //search for code ID
    public By txtCodeType = By.id("dataForm:filterId:field4value1");
    public By btnApply = By.id("dataForm:filterId:filterIdapply");
    public By tblCodeType = By.cssSelector("[id='dataForm:lview:dataTable_body']>tbody>tr");
    public By btnCodeID = By.cssSelector("[id^='rmButton_2CodeIDs2_']");
    public By tblCodeID = By.cssSelector("[id='dataForm:listView:dataTable_body']>tbody>tr");
    public By btnDeleteCodeID = By.cssSelector("[id^='rmButton_1Delete1_']");
    public By tblCodeIdSearch = By.id("dataForm:listView:dataTable_body");
    public By lnkParameterTab = By.id("parameterTab_lnk");
    public By btnSystemCodeParam = By.cssSelector("[id^='rmButton_2Parameters2_']");
    public By tblNoDataFound = By.cssSelector("td.advtbl_col.advtbl_body_col.tdshow");

    //update code Id details
    public By btnAddCodeIDDetails = By.cssSelector("[id^='rmButton_1Add1_']");
    public By txtCodeIDDesc = By.id("dataForm:SysCode_CodeIDDesc");
    public By txtCodeID = By.id("dataForm:SysCode_CodeId");
    public By txtCodeIDShortDesc = By.id("dataForm:SysCode_CodeIDShorDesc");
    public By btnSaveCodeID = By.cssSelector("[id^='rmButton_1Save1']");

    //Add new Code ID
    public By btnAddNewCodeID = By.id("rmButton_1Add1_1");
    public By lstRecordType = By.id("dataForm:auSel2");
    public By txtReadOnlyRecordType = By.id("dataForm:auSel1");
    public By txtReadOnlyNewCodeIdCodeType = By.id("dataForm:inTxt1");
    public By txtNewCodeIdCodeType = By.id("dataForm:inTxt12");
    public By txtNewCodeIdCodeDesc = By.id("dataForm:inTxt2");
    public By txtNewCodeIdRFDesc = By.id("dataForm:inTxt3");
    public By txtNewCodeIdMaxLen = By.id("dataForm:inTxt4");
    public By chkNewCodeIdAllowAddnCodes = By.id("dataForm:ckBox1");
    public By chkNewCodeIdAllowDelCodes = By.id("dataForm:ckBox2");
    public By chkNewCodeIdAllowMaintCodeIdParam = By.id("dataForm:ckBox3");
    public By chkNewCodeIdAllowDescChanges = By.id("dataForm:ckBox4");
    public By lstNewCodeIdWarehouse = By.id("dataForm:slMenu");
    public By chkNewCodeIdSysCodeParam = By.id("dataForm:ckBox5");
    public By lstNewCodeIdOrderBy = By.id("dataForm:slMenu1");
    public By btnNewCodeIdSave = By.id("rmButton_1Save2_4");

    //Add code id for a system code
    public By btnAddNewCodeIDForSysCode = By.cssSelector("[id^='rmButton_1Add1_']");
    public By lstCodeIdRecordType = By.id("dataForm:slMenu");
    public By txtSysCodeIdDetailCodeId = By.id("dataForm:SysCode_CodeId");
    public By txtSysCodeIdDetailCodeDesc = By.id("dataForm:SysCode_CodeIDDesc");
    public By txtSysCodeIdDetailCodeShortDesc = By.id("dataForm:SysCode_CodeIDShorDesc");

    //Add parameters for code id
    public By btnCodeIdParameters = By.cssSelector("[id^='rmButton_2Parameters1_']");
    public By btnAddParam = By.cssSelector("[id^='rmButton_1Add1_']");
    public By txtParamCodeId = By.id("dataForm:inTxt1");
    public By txtParamCodeDesc = By.id("dataForm:inTxt2");
    public By txtParamFromPos = By.id("dataForm:inTxt3");
    public By txtParamToPos = By.id("dataForm:inTxt4");
    public By txtParamDesc = By.id("dataForm:inTxt5");
    public By chkParamReq = By.id("dataForm:ckBox1");
    public By lstParamStyle = By.cssSelector("[id^='editStyledc_']");
    public By lstParamValType = By.cssSelector("[id^='ansEditStyle_1dc_']");
    public By btnSaveParam = By.cssSelector("[id^='rmButton_1Save1_']");

    public By lstRecType =  By.cssSelector("[id$=':recType']");
    public By txtCodeTypeByRow =  By.cssSelector("[id$=':codeType']");
    public By chkCodeID = By.cssSelector("[id$=':cdId']");

    public By getCheckboxByRow(int i) {
        return By.id("checkAll_c" + i + "_dataForm:lview:dataTable");
    }
    public By getCodeIdPositionByRow(int i){
        return By.id("checkAll_c"+i+"_dataForm:listView:dataTable");
    }

    /**
     * Method is to search for system
     *
     * @param strCodeType
     * @return
     */
    public boolean searchSystemCodes(String strCodeType) {
        //wait for page load
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        //verify Code type was displayed
        boolean result = se.element.waitForElement(txtCodeType);
        //verify if the Code type is visible
        result &= se.element.isVisible(txtCodeType);
        //verify if the Code Type clickable
        result &= se.element.waitForElementToBeClickable(txtCodeType);
        //click code type to enter search code type
        se.element.clickElement(txtCodeType);
        //verify if the entered text was displayed correctly
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtCodeType, strCodeType);
        //verify if the apply button is visible
        result &= se.element.isVisible(btnApply);
        //verify if the apply button was clickable
        result &= se.element.waitForElementToBeClickable(btnApply);
        //click on the apply button
        se.element.clickElement(btnApply);
        se.log.logSeStep("enter the the code type " + strCodeType + " and clicked on the apply button");
        //wait for page load
        se.myDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        //loop through the table to ensure we have search results correctly displayed
        List<WebElement> options = se.element.getElements(tblCodeType);
        List<WebElement> weCodeTypes = se.element.getElements(txtCodeTypeByRow);
        if(se.element.exists(tblNoDataFound) == false) {
            boolean blnFound = false;
            for (int i = 0; i < options.size(); i++) {
                String strtext = weCodeTypes.get(i).getText().trim();
                if (strtext.equalsIgnoreCase(strCodeType)) {
                    se.log.logSeStep("code type in the row # " + i + " was displayed as " + strtext +
                            " search code and matches with " + strCodeType + " code type");
                    blnFound = true;
                    break;
                }
            }
            if(blnFound!=true){
                result &= false;
            }
        }
        return result;
    }

    /**Method to select a record in the Code ID table based on Code ID
     *
     * @param strCodeID
     * @return
     */
    public boolean selectCodeId(String strCodeID){
        boolean result = se.element.isVisible(tblCodeID);
        //verify if the table of records were displayed
        List<WebElement> options = se.element.getElements(tblCodeID);
        List<WebElement>weCodeIds = se.element.getElements(chkCodeID);
        boolean blnSelected = false;
        for (int i = 0; i < options.size(); i++) {
            //select record if Record type is equal to system codes
            String strVal = weCodeIds.get(i).getText().trim();
            if (strVal.equals(strCodeID)) {
                se.element.clickElement(getCodeIdPositionByRow(i));
                se.log.logSeStep("code type in the row # " + i + " was displayed as " + strVal +
                        " code id and matches with " + strCodeID + " code id");
                blnSelected = true;
                break;
            }
        }
        if(blnSelected!=true){
            result &= false;
        }
        return result;
    }

    /**
     * Method to select record type from the system codes search table
     *
     * @return
     */
    public boolean selectRecordType() {
        boolean result = se.element.isVisible(tblCodeType);
        //verify if the table of records were displayed
        List<WebElement> options = se.element.getElements(tblCodeType);
        List<WebElement>weRecTypes =  se.element.getElements(lstRecType);
        boolean blnSelected = false;
        for (int i = 0; i < options.size(); i++) {
            //select record if Record type is equal to system codes
            String strtext = weRecTypes.get(i).getText().trim();
            if (strtext.equalsIgnoreCase("System codes")) {
                se.element.clickElement(getCheckboxByRow(i));
                se.log.logSeStep("code type in the row # " + i + " was displayed as " + strtext);
                blnSelected = true;
                break;
            }
        }
        if(blnSelected!=true){
            result &= false;
        }
        return result;
    }

    /**Method to navigate to code Id
     *
     * @return
     */
    public boolean navigateToCodeId(){
        //verify if the code id button was displayed
        boolean result = se.element.isVisible(btnCodeID);
        //verify if the code id is clickable
        result &= se.element.waitForElementToBeClickable(btnCodeID);
        //click on the Code Id button
        se.element.clickElement(btnCodeID);
        se.log.logSeStep("clicked on the CodeID button");
        //wait for the page load
        se.myDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        return result;
    }

    /**
     * Method is to add new system codes
     * @param testdata
     * @return
     */
    public boolean addACodeId(Map<String, Object> testdata, String strAction) {
        String strCodeID =  (String)testdata.get("updatecodeid");
        String strSearchCodeID = (String)testdata.get("searchcodeid");
        String strCodeIDDesc =  (String)testdata.get("updatecodeiddesc");
        String strCodeIDShortDesc = (String)testdata.get("updatecodeidshortdesc");
        //verify if the code id button was displayed
        boolean result = se.element.isVisible(btnCodeID);
        //verify if the code id is clickable
        result &= se.element.waitForElementToBeClickable(btnCodeID);
        se.element.clickElement(btnCodeID);
        se.log.logSeStep("clicked on the CodeID button");
        //wait for the page load
        se.myDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        //verify whether we need to add or modify code id
        if(strAction.equalsIgnoreCase("add")) {
            //verify if the add code Id button was displayed
            result &= se.element.isVisible(btnAddCodeIDDetails);
            //click on the add code Id
            se.element.clickElement(btnAddCodeIDDetails);
            //wait for the page load
            se.myDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        }else {
            //verify if the code ID table was displayed
            result &= se.element.isVisible(tblCodeID);
            //loop through the table to find the code id and click on checkbox
            List<WebElement> options = se.element.getElements(tblCodeID);
            List<WebElement>weCodeIds = se.element.getElements(chkCodeID);
            for (int i = 0; i < options.size(); i++) {
                String codeNumb = weCodeIds.get(i).getText().trim();
                if (codeNumb.equals(strSearchCodeID) ) {
                    se.element.clickElement(getCodeIdPositionByRow(i));
                    se.log.logSeStep("code ID in the row # " + i + " was displayed as " + codeNumb);
                    result &= true;
                    break;
                }
            }
        }
        //verify enter code ID description was displayed correctly
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtCodeIDDesc, strCodeIDDesc);
        //verify if the code ID field was clickable
        result &= se.element.waitForElementToBeClickable(txtCodeIDDesc);
        //verify enter code ID was displayed correctly
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtCodeID, strCodeID);
        //verify if the code ID short description field was clickable
        result &= se.element.waitForElementToBeClickable(txtCodeIDShortDesc);
        //verify enter code ID short description was displayed correctly
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtCodeIDShortDesc, strCodeIDShortDesc);
        //verify if the save code Id button was visible
        result &= se.element.isVisible(btnSaveCodeID);
        //verify if the save code Id button was clickable
        result &= se.element.waitForElementToBeClickable(btnSaveCodeID);
        //click on the save code id button
        se.element.clickElement(btnSaveCodeID);
        se.log.logSeStep("clicked on the save code ID button");
        return result;
    }

    /**
     * Method to verify if the code Id created was successfully displayed
     * @param testdata
     * @return
     */
    public boolean verifyCodeId(Map<String, Object>testdata){
        String strCodeID = (String)testdata.get("updatecodeid");
        String strCodeIDDesc = (String)testdata.get("updatecodeiddesc");
        String strCodeIDShortDesc = (String)testdata.get("updatecodeidshortdesc");
        //verify if the code ID table was displayed
        boolean result = se.element.isVisible(tblCodeID);
        //loop through the table to find the code id and click on checkbox
        List<WebElement> options1 = se.element.getElements(tblCodeID);
        List<WebElement>weCodeIds = se.element.getElements(chkCodeID);
        for (int i = 0; i < options1.size(); i++) {
            String  strCodeNumb = weCodeIds.get(i).getText().trim();
            if (strCodeNumb.equals(strCodeID)) {
                String blnAddStatus = weCodeIds.get(i).getAttribute("checked");
                if (blnAddStatus == "false") {
                    se.element.clickElement(getCodeIdPositionByRow(i));
                }
                se.log.logSeStep("code ID in the row # " + i + " was displayed as " + strCodeNumb);
                result &= true;
                break;
            }
        }
        //verify the newly added code id
        String strCodeIdDescText = se.element.getAttribute(txtCodeIDDesc, "value").trim();
        result &= se.assertion.verifyEquals("verify the code Id description matched", strCodeIdDescText, strCodeIDDesc);
        String strCodeIdText = se.element.getAttribute(txtCodeID, "value").trim();
        result &= se.assertion.verifyEquals("verify the code Id matched", strCodeIdText, strCodeID);
        String strCodeIdShortText = se.element.getAttribute(txtCodeIDShortDesc, "value").trim();
        result &= se.assertion.verifyEquals("verify the code Id matched", strCodeIdShortText, strCodeIDShortDesc);
        return result;
    }

    /**Method to verify if the system code created was successfully displayed
     *
     * @return
     */

    public boolean verifySystemCode(Map<String, Object>testdata) {
        String strNewCodeIDRecordType =(String)testdata.get("newcodeidrecordtype");
        String strNewCodeIDType = (String)testdata.get("newcodeidcodetype");
        String strNewCodeIDCodeDesc = (String)testdata.get("newcodeidcodedesc");
        String strNewCodeIDRFDesc = (String)testdata.get("newcodeidrfdesc");
        String strNewCodeIDMaxCodeLen = (String)testdata.get("newcodeidmaxlen");
        String strAllowAddnCode = (String)testdata.get("newcodeidallowaddcodes");
        String strAllowDelCode = (String)testdata.get("newcodeidallowdeletcodes");
        String strAllowMainCode = (String)testdata.get("newcodeidallowmaincodeidpara");
        String strAllowDescChanges = (String)testdata.get("newcodeidallowdescchange");
        String strWarehouse = (String)testdata.get("newcodeidwarehouse");
        String strSystemCodeParam = (String)testdata.get("newcodeidsyscodeparaexist");
        String strOrderBy = (String)testdata.get("newcodeidorderby");
        //verify if the add new code if button is visible
        boolean result = searchSystemCodes( strNewCodeIDType);
        //verify if the new code id record type field was displayed
        result &= se.element.waitForElement(txtReadOnlyRecordType);
        //get the record type selected value
        String strRT = getSelectedValue(txtReadOnlyRecordType).trim();
        //verify if the selected value was correctly displayed
        result &= se.assertion.verifyEquals("verify if the record type selected was displayed correctly",
                strRT, strNewCodeIDRecordType);

        //get the value of new code id code type entered
        String strNewCodeID = se.element.getAttribute(txtReadOnlyNewCodeIdCodeType, "value").trim();
        //verify if entered value is correctly displayed
        result &= se.assertion.verifyEquals("verify if the code id entered was displayed correctly",
                strNewCodeID, strNewCodeIDType);
        //verify if new code id code description field is visible
        result &= se.element.isVisible(txtNewCodeIdCodeDesc);
        //get the new code id code description
        String strNewCodeDesc = se.element.getAttribute(txtNewCodeIdCodeDesc, "value").trim();
        //verify if entered value is correctly displayed
        result &= se.assertion.verifyEquals("verify if the code description entered was displayed correctly",
                strNewCodeDesc, strNewCodeIDCodeDesc);
        //verify if the new code id rf description field is visible
        result &= se.element.isVisible(txtNewCodeIdRFDesc);
        //get the rf description
        String strNewRFDesc = se.element.getAttribute(txtNewCodeIdRFDesc, "value").trim();
        //verify if entered value is correctly displayed
        result &= se.assertion.verifyEquals("verify if the rf description entered was displayed correctly",
                strNewRFDesc, strNewCodeIDRFDesc);
        //verify if new code id max code length field is visible
        result &= se.element.isVisible(txtNewCodeIdMaxLen);
        //get the max code length value
        String strNewMaxCodeLen = se.element.getAttribute(txtNewCodeIdMaxLen, "value").trim();
        //verify if entered value is correctly displayed
        result &= se.assertion.verifyEquals("verify if the max code length entered was displayed correctly",
                strNewMaxCodeLen, strNewCodeIDMaxCodeLen);
        //verify if new code id allow additional codes field is visible
        result &= se.element.isVisible(chkNewCodeIdAllowAddnCodes);
        //select allow additional codes checkbox
        if (strAllowAddnCode.equalsIgnoreCase("yes")) {
            String blnAddStatus = se.element.getAttribute(chkNewCodeIdAllowAddnCodes, "checked");
            if (blnAddStatus == "true") {
                result &= true;
            }
        }else {
            String blnAddStatus = se.element.getAttribute(chkNewCodeIdAllowAddnCodes, "checked");
            if (blnAddStatus == "false") {
                result &= true;
            }
        }
        //verify if new code id allow deletion codes field is visible
        result &= se.element.isVisible(chkNewCodeIdAllowDelCodes);
        //select allow deletion codes checkbox
        if (strAllowDelCode.equalsIgnoreCase("yes")) {
            String blnDelStatus = se.element.getAttribute(chkNewCodeIdAllowDelCodes, "checked");
            if (blnDelStatus == "true") {
                result &= true;
            }
        }else{
            String blnDelStatus = se.element.getAttribute(chkNewCodeIdAllowDelCodes, "checked");
            if (blnDelStatus == "false") {
                result &= true;
            }
        }
        //verify if new code id allow maintenance of code id parameter field is visible
        result &= se.element.isVisible(chkNewCodeIdAllowMaintCodeIdParam);
        //select allow maintenance of code id parameter checkbox
        if (strAllowMainCode.equalsIgnoreCase("yes")) {
            String blnMainStatus = se.element.getAttribute(chkNewCodeIdAllowMaintCodeIdParam, "checked");
            if (blnMainStatus == "true") {
                result &= true;
            }
        }else{
            String blnMainStatus = se.element.getAttribute(chkNewCodeIdAllowMaintCodeIdParam, "checked");
            if (blnMainStatus == "false") {
                result &= true;
            }
        }
        //verify if new code id allow description changes field is visible
        result &= se.element.isVisible(chkNewCodeIdAllowDescChanges);
        //select allow description changes checkbox
        if (strAllowDescChanges.equalsIgnoreCase("yes")) {
            String blnDescStatus = se.element.getAttribute(chkNewCodeIdAllowDescChanges, "checked");
            if (blnDescStatus == "true") {
                result &= true;
            }
        }else{
            String blnDescStatus = se.element.getAttribute(chkNewCodeIdAllowDescChanges, "checked");
            if (blnDescStatus == "false") {
                result &= true;
            }
        }
        //get the value of the warehouse selected
        String strWare = getSelectedValue(lstNewCodeIdWarehouse).trim();
        //verify if the user specified value was selected correctly
        result &= se.assertion.verifyEquals("user selected warehouse was correctly selected", strWare, strWarehouse);
        //select allow description changes checkbox
        String strOrdBy = getSelectedValue(lstNewCodeIdOrderBy).trim();
        //verify if the user specified value was selected correctly
        result &= se.assertion.verifyEquals("user selected order by was correctly selected", strOrdBy, strOrderBy);
        return result;
    }

    /**Method to navigate to parameters tab
     *
     * @return
     */
    public boolean navigateToParametersTab(){
        //verify if the parameters tab was visible
        boolean result = se.element.isVisible(lnkParameterTab);
        //verify if the parameters tab was clickable
        result &= se.element.waitForElementToBeClickable(lnkParameterTab);
        //click on the parameters tab
        se.element.clickElement(lnkParameterTab);
        return result;
    }

    /**Method to navigate to parameters
     *
     * @return
     */
    public boolean navigateToParameters(){
        //verify if the code id button was displayed
        boolean result = se.element.isVisible(btnCodeIdParameters);
        //verify if the code id is clickable
        result &= se.element.waitForElementToBeClickable(btnCodeIdParameters);
        //click on the Code Id button
        se.element.clickElement(btnCodeIdParameters);
        se.log.logSeStep("clicked on the CodeID button");
        //wait for the page load
        se.myDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        return result;
    }

    /**
     *Method to verify the parameters
     * @param testdata
     * @return
     */
    public boolean verifyParameters(Map<String, Object>testdata){
        String strFromPos = (String)testdata.get("paranewcodeidfrompos");
        String strToPos = (String)testdata.get("paranewcodeidtopos");
        String strDesc = (String)testdata.get("paranewcodeiddesc");
        String strParamReq = (String)testdata.get("pararequired");
        String strStyleType = (String)testdata.get("parastyletype");
        String strValType = (String)testdata.get("paravaltype");
        String strFieldValue1 = (String)testdata.get("parafield1");
        String strFieldValue2 = (String)testdata.get("parafield2");

        //verify parameter details
        boolean result = se.element.waitForElement(txtParamFromPos);
        //get the displayed From Pos text value
        String strDispFromPos = se.element.getAttribute(txtParamFromPos, "value").trim();
        //verify if entered text was displayed correctly
        result &= se.assertion.verifyEquals("verified the value entered was saved successfully",
                strDispFromPos, strFromPos);
        //get the displayed To Pos text value
        String strDispToPos = se.element.getAttribute(txtParamToPos, "value").trim();
        //verify if entered text was displayed correctly
        result &= se.assertion.verifyEquals("verified the value entered was saved successfully",
                strDispToPos, strToPos);
        //get the displayed To Pos text value
        String strDisDesc = se.element.getAttribute(txtParamDesc, "value").trim();
        //verify if entered text was displayed correctly
        result &= se.assertion.verifyEquals("verified the value entered was saved successfully",
                strDisDesc, strDesc);
        //verify if the param required field was visible
        result &= se.element.isVisible(chkParamReq);
        //select param required checkbox was saved
        if (strParamReq.equalsIgnoreCase("yes")) {
            String blnParaReqStatus = se.element.getAttribute(chkParamReq, "checked");
            if (blnParaReqStatus == "true") {
                result &= true;
            }
        }else{
            String blnParaReqStatus = se.element.getAttribute(chkParamReq, "checked");
            if (blnParaReqStatus == "false") {
                result &= true;
            }
        }
        //verify selected style type was displayed correctly
        if(strStyleType.equalsIgnoreCase("Check box")) {
            result &= verifyParaStyleTypeCheckbox(strStyleType, strValType, strFieldValue1, strFieldValue2);
        }else if(strStyleType.equalsIgnoreCase("Edit box")){
            result &= verifyParaStyleTypeEditbox(strStyleType, strValType, strFieldValue1, strFieldValue2);
        }else if(strStyleType.equalsIgnoreCase("System code")){
            result &= false;
        }
        return result;
    }

    /**
     *Method to create a new code Id
     * @param testdata
     * @return
     */
    public boolean addNewCodeType(Map<String, Object>testdata) {
        String strNewCodeIDRecordType =(String)testdata.get("newcodeidrecordtype");
        String strNewCodeIDType = (String)testdata.get("newcodeidcodetype");
        String strNewCodeIDCodeDesc = (String)testdata.get("newcodeidcodedesc");
        String strNewCodeIDRFDesc = (String)testdata.get("newcodeidrfdesc");
        String strNewCodeIDMaxCodeLen = (String)testdata.get("newcodeidmaxlen");
        String strAllowAddnCode = (String)testdata.get("newcodeidallowaddcodes");
        String strAllowDelCode = (String)testdata.get("newcodeidallowdeletcodes");
        String strAllowMainCode = (String)testdata.get("newcodeidallowmaincodeidpara");
        String strAllowDescChanges = (String)testdata.get("newcodeidallowdescchange");
        String strWarehouse = (String)testdata.get("newcodeidwarehouse");
        String strSystemCodeParam = (String)testdata.get("newcodeidsyscodeparaexist");
        String strOrderBy = (String)testdata.get("newcodeidorderby");
        //wait for the page load
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        //verify if the add new code if button is visible
        boolean result = se.element.isVisible(btnAddNewCodeID);
        //verify if add new code id button is clickable
        result &= se.element.waitForElementToBeClickable(btnAddNewCodeID);
        //click on the add new code Id button
        se.element.clickElement(btnAddNewCodeID);
        //verify if the new code id record type field was displayed
        result &= se.element.waitForElement(lstRecordType);
        //verify selected value correctly displayed
        result &= verifySelectedItemCorrectlyDisplayed(lstRecordType, strNewCodeIDRecordType);
        //verify if new code id Code type is visible
        result &= se.element.isVisible(txtNewCodeIdCodeType);
        //verify new code id code type is clickable
        result &= se.element.waitForElementToBeClickable(txtNewCodeIdCodeType);
        //verify if entered value is correctly displayed
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtNewCodeIdCodeType,strNewCodeIDType );
        //verify if new code id code description field is visible
        result &= se.element.isVisible(txtNewCodeIdCodeDesc);
        //verify if the new code id code description field is clickable
        result &= se.element.waitForElementToBeClickable(txtNewCodeIdCodeDesc);
        //verify if entered value is correctly displayed
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtNewCodeIdCodeDesc,strNewCodeIDCodeDesc );
        //verify if the new code id rf description field is visible
        result &= se.element.isVisible(txtNewCodeIdRFDesc);
        //verify if the new code id rf description field is clickable
        result &= se.element.waitForElementToBeClickable(txtNewCodeIdRFDesc);
        //verify if entered value is correctly displayed
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtNewCodeIdRFDesc,strNewCodeIDRFDesc );
        //verify if new code id max code length field is visible
        result &= se.element.isVisible(txtNewCodeIdMaxLen);
        //verify if new code id max code length field is clickable
        result &= se.element.waitForElementToBeClickable(txtNewCodeIdMaxLen);
        //verify if entered value is correctly displayed
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtNewCodeIdMaxLen,strNewCodeIDMaxCodeLen );
        //verify if new code id allow additional codes field is visible
        result &= se.element.isVisible(chkNewCodeIdAllowAddnCodes);
        //verify if new code id allow additional codes field is clickable
        result &= se.element.waitForElementToBeClickable(chkNewCodeIdAllowAddnCodes);
        //select allow additional codes checkbox
        if (strAllowAddnCode.equalsIgnoreCase("yes")) {
            se.element.clickElement(chkNewCodeIdAllowAddnCodes);
        } else {
            //un-check if already selected
            String blnAddStatus = se.element.getAttribute(chkNewCodeIdAllowAddnCodes, "checked");
            if (blnAddStatus == "true") {
                se.element.clickElement(chkNewCodeIdAllowAddnCodes);
            }
        }
        //verify if new code id allow deletion codes field is visible
        result &= se.element.isVisible(chkNewCodeIdAllowDelCodes);
        //verify if new code id allow deletion codes field is clickable
        result &= se.element.waitForElementToBeClickable(chkNewCodeIdAllowDelCodes);
        //select allow deletion codes checkbox
        if (strAllowDelCode.equalsIgnoreCase("yes")) {
            se.element.clickElement(chkNewCodeIdAllowDelCodes);
        } else {
            //un-check if already selected
            String blnDelStatus = se.element.getAttribute(chkNewCodeIdAllowDelCodes, "checked");
            if (blnDelStatus == "true") {
                se.element.clickElement(chkNewCodeIdAllowDelCodes);
            }
        }
        //verify if new code id allow maintenance of code id parameter field is visible
        result &= se.element.isVisible(chkNewCodeIdAllowMaintCodeIdParam);
        //verify if new code id allow maintenance of code id parameter field is clickable
        result &= se.element.waitForElementToBeClickable(chkNewCodeIdAllowMaintCodeIdParam);
        //select allow maintenance of code id parameter checkbox
        if (strAllowMainCode.equalsIgnoreCase("yes")) {
            se.element.clickElement(chkNewCodeIdAllowMaintCodeIdParam);
        } else {
            //un-check if already selected
            String blnMainStatus = se.element.getAttribute(chkNewCodeIdAllowMaintCodeIdParam, "checked");
            if (blnMainStatus == "true") {
                se.element.clickElement(chkNewCodeIdAllowMaintCodeIdParam);
            }
        }
        //verify if new code id allow description changes field is visible
        result &= se.element.isVisible(chkNewCodeIdAllowDescChanges);
        //verify if new code id allow description changes field is clickable
        result &= se.element.waitForElementToBeClickable(chkNewCodeIdAllowDescChanges);
        //select allow description changes checkbox
        if (strAllowDescChanges.equalsIgnoreCase("yes")) {
            se.element.clickElement(chkNewCodeIdAllowDescChanges);
        } else {
            //un-check if already selected
            String blnDescStatus = se.element.getAttribute(chkNewCodeIdAllowDescChanges, "checked");
            if (blnDescStatus == "true") {
                se.element.clickElement(chkNewCodeIdAllowDescChanges);
            }
        }
        //select the warehouse
        result &= verifySelectedItemCorrectlyDisplayed(lstNewCodeIdWarehouse, strWarehouse);
        //select allow description changes checkbox
        if (strSystemCodeParam.equalsIgnoreCase("yes")) {
            se.element.clickElement(chkNewCodeIdSysCodeParam);
        } else if(strSystemCodeParam.equalsIgnoreCase("no")){
        }
        //verify if the user specified value was selected correctly
        result &= verifySelectedItemCorrectlyDisplayed(lstNewCodeIdOrderBy, strOrderBy);
        //verify if the Save button for new code is is visible
        result &= se.element.isVisible(btnNewCodeIdSave);
        //verify if the Save button for new code is is clickable
        result &= se.element.waitForElementToBeClickable(btnNewCodeIdSave);
        //save the new code id
        se.element.clickElement(btnNewCodeIdSave);
        //wait for the page to load
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        return result;
    }

    /**method to delete a code Id anc confirm delete was successfully
     *
     * @param strCodeID
     * @return
     */
    public boolean deleteCodeType(String strCodeID){
        boolean result = searchSystemCodes(strCodeID);
        result &= selectRecordType();
        //verify if the delete code id button is visible
        result &= se.element.isVisible(btnDeleteCodeID);
        //verify if the delete code id button is clickable
        result &= se.element.waitForElementToBeClickable(btnDeleteCodeID);
        //click on the delete code id button
        se.element.clickElement(btnDeleteCodeID);
        //wait for the page to load
        se.myDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        //confirm the delete
        se.myDriver.switchTo().alert().accept();
        //return to default content
        se.element.returnToDefaultContent();
        //wait for the page to load
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        //verify if the code id was deleted successfully
        if( searchSystemCodes(strCodeID) == false){result &= true;}
        return result;
    }

    /**
     * Method to add code id under the system codes
     * @param testdata
     * @return
     */
    public boolean addCodeIdForSystemCode(Map<String, Object>testdata){
        int intCodeId = Integer.parseInt((String)testdata.get(""));
        String strNewCodeIDRecordType = (String)testdata.get("");
        String strCodeID = (String)testdata.get("");
        String strCodeIDDesc = (String)testdata.get("");
        String strCodeIDShortDesc = (String)testdata.get("");
        //wait for the page to load
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        boolean result = se.element.isVisible(tblCodeID);
        //loop through the table to find the code id and click on checkbox
        List<WebElement> options = se.element.getElements(tblCodeID);
        List<WebElement> weCodeIds = se.element.getElements(chkCodeID);
            for (int i = 0; i < options.size(); i++) {
                int codeNumb = Integer.parseInt(weCodeIds.get(i).getText().trim());
                if (codeNumb == intCodeId) {
                    se.element.clickElement(getCodeIdPositionByRow(i));
                    se.log.logSeStep("code ID in the row # " + i + " was displayed as " + codeNumb);
                    result &= true;
                    break;
                }
            //verify if the add code id under system code is visible
            result &= se.element.isVisible(btnAddNewCodeIDForSysCode);
            //verify if the add code id under system code is clickable
            result &= se.element.waitForElementToBeClickable(btnAddNewCodeIDForSysCode);
            //click on the add code id under the system code
            se.element.clickElement(btnAddNewCodeIDForSysCode);
        }
        //verify if the new code id record type field was displayed
        result &= se.element.waitForElement(lstCodeIdRecordType);
        //verify if the selected value was correctly displayed
        result &= verifySelectedItemCorrectlyDisplayed(lstCodeIdRecordType, strNewCodeIDRecordType);
        //verify if the add code Id button was displayed
        result &= se.element.waitForElement(btnAddCodeIDDetails);
        //verify if the add code Id button was visible
        result &= se.element.isVisible(btnAddCodeIDDetails);
        //verify if the add code Id button was clickable
        result &= se.element.waitForElementToBeClickable(btnAddCodeIDDetails);
        //click on the add code Id button
        se.element.clickElement(btnAddCodeIDDetails);
        se.log.logSeStep("clicked on the add code ID button");
        //verify if the code ID description field was clickable
        result &= se.element.waitForElementToBeClickable(txtSysCodeIdDetailCodeDesc);
        //verify enter code ID description was displayed correctly
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtSysCodeIdDetailCodeDesc, strCodeIDDesc);
        //verify if the code ID field was clickable
        result &= se.element.waitForElementToBeClickable(txtSysCodeIdDetailCodeId);
        //verify enter code ID was displayed correctly
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtSysCodeIdDetailCodeId, strCodeID);
        //verify if the code ID short description field was clickable
        result &= se.element.waitForElementToBeClickable(txtSysCodeIdDetailCodeShortDesc);
        //verify enter code ID short description was displayed correctly
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtSysCodeIdDetailCodeShortDesc, strCodeIDShortDesc);
        //verify if the save code Id button was visible
        result &= se.element.isVisible(btnSaveCodeID);
        //verify if the save code Id button was clickable
        result &= se.element.waitForElementToBeClickable(btnSaveCodeID);
        //click on the save code id button
        se.element.clickElement(btnSaveCodeID);
        se.log.logSeStep("clicked on the save code ID button");
        return result;
    }

    /**
     * Method to add parameters to code id
     * @param testdata
     * @return
     */
    public boolean addParametersToSystemCode(Map<String, Object>testdata){
        String strFromPos = (String)testdata.get("paranewcodeidfrompos");
        String strToPos = (String)testdata.get("paranewcodeidtopos");
        String strDesc = (String)testdata.get("paranewcodeiddesc");
        String strParamReq = (String)testdata.get("pararequired");
        String strStyleType = (String)testdata.get("parastyletype");
        String strValType = (String)testdata.get("paravaltype");
        String strFieldValue1 = (String)testdata.get("parafield1");
        String strFieldValue2 = (String)testdata.get("parafield2");
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        //verify if the parameters button was displayed
        boolean result = se.element.isVisible(btnCodeIdParameters) ;
        //verify if the parameters button was clickable
        result &= se.element.waitForElementToBeClickable(btnCodeIdParameters) ;
        //click on the parameters button to add parameters
        se.element.clickElement(btnCodeIdParameters);
        //wait for page load to complete
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        //verify page title
        result &= se.element.waitForElement(wmsHomePageObject.lblPageTitle);
        String lblTitleText = se.element.getText(wmsHomePageObject.lblPageTitle);
        se.log.logTestStep("expected title System Code Parameters, but actual was " + lblTitleText);
        result &= se.assertion.verifyEquals("verify the System Code Parameters page title", lblTitleText,
                "System Code Parameters");
        //verify if add parameter button was visible
        result &= se.element.isVisible(btnAddParam);
        //verify if add parameter button was clickable
        result &= se.element.waitForElementToBeClickable(btnAddParam);
        //click on the add parameter button
        se.element.clickElement(btnAddParam);
        //wait for page load to complete
        se.myDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        //verify is the param from position is visible
        result &= se.element.isVisible(txtParamFromPos);
        //verify if the param from position is clickable
        result &= se.element.waitForElementToBeClickable(txtParamFromPos);
        //verify if entered text was displayed correctly
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtParamFromPos, strFromPos);
        //verify is the param to position is visible
        result &= se.element.isVisible(txtParamToPos);
        //verify if the param to position is clickable
        result &= se.element.waitForElementToBeClickable(txtParamToPos);
        //verify if entered text was displayed correctly
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtParamToPos, strToPos);
        //verify is the param description is visible
        result &= se.element.isVisible(txtParamDesc);
        //verify if the param description is clickable
        result &= se.element.waitForElementToBeClickable(txtParamDesc);
        //verify if entered text was displayed correctly
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtParamDesc, strDesc);
        //verify if the param required field was visible
        result &= se.element.isVisible(chkParamReq);
        //verify if the param required field was clickable
        result &= se.element.waitForElementToBeClickable(chkParamReq);
        //select param required checkbox
        if (strParamReq.equalsIgnoreCase("yes")) {
            se.element.clickElement(chkParamReq);
        } else {
            //un-check if already selected
            String blnParaReqStatus = se.element.getAttribute(chkParamReq, "checked");
            if (blnParaReqStatus == "true") {
                se.element.clickElement(chkParamReq);
            }
        }
        //verify selected style type was displayed correctly
        if(strStyleType.equalsIgnoreCase("Check box")) {
            result &= paraStyleCheckboxType(strStyleType, strValType, strFieldValue1, strFieldValue2);
        }else if(strStyleType.equalsIgnoreCase("Edit box")){
            result &= paraStyleEditBoxType(strStyleType, strValType, strFieldValue1, strFieldValue2);
        }else if(strStyleType.equalsIgnoreCase("System code")){
            result &= false;
        }
        //verify if the save button was visible
        result &= se.element.isVisible(btnSaveParam);
        //verify if the save button was clickable
        result &= se.element.waitForElementToBeClickable(btnSaveParam);
        //click on the save parameters button
        se.element.clickElement(btnSaveParam);
        //wait for page load to complete
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        return result;
    }

    /**
     * Method to add parameters to code id
     * @param testdata
     * @return
     */
    public boolean addParametersToCodeId(Map<String,Object>testdata){
        String strFromPos = (String)testdata.get("paranewcodeidfrompos");
        String strToPos = (String)testdata.get("paranewcodeidtopos");
        String strDesc = (String)testdata.get("paranewcodeiddesc");
        String strParamReq = (String)testdata.get("pararequired");
        String strStyleType = (String)testdata.get("parastyletype");
        String strValType = (String)testdata.get("paravaltype");
        String strFieldValue1 = (String)testdata.get("parafield1");
        String strFieldValue2 = (String)testdata.get("parafield2");
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);

        //verify if the parameters button was displayed
        boolean result = se.element.isVisible(btnCodeIdParameters) ;
        //verify if the parameters button was clickable
        result &= se.element.waitForElementToBeClickable(btnCodeIdParameters) ;
        //click on the parameters button to add parameters
        se.element.clickElement(btnCodeIdParameters);
        //wait for page load to complete
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        //verify page title
        result &= se.element.waitForElement(wmsHomePageObject.lblPageTitle);
        String lblTitleText = se.element.getText(wmsHomePageObject.lblPageTitle);
        se.log.logTestStep("expected title System Code Parameters, but actual was " + lblTitleText);
        result &= se.assertion.verifyEquals("verify the System Code Parameters page title", lblTitleText,
                "System Code Parameters");
        //verify if add parameter button was visible
        result &= se.element.isVisible(btnAddParam);
        //verify if add parameter button was clickable
        result &= se.element.waitForElementToBeClickable(btnAddParam);
        //click on the add parameter button
        se.element.clickElement(btnAddParam);
        //wait for page load to complete
        se.myDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        //verify is the param from position is visible
        result &= se.element.isVisible(txtParamFromPos);
        //verify if the param from position is clickable
        result &= se.element.waitForElementToBeClickable(txtParamFromPos);
        //verify if entered text was displayed correctly
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtParamFromPos, strFromPos);
        //verify is the param to position is visible
        result &= se.element.isVisible(txtParamToPos);
        //verify if the param to position is clickable
        result &= se.element.waitForElementToBeClickable(txtParamToPos);
        //verify if entered text was displayed correctly
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtParamToPos, strToPos);
        //verify is the param description is visible
        result &= se.element.isVisible(txtParamDesc);
        //verify if the param description is clickable
        result &= se.element.waitForElementToBeClickable(txtParamDesc);
        //verify if entered text was displayed correctly
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtParamDesc, strDesc);
        //verify if the param required field was visible
        result &= se.element.isVisible(chkParamReq);
        //verify if the param required field was clickable
        result &= se.element.waitForElementToBeClickable(chkParamReq);
        //select param required checkbox
        if (strParamReq.equalsIgnoreCase("yes")) {
            se.element.clickElement(chkParamReq);
        } else {
            //un-check if already selected
            String blnParaReqStatus = se.element.getAttribute(chkParamReq, "checked");
            if (blnParaReqStatus == "true") {
                se.element.clickElement(chkParamReq);
            }
        }
        //verify selected style type was displayed correctly
        if(strStyleType.equalsIgnoreCase("Check box")) {
            result &= paraStyleCheckboxType(strStyleType, strValType, strFieldValue1, strFieldValue2);
        }else if(strStyleType.equalsIgnoreCase("Edit box")){
            result &= paraStyleEditBoxType(strStyleType, strValType, strFieldValue1, strFieldValue2);
        }else if(strStyleType.equalsIgnoreCase("System code")){
            result &= false;
        }
        //verify if the save button was visible
        result &= se.element.isVisible(btnSaveParam);
        //verify if the save button was clickable
        result &= se.element.waitForElementToBeClickable(btnSaveParam);
        //click on the save button
        //se.element.clickElement(btnSaveParam);
        return result;
    }

    /**Method to select the style type using enum
     *
     * @param strStyleType
     * @param strValType
     * @param strFieldVal1
     * @param strFieldVal2
     * @return
     */
    public boolean paraStyleCheckboxType(String strStyleType, String strValType,
                                         String strFieldVal1, String strFieldVal2){
        //verify if the style drop down was visible
        boolean result =  se.element.isVisible(lstParamStyle);
        //select the user defined style from style dropdown
        for(ParameterStyle paramStyle : ParameterStyle.values()){
            String style = paramStyle.getStyle();
            if(style.contains(strStyleType)){
                //click on the option user specified
                result &= se.element.clickElement(paramStyle.getParamStyleLocator());
                //select validation type based on user input
                for(CheckBoxValidationType valTy: CheckBoxValidationType.values()){
                    String valValue = valTy.getValType();
                    if(valValue.contains(strValType)){
                        //click on the validation type specified by user
                        result &= se.element.clickElement(valTy.getValTypeLocator());
                        if((!strValType.contains("---None---")) && (!strValType.contains("Y/N Flag"))) {
                            //verify if the field one locator was visible
                            result &= se.element.isVisible(valTy.getFieldOneLocator());
                            //enter ane verify if the entered valued was correctly displayed
                            result &= verifyEnteredTextIsCorrectlyDisplayed(valTy.getFieldOneLocator(), strFieldVal1);
                            //verify if the field two locator was visible
                            result &= se.element.isVisible(valTy.getFieldTwoLocator());
                            //enter ane verify if the entered valued was correctly displayed
                            result &= verifyEnteredTextIsCorrectlyDisplayed(valTy.getFieldTwoLocator(), strFieldVal2);
                        }
                        break;
                    }
                }
                break;
            }
        }
        return result;
    }

    /**Method to select the style type using enum
     *
     * @param strStyleType
     * @param strValType
     * @param strFieldVal1
     * @param strFieldVal2
     * @return
     */
    public boolean paraStyleEditBoxType(String strStyleType, String strValType,
                                        String strFieldVal1, String strFieldVal2){
        //verify if the style drop down was visible
        boolean result =  se.element.isVisible(lstParamStyle);
        //select the user defined style from style dropdown
        for(ParameterStyle paramStyle : ParameterStyle.values()){
            String style = paramStyle.getStyle();
            if(style.contains(strStyleType)){
                //click on the option user specified
                result &= se.element.clickElement(paramStyle.getParamStyleLocator());
                //select validation type based on user input
                for(EditBoxValidationType editValTy: EditBoxValidationType.values()){
                    String valValue = editValTy.getValType();
                    if(valValue.contains(strValType)){
                        //click on the validation type specified by user
                        result &= se.element.clickElement(editValTy.getValTypeLocator());
                        if((!strValType.contains("---None---")) && (!strValType.contains("Alpha Numeric"))) {
                            //verify if the field one locator was visible
                            result &= se.element.isVisible(editValTy.getFieldOneLocator());
                            //enter ane verify if the entered valued was correctly displayed
                            result &= verifyEnteredTextIsCorrectlyDisplayed(editValTy.getFieldOneLocator(),
                                    strFieldVal1);
                            //verify if the field two locator was visible
                            result &= se.element.isVisible(editValTy.getFieldTwoLocator());
                            //enter ane verify if the entered valued was correctly displayed
                            result &= verifyEnteredTextIsCorrectlyDisplayed(editValTy.getFieldTwoLocator(),
                                    strFieldVal2);
                        }
                        break;
                    }
                }
                break;
            }
        }
        return result;
    }

    /**Method to verify the style type checkbox using enum
     *
     * @param strStyleType
     * @param strValType
     * @param strFieldVal1
     * @param strFieldVal2
     * @return
     */
    public boolean verifyParaStyleTypeCheckbox(String strStyleType, String strValType,
                                               String strFieldVal1, String strFieldVal2) {
        //verify if the style drop down was visible
        boolean result = se.element.isVisible(lstParamStyle);
        //get the style tye displayed
        String strDispStyle = getSelectedValue(lstParamStyle).trim();
        result &= se.assertion.verifyEquals("verify the style type was saved successfully", strDispStyle, strStyleType);
        for (CheckBoxValidationType valTy : CheckBoxValidationType.values()) {
            String valValue = valTy.getValType();
            if (valValue.contains(strValType)) {
                //get validation type displayed
                String strDispValType = se.element.getAttribute(valTy.getValTypeLocator(), "selected").trim();
                result &= se.assertion.verifyTrue("verify the validation type was saved successfully",
                        Boolean.valueOf(strDispValType));
                if ((!strValType.contains("---None---")) && (!strValType.contains("Y/N Flag"))) {
                    //verify if the field one locator was visible
                    result &= se.element.isVisible(valTy.getFieldOneLocator());
                    //verify if the entered valued was correctly displayed
                    String strField1 = se.element.getAttribute(valTy.getFieldOneLocator(),"value").trim();
                    result &= se.assertion.verifyEquals("verify if the entered value of field1 was correctly displayed",
                            strField1, strFieldVal1);
                    //verify if the field two locator was visible
                    result &= se.element.isVisible(valTy.getFieldTwoLocator());
                    //enter ane verify if the entered valued was correctly displayed
                    String strField2 = se.element.getAttribute(valTy.getFieldTwoLocator(),"value").trim();
                    //enter ane verify if the entered valued was correctly displayed
                    result &= se.assertion.verifyEquals("verify if the entered value of field2 was correctly displayed",
                            strField2, strFieldVal2);
                    break;
                }
            }
        }
        return result;
    }


    /**Method to verify the style type editbox using enum
     *
     * @param strStyleType
     * @param strValType
     * @param strFieldVal1
     * @param strFieldVal2
     * @return
     */
    public boolean verifyParaStyleTypeEditbox(String strStyleType,
                                              String strValType, String strFieldVal1, String strFieldVal2) {
        //verify if the style drop down was visible
        boolean result = se.element.isVisible(lstParamStyle);
        //get the style tye displayed
        String strDispStyle = getSelectedValue(lstParamStyle).trim();
        result &= se.assertion.verifyEquals("verify the style type was saved successfully",
                strDispStyle, strStyleType);
        for (EditBoxValidationType valTy : EditBoxValidationType.values()) {
            String valValue = valTy.getValType();
            if (valValue.contains(strValType)) {
                //get validation type displayed
                String strDispValType = se.element.getAttribute(valTy.getValTypeLocator(), "selected").trim();
                result &= se.assertion.verifyTrue("verify the validation type was saved successfully",
                        Boolean.valueOf(strDispValType));
                if ((!strValType.contains("---None---")) && (!strValType.contains("Alpha Numeric"))) {
                    result &= se.element.isVisible(valTy.getFieldOneLocator());
                    //verify if the entered valued was correctly displayed
                    String strField1 = se.element.getAttribute(valTy.getFieldOneLocator(), "value").trim();
                    result &= se.assertion.verifyEquals("verify if the entered value of field1 was correctly displayed",
                            strField1, strFieldVal1);
                    //verify if the field two locator was visible
                    result &= se.element.isVisible(valTy.getFieldTwoLocator());
                    //enter ane verify if the entered valued was correctly displayed
                    String strField2 = se.element.getAttribute(valTy.getFieldTwoLocator(), "value").trim();
                    //enter ane verify if the entered valued was correctly displayed
                    result &= se.assertion.verifyEquals("verify if the entered value of field2 was correctly displayed",
                            strField2, strFieldVal2);
                    break;
                }
            }
        }
        return result;
    }
}

