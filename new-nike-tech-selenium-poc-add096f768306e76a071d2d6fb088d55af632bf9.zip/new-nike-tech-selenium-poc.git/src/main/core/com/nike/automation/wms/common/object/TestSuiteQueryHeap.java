package com.nike.automation.wms.common.object;

import java.util.HashMap;
import java.util.Map;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement (name = "wms-quires")
@XmlAccessorType(XmlAccessType.FIELD)
public class TestSuiteQueryHeap {
	private Map<String, TestCaseQueryDetails> testcase = new HashMap<String, TestCaseQueryDetails>();

	public Map<String, TestCaseQueryDetails> getTestcase() {
		return testcase;
	}

	public void setTestcase(Map<String, TestCaseQueryDetails> testcases) {
		this.testcase = testcases;
	}

	public String  getDetails(String tcID){
		return tcID + testcase.get(tcID).getDetails();
	}
	public String  getSql(String tcID, int index){
		return testcase.get(tcID).getQueryList().get(index).getSqlQuery();
	}	
	public String  getSql(String tcID, String id){
		String sql = null;
		for(SqlQueryInformation queryInfo: testcase.get(tcID).getQueryList()){
			if(queryInfo.getId().equals(id)){
				sql=queryInfo.getSqlQuery();
				break;
			}				
		}
		return sql;
	}	
}
