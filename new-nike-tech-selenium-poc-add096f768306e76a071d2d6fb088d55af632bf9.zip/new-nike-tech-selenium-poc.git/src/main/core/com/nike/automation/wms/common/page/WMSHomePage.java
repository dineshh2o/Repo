package com.nike.automation.wms.common.page;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.nike.automation.wms.common.util.ApplicationKeys;

import java.util.Map;
import java.util.concurrent.TimeUnit;

public class WMSHomePage extends BasePage {

	/**
	 * Locators
	 */
	public By lnkSignOut = By.linkText("Sign Out");
	public By btnConfirmSignOut = By.id("SignoutOK");
	public By btnChooseFile = By.id("dataForm:uploadedFileID");
	public By btnSendMessage = By.id("dataForm:postMessageCmdId");
	public By lblPageTitle = By.id("dataForm:hLabel");
	public By lblPostXMlPageTitle = By.id("dataForm:page_header_panel_text");
	public By lblResultXML = By.id("dataForm:resultString");
	public By asnFilter = By.xpath("//*[@id='dataForm:ASNList_entityListView:ASNList_filterId2:field30value1']");
	public By applyFilter = By
			.xpath("//*[@id='dataForm:ASNList_entityListView:ASNList_filterId2:ASNList_filterId2apply']");
	public By firstAsnRecord = By.xpath("//*[@id='checkAll_c0_dataForm:ASNList_entityListView:dataTable']");
	public By moreButton = By.id("soheaderbuttonsmoreButton");
	public By verifyAsnMenu = By.id("CTO_ASNList_VerifyASN_more");
	public By allLpnTab = By.id("AllLpns_lnk");
	public By menuDropSecondEle = By.xpath("//*[@id='as_bas1_dd_1_li']/div/a");





	/**
	 * @author Cognizant
	 * @Description
	 * Method to verify and click on the sign-out button
	 *
	 * @return Boolean
	 */
	public boolean verifyAndClickSignOut() {
		// verify if the sign-out element() was displayed
		se.element.requireIsDisplayed("Sign-out link", lnkSignOut);
		// verify if the sign-out element() was visible
		boolean result = se.element.isVisible(lnkSignOut);
		// verify if the sign-out element() was clickable
		result &= se.element.waitForElementToBeClickable(lnkSignOut);
		// click on the sign-out element()
		se.element.clickElement(lnkSignOut);
		// report the click sign-out event on to the html report
		se.log.logSeStep("clicked on the sign-out element() successfully");
		return result;
	}

	/**
	 * @author Cognizant
	 * @Description Method to verify and click on confirm sign-out
	 * 
	 * @return Boolean
	 */
	public boolean verifyAndClickConfirmSignOut() {
		// verify if the OK element() was displayed
		se.element.requireIsDisplayed("Confirm Sign-out button", btnConfirmSignOut);
		// verify if the OK element() was visible
		boolean result = se.element.isVisible(btnConfirmSignOut);
		// verify if the OK element() was clickable
		result &= se.element.waitForElementToBeClickable(btnConfirmSignOut);
		// click on the OK element()
		se.element.clickElement(btnConfirmSignOut);
		// report the click event on the html report
		se.log.logTestStep("clicked on the confirm sign-out element() successfully");
		return result;
	}

	/**
	 * @author Cognizant
	 * @Description Method for  pixTransaction
	 * @param testdata
	 * @return Boolean
	 */

	public boolean pixTransaction(Map<String, Object> testdata) {
		WebDriverWait wait = new WebDriverWait(se.webDriver, 20);
		wait.until(ExpectedConditions.elementToBeClickable(menuLink));


		se.webDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		@SuppressWarnings("unused")
		boolean result = menuNavigation("Distribution", "PIX Transactions");

		se.webDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		By trnTypeDropDdown = By.xpath("//*[@id='dataForm:lview:filterId:field0value1']");
		se.webDriver.findElement(trnTypeDropDdown).click();
		Select trnType = new Select(se.webDriver.findElement(trnTypeDropDdown));
		trnType.selectByVisibleText("300-Allocable inventory adjustments");

		By trnCodeDropDdown = By.xpath("//*[@id='dataForm:lview:filterId:field1value1']");
		wait.until(ExpectedConditions.visibilityOfElementLocated(trnCodeDropDdown));

		Select trnCode = new Select(se.webDriver.findElement(trnCodeDropDdown));
		trnCode.selectByVisibleText("300 02-300 02-Maintain oLPN");
		se.webDriver.findElement(By.xpath("//*[@id='dataForm:lview:filterId:filterIdapply']")).click();

		By record = By.xpath("//*[text()='427998542']/parent::td/parent::tr/td[1]");
		wait.until(ExpectedConditions.visibilityOfElementLocated(record));

		se.webDriver.findElement(record).click();

		By view = By.xpath("//input[@type='button' and @value='View']");
		se.webDriver.findElement(view).click();
		return true;
	}


	/**
	 * @author Cognizant
	 * @Description Method to verify the assigned ASN
	 * @param testdata
	 * @return Boolean
	 */

	public boolean verifyAssignAsn(Map<String, Object> testdata) {

		WebDriverWait wait = new WebDriverWait(se.webDriver, 20);
		se.element.waitForElement(asnFilter);
		wait.until(ExpectedConditions.elementToBeClickable(asnFilter));

		String asn = (String) testdata.get("asn");

		se.webDriver.findElement(asnFilter).sendKeys(asn);
		se.webDriver.findElement(applyFilter).click();

		wait.until(ExpectedConditions.elementToBeClickable(firstAsnRecord));
		se.webDriver.findElement(firstAsnRecord).click();

		se.webDriver.findElement(moreButton).click();
		se.webDriver.findElement(verifyAsnMenu).click();

		se.element.waitForElement(allLpnTab);
		se.webDriver.findElement(allLpnTab).click();
		return true;
	}

	/**
	 * Method to verify and post XML file 
	 *
	 * @return Boolean
	 */
	public boolean verifyPostXML(Map<String, Object> testdata) {
		String identifier = (String) testdata.get("identifier");
		String xmlLocalTempPath = ((String) testdata.get("Local-XML-Storage")).replaceAll("/", "\\\\");

		String localXmlPath = xmlLocalTempPath + "\\" + identifier + ".xml";

		// wait for page load to complete
		se.webDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		//boolean result = menuNavigation("Integration", "Post Message");
		//boolean result = openSearchMenu(testdata, "searchPostXmlKey");		
		boolean result = openSearchMenu(ApplicationKeys.APPS_MENU_POST_XML);
		// wait for page load to complete
		se.webDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// wait for the page title to be displayed
		result = se.element.waitForElement(lblPostXMlPageTitle);
		// verify page title
		String lblTitleText = se.element.getText(lblPostXMlPageTitle).trim();
		se.log.logTestStep("expected title POST MESSAGE, but actual was " + lblTitleText);
		result &= se.assertion.verifyEquals("verify the post message page title", lblTitleText, "Post Message");
		// verify if the required field was displayed
		result &= se.element.waitForElement(btnChooseFile);
		// set the path of the xml file to upload
		se.webDriver.findElement(btnChooseFile).sendKeys(localXmlPath);
		// wait for file upload to complete
		se.webDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		// report the click event on the html report
		se.log.logTestStep("entered the file path successfully");
		// verify if the send button was displayed
		result &= se.element.waitForElement(btnSendMessage);
		// click send button to post the xml file
		scrollIntoView(btnSendMessage);
		se.element.clickElement(btnSendMessage);
		// verify if the XMl text area was displayed
		se.element.requireIsDisplayed("XML text area", lblResultXML);
		String resultXML = se.element.getText(lblResultXML);
		// validate the error message
		if (resultXML.contains("CDATA")) {
			result = false;
			// report the click event on the html report
			se.log.logTestStep("xml posting failed");
		} else {
			result = true;
			// report the click event on the html report
			se.log.logTestStep("xml posting was successful");
		}
		return result;
	}

//
//	/**
//	 * @author Cognizant
//	 * @Description Method search with specific key
//	 * @param testdata
//	 * @param key
//	 * @return Boolean
//	 */
//	public boolean openSearchMenuSpecific(Map<String, Object> testdata, String key) {
//		try{			
//		WebDriverWait wait = new WebDriverWait(se.myDriver, 20);
//		wait.until(ExpectedConditions.elementToBeClickable(menuLink));
//		se.element.waitForElement(menuLink);
//		se.myDriver.findElement(menuLink).click();
//		String searchKey = (String) testdata.get(key);
//		se.myDriver.findElement(menuText).sendKeys(searchKey);
//		se.myDriver.findElement(menuDropSecondEle).click();
//		report.updateTestLog("Search Menu ", "Search is Successfull", Status.PASS);
//	
//		}catch(Exception ex)
//		{
//			report.updateTestLog("Search Menu  ", "Unable to search the Specific Element," + ex.getMessage(), Status.FAIL);
//			
//		}
//		return true;
//	}
//	
//	/**
//	 * @author Cognizant
//	 * @Description Method search with specific key
//	 * @param testdata
//	 * @param key
//	 * @return Boolean
//	 */
//	public boolean openSearchMenuSpecific(Map<String, Object> testdata, ApplicationKeys key) {
//		try{			
//		WebDriverWait wait = new WebDriverWait(se.myDriver, 20);
//		wait.until(ExpectedConditions.elementToBeClickable(menuLink));
//		se.element.waitForElement(menuLink);
//		se.myDriver.findElement(menuLink).click();
//		String searchKey = (String) testdata.get(key.toString());
//		se.myDriver.findElement(menuText).sendKeys(searchKey);
//		se.myDriver.findElement(menuDropSecondEle).click();
//		report.updateTestLog("Search Menu ", "Search is Successfull", Status.PASS);
//	
//		}catch(Exception ex)
//		{
//			report.updateTestLog("Search Menu  ", "Unable to search the Specific Element," + ex.getMessage(), Status.FAIL);
//			
//		}
//		return true;
//	}
}