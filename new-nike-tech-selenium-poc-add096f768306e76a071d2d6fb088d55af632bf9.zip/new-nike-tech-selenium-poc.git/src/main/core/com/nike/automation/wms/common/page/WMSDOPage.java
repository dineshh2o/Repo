package com.nike.automation.wms.common.page;

import java.util.List;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cognizant.framework.Status;
import com.nike.automation.wms.common.object.GenericWmsElement;
import com.nike.automation.wms.common.util.WmsCustomException;

public class WMSDOPage extends BasePage {

	public By fulfillmentStausOkButton 			= By.id("ms_popok1");
	public By fulfillmentStatusList			    = By.xpath("//*[@id='dataForm:DOList_entityListView:DOList_MainListTable_body']/tbody/tr/td[7]/div/span");
	public By refresh 							= By.xpath("//*[@id='pghdr']/tbody/tr[1]/td[1]/table/tbody/tr/td[8]/a/img");
	public By doIdTextArea 						= By.xpath("//*[@id='dataForm:DOList_entityListView:DistributionOrderlist1:field5value1']");
	public By doNumber 							= By.xpath("//*[@id='dataForm:DOList_entityListView:DOList_MainListTable_body_tr0_td4_view']/span");
	public By applyButton 						= By.xpath("//*[@id='dataForm:DOList_entityListView:DistributionOrderlist1:DistributionOrderlist1apply']");
	public By doViewButton 						= By.id("dataForm:DO_List_View_button");
	public By transportationStatus 				= By.xpath("//table[@id='dataForm:DODetailsMainHeader_PGrid_Header']/tbody/tr/td[7]/span[2]");
	public By fulfillmentStatus 				= By.cssSelector("[id*='DODetailsMainHeader_PGrid_Header'] > tbody > tr:nth-child(2) > td:nth-child(4) > span:nth-child(2)");
	public By doFulfillmentStatus 				= By.xpath("//*[@id='dataForm:DOList_entityListView:DOList_MainListTable:0:DOList_OrderFulfillmentStatus_Output2']");
	public By parentOID 						= By.id("dataForm:DODetailsHeader_OutText_ParentorderID");
	public By menuLink 							= By.id("phMenu");
	public By menuText 							= By.xpath("//*[contains(@id,'as_bas') and contains(@id,'_in')]");

	/**
	 * @param testdata
	 * @return
	 * @throws WmsCustomException
	 */
	public By getDOCheckbox(String str) {
		String xpath = "//span[contains(text(),'" + str
				+ "')]/parent::div/parent::td/parent::tr/td[1]/input[contains(@type,'checkbox')]";

		return By.xpath(xpath);
	}

	/**
	 * @author Cognizant
	 * @param testdata
	 * @return Boolean
	 * @throws WmsCustomException
	 * @Description verification of DO Status
	 */
	public boolean verifyDOStatus(Map<String, Object> testdata) throws WmsCustomException {
		try {
			se.log.logTestStep("Starting verifyDOStatus");
			WebDriverWait wait = new WebDriverWait(se.webDriver, globalWaitDefault);
			searchDO(testdata);
			waitForComponent(se, wait, doNumber);

			while (!se.webDriver.findElements(fulfillmentStatusList).get(0).getText().equalsIgnoreCase("Released")) {
				waitForComponent(se, wait, refresh);
				se.element.clickElement(refresh);
				se.log.logTestStep("done refresh");
				processingDelay(20);
			}
			se.log.logTestStep("done wait");
			report.updateTestLog("DO Status verification", "DO verified Succesfully", Status.PASS);
		} catch (Exception ex) {
			se.log.logTestStep("Unable to verify DO status");
			report.updateTestLog("DO Status verification : ", "DO verification is Unsuccessfull", Status.FAIL);
			throw new WmsCustomException(ex);
		}

		return true;
	}

	/**
	 * @author Cognizant
	 * @param testdata
	 * @return Boolean
	 * @throws WmsCustomException
	 * @Description Search DOs
	 */
	public boolean searchDO(Map<String, Object> testdata) throws WmsCustomException {
		try {
			se.log.logTestStep("Attempting DO search");
			WebDriverWait wait = new WebDriverWait(se.webDriver, globalWaitAvg);
			waitForComponent(se, wait, doIdTextArea);
			se.webDriver.findElement(doIdTextArea).clear();
			List<GenericWmsElement> doNoList = se.getDriver().getDataReserver(getIdentifier()).getDoIds().getElement();
			String doNo = "";
			for (GenericWmsElement doNoObj : doNoList) {
				if (doNo.equalsIgnoreCase(""))
					doNo = doNoObj.getElementValue();
				else
					doNo = doNo + "," + doNoObj.getElementValue();
			}
			se.webDriver.findElement(doIdTextArea).sendKeys(doNo);
			wait.until(ExpectedConditions.presenceOfElementLocated(applyButton));
			se.webDriver.findElement(applyButton).click();
			report.updateTestLog("DO Search  ", "Apply Button is clicked", Status.DONE);
			processingDelay(globalWaitMin);
		} catch (Exception ex) {
			se.log.logTestStep("Not able to search DOs");
			report.updateTestLog("DO Search  ", "DO Search is Unsuccessfull", Status.FAIL);
			throw new WmsCustomException(ex);
		}
		return true;
	}

	/**
	 * @author Cognizant
	 * @param doNumber
	 * @return Boolean
	 * @throws WmsCustomException
	 * @Description Search DOs
	 */
	public boolean searchDO(String doNumber) throws WmsCustomException {
		try {
			WebDriverWait wait = new WebDriverWait(se.webDriver, globalWaitDefault);
			processingDelay(globalWaitMin);
			waitForComponent(se, wait, menuLink);
			se.element.clickElement(menuLink);
			se.element.waitForElement(menuText);
			se.webDriver.findElement(menuText).sendKeys("Distribution Orders");
			se.webDriver.findElement(menuText).sendKeys(Keys.RETURN);
			report.updateTestLog("Search Menu ", "Search is Successfull", Status.PASS);
			processingDelay(globalWaitMin);
			se.log.logTestStep("inside DO search");
			waitForComponent(se, wait, doIdTextArea);
			se.webDriver.findElement(doIdTextArea).clear();

			se.webDriver.findElement(doIdTextArea).sendKeys(doNumber);
			wait.until(ExpectedConditions.presenceOfElementLocated(applyButton));
			se.webDriver.findElement(applyButton).click();
			report.updateTestLog("DO Search  ", "Apply Button is clicked", Status.PASS);
		} catch (Exception ex) {
			report.updateTestLog("DO Search  ", "DO Search is Unsuccessfull," + ex.getMessage(), Status.FAIL);
			throw new WmsCustomException(ex);
		}
		return true;
	}

	/**
	 * @author Cognizant
	 * @param testdata
	 * @return Boolean
	 * @throws WmsCustomException
	 * @Description view and verify the Do status
	 */
	public boolean viewAndVerifyDOStatus(Map<String, Object> testdata) throws WmsCustomException {

		try {
			WebDriverWait wait = new WebDriverWait(se.webDriver, globalWaitDefault);
			searchDO(testdata);
			String doStatus = (String) testdata.get("doStatus");
			String doStatusChk = (String) testdata.get("doStatusChk");

			waitForComponent(se, wait, getDOCheckbox(doStatus));

			se.webDriver.findElement(getDOCheckbox(doStatus)).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(doViewButton));
			wait.until(ExpectedConditions.elementToBeClickable(doViewButton));
			se.webDriver.findElement(doViewButton).click();
			String tpStatus = (String) testdata.get("tpStatus");
			waitForComponent(se, wait, transportationStatus);
			if ((se.webDriver.findElement(transportationStatus).getText().equals(tpStatus))
					&& (se.webDriver.findElement(fulfillmentStatus).getText().equals(doStatusChk))) {

				report.updateTestLog("TP Status",
						"Transportation Status:" + se.webDriver.findElement(transportationStatus).getText(),
						Status.PASS);
				report.updateTestLog("FF Status",
						"Fulfillment Status:" + se.webDriver.findElement(fulfillmentStatus).getText(), Status.PASS);
			}
		} catch (Exception ex) {
			report.updateTestLog("DO Status", "DO Status not verified", Status.FAIL);
			throw new WmsCustomException(ex);
		}

		return true;
	}

	/**
	 * @author Cognizant
	 * @param testdata
	 * @return Boolean
	 * @throws WmsCustomException
	 * @Description view and verification of DO Status after Picking wave is
	 *              done
	 */
	public boolean viewAndVerifyDOStatusAfterPick(Map<String, Object> testdata) throws WmsCustomException {

		try {
			WebDriverWait wait = new WebDriverWait(se.webDriver, 30);
			verifymDO(testdata);
			String doStatus = (String) testdata.get("ffStatus");
			String ffStatus = (String) testdata.get("ffStatus");
			while (!se.webDriver.findElements(fulfillmentStatusList).get(0).getText()
					.equalsIgnoreCase("DC Allocated")) {
				waitForComponent(se, wait, refresh);
				se.element.clickElement(refresh);
				se.log.logTestStep("done refresh");
				processingDelay(20);
			}

			waitForComponent(se, wait, getDOCheckbox(doStatus));
			processingDelay(globalWaitMin);
			se.webDriver.findElement(getDOCheckbox(doStatus)).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(doViewButton));
			wait.until(ExpectedConditions.elementToBeClickable(doViewButton));
			se.webDriver.findElement(doViewButton).click();
			String tpStatus = (String) testdata.get("tpStatus");
			waitForComponent(se, wait, transportationStatus);
			if ((se.webDriver.findElement(transportationStatus).getText().equals(tpStatus))
					&& (se.webDriver.findElement(fulfillmentStatus).getText().equals(ffStatus))) {
				report.updateTestLog("TP status:" + se.webDriver.findElement(transportationStatus).getText(),
						"FF status:" + se.webDriver.findElement(fulfillmentStatus).getText().equals(ffStatus),
						Status.PASS);

			}
		} catch (Exception ex) {
			report.updateTestLog("After pick status", "TP and FF status are not proper", Status.FAIL);
			throw new WmsCustomException(ex);
		}

		return true;

	}

	/**
	 * @author Cognizant
	 * @param testdata
	 * @return Boolean
	 * @throws WmsCustomException
	 * @Description verify whether Major DO is created or not
	 */
	public boolean verifymDO(Map<String, Object> testdata) {

		WebDriverWait wait = new WebDriverWait(se.webDriver, globalWaitDefault);
		waitForComponent(se, wait, doIdTextArea);
		List<GenericWmsElement> majorDoNoList = se.getDriver().getDataReserver(getIdentifier()).getMajorDOIds().getElement();
		String mDoNo = null;
		for (GenericWmsElement majorDoNo : majorDoNoList) {
			String str = majorDoNo.getElementValue();
			mDoNo = str;
		}
		se.webDriver.findElement(doIdTextArea).clear();
		processingDelay(globalWaitMin);
		se.webDriver.findElement(doIdTextArea).sendKeys(mDoNo);
		se.webDriver.findElement(applyButton).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(
				By.id("dataForm:DOList_entityListView:DOList_MainListTable_body_tr0_td5_view")));
		return true;
	}

	/**
	 * @author Cognizant
	 * @param testdata
	 * @return Boolean
	 * @throws WmsCustomException
	 * @Description Store the major DO ID
	 */
	public boolean getMajorDO(Map<String, Object> testdata) throws WmsCustomException {

		try {
			se.log.logTestStep("Starting : openSearchMenu");
			WebDriverWait wait = new WebDriverWait(se.webDriver, globalWaitAvg);
			List<GenericWmsElement> doNoList = se.getDriver().getDataReserver(getIdentifier()).getDoIds().getElement();
			for (GenericWmsElement doNo : doNoList) {
				searchDO(doNo.getElementValue());
				processingDelay(globalWaitMin);
				waitForComponent(se, wait, getDOCheckbox("Released"));
				se.webDriver.findElement(getDOCheckbox("Released")).click();
				report.updateTestLog("DO Search ", "Successfully searched DO", Status.PASS);
				waitForComponent(se, wait, doViewButton);
				se.webDriver.findElement(doViewButton).click();
				waitForComponent(se, wait, parentOID);
				String majorDo = se.webDriver.findElement(parentOID).getText();

				if (majorDo == null || "".equals(majorDo)) {
					report.updateTestLog("Major DO", "Major DO can not be null", Status.FAIL);
					throw new WmsCustomException("Major Do number is empty, not able to proceed !");
				}

				getDataReserver().getMajorDOIds().getElement().add(new GenericWmsElement("MajorDoId", majorDo));
				se.log.logSeStep(se.webDriver.findElement(parentOID).getText());
				report.updateTestLog("Set Major DO", "Major DO created and set Succesfully", Status.PASS);
			}
		} catch (Exception ex) {
			report.updateTestLog("Set Major DO", "Major DO is not created and set Succesfully", Status.FAIL);
			throw new WmsCustomException(ex);
		}

		return true;

	}
}