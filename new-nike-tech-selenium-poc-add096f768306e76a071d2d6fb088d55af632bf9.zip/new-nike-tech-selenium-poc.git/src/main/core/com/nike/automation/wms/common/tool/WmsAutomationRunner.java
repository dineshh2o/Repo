package com.nike.automation.wms.common.tool;

import java.util.ArrayList;
import java.util.List;
import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlSuite.ParallelMode;
import org.testng.xml.XmlTest;

public class WmsAutomationRunner {

	public void runTSuite(){
		XmlSuite suite = new XmlSuite();
		suite.setName("Regression");
			
		XmlTest test = new XmlTest(suite);
		test.setName("Test");
		test.setParallel(ParallelMode.METHODS);
		test.setThreadCount(1);
		List<XmlClass> classes = new ArrayList<XmlClass>();
		classes.add(new XmlClass("com.nike.automation.wms.testset.dc.nalc.TESTSET_WMS_NALC_GROUPA_IB_1014"));
		test.setXmlClasses(classes) ;
		
		List<XmlSuite> suites = new ArrayList<XmlSuite>();
		suites.add(suite);
		TestNG tng = new TestNG();
		tng.setXmlSuites(suites);
		tng.run();				
	}

	public static void main(String[] args) {			
		new WmsAutomationRunner().runTSuite();
	}	
}
