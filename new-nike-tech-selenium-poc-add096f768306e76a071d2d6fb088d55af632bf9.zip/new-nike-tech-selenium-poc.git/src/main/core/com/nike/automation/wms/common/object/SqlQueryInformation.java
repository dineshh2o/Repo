package com.nike.automation.wms.common.object;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder = {"sqlQuery", "description"})
public class SqlQueryInformation {
	private String id;
	private String sqlQuery;
	private String description;
	
	public SqlQueryInformation(){}
	public SqlQueryInformation(String id, String sqlQuery){
		this.id = id;
		this.sqlQuery = sqlQuery;
		this.description = "-";
	}	
	public SqlQueryInformation(String id, String sqlQuery, String description){
		this.id = id;
		this.sqlQuery = sqlQuery;
		this.description = description;
	}
	public String getId() {
		return id;
	}
	@XmlAttribute(name = "id")
	public void setId(String id) {
		this.id = id;
	}
	public String getSqlQuery() {
		return sqlQuery;
	}
	@XmlElement(name = "sql")
	public void setSqlQuery(String sqlQuery) {
		this.sqlQuery = sqlQuery;
	}
	public String getDescription() {
		return description;
	}
	@XmlElement(name = "description")
	public void setDescription(String description) {
		this.description = description;
	}		
	
	public String getDetails(){
		return this.id+":"+this.sqlQuery+"["+description+"]";
	}
}
