package com.nike.automation.wms.functional.library;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import com.cognizant.framework.Status;
import com.cognizant.framework.selenium.CraftDriver;
import com.cognizant.framework.selenium.SeleniumReport;
import com.nike.automation.wms.common.page.WMSAsnShipmentPage;
import com.nike.automation.wms.common.page.WMSDOPage;
import com.nike.automation.wms.common.object.GenericWmsElement;
import com.nike.automation.wms.common.page.WMSHomePage;
import com.nike.automation.wms.common.page.WMSLoginPage;
import com.nike.automation.wms.common.page.WMSRFPage;
import com.nike.automation.wms.common.page.WMSTaskPage;
import com.nike.automation.wms.common.page.WMSWavePage;
import com.nike.automation.wms.common.util.ApplicationKeys;
import com.nike.automation.wms.common.util.BasePageFactory;
import com.nike.automation.wms.common.util.CommonUtils;
import com.nike.automation.wms.common.util.StaticXmlUpdater;
import com.nike.automation.wms.common.util.WmsCustomException;

import tech.nike.automation.common.framework.core.Selenium;
/**
 * @author Cognizant
 *
*/
public class WebComponent extends BaseComponent {
	protected SeleniumReport report;

	public WebComponent(CraftDriver driver) {
		this.driver = driver;
		this.report = driver.getReport();
		this.identifier=driver.getSessionId().toString();
	}

	public void updatePassReport(String stepName, String stepDescription) {
		report.updateTestLog(stepName, stepDescription, Status.PASS);
	}
	
	/**
	 * @author Cognizant
	 * Method to prepare the XML 
	 * Database connection settings are in Global Settings.properties
	*/
	public void preparePostXml() {
		try {
			String identifier = getParamValue("identifier");
			String dcCode = getParamValue("dcCode");
			String processType = getParamValue("processType");
			String xmlUniqueTags = getParamValue("xmlUniqueTags");
			String xmlUpdateTags = getParamValue("xmlUpdateTags");
			String sqlColumnMapping = getParamValue("sqlColumnMapping");
			
			String xmlSharedDrivePath = (getParamValue(dcCode + "-" + processType + "-XML-FilePath")).replaceAll("/",
					"\\\\");
			String xmlLocalTempPath = (getParamValue("Local-XML-Storage")).replaceAll("/", "\\\\");

			// The procedure to get SQL details for test cases
			String tcID = getParamValue("identifier");

			driver.getSelenium().log.logTestStep("tcID: " + tcID);

			String query1 = driver.getQueryMap().getSql(tcID, "101");
			driver.getSelenium().log.logTestStep("Query:" + query1);

			List<String> columns = Arrays.asList(sqlColumnMapping.split("\\s*,\\s*"));
			
			DatabaseComponent dbComponent = new DatabaseComponent(driver);
			ArrayList<HashMap<String, String>> resultList = dbComponent.getResultMap(query1, columns, 1);

			File source = new File(xmlSharedDrivePath + "\\" + identifier + ".xml");
			File dest = new File(xmlLocalTempPath + "\\" + identifier + ".xml");

			driver.getSelenium().log.logTestStep(xmlLocalTempPath + "\\" + identifier + ".xml");
			try {				
				CommonUtils.copyFileUsingApacheCommonsIO(source, dest);				
			} catch (Exception e) {
				String errMsg = "Not able to copy xml from:" + xmlSharedDrivePath + "\\" + identifier + ".xml";
				driver.getSelenium().log.logTestStep("Error:"+errMsg);
				report.updateTestLog("XMLCopy", errMsg, Status.FAIL);
				return;
			}

			String localXmlPath = xmlLocalTempPath + "\\" + identifier + ".xml";
			StaticXmlUpdater xmlUpdater = new StaticXmlUpdater(driver.getSelenium().log);
			xmlUpdater.updateXmlTagsWithUniqueValue(driver, xmlUniqueTags, localXmlPath);

			updateXmlData(identifier, xmlUpdateTags, resultList, columns);
			report.updateTestLog("PrepareXml", "Post XML preparation succssfull.", Status.PASS);
		} catch (Exception ex) {
			driver.getSelenium().log.logTestStep(ex);
			driver.getSelenium().log.logTestStep(ex.getMessage());
			report.updateTestLog("PrepareXml", "Problem in post XML preparation," + ex.getMessage(), Status.FAIL);
		}
	}
	
	/**
	 * @author Cognizant
	 * @Description Method to Log in to the application This method is common to all DC's
	 * @return void
	 */
	public void verifyWmsLoginProcess() {
		try {
			Selenium se = driver.getSelenium();
			Map<String, Object> params = driver.getTestcaseParams();
			String dcCode = getParamValue("dcCode");
			String environment = getParamValue(dcCode + "-WMS-URL");

			driver.get(environment);
			WMSLoginPage wmsLoginPageObject = BasePageFactory.initElements(driver, WMSLoginPage.class);
			report.updateTestLog("Initialize", "Application launch has been successful.", Status.PASS);
			se.assertion.verifyTrue("User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));
			report.updateTestLog("LOGIN", "Login successfull to WMS !", Status.PASS);
		} catch (Exception ex) {
			driver.getSelenium().log.logTestStep(ex);
			driver.getSelenium().log.logTestStep(ex.getMessage());
			report.updateTestLog("Login", "Login is Unsuccessfull," + ex.getMessage(), Status.FAIL);
		}
	}

	/**
	 * @author Cognizant
	 * @Description  Method to verify message dialog (For selenium feasibility ) 
	 * @return void
	 */
	public void verifyMessageDialog() {
		Selenium se = driver.getSelenium();
		Map<String, Object> params = driver.getTestcaseParams();
		WMSAsnShipmentPage wmsAsnShipmentObject = BasePageFactory.initElements(driver, WMSAsnShipmentPage.class);
		
		//se.assertion.verifyTrue("Open Assign ASn", wmsAsnShipmentObject.openAssignAsn(params));
		se.assertion.verifyTrue("Message Dialog", wmsAsnShipmentObject.checkMessageDioalog(params));
	}

	/**
	 * @author Cognizant
	 * @Description Method to verify Pix transaction (For selenium feasibility ) 
	 * @return void
	 */
	
	public void verifyPixTransaction() {
		Selenium se = driver.getSelenium();
		Map<String, Object> params = driver.getTestcaseParams();

		WMSHomePage wmsHomePageObject = BasePageFactory.initElements(driver, WMSHomePage.class);
		se.assertion.verifyTrue("PIX Transation", wmsHomePageObject.pixTransaction(params));

	}
	
	/**
	 * @author Cognizant
	 * @Description Method to post the XML for DO , ASN etc creation 
	 * @return void
	 */
	
	public void verifyPostXml() {
		try {
			Selenium se = driver.getSelenium();
			Map<String, Object> params = driver.getTestcaseParams();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			WMSHomePage wmsHomePageObject = BasePageFactory.initElements(driver, WMSHomePage.class);
			se.log.logTestStep("Start - Test verifyPostXml");
			// verify post xml is successful
			se.assertion.verifyTrue("post xml", wmsHomePageObject.verifyPostXML(params));

			se.log.logTestStep("End - Test verifyPostXMLData");
			report.updateTestLog("POST", "XML Posted Successfully", Status.PASS);
		} catch (Exception ex) {
			driver.getSelenium().log.logTestStep(ex);
			driver.getSelenium().log.logTestStep(ex.getMessage());
			report.updateTestLog("Post XML", "Post XML is Unsuccessfull," + ex.getMessage(), Status.FAIL);
		}
	}

	/**
	 * @author Cognizant
	 * @Description Method to verify Assigned ASN Data
	 * @return void
	 */
	public void verifyAssignAsnData() {
		Selenium se = driver.getSelenium();
		Map<String, Object> params = driver.getTestcaseParams();
		String environment = (String) params.get("environment");

		driver.get(environment);
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		WMSLoginPage wmsLoginPageObject = BasePageFactory.initElements(driver, WMSLoginPage.class);
		WMSHomePage wmsHomePageObject = BasePageFactory.initElements(driver, WMSHomePage.class);
		WMSAsnShipmentPage wmsAsnShipmentObject = BasePageFactory.initElements(driver, WMSAsnShipmentPage.class);
		se.log.logTestStep("Start - verifyAssignAsnData");

		se.assertion.verifyTrue("User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));
		se.assertion.verifyTrue("Open Assign", wmsAsnShipmentObject.openAssignAsn(params));
		se.assertion.verifyTrue("Assign Asn", wmsHomePageObject.verifyAssignAsn(params));
	}

	/**
	 * @author Cognizant
	 * @Description Method to verify Shipment ASN 
	 * @return void
	 */
	public void verifyShipmentAsn() {
		try {		
			Selenium se = driver.getSelenium();
			Map<String, Object> params = driver.getTestcaseParams();
			WMSAsnShipmentPage wmsAsnShipmentObject = BasePageFactory.initElements(driver, WMSAsnShipmentPage.class);
			se.log.logTestStep("Start - verifyShipmentAsn");
	
			se.assertion.verifyTrue("Open Assign ASn", wmsAsnShipmentObject.openAssignAsn(params));
			se.assertion.verifyTrue("Shipment Asn", wmsAsnShipmentObject.assignShipmentAsn(params));
			report.updateTestLog("ASN Shipment", "Asn has been successfully assigned to new shipment", Status.PASS);
			
			se.assertion.verifyTrue("Shipment Status", wmsAsnShipmentObject.verifyShipmentStatus(params));
			report.updateTestLog("Shipment Status", "Shipment status has been verified.", Status.PASS);	
			se.assertion.verifyTrue("Initiate Shipment ", wmsAsnShipmentObject.initiateShipment(params));
			report.updateTestLog("Initiate Shipment", "Initiate Shipment.", Status.PASS);	
						
		} catch (Exception ex) {
			driver.getSelenium().log.logTestStep(ex);
			driver.getSelenium().log.logTestStep(ex.getMessage());
			report.updateTestLog("ASN Shipment", "Asn has not been assigned to new shipment", Status.FAIL);
		}
	}
	public void verifyShiAsnAndLpn() {
		try{
			Selenium se = driver.getSelenium();
			String dcCode = getParamValue("dcCode");
			String environment = getParamValue(dcCode + "-WMS-URL");
			driver.get(environment);
			Map<String, Object> params = driver.getTestcaseParams();
			WMSAsnShipmentPage wmsAsnShipmentObject = BasePageFactory.initElements(driver, WMSAsnShipmentPage.class);
			WMSHomePage wmsHomePageObject = BasePageFactory.initElements(driver, WMSHomePage.class);
			report.addTestLogSubSection("Step - Naviagte to LPN page");
			
			se.assertion.verifyTrue("Search ASNs Menu", wmsHomePageObject.openSearchMenu(ApplicationKeys.APPS_MENU_ASN));
			se.assertion.verifyTrue("Get LPN", wmsAsnShipmentObject.checkLpnStatusFinal(params));
			
			report.updateTestLog("Step - ", "Check lpn status", Status.PASS);
			
		} catch (Exception ex) {
			driver.getSelenium().log.logTestStep(ex);
			driver.getSelenium().log.logTestStep(ex.getMessage());
			report.updateTestLog("Release Task - ", "Auto Release Task", Status.FAIL);
		}
	}

	/**
	 * @author Cognizant
	 * @Description Method to verify RF Screen operations
	 * @return void
	 */
	public void verifyRfScreenOperation() {
		Selenium se = driver.getSelenium();
		Map<String, Object> params = driver.getTestcaseParams();
		String rfsceenUrl = (String) params.get("rfsceen");
		driver.get(rfsceenUrl);
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		WMSLoginPage wmsLoginPageObject = BasePageFactory.initElements(driver, WMSLoginPage.class);
		@SuppressWarnings("unused")
		WMSHomePage wmsHomePageObject = BasePageFactory.initElements(driver, WMSHomePage.class);
		se.log.logTestStep("Start - Test verifyAssignAsnData");

		se.assertion.verifyTrue("User Logged into RF", wmsLoginPageObject.verifyWMSRfScreenLogin(params));
		se.assertion.verifyTrue("RF Action", wmsLoginPageObject.verifyWMSRfAction(params));
		se.log.logTestStep("End - Tes");
	}
	/**
	 * @author Cognizant
	 * @Description Method to verify DO Creation
	 * @return void
	 */
	public void verifyDOCreation() {
		try {
			driver.getSelenium().log.logTestStep("Starting- verifyDOCreation");
			Selenium se = driver.getSelenium();
			Map<String, Object> params = driver.getTestcaseParams();
			WMSDOPage wmsDOPageObject = BasePageFactory.initElements(driver, WMSDOPage.class);
			WMSHomePage wmsHomePageObject = BasePageFactory.initElements(driver, WMSHomePage.class);
			se.assertion.verifyTrue("Search DO", wmsHomePageObject.openSearchMenu(ApplicationKeys.APPS_MENU_SEARCH_DISTRIBUTION));
			se.assertion.verifyTrue("Verifying DO status", wmsDOPageObject.verifyDOStatus(params));
			report.updateTestLog("DO Creation", "DO created and Released Succesfully", Status.PASS);
		} catch (Exception ex) {
			driver.getSelenium().log.logTestStep(ex.getMessage());
			report.updateTestLog("DO Creation", "DO Creation Failed", Status.FAIL);
		}

	}

	/**
	 * @author Cognizant
	 * @Description Method to verify Routing wave 
	 * @return void
	 */
	public void runRoutingWave() {
		try {
			driver.getSelenium().log.logTestStep("Starting - verifyRoutingWave");
			Selenium se = driver.getSelenium();
			Map<String, Object> params = driver.getTestcaseParams();
			WMSHomePage wmsHomePageObject = BasePageFactory.initElements(driver, WMSHomePage.class);
			WMSWavePage wmsWavePageObject = BasePageFactory.initElements(driver, WMSWavePage.class);
			WMSDOPage wmsDOPageObject = BasePageFactory.initElements(driver, WMSDOPage.class);
			se.assertion.verifyTrue("search wave", wmsHomePageObject.openSearchMenu(ApplicationKeys.APPS_MENU_RUN_WAVES));
			se.assertion.verifyTrue("Routing wave template Selection", wmsWavePageObject.selectWaveTemplate(params, "routing"));
			report.updateTestLog("Routing wave template Selection", " Routing wave template selected Succesfully", Status.PASS);
			se.assertion.verifyTrue("Routing wave rule selection", wmsWavePageObject.selectRule(params, "routing"));
			report.updateTestLog("Rule Selection", " Proper rule selected", Status.PASS);
			se.assertion.verifyTrue("Search DO", wmsHomePageObject.openSearchMenu(ApplicationKeys.APPS_MENU_SEARCH_DISTRIBUTION));
			se.assertion.verifyTrue("Get the Major DO", wmsDOPageObject.getMajorDO(params));
			report.updateTestLog("Routing Wave", "Routing wave is Successfull", Status.PASS);
		} catch (Exception ex) {
			driver.getSelenium().log.logTestStep(ex);
			driver.getSelenium().log.logTestStep(ex.getMessage());
			report.updateTestLog("Routing Wave", "Routing wave is UnSuccessfull," + ex.getMessage(), Status.FAIL);
		}
	}

	/**
	 * @author Cognizant
	 * @Description Method to verify Picking wave 
	 * @return void
	 */
	public void runPickingWave() {
		try {
			Selenium se = driver.getSelenium();
			Map<String, Object> params = driver.getTestcaseParams();
			WMSHomePage wmsHomePageObject = BasePageFactory.initElements(driver, WMSHomePage.class);
			WMSWavePage wmsWavePageObject = BasePageFactory.initElements(driver, WMSWavePage.class);
			se.assertion.verifyTrue("Search Run Wave", wmsHomePageObject.openSearchMenu(ApplicationKeys.APPS_MENU_RUN_WAVES));
			se.assertion.verifyTrue("Picking wave template", wmsWavePageObject.selectWaveTemplate(params, "pick"));
			se.assertion.verifyTrue("Picking wave rule selection", wmsWavePageObject.selectRulePicking(params));
			report.updateTestLog("Picking Wave ", "Picking wave is Successfull", Status.PASS);
		} catch (Exception ex) {
			driver.getSelenium().log.logTestStep(ex);
			driver.getSelenium().log.logTestStep(ex.getMessage());
			report.updateTestLog("Picking Wave  ", "Picking wave is UnSuccessfull", Status.FAIL);
		}

	}
	
	/**
	 * @author Cognizant
	 * @Description Method to verify Picking wave 
	 * @return void
	 */
	public void verifyDoAfterPickingWave() {
		try {
			Selenium se = driver.getSelenium();
			Map<String, Object> params = driver.getTestcaseParams();
			WMSHomePage wmsHomePageObject = BasePageFactory.initElements(driver, WMSHomePage.class);
			WMSWavePage wmsWavePageObject = BasePageFactory.initElements(driver, WMSWavePage.class);
			WMSDOPage wmsDOPageObject = BasePageFactory.initElements(driver, WMSDOPage.class);
			se.assertion.verifyTrue("Search DO", wmsHomePageObject.openSearchMenu(ApplicationKeys.APPS_MENU_SEARCH_DISTRIBUTION));
			se.assertion.verifyTrue("Verifying DO status", wmsDOPageObject.viewAndVerifyDOStatusAfterPick(params));
			se.assertion.verifyTrue("Search with wave no",
					wmsHomePageObject.openSearchMenuSpecific(ApplicationKeys.APPS_MENU_WAVES));
			se.assertion.verifyTrue("task Generation", wmsWavePageObject.validateGeneratedTask(params));
			report.updateTestLog("Picking Wave", "Picking wave is Successfull,", Status.PASS);
		} catch (Exception ex) {
			driver.getSelenium().log.logTestStep(ex);
			driver.getSelenium().log.logTestStep(ex.getMessage());
			report.updateTestLog("Picking Wave", "Verification of DO status failed after Picking wave" , Status.FAIL);
		}

	}
	
	/**
	 * @author Cognizant
	 * @Description Method to verify Picking wave 
	 * @return void
	 */
	public void verifyTaskAndItemLocation() {
		try {
			Selenium se = driver.getSelenium();
			Map<String, Object> params = driver.getTestcaseParams();
			WMSHomePage wmsHomePageObject = BasePageFactory.initElements(driver, WMSHomePage.class);
			WMSWavePage wmsWavePageObject = BasePageFactory.initElements(driver, WMSWavePage.class);
			se.assertion.verifyTrue("Search with wave no",wmsHomePageObject.openSearchMenuSpecific(ApplicationKeys.APPS_MENU_WAVES));
			se.assertion.verifyTrue("task Generation", wmsWavePageObject.validateGeneratedTask(params));
			se.assertion.verifyTrue("Destination location validation",wmsWavePageObject.validateDestinationLocation(params));			
			report.updateTestLog("Picking Wave", "Picking wave is Successfull,", Status.PASS);
		} catch (Exception ex) {
			driver.getSelenium().log.logTestStep(ex);
			driver.getSelenium().log.logTestStep(ex.getMessage());
			report.updateTestLog("Picking Wave", "Picking wave is UnSuccessfull," + ex.getMessage(), Status.FAIL);
		}

	}

	/**
	 * @author Cognizant
	 * @Description Method to store Application data
	 * @return void
	 */
	public void storeApplicationData() {
		// Read the Transit object for the transition to dependent test cases
		driver.getDataReserver(identifier).setAppsData(ApplicationKeys.TRANSIT_WAVE_NUMBER, "6534113");
		driver.getDataReserver(identifier).getTaskIds().getElement().add(new GenericWmsElement(ApplicationKeys.TAG_NAME_TASK, "101", "Task-101"));
		driver.getDataReserver(identifier).getTaskIds().getElement().add(new GenericWmsElement(ApplicationKeys.TAG_NAME_TASK, "102", "Task-102"));
		driver.getDataReserver(identifier).getAsnIds().getElement().add(new GenericWmsElement(ApplicationKeys.TAG_NAME_ASN, "2001", "3"));
	}
	/**
	 * @author Cognizant
	 * @Description Method to read Application data
	 * @return void
	 */
	public void readApplicationData() {
		// Read the Transit object for the transition to dependent test cases
		String waveNumber = driver.getDataReserver(identifier).getAppsData(ApplicationKeys.TRANSIT_WAVE_NUMBER);
		driver.getSelenium().log.logTestStep("WaveNumber" + waveNumber);

	}
	/**
	 * @author Cognizant
	 * @Description Method to sign out from the application
	 * @return void
	 */
	public void signOut(){
		 Selenium se = driver.getSelenium();
		 WMSHomePage wmsHomePageObject = BasePageFactory.initElements(driver, WMSHomePage.class);
	     se.log.logTestStep("Start - Test signOut");
		 se.assertion.verifyTrue("User clicked on sign-out", wmsHomePageObject.verifyAndClickSignOut());
	}
	public void verifyTaskBeforeRF()
	{
		try{
			Selenium se = driver.getSelenium();
			Map<String, Object> params = driver.getTestcaseParams();
			WMSHomePage wmsHomePageObject = BasePageFactory.initElements(driver, WMSHomePage.class);
			WMSTaskPage wmsTaskPage = BasePageFactory.initElements(driver, WMSTaskPage.class);
			se.assertion.verifyTrue("search task menu", wmsHomePageObject.openSearchMenuSpecific(ApplicationKeys.APPS_MENU_TASK));
			se.assertion.verifyTrue("verify task", wmsTaskPage.verifyTask(params));
		}catch(Exception ex){
			driver.getSelenium().log.logTestStep(ex);
			driver.getSelenium().log.logTestStep(ex.getMessage());
			report.updateTestLog("Task Page ", "Task verification  is UnSuccessfull", Status.FAIL);
		}
	
	}
	/**
	 * @author Cognizant
	 * @Description Method to verify all the RF screen operations
	 * @return void
	 */
	public void verifyRFTask() {
		try{
		Selenium se = driver.getSelenium();
		Map<String, Object> params = driver.getTestcaseParams();
		WMSHomePage wmsHomePageObject = BasePageFactory.initElements(driver, WMSHomePage.class);
		WMSRFPage wmsRFPage = BasePageFactory.initElements(driver, WMSRFPage.class);
		reserveSlocFromDb();
		se.assertion.verifyTrue("Search RF Menu", wmsHomePageObject.openSearchMenu(ApplicationKeys.APPS_MENU_RF_SCREEN));
		se.assertion.verifyTrue("User Logged into RF", wmsRFPage.verifyWMSRfScreenLogin(params));
		se.assertion.verifyTrue("RF Action", wmsRFPage.verifyWMSRfAction(params));

		report.updateTestLog("RF Screen", "Rf Screen operation is done", Status.PASS);
		}catch(Exception ex)
		{
			driver.getSelenium().log.logTestStep(ex);
			driver.getSelenium().log.logTestStep(ex.getMessage());
			report.updateTestLog("RF Screen ", "RF Screen operation is UnSuccessfull", Status.FAIL);
		}
	}
	public void verifyPickShort()
	{
		try{
		Selenium se = driver.getSelenium();
		String dcCode = getParamValue("dcCode");
		String environment = getParamValue(dcCode + "-WMS-URL");
		driver.get(environment);
		Map<String, Object> params = driver.getTestcaseParams();
		WMSHomePage wmsHomePageObject = BasePageFactory.initElements(driver, WMSHomePage.class);
		WMSTaskPage wmsTaskPage = BasePageFactory.initElements(driver, WMSTaskPage.class);
		se.assertion.verifyTrue("search Picking short menu", wmsHomePageObject.openSearchMenu(ApplicationKeys.APPS_MENU_PICKING_SHORT));
		
		se.assertion.verifyTrue("verify Picking short", wmsTaskPage.verifyPickingShort(params));
		se.assertion.verifyTrue("search task menu", wmsHomePageObject.openSearchMenuSpecific(ApplicationKeys.APPS_MENU_TASK));
		se.assertion.verifyTrue("verify Picking short", wmsTaskPage.verifyLPN(params));
		se.assertion.verifyTrue("search Picking short menu", wmsHomePageObject.openSearchMenu(ApplicationKeys.APPS_MENU_PICKING_SHORT));
		se.assertion.verifyTrue("verify Picking short", wmsTaskPage.verifyPickingShortFinal(params));
		
		
		}catch(Exception ex)
		{
			driver.getSelenium().log.logTestStep(ex);
			driver.getSelenium().log.logTestStep(ex.getMessage());
			report.updateTestLog("Picking Short ", "Picking Short operation is UnSuccessfull" , Status.FAIL);
		}
	}

	public void reserveSlocFromDb() throws WmsCustomException{
		Selenium se = driver.getSelenium();
		try
		{
			String tcID = getParamValue("identifier");
			String sqlColumnMapping = getParamValue("sqlColumnMapping");
			String query1 = driver.getQueryMap().getSql(tcID, "101");
			
			driver.getSelenium().log.logTestStep("Query" + query1);
			List<String> columns = Arrays.asList(sqlColumnMapping.split("\\s*,\\s*"));
			se.log.logTestStep("Column-"+columns.get(0));
			DatabaseComponent dbComponent = new DatabaseComponent(driver);		
			ArrayList<HashMap<String, String>> resultList = dbComponent.getResultMap(query1, columns, 1);	
			driver.getDataReserver(identifier).setAppsData(ApplicationKeys.DB_QUERY_RESULT_SLOC, resultList.get(0).get(columns.get(0)));
			se.log.logTestStep("Column-"+driver.getDataReserver(identifier).getAppsData(ApplicationKeys.DB_QUERY_RESULT_SLOC));
		}catch(Exception e){
			se.log.logTestStep(e);
			throw new WmsCustomException(e); 
		}		
	}
	
	public boolean verifyReleaseTaskMsgFromDB(Map<String, Object> params) throws WmsCustomException {
		Selenium se = driver.getSelenium();
		try
			{
			se.log.logTestStep("Identifier" + identifier);
			String taskId=driver.getDataReserver(identifier).getAppsData(ApplicationKeys.TRANSIT_TASKID).toString();
			report.addTestLogSubSection("Step - Verify task release message for the task -" + taskId +" in DB");
			String tcID = getParamValue("identifier");
			String query=driver.getQueryMap().getSql(tcID, "101");
			query=query.replace("[TASK_ID]", taskId);
			report.updateTestLog("Verify task release message", "Query -" + query,Status.DONE);
			List<String> columns = Arrays.asList("DATA");
			se.log.logTestStep("Column:"+columns.get(0));
			DatabaseComponent dbComponent = new DatabaseComponent(driver);		
			ArrayList<HashMap<String, String>> resultList = dbComponent.getResultMap(query, columns, 1);
			if(!resultList.isEmpty()){
				String actualMsg= resultList.get(0).get(columns.get(0));
				se.log.logTestStep("Column: "+actualMsg);
				report.updateTestLog("Verify task release message", "Message in DB - " +actualMsg,Status.PASS);
			}else{
				report.updateTestLog("Verify task release message", "Message not found in DB - " ,Status.FAIL);
			}
		}catch(Exception e){
			se.log.logTestStep(e);
			throw new WmsCustomException(e); 
		}
		
		
		
		return true;
	}

	public void releaseTask() {
		try {
			Selenium se = driver.getSelenium();
			Map<String, Object> params = driver.getTestcaseParams();
			WMSHomePage wmsHomePageObject = BasePageFactory.initElements(driver, WMSHomePage.class);
			WMSWavePage wmsWavePageObject = BasePageFactory.initElements(driver, WMSWavePage.class);
			report.addTestLogSubSection("Step - Navigate to Task Page");
			se.assertion.verifyTrue("Search with wave no",wmsHomePageObject.openSearchMenuSpecific(ApplicationKeys.APPS_MENU_TASK));
			se.assertion.verifyTrue("Get Container ID", wmsWavePageObject.getContainerID(params));
			se.assertion.verifyTrue("Search and relaese task", wmsWavePageObject.searchAndReleaseTask(params));
			se.assertion.verifyTrue("Verify task release message from DB", verifyReleaseTaskMsgFromDB(params));			
		} catch (Exception ex) {
			driver.getSelenium().log.logTestStep(ex);
			driver.getSelenium().log.logTestStep(ex.getMessage());
			report.updateTestLog("Release Task - ", "Auto Release Task", Status.FAIL);
		}		
	}
	
	public void assembleTask() {
		try {
			Selenium se = driver.getSelenium();
			Map<String, Object> params = driver.getTestcaseParams();
			WMSWavePage wmsWavePageObject = BasePageFactory.initElements(driver, WMSWavePage.class);
			report.addTestLogSubSection("Step - Send PULL message from JMETER to port 20207");
			se.assertion.verifyTrue("Task status ",sendJmeterMessage(ApplicationKeys.JMETER_PULL_MSG, "20207",se.webDriver));
			report.updateTestLog("Send Jmeter message", "Send Jmeter message", Status.PASS);			
			report.addTestLogSubSection("Step - Verify the task status");
			se.assertion.verifyTrue("Task status ", wmsWavePageObject.validateTaskStatus(ApplicationKeys.TASK_STATUS_ASSEMBLED));
			report.addTestLogSubSection("Send DIVERT message to Restock Spur on port 20203");
			se.assertion.verifyTrue("Task status ",sendJmeterMessage(ApplicationKeys.JMETER_DIVERT_MSG, "20203", se.webDriver));
			report.updateTestLog("Send Jmeter message", "Send Jmeter message", Status.PASS);
			report.addTestLogSubSection("Check current location of the iLPN");
			se.assertion.verifyTrue("Verify iLPN current location", wmsWavePageObject.verifyIlpnCurrentLocation(params));
			
		} catch (Exception ex) {
			driver.getSelenium().log.logTestStep(ex);
			driver.getSelenium().log.logTestStep(ex.getMessage());
			report.updateTestLog("Release Task - ", "Assemble Release Task", Status.FAIL);
		}
		
	}	

	public void asnMannualRecv() {
		try{
			Selenium se = driver.getSelenium();
			Map<String, Object> params = driver.getTestcaseParams();
			WMSAsnShipmentPage wmsAsnShipmentObject = BasePageFactory.initElements(driver, WMSAsnShipmentPage.class);
			WMSHomePage wmsHomePageObject = BasePageFactory.initElements(driver, WMSHomePage.class);
			WMSRFPage wmsRFPage=BasePageFactory.initElements(driver, WMSRFPage.class);
			
			se.assertion.verifyTrue("Search RF Menu", wmsHomePageObject.openSearchMenu(ApplicationKeys.APPS_MENU_ASN));
			se.assertion.verifyTrue("Get LPN", wmsAsnShipmentObject.checkLpnStatus(params));
			se.assertion.verifyTrue("Search RF Menu", wmsHomePageObject.openSearchMenu(ApplicationKeys.APPS_MENU_RF_SCREEN));
			se.assertion.verifyTrue("User Logged into RF", wmsRFPage.verifyWMSRfScreenLogin(params));
			se.assertion.verifyTrue("RF Action", wmsRFPage.verifyWMSRfAction(params));
			
					
		} catch (Exception ex) {
			driver.getSelenium().log.logTestStep(ex);
			driver.getSelenium().log.logTestStep(ex.getMessage());
			report.updateTestLog("Mannual Recieve - ", "", Status.FAIL);
		}		
	}

	public void makeReplenCart() {
		try {
			Selenium se = driver.getSelenium();
			Map<String, Object> params = driver.getTestcaseParams();
			WMSRFPage wmsRFPage = BasePageFactory.initElements(driver, WMSRFPage.class);
			report.addTestLogSubSection("Step - Naviagte to RF Screen");			
			se.assertion.verifyTrue("Search RF Menu", wmsRFPage.openSearchMenu(ApplicationKeys.APPS_MENU_RF_SCREEN));
			se.assertion.verifyTrue("User Logged into RF", wmsRFPage.verifyWMSRfScreenLogin(params));
			se.assertion.verifyTrue("RF Action", wmsRFPage.verifyWMSRfAction(params));	
			
		}
		catch (Exception ex) {
			driver.getSelenium().log.logTestStep(ex);
			driver.getSelenium().log.logTestStep(ex.getMessage());
			report.updateTestLog("Make replen cart - ", "Make repln cart", Status.FAIL);
		}	
	}

	public void verifyReplenishment() {
		try {
			Selenium se = driver.getSelenium();
			Map<String, Object> params = driver.getTestcaseParams();
			WMSWavePage wmsWavePageObject = BasePageFactory.initElements(driver, WMSWavePage.class);
			se.assertion.verifyTrue("Navigate back from RF screen ", navigateBackFromRFScreen());
			se.assertion.verifyTrue("Search RF Menu", wmsWavePageObject.openSearchMenuSpecific(ApplicationKeys.APPS_MENU_TASK));
			se.assertion.verifyTrue("Task status ", wmsWavePageObject.validateTaskStatus(ApplicationKeys.TASK_STATUS_COMPLETE));
			se.assertion.verifyTrue("Verify iLPN current location", wmsWavePageObject.verifyIlpnCurrentLocation(params));
			report.addTestLogSubSection("Step - verify Task Status");
			
		}
		catch (Exception ex) {
			driver.getSelenium().log.logTestStep(ex);
			driver.getSelenium().log.logTestStep(ex.getMessage());
			report.updateTestLog("Verify Replenishment", "Verify Replenishment", Status.FAIL);
		}
		
	}
	
	public boolean navigateBackFromRFScreen(){
		String dcCode = getParamValue("dcCode");
		String environment = getParamValue(dcCode + "-WMS-URL");
		driver.get(environment);
		return true;
	}
}
