package com.nike.automation.wms.common.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Created by PSibb1 on 6/25/2016.
 */
public class WMSTemplateRulePage extends BasePage {
    //locators
    public By btnAddRule = By.cssSelector("[id$='lview:ruleHdrAddButton']");
    public By btnDeleteRule = By.cssSelector("[id$='lview:ruleHdrDeleteButton']");
    public By lstRuleType = By.id("dataForm:rlType");
    public By btnSaveConfiguration = By.cssSelector("[id*='SaveConfiguration'][type='button']");
    public By btnSubmit = By.cssSelector("[id*='SubmitWave'][type='button']");

    //task criteria
    public By lnkTaskCriteria = By.cssSelector("[class='tab'][title='Task Criteria'] a");
    public By btnAddTaskCriteria = By.id("dataForm:listViewbc:capsAddButton");
    public By lstTaskCritDesc = By.cssSelector("[style^='visibility'][id$='crit_nbr']");
    public By chkTask = By.cssSelector("[id$='dataTableCrit'][type='checkbox'][style^='visibility']");
    public By btnDeleteTask = By.id("dataForm:listViewbc:capsDeleteButton");

    // parameters
    public By lnkRuleParameters = By.name("parameterTab");
    public By txtRuleName = By.id("dataForm:ruleNameInputBox");
    public By txtRulePriority = By.id("dataForm:rlPriorty");

    //definition
    public By lnkRules = By.cssSelector("#detailTab_lnk");
    public By lnkParameters = By.id("parameterTab_lnk");
    public By chkRules = By.cssSelector("[id*='checkAll_c_dataForm:lview:dataTable']");
    public By tblRuleName = By.cssSelector("[id*=':ruleNameText']");
    public By lnkDefinition = By.id("definitionTab_lnk");
    public By txtAddRuleParenthesisStart = By.cssSelector("[id*='dataForm:ruleSelDtlDataTable_body_tr']>[id*='dataForm:ruleSelDtlDataTable:newRow'][id*=':ruleSelDtlOpenParan']");
    public By lstAddRuleColumn = By.cssSelector("[id*='dataForm:ruleSelDtlDataTable_body_tr']>[id*='dataForm:ruleSelDtlDataTable:newRow'][id*=':ruleSelDtlColumnList']");
    public By lstAddRuleOperator = By.cssSelector("[id*='dataForm:ruleSelDtlDataTable_body_tr']>[id*='dataForm:ruleSelDtlDataTable:newRow'][id*=':ruleSelDtlOperatorList']");
    public By txtAddRuleComparisonvalue = By.cssSelector("[id*='dataForm:ruleSelDtlDataTable_body_tr']>[id*='dataForm:ruleSelDtlDataTable:newRow'][id*=':ruleSelDtlRuleCmparValue']");
    public By txtAddRuleParenthesisEnd = By.cssSelector("[id*='dataForm:ruleSelDtlDataTable_body_tr']>[id*='dataForm:ruleSelDtlDataTable:newRow'][id*=':ruleSelDtlCloseParan']");
    public By lstAddRuleAndOr = By.cssSelector("[id*='dataForm:ruleSelDtlDataTable_body_tr']>[id*='dataForm:ruleSelDtlDataTable:newRow'][id*=':ruleSelDtlAndOrOrList']");
    public By btnaddSequence = By.id("dataForm:ruleSeqAddButton");
    public By lstAddSequenceColumn = By.cssSelector("[id*='dataForm:ruleSeqDtlDataTable:newRow'][id*='ruleSortDtlColumnList']");
    public By lstAddSequenceTitle = By.cssSelector("[id*='dataForm:ruleSeqDtlDataTable:newRow'][id*='ruleSortDtlSequenceList']");
    public By chkAddSequenceBreakList = By.cssSelector("[id*='dataForm:ruleSeqDtlDataTable:newRow'][id*='ruleSortDtlBreakList']");
    public By txtAddSequenceBreakCapacity = By.cssSelector("[id*='dataForm:ruleSeqDtlDataTable:newRow'][id*='ruleSortDtlBreakCapcty']");

    //capacities
    public By chkCapacities = By.cssSelector("[id$='dataTableCaps'][type='checkbox'][style^='visibility']");
    public By lnkCapacities = By.cssSelector("[class*='tab_span -tbs_tbgrt']>[id*='TaskNCapsTab_2_lnk']");
    public By chkDiscretePicking = By.id("dataForm:discretePickingValue");
    public By lstFootwearSorters = By.id("dataForm:FootwearSortersList");
    public By lstApparelSorters = By.id("dataForm:ApparelSortersList");
    public By lstMixedSkuSorters = By.id("dataForm:MixedSkuSortersList");
    public By txtMaxPickZones = By.id("dataForm:custId");
    public By tblCapacities = By.cssSelector("[id='dataForm:listViewb:dataTableCaps_body']>tbody>tr");
    public By tblNoDataFoundCapacities = By.id("dataForm:listViewb:dataTableCaps:nodataRow");
    public By lstCapacityType = By.cssSelector("[id*='dataForm:listViewb:dataTableCaps:newRow_'][id$=':cap_type']");
    public By txtVasHrs = By.cssSelector("[id*='dataForm:listViewb:dataTableCaps:newRow_'][id$=':sams_custom']");
    public By txtRPUnits = By.cssSelector("[id*='dataForm:listViewb:dataTableCaps:newRow_'][id$=':units_custom']");
    public By txtSUnitDO = By.cssSelector("[id*='dataForm:listViewb:dataTableCaps:newRow_'][id$=':picks_custom']");
    public By txtRPoLPN = By.cssSelector("[id*='dataForm:listViewb:dataTableCaps:newRow_'][id$=':lines_custom']");
    public By txtFCoLPN = By.cssSelector("[id*='dataForm:listViewb:dataTableCaps:newRow_'][id$=':dollars_custom']");
    public By txtTotaloLPN = By.cssSelector("[id*='dataForm:listViewb:dataTableCaps:newRow_'][id$=':cartons_custom']");
    public By btnAddCapacities = By.id("dataForm:listViewb:capsAddButton");
    public By btnDeleteCapacities = By.id("dataForm:listViewb:ruleHdrDeleteButton");
    public By chkCapacityName = By.cssSelector("[id*='_dataForm:listViewb:dataTableCaps']");
    public By btnDeleteCapacity = By.cssSelector("[id*='dataForm:listViewb:ruleHdrDeleteButton']");
    public By strtemplateCountCheck = By.cssSelector(".pagerNoWrap:nth-child(2)");
    public By btnNextRulePage = By.cssSelector("[class*='paginationCtrlCls'][id*='pager:next']");
    public By txtExistingRuleName = By.cssSelector("[id*='dataForm:ruleNameInputBox']");

    public By txtRuleDescription = By.cssSelector("[id*='dataForm:ruleDescInputBox']");
    public By txtRuleMaxOrders = By.cssSelector("[id*='dataForm:immxOrds']");
    public By txtRuleMaxOrderLines = By.cssSelector("[id*='dataForm:immxOrdLines']");
    public By txtMaxUnits = By.cssSelector("[id*='dataForm:mxUnits']");

    // definition
    public By btnAddRuleDefinition = By.id("dataForm:ruleSelAddButton");
    public By rdoDefinition = By.cssSelector("[style^='visibility'] [id$='undefined']");
    public By lstColumn = By.cssSelector("[id$='ruleSelDtlColumnList'][style^='visibility']");
    public By btnDeleteDefinition = By.id("dataForm:ruleSelDeleteButton");

    /**
     * Method to count the number of definition rows/sequence rows
     *
     * @param rowName
     * @param testdata
     * @return int
     */
    public static int getRowCount(String rowName, Map<String, Object> testdata) {
        int count = 1;
        try {
            while (true) {
                if (testdata.get(rowName + Integer.toString(count)).equals(""))
                    break;
                if (!testdata.get(rowName + Integer.toString(count)).equals(""))
                    count++;
            }
        } catch (Exception e) {
        }
        return count - 1;
    }

    /**
     * method to add a task criteria and save configuration
     *
     * @param testdata
     * @return
     */
    public boolean addTaskCriteria(Map<String, Object> testdata) {
        String strTaskCriteria = "";
        boolean flag = true;
        boolean result = true;
        try {
            strTaskCriteria = (String) testdata.get("taskcriteria");
        } catch (Exception e) {
            flag = false;
        }
        if (flag && strTaskCriteria != null) {
            //wait for the page load
            //navigate to task criteria
            se.element.requireIsDisplayed("task criteria button", lnkTaskCriteria);
            //verify if the task criteria button was clickable
            result &= se.element.waitForElementToBeClickable(lnkTaskCriteria);
            //click on the task criteria button
            se.element.clickElement(lnkTaskCriteria);
            //click on the add task criteria
            se.element.requireIsDisplayed("add task criteria button", btnAddTaskCriteria);
            //verify if the aa task criteria button was clickable
            result &= se.element.waitForElementToBeClickable(btnAddTaskCriteria);
            //click on the add task criteria button
            se.element.clickElement(btnAddTaskCriteria);
            //wait for the page load to complete
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            se.webDriver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
            //verify if the task criteria drop down was visible
            se.element.requireIsDisplayed("task criteria dropdown", lstTaskCritDesc);
            //verify if the task criteria dropdown was clickable
            result &= se.element.waitForElementToBeClickable(lstTaskCritDesc);
            //verify if the user entered value was correctly selected
            result &= verifySelectedItemCorrectlyDisplayed(lstTaskCritDesc, strTaskCriteria);
            //verify if the save the task criteria button was visible
            se.element.requireIsDisplayed("save configuration button", btnSaveConfiguration);
            //verify if the task criteria button was clickable
            result &= se.element.waitForElementToBeClickable(btnSaveConfiguration);
            //click on the save configuration button
            se.element.clickElement(btnSaveConfiguration);
            //wait for the page load to complete
            se.webDriver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        }
        return result;
    }

    /**
     * method to delete an existing task criteria by criteria description
     *
     * @param strTaskCriteria
     * @return
     */
    public boolean deleteTaskCriteria(String strTaskCriteria) {
        boolean result = true;
        List<WebElement> weAllTasks = se.element.getElements(lstTaskCritDesc);
        List<WebElement> weAllTaskChks = se.element.getElements(chkTask);
        for (int i = 0; i <= weAllTasks.size(); i++) {
            String strDispTask = weAllTaskChks.get(i).getAttribute("value").trim();
            if (strDispTask == strTaskCriteria) {
                weAllTaskChks.get(i).click();
                //verify if the delete button was clickable
                result &= se.element.waitForElementToBeClickable(btnDeleteTask);
                //click on the delete task button
                se.element.clickElement(btnDeleteTask);
                //wait for the page load to complete
                se.webDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
                //confirm the delete
                se.webDriver.switchTo().alert().accept();
                //return to default content
                se.element.returnToDefaultContent();
                //wait for the page to load
                se.webDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
                break;
            }
        }
        return result;
    }

    /**
     * method to select the rule type
     *
     * @param strRuleType
     * @return
     */
    public boolean selectRuleType(String strRuleType) {
        //verify if the required Rule type field was displayed
        se.element.requireIsDisplayed("Rule Type Drop Down box", lstRuleType);
        //verify if rule type drop down is clickable
        boolean result = se.element.isClickable(lstRuleType);
        //verify if user specified rule type was correctly selected
        result &= verifySelectedItemCorrectlyDisplayed(lstRuleType, strRuleType);
        return result;
    }

    /**
     * method to add the parameters to rule
     *
     * @param testdata
     * @return
     */
    public boolean addRuleParameters(Map<String, Object> testdata, String ruleName, int ruleIndex) {
        //Label for rule count
        String countLabelOld = se.element.getText(strtemplateCountCheck, 0);
        String strRuleName = ruleName;
        String strRulePriority = (String) testdata.get("R" + ruleIndex + "parameterrulepriority");
        String strRuleDescription = "NA";
        String strRuleMaxOrders = "NA";
        String strRuleMaxOrderLines = "NA";
        String strRuleMaxUnits = "NA";
        try {
            if (!testdata.get("R" + ruleIndex + "description").toString().equals("null"))
                strRuleDescription = (String) testdata.get("R" + ruleIndex + "description");
        } catch (Exception e) {
            strRuleDescription = "NA";
        }
        try {
            if (!testdata.get("R" + ruleIndex + "maxorders").toString().equals("null"))
                strRuleMaxOrders = (String) testdata.get("R" + ruleIndex + "maxorders");
        } catch (Exception e) {
            strRuleMaxOrders = "NA";
        }
        try {
            if (!testdata.get("R" + ruleIndex + "maxorderline").toString().equals("null"))
                strRuleMaxOrderLines = (String) testdata.get("R" + ruleIndex + "maxorderline");
        } catch (Exception e) {
            strRuleMaxOrderLines = "NA";
        }
        try {
            if (!testdata.get("R" + ruleIndex + "maxunits").toString().equals("null"))
                strRuleMaxUnits = (String) testdata.get("R" + ruleIndex + "maxunits");
        } catch (Exception e) {
            strRuleMaxUnits = "NA";
        }

        //verify if the Parameter tab was displayed
        se.element.requireIsDisplayed("Parameter tab", lnkParameters);
        //verify if Parameter tab is clickable
        boolean result = se.element.isClickable(lnkParameters);
        //click on the parameter tab
        se.element.clickElement(lnkParameters);
        //verify if Rule Name was displayed
        se.element.requireIsDisplayed("Rule Name field under Parameters tab", txtRuleName);
        //verify if Rule Name is clickable
        result &= se.element.isClickable(txtRuleName);
        //Click the Rulename Textbox
        se.element.clickElement(txtRuleName);
        //set the value for rulename field
        se.element.enterText(txtRuleName, strRuleName);

        if (!strRuleDescription.equals("NA")) {
            //verify if Rule Description was displayed
            se.element.requireIsDisplayed("Rule Description field under Parameters tab", txtRuleDescription);
            //verify if Rule Description is clickable
            result &= se.element.isClickable(txtRuleDescription);
            //Click the RuleDescription Textbox
            se.element.clickElement(txtRuleDescription);
            //set the value for ruleDescription field
            se.element.enterText(txtRuleDescription, strRuleDescription);
        }
        //verify if the required rule priority field was displayed
        se.element.requireIsDisplayed("Rule Priority field under the Parameters tab", txtRulePriority);
        //verify if the rule priority filed was clickable
        result &= se.element.isClickable(txtRulePriority);
        //Click the Rule-priority Textbox
        se.element.clickElement(txtRulePriority);
        //set the value for Rule-priority field
        se.element.enterText(txtRulePriority, strRulePriority);

        if (!strRuleMaxOrders.equals("NA")) {
            //verify if Rule Max Orders was displayed
            se.element.requireIsDisplayed("Rule Max Orders field under Parameters tab", txtRuleMaxOrders);
            //verify if Rule Max Orders is clickable
            result &= se.element.isClickable(txtRuleMaxOrders);
            //Click the Max Orders Textbox
            se.element.clickElement(txtRuleMaxOrders);
            //set the value for Max Orders field
            se.element.enterText(txtRuleMaxOrders, strRuleMaxOrders);
        }
        if (!strRuleMaxOrderLines.equals("NA")) {
            //verify if Rule Rule Max Order Lines was displayed
            se.element.requireIsDisplayed("Rule Rule Max Order Lines field under Parameters tab", txtRuleMaxOrderLines);
            //verify if Rule Rule Max Order Lines is clickable
            result &= se.element.isClickable(txtRuleMaxOrderLines);
            //Click the Rule Max Order Lines Textbox
            se.element.clickElement(txtRuleMaxOrderLines);
            //set the value for Rule Max Order Lines field
            se.element.enterText(txtRuleMaxOrderLines, strRuleMaxOrderLines);
        }
        if (!strRuleMaxUnits.equals("NA")) {
            //verify if Rule max Units was displayed
            se.element.requireIsDisplayed("Rule max Units field under Parameters tab", txtMaxUnits);
            //verify if Rule max Units is clickable
            result &= se.element.isClickable(txtMaxUnits);
            //Click the max Units Textbox
            se.element.clickElement(txtMaxUnits);
            //set the value for max Units field
            se.element.enterText(txtMaxUnits, strRuleMaxUnits);
        }
        //Variable stores the count of rules that is previosult created
        @SuppressWarnings("unused")
		int sizeOld = se.element.getNumberOfElements(tblRuleName);
        //verify if the save configuration button was displayed
        se.element.requireIsDisplayed("Saveconfiguration Button", btnSaveConfiguration);
        //verify if save configuration button is clickable
        result &= se.element.isClickable(btnSaveConfiguration);
        //click on the save configuration button
        se.element.clickElement(btnSaveConfiguration);
        se.element.explicitWait(3000);
        //wait while the newly creater rule has not been added in the list
        while (countLabelOld.equals(se.element.getText(strtemplateCountCheck, 0))) {
        }
        //optionButton will store the index where the newly created rule is displayed
        String ruleCountHeader = se.element.getText(strtemplateCountCheck, 0);
        String displayedCount = ruleCountHeader.substring(ruleCountHeader.indexOf("-") + 1, ruleCountHeader.indexOf("of"));
        String maximumCount = ruleCountHeader.substring(ruleCountHeader.indexOf("of") + 2, ruleCountHeader.indexOf("at"));
        int optionButton = 999;
        //check if total number of rules are less than or equal to 20
        if (displayedCount.equals(maximumCount)) {
            for (int j = 0; j < se.element.getNumberOfElements(tblRuleName); j++) {
                if (se.element.getText(tblRuleName, j).equals(strRuleName)) {
                    optionButton = j;
                    break;
                }
            }
        } else {
            boolean flag = false;
            //if the total number of rules is moe than 20
            while (!displayedCount.equals(maximumCount) && flag == false) {
                for (int j = 0; j < se.element.getNumberOfElements(tblRuleName) && flag == false; j++) {
                    if (se.element.getText(tblRuleName, j).equals(strRuleName)) {
                        optionButton = j;
                        flag = true;
                        break;
                    }
                }
                //if created rule name is not present in the present page
                if (flag == false) {
                    //verify if the next Button is displayed
                    se.element.requireIsDisplayed("Next Rule Page", btnNextRulePage);
                    //verify if the next Rule page button is clickable
                    result &= se.element.isClickable(btnNextRulePage);
                    //click on the Next Rule Page Button
                    se.element.clickElement(btnNextRulePage);
                    se.element.explicitWait(2000);
                    //wait while the rule page is navigated to next page
                    while (countLabelOld.equals(se.element.getText(strtemplateCountCheck, 0))) {
                    }
                    ruleCountHeader = se.element.getText(strtemplateCountCheck, 0);
                    displayedCount = ruleCountHeader.substring(ruleCountHeader.indexOf("-") + 1, ruleCountHeader.indexOf("of"));
                    maximumCount = ruleCountHeader.substring(ruleCountHeader.indexOf("of") + 2, ruleCountHeader.indexOf("at"));
                }
            }
            //check the last rule page
            if (flag == false) {
                for (int j = 0; j < se.element.getNumberOfElements(tblRuleName); j++) {
                    if (se.element.getText(tblRuleName, j).equals(strRuleName)) {
                        optionButton = j;
                        flag = true;
                        break;
                    }
                }
            }
        }
        //verify if the checkbox with the rule name was displayed
        se.element.requireIsDisplayed("Rule Name", chkRules);
        //verify if the label with the rule name was displayed
        se.element.requireIsDisplayed("Option Button to select created Rule", tblRuleName);
        //verify if checkbox with the Rule name is clickable
        result &= se.element.isClickable(chkRules);
        //click on the checkbox
        se.element.clickElement(chkRules, optionButton);
        se.element.explicitWait(1500);
        //wait till the rule is selected and the rule name appears on the rule name textbox
        while (!se.element.getText(tblRuleName, optionButton).equals(se.element.getValue(txtExistingRuleName))) {
            try {
                se.element.clickElement(chkRules, optionButton);
                se.element.explicitWait(1000);
            } catch (Exception e) {
            }
        }
        //verify if checkbox with the Rule name is displayed
        se.element.requireIsDisplayed("Rule Name", chkRules);
        //verify if checkbox with the Rule name is clickable
        result &= se.element.isClickable(chkRules);
        return result;
    }

    /**
     * method to add a rule to the rule definition table
     *
     * @param testdata
     * @return
     */
    public boolean addRuleDefinition(Map<String, Object> testdata, int ruleIndex) {
        //wait for the page to load
        se.element.explicitWait(3000);
        se.webDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        //verify if Definition Tab was displayed
        se.element.requireIsDisplayed("Definition Tab", lnkDefinition);
        //verify if the Definition Tab is clickable
        se.element.isClickable(lnkDefinition);
        //click on the Definition Tab
        se.element.clickElement(lnkDefinition);
        //Verify if Definition Tab was displayed
        se.element.requireIsDisplayed("Definition Tab", lnkDefinition);
        //verify if the Definition Tab is clickable
        se.element.isClickable(lnkDefinition);
        //click on the Definition Tab
        se.element.clickElement(lnkDefinition);
        //verify if Definition Tab was displayed
        se.element.requireIsDisplayed("Definition Tab", lnkDefinition);
        //verify if the Definition Tab is clickable
        boolean result = se.element.isClickable(lnkDefinition);
        //Integer that will hold the number of rule steps
        int rows = getRowCount("R" + ruleIndex + "definition", testdata);
        //verify if add button is displayed
        se.element.requireIsDisplayed("Add definition button", btnAddRuleDefinition);
        //verify if the add definition button was displayed
        result &= se.element.isClickable(btnAddRuleDefinition);
        //click on the add definition button
        se.element.clickElement(btnAddRuleDefinition);
        //wait for the page load to complete
        se.webDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        //verify if add button is displayed
        se.element.requireIsDisplayed("Add definition button", btnAddRuleDefinition);
        //verify if the add definition button was displayed
        result &= se.element.isClickable(btnAddRuleDefinition);
        for (int i = 0; i < rows; i++) {
            //wait for the page load to complete
            se.webDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
            //String stores the complete row value of a rule from xml
            String tempRowValues = testdata.get("R" + ruleIndex + "definition" + Integer.toString(i + 1)).toString();
            //Array of String which will contain all the separate column entries
            String[] rowValue = tempRowValues.split(",");
            //Temporary variable to store the cell values
            String openingParanthesis = rowValue[0];
            String column = rowValue[1];
            String operator = rowValue[2];
            String comparisonValue = rowValue[3];
            String endParanthesis = rowValue[4];
            String andOr = rowValue[5];
            //verify if Start Parenthesis Field is displayed
            se.element.requireIsDislplayed("Start parenthisis", txtAddRuleParenthesisStart, i);
            //verify if the  Start Parenthesis Field was clikable
            result &= se.element.isClickable(txtAddRuleParenthesisStart);
            //click if applicable on the txtAddRuleParenthesisStart
            if ((openingParanthesis.toLowerCase().equals("yes")) || openingParanthesis.equals("("))
                se.element.clickElement(txtAddRuleParenthesisStart, i);
            //verify if the column dropdown was displayed
            se.element.requireIsDislplayed("Rule Creation Dropdown Colum", lstAddRuleColumn, i);
            //verify if column dropdown is clickable
            result &= se.element.isClickable(lstAddRuleColumn);
            //verify if user specified column type was correctly selected
            result &= verifySelectedItemCorrectlyDisplayed(lstAddRuleColumn, i, column);
            //verify if the operator dropdown was displayed
            se.element.requireIsDislplayed("Rule Creation Dropdown Operator", lstAddRuleOperator, i);
            //verify if operator dropdown is clickable
            result &= se.element.isClickable(lstAddRuleOperator);
            //verify if user operator column type was correctly selected
            result &= verifySelectedItemCorrectlyDisplayed(lstAddRuleOperator, i, operator);
            //verify if Comparison Value was displayed
            se.element.requireIsDislplayed("Comparison value", txtAddRuleComparisonvalue, i);
            //verify if Comparison Value is clickable
            result &= se.element.isClickable(txtAddRuleComparisonvalue);
            //Click the Comparison Value Textbox and add Text
            verifyEnteredTextIsCorrectlyDisplayed(txtAddRuleComparisonvalue, i, comparisonValue);
            //verify if End Parenthesis Field is displayed
            se.element.requireIsDislplayed("End parenthisis", txtAddRuleParenthesisEnd, i);
            //verify if the  End Parenthesis Field was clikable
            result &= se.element.isClickable(txtAddRuleParenthesisEnd);
            //click if applicable on the txtAddRuleParenthesisEnd
            if ((endParanthesis.toLowerCase().equals("yes")) || endParanthesis.equals(")"))
                se.element.clickElement(txtAddRuleParenthesisEnd, i);
            //Condition which check if it is last row then we cannot put And/OR and if it is not then it will click Add button
            if (i != rows - 1) {
                //verify if Add Button was displayed
                se.element.requireIsDisplayed("Add definition button", btnAddRuleDefinition);
                //verify if the Add Button was displayed
                result &= se.element.isClickable(btnAddRuleDefinition);
                //click on the add button
                se.element.clickElement(btnAddRuleDefinition);
                //verify if And/OR was displayed
                se.element.requireIsDislplayed("And/Or Select", lstAddRuleAndOr, i);
                //verify if And/OR is clickable
                result &= se.element.isClickable(lstAddRuleAndOr);
                //verify the And/OR was correctly displayed
                result &= verifySelectedItemCorrectlyDisplayed(lstAddRuleAndOr, i, andOr);
            }
        }
        return result;
    }

    /**
     * method to delete a user specified definition from the definition table
     *
     * @param testdata
     * @return
     */
    public boolean deleteADefinition(Map<String, Object> testdata) {
        String strColumn = (String) testdata.get("");
        //verify row count of the definition table is not zero
        boolean result = se.element.getNumberOfElements(rdoDefinition) > 0;
        List<WebElement> weAllDefRadios = se.element.getElements(rdoDefinition);
        List<WebElement> weAllColumns = se.element.getElements(lstColumn);
        //delete the definition by row value
        for (int j = 0; j <= weAllDefRadios.size(); j++) {
            String strDispColumn = weAllColumns.get(j).getAttribute("value").trim();
            if (strDispColumn.equalsIgnoreCase(strColumn)) {
                weAllDefRadios.get(j).click();
                //verify if the delete button was displayed
                se.element.requireIsDisplayed("Delete Definition button", btnDeleteDefinition);
                //verify if the delete button was clickable
                result &= se.element.waitForElementToBeClickable(btnDeleteDefinition);
                se.element.clickElement(btnDeleteDefinition);
                //wait for the page load to complete
                se.webDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
                //confirm the delete
                se.webDriver.switchTo().alert().accept();
                //return to default content
                se.element.returnToDefaultContent();
                //wait for the page to load
                se.webDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
                break;
            }
        }
        return result;
    }

    /**
     * method to add rules
     *
     * @param testdata
     * @return
     */
    public boolean addNewRules(Map<String, Object> testdata) {
        //String strRuleType=(String) params.get("ruletype");
        //Check the number of rules that are already created
        int numberOfRules = se.element.getNumberOfElements(tblRuleName);
        //List of all the names of rules which are created
        ArrayList<String> exisitingRules = new ArrayList<String>();
        //All the name of rules that has to be created
        String strallRuleNames = (String) testdata.get("allrulename");
        //Split all the rule names that are seperated by comma seperator
        String[] rules = strallRuleNames.split(",");
        //verify if the Rules Tab is displayed
        se.element.requireIsDisplayed("Rules Tab", lnkRules);
        //verify if the Rules Tab was clickable
        boolean result = se.element.isClickable(lnkRules);
        //click on the Rules Tab
        se.element.clickElement(lnkRules);
        //Variable which will store the total number of rules that are already created and rule page tracking
        String ruleCountHeader = se.element.getText(strtemplateCountCheck, 0);
        String displayedCount = ruleCountHeader.substring(ruleCountHeader.indexOf("-") + 1, ruleCountHeader.indexOf("of"));
        String maximumCount = ruleCountHeader.substring(ruleCountHeader.indexOf("of") + 2, ruleCountHeader.indexOf("at"));
        //Variable which stores the count of all the rules
        String countLabelOld = se.element.getText(strtemplateCountCheck, 0);
        //If there is less than or equal to 20 rules present then add to the list
        if (displayedCount.equals(maximumCount))
            for (int j = 0; j < numberOfRules; j++) {
                exisitingRules.add(se.element.getText(tblRuleName, j));
            }
        else {
            //Traverese through all the pages of rules and add to the list
            while (!displayedCount.equals(maximumCount)) {
                numberOfRules = se.element.getNumberOfElements(tblRuleName);
                for (int j = 0; j < numberOfRules; j++) {
                    exisitingRules.add(se.element.getText(tblRuleName, j));
                }
                //verify if the next Button is displayed
                se.element.requireIsDisplayed("Next Rule Page", btnNextRulePage);
                //verify if the next Rule page button is clickable
                result &= se.element.isClickable(btnNextRulePage);
                //click on the Next Rule Page Button
                se.element.clickElement(btnNextRulePage);
                //Wait till the rule page changes
                while (countLabelOld.equals(se.element.getText(strtemplateCountCheck, 0))) {
                }
                ruleCountHeader = se.element.getText(strtemplateCountCheck, 0);
                displayedCount = ruleCountHeader.substring(ruleCountHeader.indexOf("-") + 1, ruleCountHeader.indexOf("of"));
                maximumCount = ruleCountHeader.substring(ruleCountHeader.indexOf("of") + 2, ruleCountHeader.indexOf("at"));
            }
            //Get the number of rules present in that page
            numberOfRules = se.element.getNumberOfElements(tblRuleName);
            for (int j = 0; j < numberOfRules; j++) {
                exisitingRules.add(se.element.getText(tblRuleName, j));
            }
        }
        //Check if the rule exist then addition of new rule is not required
        for (int i = 0; i < rules.length; i++) {
            //variable to check if the rule exist
            boolean flag = false;
            for (int k = 0; k < exisitingRules.size(); k++) {
                //checking the name of the new rule is present
                if (rules[i].toString().toLowerCase().equals(exisitingRules.get(k).toLowerCase()) && flag == false) {
                    flag = true;
                }
            }
            //if rule doesnot exist create a new rule
            if (flag == false) {
                //Add new rule
                addNewRule(testdata, rules[i], i + 1);
                //Add the name of the newly added rule to the list to avoid duplicacy
                exisitingRules.add(rules[i]);
                //Add sequence
                addNewSequence(testdata, i + 1);
            }
        }
        return result;
    }

    /**
     * method to add a new rule the rule type
     *
     * @param testdata
     * @return
     */
    public boolean addNewRule(Map<String, Object> testdata, String rulename, int ruleindex) {
        //String strRuleType=(String) params.get("ruletype");
        String strRuleType = (String) testdata.get("R" + ruleindex + "ruletype");
        //verify if rule type drop down was selected
        boolean result = selectRuleType(strRuleType);
        //verify if the add button was displayed
        se.element.requireIsDisplayed("Add rule button", btnAddRule);
        //verify if the add rule button was clickable
        result &= se.element.isClickable(btnAddRule);
        //click on the add rule button
        se.element.clickElement(btnAddRule);
        //wait for page load to complete
        se.element.explicitWait(3000);
        //verify if the rule parameters were added successfully
        result &= addRuleParameters(testdata, rulename, ruleindex);
        //verify if the rule definition were added successfully
        result &= addRuleDefinition(testdata, ruleindex);
        return result;
    }

    /**
     * method to add a new rule sequence
     *
     * @param
     * @return
     */
    public boolean addNewSequence(Map<String, Object> testdata, int index) {
        boolean result = true;
        //Integer that will hold the number of rule steps
        int rows = getRowCount("S" + Integer.toString(index) + "sequence", testdata);
        if (rows != 0) {
            //verify if add sequence button is displayed
            se.element.requireIsDisplayed("Add Sequence button", btnaddSequence);
            //verify if the add sequence button was displayed
            result = se.element.isClickable(btnaddSequence);
            //click on the add sequence button
            se.element.clickElement(btnaddSequence);
            //flagCheck to check if breaklist is Checked or not Checked
            boolean flagCheck = false;
            //Add the sequences row-wise
            for (int i = 0; i < rows; i++) {
                //wait for the page load to complete
                se.webDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
                //Variable to store number of rows in sequence
                String tempRowValues = testdata.get("S" + Integer.toString(index) + "sequence" + Integer.toString(i + 1)).toString();
                //Array of String which will contain all the separate column entries
                String[] rowValue = tempRowValues.split(",");
                //Temporary variable to store the cell values
                String column = rowValue[0];
                String sequence = rowValue[1];
                String breakList = rowValue[2];
                String breakCapacity = rowValue[3];
                //verify if Column Field is displayed
                se.element.requireIsDisplayed("Sequence Column Dropdown", lstAddSequenceColumn, i);
                //verify if the  Column Field was clikable
                result &= se.element.isClickable(lstAddSequenceColumn);
                //click if applicable on the Column
                result &= verifySelectedItemCorrectlyDisplayed(lstAddSequenceColumn, i, column);
                //verify if Sequence Title Field is displayed
                se.element.requireIsDisplayed("Sequence Column Sequence Dropdown", lstAddSequenceTitle, i);
                //verify if the Sequence Title Field was clikable
                result &= se.element.isClickable(lstAddSequenceTitle);
                //click if applicable on the Sequence Title
                result &= verifySelectedItemCorrectlyDisplayed(lstAddSequenceTitle, i, sequence);
                //Check if Breaklist is yes and if it Yes it will be Yes for all
                if (breakList.toLowerCase().equals("yes")) {
                    if (flagCheck == false) {
                        //verify if Break List checkbox is displayed
                        se.element.requireIsDisplayed("Checkbox for Break List", chkAddSequenceBreakList, i);
                        //click on the Break List checkbox
                        se.element.clickElement(chkAddSequenceBreakList, i);
                        flagCheck = true;
                    }
                    //verify if Break Capacity Field was displayed
                    se.element.requireIsDisplayed("Break List Capacity", txtAddSequenceBreakCapacity, i);
                    //verify if Break Capacity Field is clickable
                    result &= se.element.isClickable(txtAddSequenceBreakCapacity);
                    //verify the Break Capacity Field was correctly displayed
                    result &= verifyEnteredTextIsCorrectlyDisplayed(txtAddSequenceBreakCapacity, i, breakCapacity);
                }
                if (breakList.toLowerCase().equals("no")) {
                    if (flagCheck == true) {
                        //verify if Break List checkbox is displayed
                        se.element.requireIsDisplayed("Checkbox for Break List", chkAddSequenceBreakList, i);
                        //click on the Break List checkbox
                        se.element.clickElement(chkAddSequenceBreakList, i);
                        flagCheck = false;
                    }
                }
                if (i != rows - 1) {
                    //verify if required field was displayed
                    se.element.requireIsDisplayed("Add Sequence button", btnaddSequence);
                    //verify if the add definition button was displayed
                    result &= se.element.isClickable(btnaddSequence);
                    //click on the add definition button
                    se.element.clickElement(btnaddSequence);
                }
            }
        }
        //verify if the save configuration button was displayed
        se.element.requireIsDisplayed("Saveconfiguration Button", btnSaveConfiguration);
        //verify if save configuration button is clickable
        result &= se.element.isClickable(btnSaveConfiguration);
        //click on the save configuration button
        se.element.clickElement(btnSaveConfiguration);
        se.element.explicitWait(2000);
        String ruleCountHeader = se.element.getText(strtemplateCountCheck, 0);
        @SuppressWarnings("unused")
		String displayedCount = ruleCountHeader.substring(ruleCountHeader.indexOf("-") + 1, ruleCountHeader.indexOf("of"));
        @SuppressWarnings("unused")
		String maximumCount = ruleCountHeader.substring(ruleCountHeader.indexOf("of") + 2, ruleCountHeader.indexOf("at"));
        return result;
    }

    /**
     * Method to navigate to capacities tab
     *
     * @return
     */
    public boolean navigateToCapacities() {
        //verify if the capacities tab was displayed
        se.element.requireIsDisplayed("Capacities tab", lnkCapacities);
        //verify if the tab was clickable
        boolean result = se.element.waitForElementToBeClickable(lnkCapacities);
        //click on the capacities tab
        se.element.clickElement(lnkCapacities);
        //wait for navigation to complete
        se.webDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        return result;
    }

    /**
     * method to add capacities with and without default wave header capacity
     *
     * @param testdata
     * @return
     */

    public boolean addCapacities(Map<String, Object> testdata) {
        @SuppressWarnings("unused")
		String strSiteType = (String) testdata.get("");
        int loopCount = getRowCount("capacity", testdata);
        String strDiscretePicking = (String) testdata.get("discretepicking");
        String strFWSorters = (String) testdata.get("fwsorters");
        String strAppSorters = (String) testdata.get("appsorters");
        String strMixedSorters = (String) testdata.get("mixedsorters");
        String strMaxPickZone = (String) testdata.get("maxpickzone");
        //verify if the add button was displayed
        se.element.requireIsDisplayed("Add capacities button", btnAddCapacities);
        //verify if the add capacities button was clickable
        boolean result = se.element.waitForElementToBeClickable(btnAddCapacities);
        if (se.assertion.verifyFalse("No data found table exists", se.element.exists(tblNoDataFoundCapacities))) {
            for (int i = 0; i < loopCount; i++) {
                String[] capacity = testdata.get("capacity" + Integer.toString(i + 1)).toString().split(",");
                String strCapacityType = capacity[0];
                String strVASHrs = capacity[1];
                String strRPUnits = capacity[2];
                String strSUnitDO = capacity[3];
                String strRPoLPN = capacity[4];
                String strFCoLPN = capacity[5];
                String strTotaloLPN = capacity[6];

                //click on the add capacities button
                se.element.clickElement(btnAddCapacities);
                //wait for row to get visible
                se.webDriver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
                //add capacity
                if (strCapacityType != "" || strCapacityType != "(none)") {
                    result &= verifySelectedItemCorrectlyDisplayed(lstCapacityType, i, strCapacityType);
                    //add column
                }
                if (strVASHrs != "") {
                    result &= verifyEnteredTextIsCorrectlyDisplayed(txtVasHrs, i, strVASHrs);
                    //add operator
                }
                if (strRPUnits != "") {
                    result &= verifyEnteredTextIsCorrectlyDisplayed(txtRPUnits, i, strRPUnits);
                }
                if (strSUnitDO != "") {
                    result &= verifyEnteredTextIsCorrectlyDisplayed(txtSUnitDO, i, strSUnitDO);
                }
                if (strRPoLPN != "") {
                    result &= verifyEnteredTextIsCorrectlyDisplayed(txtRPoLPN, i, strRPoLPN);
                }
                if (strFCoLPN != "") {
                    result &= verifyEnteredTextIsCorrectlyDisplayed(txtFCoLPN, i, strFCoLPN);
                }
                if (strTotaloLPN != "") {
                    result &= verifyEnteredTextIsCorrectlyDisplayed(txtTotaloLPN, i, strTotaloLPN);
                }
            }
        } else {
            for (int i = 0; i < loopCount; i++) {
                String[] capacity = testdata.get("capacity" + Integer.toString(i + 1)).toString().split(",");
                String strCapacityType = capacity[0];
                String strVASHrs = capacity[1];
                String strRPUnits = capacity[2];
                String strSUnitDO = capacity[3];
                String strRPoLPN = capacity[4];
                String strFCoLPN = capacity[5];
                String strTotaloLPN = capacity[6];
                //verify if the capacity is already selected
                List<WebElement> list = se.webDriver.findElements(By.cssSelector("[id$='cap_type']"));
                Select dropdown = new Select(list.get(i));
                WebElement strOption = dropdown.getFirstSelectedOption();
                String seltext = strOption.getText();
                if (!seltext.equals(strCapacityType)) {
                    //click on the add capacities button
                    se.element.clickElement(btnAddCapacities);
                    //wait for row to get visible
                    se.webDriver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
                    if (strCapacityType != "" || strCapacityType != "(none)") {
                        result &= verifySelectedItemCorrectlyDisplayed(lstCapacityType, i, strCapacityType);
                        //add column
                    }
                    if (strVASHrs != "") {
                        result &= verifyEnteredTextIsCorrectlyDisplayed(txtVasHrs, i, strVASHrs);
                        //add operator
                    }
                    if (strRPUnits != "") {
                        result &= verifyEnteredTextIsCorrectlyDisplayed(txtRPUnits, i, strRPUnits);
                    }
                    if (strSUnitDO != "") {
                        result &= verifyEnteredTextIsCorrectlyDisplayed(txtSUnitDO, i, strSUnitDO);
                    }
                    if (strRPoLPN != "") {
                        result &= verifyEnteredTextIsCorrectlyDisplayed(txtRPoLPN, i, strRPoLPN);
                    }
                    if (strFCoLPN != "") {
                        result &= verifyEnteredTextIsCorrectlyDisplayed(txtFCoLPN, i, strFCoLPN);
                    }
                    if (strTotaloLPN != "") {
                        result &= verifyEnteredTextIsCorrectlyDisplayed(txtTotaloLPN, i, strTotaloLPN);
                    }
                }
            }
        }
        if (loopCount > 0)

        {
            if (strDiscretePicking.equalsIgnoreCase("yes")) {
                //verify if required discrete picking field was displayed
                se.element.requireIsDisplayed("Discrete Picking checkbox", chkDiscretePicking);
                //click discrete picking checkbox
                se.element.clickElement(chkDiscretePicking);
            }
            if (strAppSorters != "none") {
                //verify if the required Apparel sorters field was displayed
                se.element.requireIsDisplayed("ApparelSorters drop down", lstApparelSorters);
                //verify if the user defined value was selected for the Apparel Sorters
                result &= verifySelectedItemCorrectlyDisplayed(lstApparelSorters, strAppSorters);
            }
            if (strFWSorters != "none") {
                //verify if the required Footwear sorters field was displayed
                se.element.requireIsDisplayed("FootwearSorters drop down", lstFootwearSorters);
                //verify if the user defined value was selected for the FW Sorters
                result &= verifySelectedItemCorrectlyDisplayed(lstFootwearSorters, strFWSorters);
            }
            if (strMixedSorters != "none") {
                //verify if the required Mixed sorters field was displayed
                se.element.requireIsDisplayed("MixedSorters drop down", lstMixedSkuSorters);
                //verify if the user defined value was selected for the Mixed Sorters
                result &= verifySelectedItemCorrectlyDisplayed(lstMixedSkuSorters, strMixedSorters);
            }
            if (strMaxPickZone != "none") {
                //verify if the required FW sorters field was displayed
                se.element.requireIsDisplayed("Max Pick Zone text box", txtMaxPickZones);
                //verify if the user defined value was selected for the Max pick zone
                result &= verifyEnteredTextIsCorrectlyDisplayed(txtMaxPickZones, strMaxPickZone);
            }
        }

        return result;
    }

    /**
     * method to delete a user specified capacity for the capacity table
     *
     * @param testdata
     * @return
     */
    public boolean deleteACapacity(Map<String, Object> testdata) {
        String strCapacityType = (String) testdata.get("");
        //verify row count of the definition table is not zero
        boolean result = se.element.getNumberOfElements(tblCapacities) > 0;
        int rowCount = se.element.getNumberOfElements(tblCapacities);
        List<WebElement> weCapTypes = se.element.getElements(lstCapacityType);
        List<WebElement> weAllCheckboxes = se.element.getElements(chkCapacities);
        //delete the definition by row value
        for (int j = 0; j <= rowCount; j++) {
            String strDispCapacity = weCapTypes.get(j).getAttribute("value").trim();
            if (strDispCapacity.equalsIgnoreCase(strCapacityType)) {
                weAllCheckboxes.get(j).click();
                //verify if the delete button was displayed
                se.element.requireIsDisplayed("Delete Definition button", btnDeleteCapacities);
                //verify if the delete button was clickable
                result &= se.element.waitForElementToBeClickable(btnDeleteCapacities);
                se.element.clickElement(btnDeleteCapacities);
                //wait for the page load to complete
                se.webDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
                //confirm the delete
                se.webDriver.switchTo().alert().accept();
                //return to default content
                se.element.returnToDefaultContent();
                //wait for the page to load
                se.webDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
                break;
            }
        }
        return result;
    }

    public boolean deleteAllCapacities(Map<String, Object> testdata) {
        boolean result = true;
        try {
            List<WebElement> elements;
            //myLog.logSeStep("Enter Text '" + textToType + "' in Element: " + locator.toString());
            //elements = searchForClickableElements(locator);
            elements = se.element.getElements(chkCapacityName);
            int count = se.element.getNumberOfElements(chkCapacityName);
            for (int i = 0; i < count; i++) {
                elements.get(i).click();
                try {
                    Thread.sleep(500);
                } catch (Exception e) {
                }
            }

            se.element.requireIsDisplayed("Delete Rule Button ", btnDeleteCapacity);
            //verify if the RunWave Button is clickable
            result &= se.element.isClickable(btnDeleteCapacity);
            //click on the Run Wave Button
            se.element.clickElement(btnDeleteCapacity);
            //}
            se.element.javaScriptPopUp("yes");

            Thread.sleep(500);
        } catch (Exception e) {
        }
        return result;
    }

    /**
     * method to delete all the rules
     *
     * @param testdata
     * @return
     */
    public boolean deleteAllRules(Map<String, Object> testdata) {
        boolean result = true;
        int count = se.element.getNumberOfElements(tblRuleName);
        for (int i = 0; i < count; i++) {
            //Variable which stores the count of all the templates
            String countLabelOld = se.element.getText(strtemplateCountCheck, 0);
            //verify if the checkbox with the rule name was displayed
            se.element.requireIsDisplayed("Rule Name", chkRules);
            //verify if the label with the rule name was displayed
            se.element.requireIsDisplayed("Option Button to select created Rule", tblRuleName);
            //verify if checkbox with the Rule name is clickable
            result &= se.element.isClickable(chkRules);
            //click on the checkbox
            se.element.clickElement(chkRules, 0);
            //verify if the button Run Wave is displayed
            se.element.requireIsDisplayed("Delete Rule Button ", btnDeleteRule);
            //verify if the RunWave Button is clickable
            result &= se.element.isClickable(btnDeleteRule);
            //click on the Run Wave Button
            se.element.clickElement(btnDeleteRule);
            try {
                Thread.sleep(500);
            } catch (Exception e) {
            }
            se.element.javaScriptPopUp("yes");
            try {
                Thread.sleep(500);
            } catch (Exception e) {
            }
            while (countLabelOld.equals(se.element.getText(strtemplateCountCheck, 0))) {
            }
        }
        return result;
    }

    /**
     * method to verify if the rule exists in the rule table
     *
     * @param testdata
     * @return
     */
    public boolean verifyRuleExists(Map<String, Object> testdata) {
        boolean result = true;

        return result;
    }


}