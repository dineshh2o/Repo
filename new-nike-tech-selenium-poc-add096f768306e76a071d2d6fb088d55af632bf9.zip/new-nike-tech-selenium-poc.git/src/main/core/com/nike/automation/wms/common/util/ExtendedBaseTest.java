package com.nike.automation.wms.common.util;

import java.io.FileNotFoundException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import javax.xml.bind.JAXBException;
import org.testng.SkipException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import com.cognizant.framework.IterationOptions;
import com.cognizant.framework.selenium.Browser;
import com.cognizant.framework.selenium.SeleniumTestParameters;
import com.nike.automation.wms.common.object.IgnoreTestArtifactDetails;
import supportlibraries.DriverScript;
import tech.nike.automation.common.framework.core.CommonBaseTest;
import tech.nike.automation.common.framework.core.SystemUtil;

public abstract class ExtendedBaseTest extends CommonBaseTest {
		
    @BeforeMethod(alwaysRun = true)
    protected void setSelenium(){
    }	
    /**
     * Convenience method for getting base url
     *
     * @return
     * @author Cognizant Technology CoE
     */
    public String getBaseUrl() {
        return SystemUtil.getBaseUrl();
    }

    /**
     * Convenience method for getting locale
     *
     * @return
     * @author Cognizant Technology CoE
     */
    public String getLocale() {
        return SystemUtil.getLocale();
    }

    /**
     * Convenience method for getting store ure
     *
     * @return
     * @author Cognizant Technology CoE
     */
    public String getBaseWmsUrl() {
        return SystemUtil.getWmsBaseUrl();
    }
    
    @SuppressWarnings("unchecked")
	@DataProvider(name = "xmlData")
    public Object[][] xmlDataProvider(final Method testMethod) throws Exception {
        List<ConcurrentHashMap<String, Object>> dataList = new ArrayList<ConcurrentHashMap<String, Object>>();
        //get annotation from test method
        TestData testData = testMethod.getAnnotation(TestData.class);

        //check for annotation for filename
        if (testData == null || testData.fileName() == null || testData.fileName().length() == 0) {
            throw new Exception(testMethod.getClass().getSimpleName() + ": Data file missing !");
        }
        Object testObject = getTestParameters(testData.fileName()).get("test");

        //if we have more than one test
        if (testObject instanceof List) {
            for (ConcurrentHashMap<String, Object> test : (List<ConcurrentHashMap<String, Object>>) testObject) {
                dataList.add(test);
            }
        }
        //if there is only one test tag in xml file
        else if (testObject instanceof HashMap<?, ?>) {
        	ConcurrentHashMap<String, Object> map = new ConcurrentHashMap<String, Object>();
            
        	map.putAll((HashMap<String, Object>) testObject);
            dataList.add(map);
        }
        //something is wrong with the file
        else {
            throw new Exception(testMethod.getClass().getSimpleName() + ":"+testObject.getClass().getName()+" Format incorrect !");
        }    	
        
//        Object[][] baseData = weaveInSeHelpers(Data.createDataProviderFromDelimitedString(SystemUtil.getBrowsers(), ","));
        Object[][] returnData = weaveInParameters(new Object[dataList.size()][], dataList);
        return returnData;
    }

    public DriverScript getDefaultScriptSettings(SeleniumTestParameters testParameters, ConcurrentHashMap<String, Object> params){
		testParameters.setBrowser(Browser.INTERNET_EXPLORER);
		testParameters.setIterationMode(IterationOptions.RUN_ONE_ITERATION_ONLY);
		testParameters.setStartIteration(1);
		testParameters.setEndIteration(1);
		testParameters.setTestcaseParams(params);
		params.putAll(ApplicationSettings.getSettings());
		
		ObjectXMLTransformer transformer = new ObjectXMLTransformer();
		IgnoreTestArtifactDetails ignoreArtifact;
		try {
			ignoreArtifact = (IgnoreTestArtifactDetails)
					transformer.loadXmlAsbject("ignore-artifact.xml", IgnoreTestArtifactDetails.class);
		} catch (FileNotFoundException | JAXBException e) {
			throw new SkipException("Undble to load ignore-artifact.xml !");
		}
		String testCaseName = (String) params.get("identifier");
		String dcCode = (String) params.get("dcCode");
		if(ignoreArtifact.getIgnoreDcCodes().contains(dcCode))
			throw new SkipException("As configured ignoring dc: "+dcCode);		
		if(ignoreArtifact.getIgnorePackages().contains(testParameters.getCurrentScenario()))
				throw new SkipException("As configured ignoring package: "+testParameters.getCurrentScenario());		
		if(ignoreArtifact.getIgnoreTestSuites().contains(testParameters.getCurrentTestcase()))
			throw new SkipException("As configured ignoring suite: "+testParameters.getCurrentTestcase());		
		if(ignoreArtifact.getIgnoreTestCases().contains(testCaseName))
			throw new SkipException("As configured ignoring testcase: "+testCaseName);		
		
		return new DriverScript(testParameters);
    }    
 
    
	@Override
	public void setUp() {
		report.addTestLogSection("Setup");
	}

	@Override
	public void tearDown() {
		report.addTestLogSection("tearDown");
	}    
}
