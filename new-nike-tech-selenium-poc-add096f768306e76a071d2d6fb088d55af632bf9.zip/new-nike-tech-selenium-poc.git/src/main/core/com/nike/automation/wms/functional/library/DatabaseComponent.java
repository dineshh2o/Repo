package com.nike.automation.wms.functional.library;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.xml.bind.JAXBException;
import com.cognizant.framework.selenium.CraftDriver;
import com.nike.automation.wms.common.object.TestSuiteQueryHeap;
import com.nike.automation.wms.common.util.ObjectXMLTransformer;

import oracle.sql.CLOB;
import tech.nike.automation.common.framework.core.Data;

public class DatabaseComponent extends BaseComponent {
	// JDBC driver name and database URL
	String JDBC_DRIVER = "oracle.jdbc.driver.OracleDriver";
	String dbUrl, user, password;
	public DatabaseComponent(CraftDriver driver){
		this.driver=driver;
	}
	public void setConnectionString(){
		String dcCode = getParamValue("dcCode");
		String dbHostName = getParamValue(dcCode + "-DB-HostName");
		String dbPort = getParamValue(dcCode + "-DB-Port");
		String dbUserName = getParamValue(dcCode + "-DB-UserName");
		Data.EncryptedString es = new Data.EncryptedString((String) getParamValue(dcCode + "-DB-Password"));
		String dbPassword = es.getString();
		String dbSid = getParamValue(dcCode + "-DB-SID");
		this.dbUrl="jdbc:oracle:thin:@" + dbHostName + ":" + dbPort + ":" + dbSid;;
		this.user=dbUserName;
		this.password=dbPassword;
	}
	
	public String getRowDetails(ArrayList<HashMap<String, String>> resultList, int rowNumber, String column){
		if(resultList!=null && rowNumber<resultList.size() && resultList.get(rowNumber)!=null) {
			return resultList.get(rowNumber).get(column);
		}
		else return null;
	}
	
	public ArrayList<HashMap<String, String>> getResultMap(String query, List<String> columns, int rowNeeded) {
		ArrayList<HashMap<String, String>> resultList = new ArrayList<HashMap<String, String>>();
		Connection conn = null;
		Statement stmt = null;
		setConnectionString();
		try {
			Class.forName(JDBC_DRIVER);			
			conn = DriverManager.getConnection(dbUrl, user, password);
			stmt = conn.createStatement();
			ResultSet resultSet = stmt.executeQuery(query);
				
			int rowCounter = 0; 
			while(resultSet.next() && rowCounter<rowNeeded) 
			{
				//resultSet.next();	//Only first	
				HashMap<String, String> resultMap = new HashMap<String, String>();				
				for(int i=0;i<columns.size();i++){
					if(resultSet.getObject(columns.get(i)) instanceof CLOB){
						resultMap.put(columns.get(i), resultSet.getString(columns.get(i)).toString());
						System.out.println(columns.get(i)+":"+resultMap.get(columns.get(i)));
					}else{
					resultMap.put(columns.get(i), resultSet.getObject(columns.get(i)).toString());
					System.out.println(columns.get(i)+":"+resultMap.get(columns.get(i)));
					}
				}
				resultList.add(resultMap);
				rowCounter++;
			}
			resultSet.close();
			stmt.close();
			conn.close();
		} catch (SQLException se) {
			// Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			// Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			// finally block used to close resources
			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException se2) {
			} // nothing we can do
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
			} // end finally try
		} // end try
		return resultList;
	}

	public static void main(String[] args) throws FileNotFoundException, JAXBException {
		ObjectXMLTransformer transformer = new ObjectXMLTransformer("src/test/resources/wms/sql");
		TestSuiteQueryHeap sqlHeap = (TestSuiteQueryHeap) transformer.loadXmlAsbject("QueryLibrary.xml",
				TestSuiteQueryHeap.class);
		String query = sqlHeap.getSql("ANYDC_SAMPLE_OTHERDC_MODEL_TESTCASE_A", 0);
		System.out.println(query);

//		String str = "ITEM_NAME,QUANTITY";
//		List<String> columns = Arrays.asList(str.split("\\s*,\\s*"));
		
//		DatabaseComponent dbComponent = new DatabaseComponent(driver);
//		dbComponent.setConnectionString();
//		ArrayList<HashMap<String, String>> resultList = dbComponent.getResultMap(query, columns, 1);	
//		System.out.println(dbComponent.getRowDetails(resultList, 0, columns.get(0)));
		
	}
}
