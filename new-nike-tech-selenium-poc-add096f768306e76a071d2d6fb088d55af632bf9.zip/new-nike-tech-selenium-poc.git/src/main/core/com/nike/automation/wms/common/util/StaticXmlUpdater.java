package com.nike.automation.wms.common.util;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.cognizant.framework.selenium.CraftDriver;
import com.nike.automation.wms.common.object.GenericWmsElement;

import tech.nike.automation.common.framework.core.Log;
import tech.nike.automation.common.framework.core.Util;


public class StaticXmlUpdater {

	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder dBuilder = null;
	Document doc = null;
	Log log = null;

	public StaticXmlUpdater(Log log){
		this.log=log;
	}
	// Function : to get the XML doc
	public Document getXmlDoc(String filePath) {
		try {
			File inputFile = new File(filePath);
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return doc;
	}

	// Function to getvalue by tagname
	public String[] getValueByTagName(String tagname, Document doc) {
		try {
			NodeList nList = doc.getElementsByTagName(tagname);
			String[] val = new String[nList.getLength()];
			for (int i = 0; i < nList.getLength(); i++) {
				Node nNode = nList.item(i);
				val[i] = nNode.getTextContent();
			}
			return val;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	// Function to update an XML
	public void updateXML(String tagName, String[] value, Document doc, String filePath) {
		try {
			NodeList nList = doc.getElementsByTagName(tagName);
			for (int i = 0; i < nList.getLength(); i++) {
				if (i < value.length) {
					Node nNode = nList.item(i);
					String oldVal=getValueByTagName(tagName, doc)[i].toString();
					nNode.setTextContent(value[i]);
					log.logSeStep(tagName +" Updated from "+oldVal+" to "+ value[i]);
				} else {
					log.logSeStep(i + " nodes out of " + nList.getLength() + " are updated");
					break;
				}
			}
			saveXML(doc, filePath);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// function get a XML node
	public NodeList getXmlNode(String tagName, Document doc) {
		try {
			NodeList nList = doc.getElementsByTagName(tagName);
			return nList;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	// save a xml
	public void saveXML(Document doc, String filePath) throws TransformerException {
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File(filePath));
		transformer.transform(source, result);
	}

	public void updateXmlTagsWithUniqueValue(CraftDriver driver ,String xmlTag, String filePath ){
		Document doc = getXmlDoc(filePath);
		String[] xmlTags = xmlTag.split(",");
		for (String tag : xmlTags) {
			NodeList nodeList = getXmlNode(tag, doc);
			int occuranceCount = nodeList.getLength();
			int valueLength=getValueByTagName(tag, doc)[0].length();
			String[] uniqueID = new String[occuranceCount];
			Date dNow = new Date();			
			SimpleDateFormat ft = new SimpleDateFormat("SSSssmmhhyyyyMMdd");
			for (int i = 0; i < occuranceCount; i++) {
				String id = "AUTO" + i + ft.format(dNow)+"000000000000000000";
				uniqueID[i] = id.substring(0, valueLength);
				String reserverIdentifier = driver.getSessionId().toString();
				if(tag.equalsIgnoreCase(ApplicationKeys.TAG_NAME_DO_ID.toString())){
					driver.getDataReserver(reserverIdentifier).getDoIds().getElement().add(new GenericWmsElement(tag, id.substring(0, valueLength)));					
				}else if(tag.equalsIgnoreCase(ApplicationKeys.TAG_NAME_LPN_ID.toString())){
						driver.getDataReserver(reserverIdentifier).getLpnIds().getElement().add(new GenericWmsElement(tag, id.substring(0, valueLength)));
				}else{
					String key = tag+"-"+(i+1);
					String value = id.substring(0, valueLength);
					log.logSeStep("Datareserver:"+key+"="+value);
					driver.getDataReserver(reserverIdentifier).getAppsData().put(tag+"-"+(i+1), id.substring(0, valueLength));
				}

			}
			updateXML(tag, uniqueID, doc, filePath);
		}
	}
	
	public void updateXmlTagsWithSpecificValue(String xmlTag, String nodeValue, String filePath) throws Exception{
		Document doc = getXmlDoc(filePath);
		String[] values = nodeValue.split(",");

		if(nodeValue==null || values==null || values.length==0)
			throw new WmsCustomException("Invalid tag value :"+xmlTag);
		updateXML(xmlTag, values, doc, filePath);
	}
	
	public static void main(String[] args) throws Exception {
	    Log log = new Log(Util.randomNum(0, 9999) + "_" + Util.getDateStamp(new SimpleDateFormat("yyyyMMddkkmmssSSS")));
		StaticXmlUpdater obj = new StaticXmlUpdater(log);
		
		String filePath = "D:/OB_1064NDC_PW03AT_HP_28_INT9_P40_MaxFromDyn.xml";
//		String xmlTag = "Reference_ID,DistributionOrderId";
//		obj.updateXmlTagsWithUniqueValue(xmlTag, filePath);
		
		obj.updateXmlTagsWithSpecificValue("ItemName","429628-096-10.6", filePath);
	}
}