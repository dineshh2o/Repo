package com.nike.automation.wms.common.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import com.nike.automation.wms.common.object.GenericWmsElement;
import com.nike.automation.wms.common.object.IgnoreTestArtifactDetails;
import com.nike.automation.wms.common.object.InOutDataReserver;
import com.nike.automation.wms.common.object.SqlQueryInformation;
import com.nike.automation.wms.common.object.TestCaseQueryDetails;
import com.nike.automation.wms.common.object.TestSuiteQueryHeap;

public class ObjectXMLTransformer {
	public String storagePath;
	public ObjectXMLTransformer(){
		this.storagePath="";
	}
	public ObjectXMLTransformer(String storagePath){
		this.storagePath=storagePath;
	}
	public void preserveObjectAsXml(Class<?> className, Object content, String xmlFileName)
			throws JAXBException, IOException {
		if(xmlFileName==null || xmlFileName.equals(""))return;		
		JAXBContext jaxbContext = JAXBContext.newInstance(className);		
		Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
		jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		jaxbMarshaller.marshal(content, System.out);
		File file = new File(storagePath+"/" + xmlFileName);
		if(!file.exists()){
			file.getParentFile().mkdirs(); 
			file.createNewFile();
		}
		
		OutputStream os = new FileOutputStream(file);		
		jaxbMarshaller.marshal(content, os);

	}

	public Object loadXmlAsbject(String xmlFileName, Class<?> className)
			throws JAXBException, FileNotFoundException {
		if(xmlFileName==null || xmlFileName.equals(""))return null;
		JAXBContext jaxbContext = JAXBContext.newInstance(className);
		Object unMarshalledObj = null;
		InputStream is = null;
		if(storagePath==null || "".equals(storagePath))
			is = new FileInputStream(xmlFileName);
		else
			is = new FileInputStream(storagePath+"/" + xmlFileName);
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		unMarshalledObj = jaxbUnmarshaller.unmarshal(is);
		return unMarshalledObj;
	}
	
	public static void main(String[] args) throws JAXBException, IOException {
		ObjectXMLTransformer transformer = new ObjectXMLTransformer("src/test/resources/wms/test");
		
		TestSuiteQueryHeap queryHeap = new TestSuiteQueryHeap();		
		TestCaseQueryDetails query1 = new TestCaseQueryDetails();
		query1.getQueryList().add(new SqlQueryInformation("101", "Sql1","Desc-1"));
		query1.getQueryList().add(new SqlQueryInformation("102", "Sql2","Desc-2"));
		queryHeap.getTestcase().put("TC1", query1);

		TestCaseQueryDetails query2 = new TestCaseQueryDetails();
		query2.getQueryList().add(new SqlQueryInformation("103", "Sql3","Desc-3"));
		query2.getQueryList().add(new SqlQueryInformation("104", "Sql4","Desc-4"));
		queryHeap.getTestcase().put("TC2", query2);

		transformer.preserveObjectAsXml(TestSuiteQueryHeap.class, queryHeap, "Library.xml");	
		
		TestSuiteQueryHeap sqlHeap = (TestSuiteQueryHeap) transformer.loadXmlAsbject("Library.xml", TestSuiteQueryHeap.class);
		System.out.println(sqlHeap.getDetails("TC2"));
		
		InOutDataReserver reserver = new InOutDataReserver();
		reserver.getTaskIds().getElement().add(new GenericWmsElement("task","101","1"));
		reserver.getTaskIds().getElement().add(new GenericWmsElement("task","102","2"));
		
		reserver.getAsnIds().getElement().add(new GenericWmsElement("asn","2001","3"));
		reserver.getAsnIds().getElement().add(new GenericWmsElement("asn","2002","4"));
		transformer.preserveObjectAsXml(InOutDataReserver.class, reserver, "InWard.xml");	
		
		InOutDataReserver data = (InOutDataReserver) transformer.loadXmlAsbject("InWard.xml", InOutDataReserver.class);
		System.out.println(data.getAsnIds().getDetails());
		
		
		IgnoreTestArtifactDetails ignoreArtifact = new IgnoreTestArtifactDetails();
		ignoreArtifact.getIgnoreDcCodes().add("otherdc");
		ignoreArtifact.getIgnorePackages().add("com.nike.automation.wms.testset.model.*");
		ignoreArtifact.getIgnoreTestSuites().add("TESTSET_WMS_ANYDC_SAMPLE");
		ignoreArtifact.getIgnoreTestCases().add("ANYDC_SAMPLE_OTHERDC_MODEL_TESTCASE_A");
		ignoreArtifact.getIgnoreTestCases().add("ANYDC_SAMPLE_OTHERDC_MODEL_TESTCASE_B");
				
		transformer.preserveObjectAsXml(IgnoreTestArtifactDetails.class, ignoreArtifact, "ignore-artifact.xml");
		ignoreArtifact = (IgnoreTestArtifactDetails)transformer.loadXmlAsbject("ignore-artifact.xml", IgnoreTestArtifactDetails.class);
	}
}
