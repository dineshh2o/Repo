package com.nike.automation.wms.common.page;

import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cognizant.framework.Status;
import com.nike.automation.wms.common.util.ApplicationKeys;
import com.nike.automation.wms.common.util.WmsCustomException;

public class WMSTaskPage extends BasePage {
	public By taskIdTextArea		  = By.id("dataForm:lview:filterId:field1value1");
	public By taskApplyButton	 	  = By.xpath("//input[@id='dataForm:lview:filterId:filterIdapply']");
	public By assgnToAutoRelButton 	  = By.id("rmButton_1AssignForAuto-Release1_167271557");
	public By btnAlertOk			  = By.id("dataForm:autoReleaseOkButton");
	public By refresh				  = By.xpath("//*[@id='pghdr']/tbody/tr[1]/td[1]/table/tbody/tr/td[8]/a/img");
	public By taskViewButton 		  = By.id("rmButton_1View1_167271343");
	public By detailTabLink 		  = By.id("DetailsTab_lnk");
	public By LPNTabLink 			  = By.id("LPNsTab_lnk");
	public By lpnNo					  = By.xpath("//*[@id='dataForm:LPNList_entityListView:LPNList_MainListTable:0:LPNList_Outbound_Link_NameText_param_out']");
	public By itemNumber 			  = By.xpath("//*[@id='dataForm:lview:dataTable:0:ItemBOMDetailsListEV_item_popup_button']");
	public By barCode				  = By.id("dataForm:Item_popup_barcode_outText");
	public By allocatedQty 			  = By.id("dataForm:Tab1_D24");
	public By itemInformationCross	  = By.xpath("//*[@id='dataForm:ItemBOMListEV_Item_Popup_basicDialogTemplate_cCId']/img");
	public By slotID				  = By.id("dataForm:Tab1_D12");
	public By oLpn					  = By.id("dataForm:Tab1_D29");
	public By waveNoTextArea		  = By.id("dataForm:listView:filterId:field1value1");
	public By pickingShortApplyButton = By.id("dataForm:listView:filterId:filterIdapply");
	public By chaseWaveNumber		  = By.id("dataForm:listView:PickingShortDataTable:0:CHASElocn1");

	public By getHeaderStatus(String str) {
		String xpath = "//span[contains(text(),'" + str + "')]//parent::td//parent::tr/td[5]/span[1]";
		return By.xpath(xpath);
	}

	public By getTaskChkbox(String str) {
		String xpath = "//span[contains(text(),'" + str
				+ "')]//parent::td//parent::tr/td[1]/input[contains(@type,'checkbox')]";
		return By.xpath(xpath);
	}

	public By getStatCode(String str) {
		String xpath = "//span[contains(text(),'" + str + "')]//parent::td//parent::tr/td[9]/span[1]";
		return By.xpath(xpath);
	}

	public By getShortedunits(String str) {
		String xpath = "//span[contains(text(),'" + str + "')]//parent::td//parent::tr/td[8]/span[1]";
		return By.xpath(xpath);
	}

	public By getlpnFacilityStatus(String str) {
		String xpath = "//span[contains(text(),'" + str + "')]//parent::a//parent::td//parent::tr/td[3]/span[1]";
		return By.xpath(xpath);
	}

	public boolean verifyTask(final Map<String, Object> testdata) throws WmsCustomException {
		try {
			WebDriverWait wait = new WebDriverWait(se.webDriver, globalWaitDefault);
			String taskID = getDataReserver().getAppsData(ApplicationKeys.TRANSIT_TASKID);
			final String taskType = getDataReserver().getAppsData(ApplicationKeys.TRANSIT_TASK_TYPE);
			String headerStatusBefore = (String) testdata.get("headerStatusBefore");
			waitForComponent(se, wait, taskIdTextArea);
			se.webDriver.findElement(taskIdTextArea).clear();
			se.webDriver.findElement(taskIdTextArea).sendKeys(taskID);
			wait.until(ExpectedConditions.visibilityOfElementLocated(taskApplyButton));
			se.webDriver.findElement(taskApplyButton).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(getHeaderStatus(taskType)));
			String headerStat=se.webDriver.findElement(getHeaderStatus(taskType)).getText();
			if (se.webDriver.findElement(getHeaderStatus(taskType)).getText().equalsIgnoreCase(headerStatusBefore)) {
				se.log.logSeStep("Header Status is" + se.webDriver.findElement(getHeaderStatus(taskType)).getText());
				report.updateTestLog("Header status",
						"Header status is" +headerStat , Status.PASS);
			}

			wait.until(ExpectedConditions.visibilityOfElementLocated(getTaskChkbox(taskType)));
			se.webDriver.findElement(getTaskChkbox(taskType)).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(assgnToAutoRelButton));
			se.webDriver.findElement(assgnToAutoRelButton).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(btnAlertOk));
			se.webDriver.findElement(btnAlertOk).click();

			while (!se.webDriver.findElement(getHeaderStatus(taskType)).getText()
					.equalsIgnoreCase(testdata.get("headerStatusAfter").toString())) {
				waitForComponent(se, wait, refresh);
				se.element.clickElement(refresh);
				se.log.logTestStep("done refresh");
				processingDelay(20);
			}
			String headerStatNow=se.webDriver.findElement(getHeaderStatus(taskType)).getText();
			report.updateTestLog("Header status",
					"Header status is:" + headerStatNow, Status.PASS);

			waitForComponent(se, wait, itemNumber);
			se.webDriver.findElement(itemNumber).click();
			waitForComponent(se, wait, barCode);
			String barcode = se.webDriver.findElement(barCode).getText();
			if (barcode != null && !"".equals(barcode)) {
				getDataReserver().setAppsData(ApplicationKeys.BAR_CODE, barcode);
				se.log.logTestStep("DataReserver barcode : " + getDataReserver().getAppsData(ApplicationKeys.BAR_CODE));
			} else {
				String errorMsg = "Barcode is EMPTY !";
				se.log.logSeStep(errorMsg);
				throw new WmsCustomException(errorMsg);
			}

			report.updateTestLog("Task", "Barcode-" + barcode, Status.PASS);
			wait.until(ExpectedConditions.visibilityOfElementLocated(itemInformationCross));
			se.webDriver.findElement(itemInformationCross).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(getTaskChkbox(taskType)));
			se.webDriver.findElement(getTaskChkbox(taskType)).click();
			se.webDriver.findElement(taskViewButton).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(detailTabLink));
			se.webDriver.findElement(detailTabLink).click();
			waitForComponent(se, wait, slotID);
			String slotId = se.webDriver.findElement(slotID).getText();
			getDataReserver().setAppsData(ApplicationKeys.SLOT_ID, slotId);

			waitForComponent(se, wait, oLpn);
			String olpn = se.webDriver.findElement(oLpn).getText();
			getDataReserver().setAppsData(ApplicationKeys.OLPN, olpn);

			waitForComponent(se, wait, allocatedQty);
			String allocatedQnty = se.webDriver.findElement(allocatedQty).getText();
			if (allocatedQnty == null || "".equals(allocatedQnty)) {
				throw new WmsCustomException("Allocated quantity should not be empty");
			}
			getDataReserver().setAppsData(ApplicationKeys.ALLOCATED_QTY, allocatedQnty);

			wait.until(ExpectedConditions.visibilityOfElementLocated(LPNTabLink));
			se.webDriver.findElement(LPNTabLink).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(lpnNo));
			String lpn = se.webDriver.findElement(lpnNo).getText();
			if (se.webDriver.findElement(lpnNo).isDisplayed()) {
				se.log.logSeStep("LPN is displayed" + lpn);
				report.updateTestLog("LPN is displayed", "LPN is displayed-" + lpn, Status.PASS);
			} else {
				report.updateTestLog("LPN is not displayed", "LPN is not displayed", Status.FAIL);
			}
		} catch (Exception ex) {
			se.log.logTestStep("Task verification unsuccessful" + ex.getMessage());
			report.updateTestLog("Task", "Task verification is unsuccessful", Status.FAIL);
			throw new WmsCustomException();
		}
		return true;

	}

	public boolean verifyPickingShort(final Map<String, Object> testdata) throws WmsCustomException {
		try {
			WebDriverWait wait = new WebDriverWait(se.webDriver, globalWaitDefault);
			waitForComponent(se, wait, waveNoTextArea);
			String waveNum = getDataReserver().getAppsData(ApplicationKeys.TRANSIT_WAVE_NUMBER);
			se.webDriver.findElement(waveNoTextArea).sendKeys(waveNum);
			waitForComponent(se, wait, pickingShortApplyButton);
			se.webDriver.findElement(pickingShortApplyButton).click();
			waitForComponent(se, wait, getStatCode(waveNum));
			String statCode = se.webDriver.findElement(getStatCode(waveNum)).getText();
			waitForComponent(se, wait, getShortedunits(waveNum));
			String shortedUnits = se.webDriver.findElement(getShortedunits(waveNum)).getText();
			if (statCode.equalsIgnoreCase((ApplicationKeys.WAVE_STAT_CODE).toString())
					&& shortedUnits.equalsIgnoreCase((ApplicationKeys.WAVE_SHORTED_ITEM).toString())) {
				report.updateTestLog("Pick Short", "Stat code is" + statCode, Status.PASS);
				report.updateTestLog("Pick Short", "Shorted unit is" + shortedUnits, Status.PASS);
			}

		} catch (Exception ex) {
			report.updateTestLog("Pick Short", "Picking short verification is falied", Status.FAIL);
			throw new WmsCustomException();
		}
		return true;

	}
	public boolean verifyPickingShortFinal(final Map<String, Object> testdata) throws WmsCustomException {
		try {
			WebDriverWait wait = new WebDriverWait(se.webDriver, globalWaitDefault);
			waitForComponent(se, wait, waveNoTextArea);
			String waveNum = getDataReserver().getAppsData(ApplicationKeys.TRANSIT_WAVE_NUMBER);
			se.webDriver.findElement(waveNoTextArea).sendKeys(waveNum);
			waitForComponent(se, wait, pickingShortApplyButton);
			se.webDriver.findElement(pickingShortApplyButton).click();
			waitForComponent(se, wait, getStatCode(waveNum));
			String statCode = se.webDriver.findElement(getStatCode(waveNum)).getText();
			waitForComponent(se, wait, getShortedunits(waveNum));
			String shortedUnits = se.webDriver.findElement(getShortedunits(waveNum)).getText();
			String chaseWave=se.webDriver.findElement(chaseWaveNumber).getText();
			if (statCode.equalsIgnoreCase((ApplicationKeys.WAVE_STAT_CODE_FINAL).toString())
					&& shortedUnits.equalsIgnoreCase((ApplicationKeys.WAVE_SHORTED_ITEM).toString())&&(chaseWave!=null ||!"".equals(chaseWave))) {
				se.log.logTestStep("Stat code is-"+statCode);
				report.updateTestLog("Pick Short", "Stat code is" + statCode, Status.PASS);
				se.log.logTestStep("Shorted Units is-"+shortedUnits);
				report.updateTestLog("Pick Short", "Shorted unit is" + shortedUnits, Status.PASS);
				se.log.logTestStep("Chase Wave Number is-"+chaseWave);
				report.updateTestLog("Pick Short", "Chase wave generated"+chaseWave, Status.PASS);
			}

		} catch (Exception ex) {
			report.updateTestLog("Pick Short", "Picking short verification is falied", Status.FAIL);
			throw new WmsCustomException();
		}
		return true;

	}

	public boolean verifyLPN(final Map<String, Object> testdata) throws WmsCustomException {
		try {
			WebDriverWait wait = new WebDriverWait(se.webDriver, globalWaitDefault);
			String taskID = getDataReserver().getAppsData().get("taskID");
			final String taskType = getDataReserver().getAppsData().get("taskType");
			waitForComponent(se, wait, taskIdTextArea);
			se.webDriver.findElement(taskIdTextArea).clear();
			se.webDriver.findElement(taskIdTextArea).sendKeys(taskID);
			se.webDriver.findElement(taskApplyButton).click();
			waitForComponent(se, wait, getHeaderStatus(taskType));
			String headerStatus = se.webDriver.findElement(getHeaderStatus(taskType)).getText();
			if (headerStatus.equalsIgnoreCase((ApplicationKeys.TASK_STATUS_COMPLETE).toString())) {
				report.updateTestLog("Task Header status", "The task Header status is Complete", Status.PASS);

			} else {
				report.updateTestLog("Task Header status", "The task Header status is not Complete", Status.FAIL);
				throw new WmsCustomException();
			}
			waitForComponent(se, wait, getTaskChkbox(taskType));
			se.webDriver.findElement(getTaskChkbox(taskType)).click();
			se.webDriver.findElement(taskViewButton).click();
			waitForComponent(se, wait, LPNTabLink);
			se.webDriver.findElement(LPNTabLink).click();

			String majorDO = getDataReserver().getMajorDOIds().getElement().toString();

			String lpnStatus = se.webDriver.findElement(getlpnFacilityStatus(majorDO)).toString();
			if (lpnStatus.equalsIgnoreCase((ApplicationKeys.TASK_LPN_FACILITY_STATUS).toString())) {
				se.log.logSeStep("LPN status is" + lpnStatus);
				report.updateTestLog("Task Header status", "LPN status is in Packing", Status.PASS);
			} else {
				report.updateTestLog("Task Header status", "LPN status is not in Packing", Status.FAIL);
				throw new WmsCustomException();

			}
		} catch (Exception ex) {
			se.log.logSeStep("LPN verification unsuccessful" + ex.getMessage());

			throw new WmsCustomException();

		}
		return true;
	}
}


