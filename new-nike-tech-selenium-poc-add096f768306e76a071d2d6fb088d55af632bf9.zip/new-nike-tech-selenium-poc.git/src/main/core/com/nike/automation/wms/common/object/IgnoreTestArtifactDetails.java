package com.nike.automation.wms.common.object;


import java.util.ArrayList;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement (name = "ignore-artifacts")
@XmlType(propOrder = {"ignoreDcCodes","ignorePackages","ignoreTestSuites", "ignoreTestCases"})
public class IgnoreTestArtifactDetails {
	ArrayList<String> ignoreDcCodes = new ArrayList<String>();
	ArrayList<String> ignorePackages = new ArrayList<String>();
	ArrayList<String> ignoreTestSuites = new ArrayList<String>();
	ArrayList<String> ignoreTestCases = new ArrayList<String>();
	
	public ArrayList<String> getIgnoreDcCodes() {
		return ignoreDcCodes;
	}
	@XmlElement(name = "ignore-dc")
	public void setIgnoreDcCodes(ArrayList<String> ignoreDcCodes) {
		this.ignoreDcCodes = ignoreDcCodes;
	}
	public ArrayList<String> getIgnorePackages() {
		return ignorePackages;
	}
	@XmlElement(name = "ignore-package")
	public void setIgnorePackages(ArrayList<String> ignorePackages) {
		this.ignorePackages = ignorePackages;
	}
	public ArrayList<String> getIgnoreTestSuites() {
		return ignoreTestSuites;
	}
	@XmlElement(name = "ignore-suite")
	public void setIgnoreTestSuites(ArrayList<String> ignoreTestSuites) {
		this.ignoreTestSuites = ignoreTestSuites;
	}
	public ArrayList<String> getIgnoreTestCases() {
		return ignoreTestCases;
	}
	@XmlElement(name = "ignore-testcase")
	public void setIgnoreTestCases(ArrayList<String> ignoreTestCases) {
		this.ignoreTestCases = ignoreTestCases;
	}
	
	
}
