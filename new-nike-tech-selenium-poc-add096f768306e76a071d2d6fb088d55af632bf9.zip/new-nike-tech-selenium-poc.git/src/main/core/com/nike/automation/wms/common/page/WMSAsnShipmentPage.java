package com.nike.automation.wms.common.page;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cognizant.framework.Status;
import com.google.common.base.Function;
import com.nike.automation.wms.common.util.ApplicationKeys;
import com.nike.automation.wms.common.util.WmsCustomException;

public class WMSAsnShipmentPage extends BasePage {

	public By searchField 			= By.id("dataForm:ASN_filterId:field1value1");
	public By applyButton 			= By.id("dataForm:ASN_filterId:ASN_filterIdapply");
	public By asnCheckbox 			= By.id("dataForm:treeTable:0:treeB:adaptor:0::selectId");
	public By okShipmentButton 		= By.id("dataForm:sv");		
	public By creatShipmentButton 	= By.xpath("//input[@value='Create Shipment ID']");
	public By genShipmentButton 	= By.id("dataForm:gena");
	public By newShipmentText 		= By.id("dataForm:shipmentIdh1");	
	public By shipmentSearchField 	= By.id("dataForm:ShpList_entityListView:Shipmentlist1:field2value1");
	public By shipmentApplyButton 	= By.id("dataForm:ShpList_entityListView:Shipmentlist1:Shipmentlist1apply");
	public By shipmentStatusText 	= By.id("dataForm:ShpList_entityListView:ShpList_MainListTable:0:ShpList_ShpStatus_Output2");
	public By shipmentChkBox 		= By.id("checkAll_c0_dataForm:ShpList_entityListView:ShpList_MainListTable");
	public By errorMsgText 			= By.cssSelector("#er_d1_bid > ul > li");
	public By errorMsgCloseButton 	= By.id("er_d1_c1");
	public By shipmentMoreBtn		= By.id("j_id122moreButton");
	public By initiateShipmentLnk	= By.id("ShipmentList_InitiateShipment_more");
	public By msgCloseBtn			= By.xpath("//*[@id='er_d1_c1']/img");
	public By asnSearchField		= By.id("dataForm:ASNList_entityListView:ASNList_filterId2:field30value1");
	public By asnSearchApplyButton	= By.id("dataForm:ASNList_entityListView:ASNList_filterId2:ASNList_filterId2apply");
	public By lpnTab				= By.id("ASNDetailLPNsTab_lnk");
	public By lpnStatus				= By.id("dataForm:LPNListTable:0:LPNStatus");
	public By asnChkBox				= By.id("checkAll_c0_dataForm:ASNList_entityListView:dataTable");
	public By asnViewBtn			= By.id("dataForm:ASNList_commandbutton_View");
	public By moveRightButton 		= By.xpath("//*[contains(@src,'move_right')]"); // *[@id='dataForm:cb5']
	public By saveButton 			= By.xpath("//*[@value='Save']");
	public By getNewShipmentCheckbox(String str)
	{
		String xpath="//*[contains(text(),'" +str+ "')]/preceding-sibling::input[1]";
		return By.xpath(xpath);
	}
		
	/**
	 * @author Cognizant
	 * @Description Method to open ASN 
	 * @param testdata
	 * @return Boolean
	 */

	public boolean openAssignAsn(Map<String, Object> testdata) {
		WebDriverWait wait = new WebDriverWait(se.webDriver, 20);
		waitForComponent(se, wait, menuLink);
		driver.findElement(menuLink).click();
		driver.findElement(menuText).sendKeys(ApplicationKeys.APPS_MENU_ASSIGN_ASN.toString());
		driver.findElement(menuText).sendKeys(Keys.RETURN);
		report.updateTestLog("ASN Shipment : ", "Navigate to assign ASN to shipment", Status.PASS);
		return true;
	}
	
	/**
	 * @author Cognizant
	 * @Description Method to Assign shipment to ASN
	 * @param testdata
	 * @return Boolean
	 * @throws WmsCustomException 
	 */

	public boolean assignShipmentAsn(Map<String, Object> testdata) throws WmsCustomException {
		WebDriverWait wait = new WebDriverWait(se.webDriver, globalWaitDefault);
		String asnSearchKey = se.getDriver().getDataReserver(getIdentifier()).getAppsData().get("ASNID-1");
		se.log.logTestStep("ASN ID Is"+asnSearchKey);
		System.out.println("ASN ID Is"+asnSearchKey);
		wait.until(ExpectedConditions.visibilityOfElementLocated(searchField));
		se.webDriver.findElement(searchField).sendKeys(asnSearchKey);
		se.webDriver.findElement(applyButton).click();

		waitForComponent(se, wait, asnCheckbox);
		se.element.clickElement(asnCheckbox);

		se.element.clickElement(creatShipmentButton);

		waitForComponent(se, wait, okShipmentButton);

		waitForComponent(se, wait, genShipmentButton);
		se.webDriver.findElement(genShipmentButton).click();
		
		processingDelay(3);
		waitForComponent(se, wait, newShipmentText);
		se.webDriver.findElement(newShipmentText).click();
		String newShipmentID = se.element.getAttribute(newShipmentText, "value");
		se.log.logSeStep("newShipmentID:" + newShipmentID);
		if(newShipmentID==null || "".equals(newShipmentID))
			throw new WmsCustomException("New Shipment ID is empty which is not valid !");
		report.updateTestLog("ASN Shipment : ", "Create shipment", Status.PASS);
		se.getDriver().getDataReserver(getIdentifier()).setAppsData(ApplicationKeys.TRANSIT_SHIPMENT_ID, newShipmentID);
		se.element.clickElement(okShipmentButton);
		String newShpTxt= se.element.getAttribute(newShipmentText, "value");
		waitForComponent(se, wait, getNewShipmentCheckbox(newShpTxt));
		se.webDriver.findElement(getNewShipmentCheckbox(newShpTxt)).click();
		se.element.clickElement(moveRightButton);
		processingDelay(globalWaitMin);
		waitForComponent(se, wait, saveButton);
		se.element.clickElement(saveButton);
		report.updateTestLog("ASN Shipment : ", "Assign ASN to shipment", Status.PASS);
		
		return true;

	}
	
	/**
	 * @author Cognizant
	 * @Description Method to handle the message dialog
	 * @param testdata
	 * @return Boolean
	 */
	public boolean checkMessageDioalog(Map<String, Object> testdata) {
		WebDriverWait wait = new WebDriverWait(se.webDriver, 20);
		se.log.logSeStep("Before JMeter..");
		FluentWait<WebDriver> waitProcess = new FluentWait<WebDriver>(se.webDriver);
		waitProcess.pollingEvery(250, TimeUnit.MILLISECONDS);
		waitProcess.withTimeout(2, TimeUnit.MINUTES);
		waitProcess.ignoring(NoSuchElementException.class);

		Function<WebDriver, String> function = new Function<WebDriver, String>() {
			public String apply(WebDriver arg0) {

				for (int count = 0; count < 5; count++) {
					processingDelay(2);
					se.log.logSeStep("JMeter Processing : " + count);
				}

				return "JMeter Process Done";
			}
		};

		waitProcess.until(function);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(creatShipmentButton));
		se.element.clickElement(creatShipmentButton);

		wait.until(ExpectedConditions.visibilityOfElementLocated(okShipmentButton));
		se.element.waitForElementToBeClickable(okShipmentButton);
		se.webDriver.findElement(okShipmentButton).click();

		wait.until(ExpectedConditions.visibilityOfElementLocated(errorMsgText));
		System.out.println("newShipmentText:" + se.element.getText(errorMsgText));
		se.webDriver.findElement(errorMsgCloseButton).click();

		wait.until(ExpectedConditions.visibilityOfElementLocated(genShipmentButton));
		se.element.waitForElementToBeClickable(genShipmentButton);
		se.webDriver.findElement(genShipmentButton).click();

		se.log.logSeStep("newShipmentText:" + se.element.getAttribute(newShipmentText, "value"));

		se.element.clickElement(okShipmentButton);

		return true;
	}
	
	public boolean verifyShipmentStatus(Map<String, Object> testdata) throws WmsCustomException {
		try
		{
			se.webDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			menuNavigation(ApplicationKeys.APPS_MENU_DISTRIBUTION, ApplicationKeys.APPS_MENU_SHIPMENTS);
			
			WebDriverWait wait = new WebDriverWait(se.webDriver, globalWaitDefault);

			String shipmentNumber = se.getDriver().getDataReserver(getIdentifier()).getAppsData(ApplicationKeys.TRANSIT_SHIPMENT_ID);			
			waitForComponent(se, wait, shipmentSearchField);			
			if(shipmentNumber==null || "".equals(shipmentNumber)){
				throw new WmsCustomException(" Shipment ID is empty which is not valid for search !");
			}
			
			se.webDriver.findElement(shipmentSearchField).sendKeys(shipmentNumber);
			se.webDriver.findElement(shipmentApplyButton).click();
			waitForComponent(se, wait, shipmentStatusText);
			String status = se.webDriver.findElement(shipmentStatusText).getText();
			se.log.logSeStep("Shipment status:"+status);
			se.getDriver().getDataReserver(getIdentifier()).setAppsData(ApplicationKeys.TRANSIT_SHIPMENT_STATUS, status);
			if(status==null||"".equals(status)||!status.contains("In Transit"))
				throw new WmsCustomException("Shipment status is "+ status+", which is not expected");				
			
			report.updateTestLog("Shipment Status", "Shipment ID:"+shipmentNumber+" has been verified with status "+status, Status.PASS);
		} catch (Exception ex) {
			se.log.logTestStep(ex);
			se.log.logTestStep(ex.getMessage());
			report.updateTestLog("Shipment Statu", "Invalid status, " + ex.getMessage(), Status.FAIL);
		}

		return true;
	}

	public boolean initiateShipment(Map<String, Object> params) {
		WebDriverWait wait = new WebDriverWait(se.webDriver, globalWaitDefault);
		waitForComponent(se, wait, shipmentChkBox);
		se.webDriver.findElement(shipmentChkBox).click();
		se.webDriver.findElement(shipmentMoreBtn).click();
		se.webDriver.findElement(initiateShipmentLnk).click();
		se.webDriver.findElement(msgCloseBtn).click();
		
		return true;
	}

	public boolean checkLpnStatus(Map<String, Object> params) {
		try{
			se.webDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(se.webDriver, globalWaitDefault);

			String asnId = se.getDriver().getDataReserver(getIdentifier()).getAppsData(ApplicationKeys.TRANSIT_ASN_1);			
			waitForComponent(se, wait, asnSearchField);				
			if(asnId==null || "".equals(asnId)){
				throw new WmsCustomException(" Asn ID is empty which is not valid for search !");
			}
			
			
			se.webDriver.findElement(asnSearchField).sendKeys(asnId);
			se.webDriver.findElement(asnSearchApplyButton).click();
			waitForComponent(se, wait, asnChkBox);
			se.webDriver.findElement(asnChkBox).click();
			se.webDriver.findElement(asnViewBtn).click();
//			waitForComponent(se, wait, lpnTab);
//			se.myDriver.findElement(lpnTab).click();
//			processingDelay(10);//Used because after clicking LPN tab page is getting hang
//			waitForComponent(se, wait, lpnStatus);
//			String lpnstatus=se.myDriver.findElement(lpnStatus).getText();
//			if("In-Transit".equalsIgnoreCase(lpnstatus)){
//				report.updateTestLog("Check LPN status", "LPN status "+lpnstatus, Status.PASS);
//			}			
		}
		catch(Exception ex){
			ex.printStackTrace();
			se.log.logTestStep(ex);
			se.log.logTestStep(ex.getMessage());
			report.updateTestLog("Check LPN status", "Error while navigation to LPN", Status.FAIL);
		}
		
		return true;
	}
	public boolean checkLpnStatusFinal(Map<String, Object> params) {
		try{
			se.webDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(se.webDriver, globalWaitDefault);

			String asnId = se.getDriver().getDataReserver(getIdentifier()).getAppsData(ApplicationKeys.TRANSIT_ASN_1);			
			waitForComponent(se, wait, asnSearchField);				
			if(asnId==null || "".equals(asnId)){
				throw new WmsCustomException(" Asn ID is empty which is not valid for search !");
			}
			waitForComponent(se, wait, asnSearchField);
			se.webDriver.findElement(asnSearchField).click();
			se.webDriver.findElement(asnSearchField).clear();
			se.webDriver.findElement(asnSearchField).sendKeys(asnId);
			se.webDriver.findElement(asnSearchApplyButton).click();
			waitForComponent(se, wait, asnChkBox);
			se.webDriver.findElement(asnChkBox).click();
			se.webDriver.findElement(asnViewBtn).click();
//			waitForComponent(se, wait, lpnTab);
//			se.webDriver.findElement(lpnTab).click();
//			se.webDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//			waitForComponent(se, wait, lpnStatus);
//			String lpnstatus=se.webDriver.findElement(lpnStatus).getText();
//			if("Inventory NotPutaway".equalsIgnoreCase(lpnstatus)){
//				report.updateTestLog("Check LPN status", "LPN status "+lpnstatus, Status.PASS);
//			}			
		}
		catch(Exception ex){
			ex.printStackTrace();
			se.log.logTestStep(ex);
			se.log.logTestStep(ex.getMessage());
			report.updateTestLog("Check LPN status", "Error while navigation to LPN", Status.FAIL);
		}
		
		return true;
	}

	
}
