package com.nike.automation.wms.common.object;


import java.util.HashMap;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.nike.automation.wms.common.util.ApplicationKeys;

@XmlRootElement (name = "transit-data")
@XmlType(propOrder = {"appsData","asnIds", "taskIds", "doIds","majorDOIds", "lpnIds"})
public class InOutDataReserver {
	private HashMap<String, String> appsData = new HashMap<String, String>();
	private GenericWmsItemList taskIds = new GenericWmsItemList();
	private GenericWmsItemList asnIds = new GenericWmsItemList();
	private GenericWmsItemList doIds = new GenericWmsItemList();
	private GenericWmsItemList majorDOIds = new GenericWmsItemList();
	private GenericWmsItemList lpnIds = new GenericWmsItemList();
	
	public GenericWmsItemList getTaskIds() {
		return taskIds;
	}
	@XmlElement(name = "tasks")
	public void setTaskIds(GenericWmsItemList taskIds) {
		this.taskIds = taskIds;
	}
	public GenericWmsItemList getAsnIds() {
		return asnIds;
	}
	@XmlElement(name = "asns")
	public void setAsnIds(GenericWmsItemList asnIds) {
		this.asnIds = asnIds;
	}
	public GenericWmsItemList getDoIds() {
		return doIds;
	}
	@XmlElement(name = "doIds")
	public void setDoIds(GenericWmsItemList doIds) {
		this.doIds = doIds;
	}
	public GenericWmsItemList getMajorDOIds() {
		return majorDOIds;
	}
	@XmlElement(name = "majorDOIds")
	public void setMajorDOIds(GenericWmsItemList majorDOIds) {
		this.majorDOIds = majorDOIds;
	}
	public HashMap<String, String> getAppsData() {
		return appsData;
	}
	@XmlElement(name = "appsData")
	public void setAppsData(HashMap<String, String> appsData) {
		this.appsData = appsData;
	}	
	
	public String getAppsData(ApplicationKeys key) {
		return appsData.get(key.toString());
	}
	public void setAppsData(ApplicationKeys key, String value) {
		this.appsData.put(key.toString(), value);
	}
	public GenericWmsItemList getLpnIds() {
		return lpnIds;
	}
	public void setLpnIds(GenericWmsItemList lpnIds) {
		this.lpnIds = lpnIds;
	}	
}
