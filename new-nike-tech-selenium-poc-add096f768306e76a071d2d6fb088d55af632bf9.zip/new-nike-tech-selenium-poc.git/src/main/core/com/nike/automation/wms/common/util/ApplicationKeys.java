package com.nike.automation.wms.common.util;

public enum ApplicationKeys {
	APPS_MENU_POST_XML			("Post Message"),
	APPS_MENU_DISTRIBUTION   	("Distribution"),
	APPS_MENU_SEARCH_DISTRIBUTION("Distribution Orders"),
	APPS_MENU_SHIPMENTS   		("Shipments"),
	APPS_MENU_ASN				("ASNs"),
	APPS_MENU_ASSIGN_ASN        ("Assign ASN "),	
	APPS_MENU_TASK				("Tasks"),
	APPS_MENU_ILPN				("iLPNs"),
	APPS_MENU_RF_SCREEN			("RF Menu"),
	APPS_MENU_RUN_WAVES			("Run Waves"),
	APPS_MENU_WAVES				("Waves"),
	APPS_MENU_PICKING_SHORT		("Picking Short"),
	
	TRANSIT_WAVE_NUMBER 		("WaveNumber"),
	TRANSIT_DO_NUMBER 			("DoNumber"),
	TRANSIT_MAJOR_DO_NUMBER		("MajorDo"),
	TRANSIT_SHIPMENT_ID     	("ShipmentID"),
	TRANSIT_SHIPMENT_STATUS     ("ShipmentStatus"),	
	TRANSIT_ASN_1 				("ASNID-1"),
	TRANSIT_TASKID				("taskID"),
	TRANSIT_CONTAINERID 		("ContainerId"),
	TRANSIT_TASK_TYPE			("taskType"),

	TAG_NAME_ASN 				("asn"),
	TAG_NAME_TASK 				("task"),
	TAG_NAME_DO_ID				("DistributionOrderId"),
	TAG_NAME_LPN_ID				("LPNID"),
	TAG_NAME_ASN_ID				("ASNID"),
	
	DO_STATUS_RELEASE			("Release"), 
	DO_STATUS_DRAFT				("Draft"),
	DO_STATUS_ERROR				("Error"),
	ITEMNAME					("Item"),
	DESTINATION_LOCATION		("DestLocation"),
	BAR_CODE					("Barcode"),
	
	DB_QUERY_RESULT_SLOC		("LOCN_BRCD"),
	DB_QUERY_RESULT_DATA		("Data"),
	ALLOCATED_QTY				("AllocatedQty"), 
	TASK_STATUS_RELEASE			("Released"),
	TASK_STATUS_ASSEMBLED		("Task Assembled"),
	TASK_STATUS_COMPLETE		("Complete"),
	TASK_LPN_FACILITY_STATUS	("In packing"),
	
	WAVE_STAT_CODE				("Unprocessed"),
	WAVE_STAT_CODE_FINAL		("Processed"),
	WAVE_SHORTED_ITEM			("1"),
	
	JMETER_PULL_MSG				("PULL"),
	JMETER_DIVERT_MSG			("DIVERT"), 
	JMETER_BIN_PATH_KEY			("JMeter-Bin-Path"),
	JMETER_JMX_FILE_PATH_KEY	("JMeter-JMX-FilePath"), 
	JMETER_RESULT_FILE_PATH_KEY	("JMeter-Result-FilePath"),
	JMETER_TEMP_FILE_PATH_KEY	("JMeter-Temp-Batch-FilePath"),
	SLOT_ID						("Slot_Id"),
	OLPN						("oLPN");
	

	private final String key;       
    private ApplicationKeys(String key) {
        this.key = key;
    }

    public boolean equalsName(String otherkey) {
        return key.equals(otherkey);
    }

    public String toString() {
       return this.key;
    }	
}
