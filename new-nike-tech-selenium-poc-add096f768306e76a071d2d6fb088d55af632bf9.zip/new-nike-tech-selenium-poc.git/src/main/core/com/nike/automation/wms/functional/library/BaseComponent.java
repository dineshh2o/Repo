package com.nike.automation.wms.functional.library;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.xml.bind.JAXBException;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.FluentWait;

import com.cognizant.framework.selenium.CraftDriver;
import com.cognizant.framework.selenium.SeleniumReport;
import com.google.common.base.Function;
import com.nike.automation.wms.common.object.GenericWmsElement;
import com.nike.automation.wms.common.object.InOutDataReserver;
import com.nike.automation.wms.common.util.ApplicationKeys;
import com.nike.automation.wms.common.util.ApplicationSettings;
import com.nike.automation.wms.common.util.JMeterUtil;
import com.nike.automation.wms.common.util.ObjectXMLTransformer;
import com.nike.automation.wms.common.util.StaticXmlUpdater;
import com.nike.automation.wms.common.util.WmsCustomException;

public class BaseComponent {
	protected String identifier;	
	protected CraftDriver driver;	
	protected SeleniumReport report;

	public BaseComponent(){}
	
	public BaseComponent(CraftDriver driver) {
		this.driver = driver;
		this.report = driver.getReport();
		this.identifier=driver.getSessionId().toString();
	}
	
	public String getParamValue(String paramKey){
	    Map<String, Object> params = driver.getTestcaseParams();
		Object paramValue = params.get(paramKey);
	    if(paramValue!=null){
	    	return (String)paramValue;
	    }
	    else{
		    driver.getSelenium().log.logTestStep("Param value not found:"+paramKey);	    	
	    	return "";	    	
	    }
	}
	public void inWardDataLoadExample(CraftDriver driver) throws FileNotFoundException, JAXBException  {
			ObjectXMLTransformer transformer = new ObjectXMLTransformer(ApplicationSettings.INOUT_TRANSIT_PATH);	    
			String inwardDataFile = (String)driver.getTestcaseParams().get("inwardDataFile");
			System.out.println("inwardDataFile:"+inwardDataFile);			
			InOutDataReserver data = (InOutDataReserver) transformer.loadXmlAsbject(inwardDataFile, InOutDataReserver.class);
			if(data!=null)System.out.println(data.getAsnIds().getDetails());			
	}
	public void outWardDataPreserveExample(CraftDriver driver) throws JAXBException, IOException {
		ObjectXMLTransformer transformer = new ObjectXMLTransformer(ApplicationSettings.INOUT_TRANSIT_PATH);
		String outwardDataFile = (String)driver.getTestcaseParams().get("outwardDataFile");
		
		InOutDataReserver reserver = new InOutDataReserver();
		reserver.getTaskIds().getElement().add(new GenericWmsElement("task","101","Task-101"));
		reserver.getTaskIds().getElement().add(new GenericWmsElement("task","102","Task-102"));
		
		reserver.getAsnIds().getElement().add(new GenericWmsElement("asn","2001","3"));
		transformer.preserveObjectAsXml(InOutDataReserver.class, reserver, outwardDataFile);
	}
	
	public boolean processingDelay(final long sec){
		FluentWait<WebDriver> waitProcess = new FluentWait<WebDriver>(driver.getSelenium().webDriver);
		waitProcess.pollingEvery(5000, TimeUnit.MILLISECONDS);
		waitProcess.withTimeout(6, TimeUnit.MINUTES);
		waitProcess.ignoring(NoSuchElementException.class);
		Function<WebDriver, Boolean> function = new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver driver) {
				try {
					Thread.sleep(sec*1000);
				} catch (InterruptedException e) {
					return false;
				}
				return true;
			}
		};
    	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		return waitProcess.until(function);
    }
	
	
	public void updateXmlData(String tcIdentifier, String xmlUpdateTags, ArrayList<HashMap<String, String>> resultList, List<String> columns ) throws WmsCustomException{
		StaticXmlUpdater xmlUpdater = new StaticXmlUpdater(driver.getSelenium().log);
		String xmlLocalTempPath = (getParamValue("Local-XML-Storage")).replaceAll("/", "\\\\");
		DatabaseComponent dbComponent = new DatabaseComponent(driver);
		String localXmlPath = xmlLocalTempPath+"\\"+tcIdentifier+".xml";

		
		switch(tcIdentifier){
		case "OB_1064_PW03AT_HP_20_INT51_Alloc_and_Task_Creation_PROMO":
		{
			//ItemName,CountryOfOrigin,ItemAttribute1,OrderQty
			String[] tags=xmlUpdateTags.split(",");
			String itemNumber=tags[0]; 
			String countryOfOrigin=tags[1]; 
			String itemAttribute1=tags[2];
			String orderQty=tags[3];
						
			String itemNameValue=dbComponent.getRowDetails(resultList, 0, columns.get(0));		
			String countryOfOriginValue=dbComponent.getRowDetails(resultList, 0, columns.get(1));		
			String itemAttribute1Value=dbComponent.getRowDetails(resultList, 0, columns.get(2));		
			String orderQtyValue="2";
			
			try {
				xmlUpdater.updateXmlTagsWithSpecificValue(itemNumber,itemNameValue, localXmlPath);
				xmlUpdater.updateXmlTagsWithSpecificValue(countryOfOrigin,countryOfOriginValue, localXmlPath);
				xmlUpdater.updateXmlTagsWithSpecificValue(itemAttribute1,itemAttribute1Value, localXmlPath);
				xmlUpdater.updateXmlTagsWithSpecificValue(orderQty,orderQtyValue, localXmlPath);
			} catch (Exception e) {
				driver.getSelenium().log.logTestStep("TagError:"+e.getMessage());
			}
		}
			break;
		case "OB_1064NDC_PW03AT_HP_28_INT9_P40_MaxFromDyn":
		{
			String[] tags=xmlUpdateTags.split(",");
			String itemName=tags[0]; 
			String countryOfOrigin=tags[1]; 
			String itemAttribute1=tags[2];
			String orderQty=tags[3];
			
			String itemNameValue=dbComponent.getRowDetails(resultList, 0, columns.get(0));	
			String countryOfOriginValue=dbComponent.getRowDetails(resultList, 0, columns.get(1));
			String itemAttribute1Value=dbComponent.getRowDetails(resultList, 0, columns.get(2));
			Object quatityValue = dbComponent.getRowDetails(resultList, 0, columns.get(3));
			
			if(itemNameValue==null ||countryOfOriginValue==null||itemAttribute1Value==null||quatityValue==null){
				throw new WmsCustomException("Empty value receive from database!");
				
			}
			int qty=Integer.parseInt((String) quatityValue);
			String orderQtyValue=(qty/2) +","+(qty-(qty/2));
			
			try {
			xmlUpdater.updateXmlTagsWithSpecificValue(itemName,itemNameValue+","+itemNameValue, localXmlPath);
			xmlUpdater.updateXmlTagsWithSpecificValue(countryOfOrigin,countryOfOriginValue+","+countryOfOriginValue, localXmlPath);
			xmlUpdater.updateXmlTagsWithSpecificValue(itemAttribute1,itemAttribute1Value+","+itemAttribute1Value, localXmlPath);
			xmlUpdater.updateXmlTagsWithSpecificValue(orderQty,orderQtyValue, localXmlPath);
			} catch (Exception e) {
				driver.getSelenium().log.logTestStep("TagError:"+e.getMessage());
			}
		}
			break;
		default:
			String specificTagName1=xmlUpdateTags.split(",")[0];			
			String specificTagValue1=dbComponent.getRowDetails(resultList, 0, columns.get(0));		
			try {
				xmlUpdater.updateXmlTagsWithSpecificValue(specificTagName1,specificTagValue1, localXmlPath);
			} catch (Exception e) {
				driver.getSelenium().log.logTestStep("TagError:"+e.getMessage());
			}
			
		}		
	}
	
	public boolean sendJmeterMessage(final ApplicationKeys jmeterPullMsg, final String portNo ,WebDriver myDriver) {
		final String taskId=driver.getDataReserver(identifier).getAppsData(ApplicationKeys.TRANSIT_TASKID).toString();
		final String containerID=driver.getDataReserver(identifier).getAppsData(ApplicationKeys.TRANSIT_CONTAINERID).toString();		
		
		FluentWait<WebDriver> waitProcess = new FluentWait<WebDriver>(myDriver);
		waitProcess.pollingEvery(10000, TimeUnit.MILLISECONDS);
		waitProcess.withTimeout(2, TimeUnit.MINUTES);
		waitProcess.ignoring(NoSuchElementException.class);
		Function<WebDriver, String> function = new Function<WebDriver, String>() {
			public String apply(WebDriver arg0) {
				try {
					new JMeterUtil(driver.getTestcaseParams()).sendJmeterMsg(jmeterPullMsg.toString(),taskId,containerID,portNo);
				} catch (WmsCustomException e) {
					driver.getSelenium().log.logTestStep(e);					
				}
				return "JMeter Process Done";
			}
		};
		waitProcess.until(function);
		processingDelay(10);// some delay before checking the status in the application
		return true;
	}
}
