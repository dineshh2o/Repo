package com.nike.automation.wms.common.object;

import java.util.ArrayList;
import javax.xml.bind.annotation.XmlElement;

public class TestCaseQueryDetails {
	private ArrayList<SqlQueryInformation> queryList = new ArrayList<SqlQueryInformation>();

	public ArrayList<SqlQueryInformation> getQueryList() {
		return queryList;
	}

	@XmlElement(name = "query")
	public void setQueryList(ArrayList<SqlQueryInformation> queryList) {
		this.queryList = queryList;
	}
	public String getDetails(){
		String details="";
		for(int i=0;i<queryList.size();i++){
			details+="\n\t"+queryList.get(i).getDetails();
		}
		return details;
	}	
}
