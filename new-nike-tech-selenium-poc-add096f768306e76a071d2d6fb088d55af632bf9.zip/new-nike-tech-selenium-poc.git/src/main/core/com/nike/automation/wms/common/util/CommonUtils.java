package com.nike.automation.wms.common.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.commons.io.FileUtils;

public class CommonUtils {
	public static String getDetails(Class<?> object) {
		long threadID = Thread.currentThread().getId();
		String className = object.getEnclosingClass().getName();
		String methodName = object.getEnclosingMethod().getName().replaceFirst("test_", "");
		return threadID + " - " + className + "." + methodName;
	}

	public static String getPackageName(Class<?> object) {
		return object.getPackage().getName();
	}

	public static String getClassName(Class<?> object) {
		return object.getEnclosingClass().getSimpleName();
	}

	public static String getMethodName(Class<?> object) {
		return object.getEnclosingMethod().getName();
	}

	public static void copyFileUsingStream(File source, File dest) throws IOException {
			InputStream is = null;
			OutputStream os = null;
			try {
				if (dest.exists())
					dest.delete();
				is = new FileInputStream(source);
				os = new FileOutputStream(dest);
				byte[] buffer = new byte[1024];
				int length;
				while ((length = is.read(buffer)) > 0) {
					os.write(buffer, 0, length);
				}
			} finally {
				is.close();
				os.close();
			}
	}
	
	public static void copyFileUsingApacheCommonsIO(File source, File dest) throws IOException {
	    FileUtils.copyFile(source, dest);
	}	
}
