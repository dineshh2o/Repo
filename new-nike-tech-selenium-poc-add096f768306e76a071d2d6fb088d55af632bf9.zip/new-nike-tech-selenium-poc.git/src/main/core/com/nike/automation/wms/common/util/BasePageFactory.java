package com.nike.automation.wms.common.util;

import org.openqa.selenium.support.PageFactory;
import com.cognizant.framework.selenium.CraftDriver;
import com.nike.automation.wms.common.page.BasePage;
import tech.nike.automation.common.framework.core.Selenium;

public class BasePageFactory {

    public static <T> T initElements(CraftDriver driver, java.lang.Class<T> pageClassToProxy) {
        T obj = PageFactory.initElements(driver.getWebDriver(), pageClassToProxy);
        Selenium se = driver.getSelenium();
        se.setDriver(driver);
        se.setWebDriver(driver.getWebDriver());
        
	    //Map<String, Object> params = driver.getTestcaseParams();
	    //String identifier = (String) params.get("identifier");
        
	    String identifier = driver.getSessionId().toString();
	    ((BasePage) obj).setIdentifier(identifier);
        ((BasePage) obj).setDataReserver(driver.getDataReserver(identifier));
        ((BasePage) obj).setWebDriver(se);
        ((BasePage) obj).setRport(driver.getReport());        
        return obj;
    }
    
    public static <T> T initElements(Selenium se, java.lang.Class<T> pageClassToProxy) {
        T obj = PageFactory.initElements(se.webDriver, pageClassToProxy);
        ((BasePage) obj).setWebDriver(se);
        return obj;
    }
}
