package com.nike.automation.wms.common.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Created by psibb1 on 6/23/2016.
 */
public class WMSShipWaveTemplatePage extends BasePage {
    //$= is a tail-string match, that's all. Similarly *= is a partial-substring match, and ^= is a head-string match.
    //locators
    //template page buttons
    public By btnAddTemplate = By.cssSelector("[id*='Add'][class*='button']");
    public By btnDeleteTemplate = By.cssSelector("[id*='Delete'][class*='button']");
    public By txtSearchByDesc = By.cssSelector("[id*='filterId'][type='text']");
    public By btnApply = By.cssSelector("[id$='filterIdapply']");

    //special instructions
    public By lnkSpecialInstructionsTab = By.cssSelector("[title='Special Instructions'] [name^='TAB']");
    public By lstSpecialInstructions = By.cssSelector("[id^='dataForm:glid2'] [id^='dataForm:c']");

    public By lstSpecialInstructionsVer = By.cssSelector("[id^='dataForm:glid1'] [id^='dataForm:c']");
    public By btnSaveSpecialInstructions = By.cssSelector("[id*='TAB2'][value='Save'][type='button']");

    //ship wave table
    public By lblShiWaveTempDesc = By.cssSelector("[id$=':packWaveParmDesc']");
    public By chkShipWaveTemplate = By.cssSelector("[id^='checkAll_c'][type='checkbox']");

    //add template
    public By lnkDetails = By.cssSelector("[title='Details'] [name^='TAB']");
    public By txtTempDesc = By.cssSelector("[id^='dataForm:c'][type='text']");
    public By lstDetailsFields = By.cssSelector("[id^='dataForm:glid1'] [id^='dataForm:c']");
    public By btnSaveTemplate = By.cssSelector("[id*='TAB1'][value='Save'][type='button']");

    //add template buttons
    public By btnAddTempSave = By.cssSelector("#rmButton_1Save2_8882000TAB2_tf");

    public By strtemplateCountCheck = By.cssSelector(".pagerNoWrap:nth-child(2)");
    public By txtsearchTemplate = By.cssSelector("[id*='dataForm:listView:filterId:field1value']");
    public By btnapplySearch = By.cssSelector("[id*='dataForm:listView:filterId:filterIdapply']");
    public By tblsearchResult = By.cssSelector("[id*='dataForm:listView:dataTable'][id*='packWaveParmDesc']");
    public By chkSearchResult = By.cssSelector("[id*='checkAll_c']");
    public By btnsearchResultDelete = By.cssSelector("[id*='rmButton_1Delete1']");


    //offshore change
    //add template
    public By txtAddTempDesc = By.id("dataForm:c11");
    public By lstAddTempPicking = By.id("dataForm:c12");
    public By lstAddTempPickingWaveParam = By.id("dataForm:c21");
    public By lstAddTempOrderConsolidation = By.id("dataForm:c15");
    public By lstAddTempRouting = By.id("dataForm:c13");
    public By lstAddTempRoutingWaveParam = By.id("dataForm:c14");
    public By lstAddTempPulldown = By.id("dataForm:c16");
    public By lstAddTempPulldownWaveParam = By.id("dataForm:c17");

    /**
     * Method to add a new ship wave template
     *
     * @param testdata
     * @return
     */
    public boolean addNewTemplate(Map<String, Object> testdata) {
        boolean result = true;
        String strAddTempDesc = (String) testdata.get("newtempDesc");
        String strAddTempPicking = (String) testdata.get("newtemppicking");
        String strAddTempPickingWaveParam = (String) testdata.get("newtemppickwaveparam");
        String strAddTempOrderConsl = (String) testdata.get("newtemporderConsl");
        String strAddTempRouting = (String) testdata.get("newtemprouting");
        String strAddTempRoutingWaveParam = (String) testdata.get("newtemproutwaveparam");
        String strAddTempPulldown = (String) testdata.get("newtemppulldown");
        String strAddTempPulldownWaveParam = (String) testdata.get("newtemppulldownwaveparam");
        //verify if the template already exists, if exists don't create same template
        boolean blnFound = searchForShipWaveTemplate(testdata);
        if (blnFound != true) {
            //verify if add template button was displayed
            se.element.requireIsDisplayed("Add button field in Ship Wave templates page", btnAddTemplate);
            //verify if the add template button was clickable
            result = se.element.waitForElementToBeClickable(btnAddTemplate);
            //click add template button
            se.element.clickElement(btnAddTemplate);
            //wait for the page load
            se.webDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            //verify if the entered value for the Template description was correctly displayed
            result &= verifyEnteredTextIsCorrectlyDisplayed(txtTempDesc, strAddTempDesc);
            result &= se.webDriver.findElements(lstDetailsFields).size() > 0;
            List<WebElement> weAllOptions = se.element.getElements(lstDetailsFields);
            // verify if the selected value for the Template picking was correctly displayed
            result &= verifySelectedItemCorrectlyDisplayed(weAllOptions.get(2), strAddTempPicking);
            if (strAddTempPicking.equalsIgnoreCase("yes")) {
                //verify if the selected value for the Template picking wave parameter was correctly displayed
                result &= verifySelectedItemCorrectlyDisplayed(weAllOptions.get(4), strAddTempPickingWaveParam);
            }
            //verify if the selected value for the Template order consolidation was correctly displayed
            result &= verifySelectedItemCorrectlyDisplayed(weAllOptions.get(6), strAddTempOrderConsl);
            //verify if the selected value for the Template routing was correctly displayed
            result &= verifySelectedItemCorrectlyDisplayed(weAllOptions.get(1), strAddTempRouting);
            if (strAddTempRouting.equalsIgnoreCase("yes")) {
                //verify if the selected value for the Template routing wave parameters was correctly displayed
                result &= verifySelectedItemCorrectlyDisplayed(weAllOptions.get(3), strAddTempRoutingWaveParam);
            }
            //verify if the selected value for the Template pull down was correctly displayed
            result &= verifySelectedItemCorrectlyDisplayed(weAllOptions.get(5), strAddTempPulldown);
            if (strAddTempPulldown.equalsIgnoreCase("yes")) {
                //verify if the selected value for the Template pull down wave parameter was correctly displayed
                result &= verifySelectedItemCorrectlyDisplayed(weAllOptions.get(7), strAddTempPulldownWaveParam);
            }

            result &= addSpecialInstructions(testdata);

        } else {
            se.log.logSeStep(strAddTempDesc + "  template already exists, ");
            result &= true;
        }
      /*  //verify if save template button was displayed
        se.element.requireIsDisplayed("Save button field in Ship wave templates page", btnSaveTemplate);
        //verify if the save template button was clickable
        result &= se.element.waitForElementToBeClickable(btnSaveTemplate);
        //click save template button
        se.element.clickElement(btnSaveTemplate);*/
        return result;
    }

    /**
     * Method to verify ship wave template details
     *
     * @param testdata
     * @return
     */
    public boolean verifyShipWaveTemplate(Map<String, Object> testdata) {
        String strAddTempDesc = (String) testdata.get("newtempDesc");
        String strAddTempPicking = (String) testdata.get("newtemppicking");
        String strAddTempPickingWaveParam = (String) testdata.get("newtemppickwaveparam");
        String strAddTempOrderConsl = (String) testdata.get("newtemporderConsl");
        String strAddTempRouting = (String) testdata.get("newtemprouting");
        String strAddTempRoutingWaveParam = (String) testdata.get("newtemproutwaveparam");
        String strAddTempPulldown = (String) testdata.get("newtemppulldown");
        String strAddTempPulldownWaveParam = (String) testdata.get("newtemppulldownwaveparam");
        //click on the details tab
        se.element.clickElement(lnkDetails);
        //wait for the page load
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //verify if template details was displayed
        boolean result = se.webDriver.findElements(lstSpecialInstructionsVer).size() > 0;
        List<WebElement> weAllOptions = se.element.getElements(lstSpecialInstructionsVer);
        //get the value for the template description value displayed
        String strDispTempDesc = weAllOptions.get(0).getText().trim();
        //verify is template description was correctly displayed
        result = se.assertion.verifyEquals("Verify template description", strDispTempDesc, strAddTempDesc);
        //get the value of the picking selected for the template
        String strDispTempPicking = weAllOptions.get(2).getText().trim();
        //verify is template picking option was correctly displayed
        result &= se.assertion.verifyEquals("verify picking option selected", strDispTempPicking, strAddTempPicking);
        if (strAddTempPicking.equalsIgnoreCase("yes")) {
            //get the value of the picking wave parameters selected for the template
            String strDispTempPickingWaveParams = weAllOptions.get(4).getText().trim();
            //verify is template picking wave parameters option was correctly displayed
            result &= se.assertion.verifyEquals("verify picking wave parameters option selected",
                    strDispTempPickingWaveParams, strAddTempPickingWaveParam);
        }
        //get the value of the order consolidation selected for the template
        String strDispTempOrderConsl = weAllOptions.get(6).getText().trim();
        //verify is template order consolidation was correctly displayed
        result &= se.assertion.verifyEquals("verify order consolidation option selected",
                strDispTempOrderConsl, strAddTempOrderConsl);
        //get the value of the routing selected for the template
        String strDispTempRouting = weAllOptions.get(1).getText().trim();
        //verify is template routing was correctly displayed
        result &= se.assertion.verifyEquals("verify routing option selected", strDispTempRouting, strAddTempRouting);
        if (strDispTempRouting.equalsIgnoreCase("yes")) {
            //get the value of the routing wave parameters selected for the template
            String strDispTempRoutingWaveParam = weAllOptions.get(3).getText().trim();
            //verify is template routing wave parameters was correctly displayed
            result &= se.assertion.verifyEquals("verify routing wave parameter option selected",
                    strDispTempRoutingWaveParam, strAddTempRoutingWaveParam);
        }
        //get the value of the pull down selected for the template
        String strDispTempPulldown = weAllOptions.get(5).getText().trim();
        //verify is template pull down was correctly displayed
        result &= se.assertion.verifyEquals("verify pull down option selected", strDispTempPulldown, strAddTempPulldown);
        if (strDispTempPulldown.equalsIgnoreCase("yes")) {
            //get the value of the pull down wave parameters selected for the template
            String strDispTempPulldownWaveParam = weAllOptions.get(7).getText().trim();
            //verify is template pull down wave parameters was correctly displayed
            result &= se.assertion.verifyEquals("verify pull down option selected",
                    strDispTempPulldownWaveParam, strAddTempPulldownWaveParam);
        }
        return result;
    }

    /**
     * Method to search for the ship wave template
     *
     * @param testdata
     * @return
     */
    public boolean searchForShipWaveTemplate(Map<String, Object> testdata) {
        //Variable which stores the count of all the templates
        String countLabelOld = se.element.getText(strtemplateCountCheck);

        String strTempDesc = (String) testdata.get("newtempDesc");
        //verify if the search by description field was visible
        se.element.requireIsDisplayed("Search by Description field in Ship Wave Template page", txtSearchByDesc);
        //verify if the search by description field was clickable
        boolean result = se.element.waitForElement(txtSearchByDesc);
        //verify if the entered value in the search description field was displayed correctly
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtSearchByDesc, strTempDesc);
        //verify if the apply button was visible
        result &= se.element.isVisible(btnApply);
        //verify if the apply button was clickable
        result &= se.element.waitForElementToBeClickable(btnApply);
        //click on the apply button
        se.element.clickElement(btnApply);
        //wait for the page load to complete
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
//        //wait for the page to load
//        result &= se.myDriver.findElements(lblShiWaveTempDesc).size() > 0;
//        //verify if the searched ship wave template was successfully displayed
//        List<WebElement> weDescs = se.element.getElements(lblShiWaveTempDesc);
//        if (weDescs.size() > 1) {
//            boolean blnFound = false;
//            for (int i = 0; i < weDescs.size(); i++) {
//                WebElement we = weDescs.get(i);
//                String strText = we.getText().trim();
//                if (strText.equalsIgnoreCase(strTempDesc)) {
//                    se.log.logSeStep("description type in the row # " + i + " was displayed as " + strText +
//                            " description and matches with " + strTempDesc + " description");
//                    blnFound = true;
//                    break;
//                }
//            }
//            if (blnFound != true) {
//                result &= false;
//            }
//        } else {
//            se.log.logSeStep("no records found with template name " + strTempDesc);
//            result &= false;
//        }
        //Verify if the count of all the templates is displayed
        se.element.requireIsDisplayed("Count of Template", strtemplateCountCheck);
        int size = 0;

        //Variable which will store the name of template
        String templateName = strTempDesc;

        while (countLabelOld.equals(se.element.getText(strtemplateCountCheck))) {

        }
        size = se.element.getNumberOfElements(tblsearchResult);
        boolean flag = false;
        for (int i = 0; i < size; i++) {
            if (se.element.getText(tblsearchResult, i).toLowerCase().equals(templateName.toLowerCase()))
                flag = true;
        }
        if (flag != result)
            result = flag;
        return result;
    }

    /**
     * Method to select a ship wave template based on user input
     *
     * @param testdata
     * @return
     */
    public boolean selectShipWaveTemplate(Map<String, Object> testdata) {
        String strTempDesc = (String) testdata.get("newtempDesc");
        //wait for the ship wave table to be loaded
        boolean result = se.element.waitForElement(lblShiWaveTempDesc);
        //wait for the required ship wave table to be displayed
        se.element.requireIsDisplayed("Ship wave Template Desc", lblShiWaveTempDesc);
        //verify if the searched ship wave template was successfully displayed
        List<WebElement> weDescs = se.element.getElements(lblShiWaveTempDesc);
        result &= se.webDriver.findElements(chkShipWaveTemplate).size() > 0;
        List<WebElement> weChks = se.element.getElements(chkShipWaveTemplate);
        boolean blnSelected = false;
        for (int i = 0; i < weChks.size(); i++) {
            String strText = weDescs.get(i).getText().trim();
            if (strText.equalsIgnoreCase(strTempDesc)) {
                se.log.logSeStep("description type in the row # " + i + " was displayed as " + strText +
                        " description and matches with " + strTempDesc + " description");
                //verify if required ship wave template checkbox was displayed
                se.element.requireIsDisplayed("Ship wave template checkbox field", weChks.get(i));
                weChks.get(i).click();
                blnSelected = true;
                break;
            }
        }
        if (blnSelected != true) {
            result &= false;
        }
        return result;
    }

    /**
     * Method to delete ship wave template
     *
     * @param testdata
     * @return
     */
    public boolean deleteShipWaveTemplate(Map<String, Object> testdata) {
        boolean result = true;
        String strTempDesc = (String) testdata.get("newtempDesc");
        String[] arrTempCount = strTempDesc.split(",");
        for (int k = 0; k <= arrTempCount.length; k++) {
            //wait for the page load
            se.webDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            result &= searchForShipWaveTemplate(testdata);
            se.webDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            //select the ship wave to be deleted
            result &= selectShipWaveTemplate(testdata);
            result &= se.webDriver.findElements(lblShiWaveTempDesc).size() > 0;
            //verify if the searched ship wave template was successfully displayed
            List<WebElement> weDescs = se.element.getElements(lblShiWaveTempDesc);
            boolean blnDeleted = false;
            for (WebElement we : weDescs) {
                String strText = we.getText().trim();
                if (strText.equalsIgnoreCase(strTempDesc)) {
                    se.log.logSeStep("description type in the row # " + we.getLocation() + " was displayed as " + strText +
                            " description and matches with " + strTempDesc + " description");
                    //verify if the required delete button was displayed
                    se.element.requireIsDisplayed("Delete button field on ship wave templates page ", btnDeleteTemplate);
                    //click on the delete button
                    se.element.clickElement(btnDeleteTemplate);
                    //wait for the alert to display
                    se.webDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
                    //confirm the delete
                    se.webDriver.switchTo().alert().accept();
                    //return to default content
                    se.element.returnToDefaultContent();
                    //wait for the page to load
                    se.webDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
                    se.log.logSeStep(strTempDesc.toUpperCase() + "  template was successfully deleted");
                    blnDeleted = true;
                    break;
                }
            }
            if (blnDeleted != true) {
                result &= false;
            }
            if (k == arrTempCount.length - 1) {
                break;
            }
        }
        return result;
    }

    /**
     * Method to add special instructions on the shipping wave
     *
     * @param testdata
     * @return
     */
    public boolean addSpecialInstructions(Map<String, Object> testdata) {
        String strInst = (String) testdata.get("specialinstructions");
        boolean result = true;
        //verify if the special instructions tab was displayed
        se.element.requireIsDisplayed("Special Instructions tab field", lnkSpecialInstructionsTab);
        //click on the special instructions tab
        se.element.clickElement(lnkSpecialInstructionsTab);
        //wait for the page load
        se.webDriver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        //get the count of the parameters for special instructions
        String[] arrParamCount = strInst.split(",");
        //verify if the special instructions details were visible
        result = se.webDriver.findElements(lstSpecialInstructions).size() > 0;
        List<WebElement> weLstAllSpecialInstrs = se.element.getElements(lstSpecialInstructions);
        if (arrParamCount[0] != "" || arrParamCount[0] != "(none)") {
            //verify if selected value in instructions1 field was correctly displayed
            result &= verifySelectedItemCorrectlyDisplayed(weLstAllSpecialInstrs.get(0), arrParamCount[0]);
            se.webDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        }
        if (arrParamCount[1] != "" || arrParamCount[1] != "(none)") {
            //verify if selected value in instructions2 field was correctly displayed
            result &= verifySelectedItemCorrectlyDisplayed(weLstAllSpecialInstrs.get(2), arrParamCount[1]);
        }
        if (arrParamCount[2] != "" || arrParamCount[2] != "(none)") {
            //verify if selected value in instructions3 field was correctly displayed
            result &= verifySelectedItemCorrectlyDisplayed(weLstAllSpecialInstrs.get(4), arrParamCount[2]);
            se.webDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        }
        if (arrParamCount[3] != "" || arrParamCount[3] != "(none)") {
            //verify if selected value in instructions4 field was correctly displayed
            result &= verifySelectedItemCorrectlyDisplayed(weLstAllSpecialInstrs.get(1), arrParamCount[3]);
            se.webDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        }
        if (arrParamCount[4] != "" || arrParamCount[4] != "(none)") {
            //verify if selected value in instructions5 field was correctly displayed
            result &= verifySelectedItemCorrectlyDisplayed(weLstAllSpecialInstrs.get(3), arrParamCount[4]);
            se.webDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        }
        //verify if save template button was displayed
        try {


            //verify if save template button was displayed
            se.element.requireIsDisplayed("Save button field in Ship wave templates page", btnAddTempSave);
            //verify if the save template button was clickable
            result &= se.element.isClickable(btnAddTempSave);
            //click save template button
            se.element.clickElement(btnAddTempSave);


//            se.element.requireIsDisplayed("Save button field in Ship wave templates page", btnSaveSpecialInstructions);
//            //verify if the save template button was clickable
//            result &= se.element.waitForElementToBeClickable(btnSaveSpecialInstructions);
//            //click save template button
//            se.element.clickElement(btnSaveSpecialInstructions);
        } catch (Exception e) {

        }
        return result;
    }

    /**
     * Method to verify special instructions
     *
     * @param testdata
     * @return
     */
    public boolean verifySpecialInstructions(Map<String, Object> testdata) {
        String strInst = (String) testdata.get("specialinstructions");
        //wait for the page load
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        String[] arrParamCount = strInst.split(",");
        boolean result = se.webDriver.findElements(lstSpecialInstructions).size() > 0;
        List<WebElement> weLstAllSpecialInstrs = se.element.getElements(lstSpecialInstructions);
        if (arrParamCount[0] == "" || arrParamCount[0].contains("(none)")) {
            result &= true;
        } else {
            //get the instructions1 field text


            System.out.print("TestDisp" + weLstAllSpecialInstrs.get(0).getText().trim());
            String strDispInstr1 = weLstAllSpecialInstrs.get(0).getText().trim();


            //verify if selected value in instructions1 field was correctly displayed
            result &= se.assertion.verifyEquals("verify Instructions1 field data", strDispInstr1, arrParamCount[0]);
        }
        if (arrParamCount[1] == "" || arrParamCount[1].contains("(none)")) {
            result &= true;
        } else {
            //get the instructions2 field text
            String strDispInstr2 = weLstAllSpecialInstrs.get(1).getText().trim();
            //verify if selected value in instructions2 field was correctly displayed
            result &= se.assertion.verifyEquals("verify Instructions2 field data", strDispInstr2, arrParamCount[1]);

        }
        //get the instructions3 field text
        if (arrParamCount[2] == "" || arrParamCount[2].contains("(none)")) {
            result &= true;
        } else {
            String strDispInstr3 = weLstAllSpecialInstrs.get(2).getText().trim();
            //verify if selected value in instructions3 field was correctly displayed
            result &= se.assertion.verifyEquals("verify Instructions2 field data", strDispInstr3, arrParamCount[2]);

        }
        //get the instructions4 field text
        if (arrParamCount[3] == "" || arrParamCount[3].contains("(none)")) {
            result &= true;
        } else {
            String strDispInstr4 = weLstAllSpecialInstrs.get(3).getText().trim();
            //verify if selected value in instructions4 field was correctly displayed
            result &= se.assertion.verifyEquals("verify Instructions4 field data", strDispInstr4, arrParamCount[3]);
        }
        //get the instructions5 field text
        if (arrParamCount[4] == "" || arrParamCount[4].contains("none")) {
            result &= true;
        } else {
            String strDispInstr5 = weLstAllSpecialInstrs.get(4).getText().trim();
            //verify if selected value in instructions5 field was correctly displayed
            result &= se.assertion.verifyEquals("verify Instructions4 field data", strDispInstr5, arrParamCount[4]);
        }
        return result;
    }

    /**
     * method to create a new ship wave template with/without special instructions
     *
     * @param testdata
     * @return
     */
    public boolean createANewShipWaveTemplate(Map<String, Object> testdata) {
        //verify add a ship wave template
        boolean result = addNewTemplate(testdata);
        //add special instructions
        return result;
    }

    /**
     * method to verify the created ship wave template and special instructions
     *
     * @param testdata
     * @return
     */
    public boolean verifyANewShipWaveTemplate(Map<String, Object> testdata) {
        @SuppressWarnings("unused")
		String strTempDesc = (String) testdata.get("newtempDesc");
        //wait for page load
        se.webDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        //verify special instructions
        boolean result = verifySpecialInstructions(testdata);
        //verify a ship wave template
        result &= verifyShipWaveTemplate(testdata);
        return result;
    }

    /**
     * method to delete template
     *
     * @param params
     * @return
     */
    public boolean deleteTemplate(Map<String, Object> params) {
        //Variable which stores the content of Description Search Field
        String text = se.element.getValue(txtsearchTemplate);
        //Variable which stores the count of all the templates
        String countLabelOld = se.element.getText(strtemplateCountCheck);
        boolean result = true;
        if (text.length() > 0) {
            //Variable which stores the count of all the templates
            countLabelOld = se.element.getText(strtemplateCountCheck);
            //verify if the search by description field was visible
            result &= se.element.isVisible(txtsearchTemplate);
            //verify if the search by description field was clickable
            result &= se.element.isClickable(txtsearchTemplate);
            //verify if the entered search template description was correctly displayed
            result &= verifyEnteredTextIsCorrectlyDisplayed(txtsearchTemplate, "");
            se.element.explicitWait(1000);
            //verify if apply button was visible
            result &= se.element.isVisible(btnapplySearch);
            //verify if the apply button was clickable
            result &= se.element.isClickable(btnapplySearch);
            //click on the apply button
            se.element.clickElement(btnapplySearch);
            //wait for the page load to complete
            while (countLabelOld.equals(se.element.getText(strtemplateCountCheck))) {
            }
        }
        //Variable which stores the count of all the templates
        countLabelOld = se.element.getText(strtemplateCountCheck);
        //Variable which will store the name of template
        String templateName = params.get("newtempDesc").toString();
        //verify if the text box for searching was displayed
        se.element.requireIsDisplayed("Search Text box", txtsearchTemplate);
        //verify if text box for searching is clickable
        result &= se.element.isClickable(txtsearchTemplate);
        //click on the textbox and enter Template name to search
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtsearchTemplate, templateName);
        //verify if the Apply button was displayed
        se.element.requireIsDisplayed("Apply Button", btnapplySearch);
        //verify if apply button is clickable
        result &= se.element.isClickable(btnapplySearch);
        //click on the Apply Button
        se.element.clickElement(btnapplySearch);
        //Verify if the count of all the templates is displayed
        se.element.requireIsDisplayed("Count of Template", strtemplateCountCheck);
        //New Variable which stores the count of all the templates after search
        @SuppressWarnings("unused")
		String countLabelNew = se.element.getText(strtemplateCountCheck);
        int size = 0;
        while (countLabelOld.equals(se.element.getText(strtemplateCountCheck))) {
        }
        size = se.element.getNumberOfElements(tblsearchResult);
        int position = 0;
        boolean flag = false;
        for (int i = 0; i < size; i++) {
            if (se.element.getText(tblsearchResult, i).toLowerCase().equals(templateName.toLowerCase())) {
                flag = true;
                break;
            }
            position++;
        }
        if (flag == true) {
            countLabelOld = se.element.getText(strtemplateCountCheck);
            //verify if search result checkbox is displayed
            se.element.requireIsDisplayed("Search Result CheckBox", chkSearchResult, position);
            //verify if the search result checkbox was clikable
            result &= se.element.isClickable(chkSearchResult);
            //Cick SearchResult Checkbox
            result &= se.element.clickElement(chkSearchResult, position);
            //verify if search result delete button is displayed
            se.element.requireIsDisplayed("Delete Button", btnsearchResultDelete);
            //verify if the search result delete button was clikable
            result &= se.element.isClickable(btnsearchResultDelete);
            //Cick search result delete button
            result &= se.element.clickElement(btnsearchResultDelete);
            se.element.explicitWait(500);
            se.element.javaScriptPopUp("yes");
            se.element.explicitWait(500);
            while (countLabelOld.equals(se.element.getText(strtemplateCountCheck))) {
            }
        }

        return result;
    }
}