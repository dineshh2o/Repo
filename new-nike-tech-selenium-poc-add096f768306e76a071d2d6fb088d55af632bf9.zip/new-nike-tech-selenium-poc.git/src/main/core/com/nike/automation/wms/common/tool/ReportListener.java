package com.nike.automation.wms.common.tool;

import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

public class ReportListener extends TestListenerAdapter {

	@Override
	public void onTestStart(ITestResult tr) {
		log("onTestStart");
	}

	@Override
	public void onTestSuccess(ITestResult tr) {
		log("Test '" +tr.getTestClass() + "."+ tr.getName() + "' PASSED");
	}

	@Override
	public void onTestFailure(ITestResult tr) {

		log("Test '"  +tr.getTestClass() + "." + tr.getName() + "' FAILED");
	}

	@Override
	public void onTestSkipped(ITestResult tr) {
		log("Test '"  +tr.getTestClass() + "."+ tr.getName() + "' SKIPPED");
	}

	private void log(String methodName) {
		System.out.println(methodName);
	}
}