package com.nike.automation.wms.common.object;

import java.util.ArrayList;

public class GenericWmsItemList {
	private ArrayList<GenericWmsElement> element= new ArrayList<GenericWmsElement>();

	public ArrayList<GenericWmsElement> getElement() {
		return element;
	}

	public void setElement(ArrayList<GenericWmsElement> element) {
		this.element= element;
	}
	
	public String getDetails(){
		String data="";
		for(int i=0;i<element.size();i++){
			data+=element.get(i).getElementName()+":"+element.get(i).getElementValue()+ " ";
		}
		return data;
	}
}
