package com.nike.automation.wms.common.util;

public class WmsCustomException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public WmsCustomException(){}
	public WmsCustomException(String message){
		super(message);
	}
	
	public WmsCustomException(Throwable cause){
		super(cause);
	}
	
	public WmsCustomException(String message, Throwable cause){
		super(message, cause);
	}
	
	public WmsCustomException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace){
		super(message, cause, enableSuppression, writableStackTrace);
	}
}
