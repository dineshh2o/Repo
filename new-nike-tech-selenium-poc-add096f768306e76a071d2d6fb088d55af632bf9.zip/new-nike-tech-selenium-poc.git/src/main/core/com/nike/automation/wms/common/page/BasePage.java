package com.nike.automation.wms.common.page;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cognizant.framework.Status;
import com.cognizant.framework.selenium.SeleniumReport;
import com.google.common.base.Function;
import com.nike.automation.wms.common.object.InOutDataReserver;
import com.nike.automation.wms.common.util.ApplicationKeys;

import tech.nike.automation.common.framework.core.Selenium;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public abstract class BasePage {

    public Selenium se;
    public SeleniumReport report;
    public WebDriver driver;
    private FluentWait<WebDriver> wait;
	private InOutDataReserver dataReserver;  
	private String identifier; 
	public int globalWaitDefault = 30;
    public int globalWaitAvg = 20;
    public int globalWaitMin = 5;

	public By lnkMenu 			= By.id("phMenu");
	public By menuLink 			= By.id("phMenu");
	public By menuText 			= By.xpath("//*[contains(@id,'as_bas') and contains(@id,'_in')]");   
	public By menuDropSecondEle = By.xpath("//*[@id='as_bas1_dd_1_li']/div/a");
    

    protected WebDriver getDriver() {
        return this.driver;
    }
    
	public void setRport(SeleniumReport report) {
		this.report = report;
	}

	public SeleniumReport getReport() {
		return this.report;
	}    
	
    public InOutDataReserver getDataReserver() {
		return dataReserver;
	}

	public void setDataReserver(InOutDataReserver dataReserver) {
		this.dataReserver = dataReserver;
	}

	protected FluentWait<WebDriver> getWait() {
        return this.wait;
    }

    public void setWebDriver(Selenium se) {
        this.driver = se.webDriver;
        this.se = se;
        this.wait = new WebDriverWait(this.driver, 30).ignoring(StaleElementReferenceException.class).ignoring(NoSuchElementException.class);
    }

    public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	/**
     * Method to validate entered text correctly displayed
     *
     * @param txtLocator
     * @param strText
     * @return
     */
	public boolean verifyEnteredTextIsCorrectlyDisplayed(By txtLocator, String strText) {
		boolean enteredText = true;
		se.log.testStep("Enter search text on to locator " + txtLocator);
		// click on the locator
		se.element.clickElement(txtLocator);
		// enter the text into the text locator field
		se.element.enterText(txtLocator, strText);
		se.log.testStep("Entered search text on to locator " + txtLocator + " as " + strText);
		// get the value displayed on the locator
		String strFieldTextValue = se.element.getAttribute(txtLocator, "value").trim();
		// verify if the entered code id was correctly displayed
		enteredText &= se.assertion.verifyEquals("verify if the user entered text was correctly displayed",
				strFieldTextValue, strText);
		return enteredText;
	}

	public By getLinkText(String strLinkText) {
		return By.linkText(strLinkText);
	}
	/**
	 * 
	 * @author Cognizant
	 * @param strTabName
	 * @return Boolean
	 * @Description Method to verify links by names on wms menus
	 */
	public boolean verifyLinkByName(String strTabName) {
		// wait for the element() to display
		se.element.requireIsDisplayed(strTabName + " link ", getLinkText(strTabName));
		// wait for the element() to be visible
		boolean result = se.element.isVisible(getLinkText(strTabName));
		// wait for the element() to be clickable
		result &= se.element.waitForElementToBeClickable(getLinkText(strTabName));
		return result;
	}
	
	/**
	 * @author Cognizant
	 * @Description Method will allow user to select a wms menu option after navigating into
	 * a menu tab
	 * @return Boolean
	 */
	public boolean selectMenu(String strTabMenuName, String strLinkName) {
		// verify if the main menu is displayed and clickable
		boolean result = verifyLinkByName(strTabMenuName);
		// click on the main link
		se.element.clickElement(getLinkText(strTabMenuName));
		// wait for page load to complete
		se.webDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		// verify if the secondary link was displayed
		result &= verifyLinkByName(strLinkName);
		// click on the secondary link
		se.element.clickElement(getLinkText(strLinkName));
		// report the click sign-out event on to the html report
		se.log.logTestStep("user successfully navigated to " + strTabMenuName + " and then into " + strLinkName);
		return result;
	}    
	
	public boolean menuNavigation(ApplicationKeys primaryMenu, ApplicationKeys secondaryMenu){
		return menuNavigation(primaryMenu.toString(), secondaryMenu.toString());
	}
	
	/**
	 * Method to navigate to system menu
	 *
	 * @return Boolean
	 */
	public boolean menuNavigation(String strPrimaryMenu, String strSecondaryMenu) {
		// verify if the menu link was displayed
		se.element.requireIsDisplayed("Main Menu link", lnkMenu);
		// verify if the menu link was visible
		boolean result = se.element.isVisible(lnkMenu);
		// verify if the menu link was clickable
		result &= se.element.waitForElementToBeClickable(lnkMenu);
		// click on the menu link
		se.element.clickElement(lnkMenu);
		// report the click event on the html report
		se.log.logTestStep("clicked on menu link successfully");
		// verify and click on navigation links
		result &= selectMenu(strPrimaryMenu, strSecondaryMenu);
		// wait for page load to complete
		se.webDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		return result;
	}

    /**
     * Method to validate entered text correctly displayed
     *
     * @param element
     * @param strText
     * @return
     */
	public boolean verifyEnteredTextIsCorrectlyDisplayed(WebElement element, String strText) {
		boolean enteredText = true;
		se.log.testStep("Enter search text on to locator " + element.toString());
		// click on the locator
		element.click();
		// enter the text into the text locator field
		element.sendKeys(strText);
		se.log.testStep("Entered search text on to locator " + element.toString() + " as " + strText);
		// get the value displayed on the locator
		String strFieldTextValue = element.getAttribute("value").trim();
		// verify if the entered code id was correctly displayed
		enteredText &= se.assertion.verifyEquals("verify if the user entered text was correctly displayed",
				strFieldTextValue, strText);
		return enteredText;
	}

    /**
     * Method to validate selected option was correctly displayed
     *
     * @param lstLocator
     * @param strText
     * @return
     */
	public boolean verifySelectedItemCorrectlyDisplayed(By lstLocator, String strText) {
		boolean selectedText = true;
		// select the warehouse
		Select dropdown = new Select(se.webDriver.findElement(lstLocator));
		dropdown.selectByVisibleText(strText);
		WebElement strOption = dropdown.getFirstSelectedOption();
		// get the value of the warehouse selected
		String strSelText = strOption.getText().trim();
		// verify if the user specified value was selected correctly
		selectedText &= se.assertion.verifyEquals("user selection was as correctly selected", strSelText, strText);
		return selectedText;
	}

    /**
     * Method to validate selected option was correctly displayed
     *
     * @param element
     * @param strText
     * @return
     */
	public boolean verifySelectedItemCorrectlyDisplayed(WebElement element, String strText) {
		boolean selectedText = true;
		// select the warehouse
		try {
			Select dropdown = new Select(element);
			dropdown.selectByVisibleText(strText);
			WebElement strOption = dropdown.getFirstSelectedOption();
			// get the value of the warehouse selected
			String strSelText = strOption.getText().trim();
			// verify if the user specified value was selected correctly
			selectedText &= se.assertion.verifyEquals("user selection was as correctly selected", strSelText, strText);

		} catch (Exception e) {
			String strSelText = element.getText();
			// verify if the user specified value was selected correctly
			selectedText &= se.assertion.verifyEquals("user selection was as correctly selected", strSelText, strText);
		}
		return selectedText;
	}


    /**
     * Method to validate selected option was correctly displayed
     *
     * @param lstLocator
     * @param elementPostition
     * @param strText
     * @return
     */
	public boolean verifySelectedItemCorrectlyDisplayed(By lstLocator, int elementPostition, String strText) {
		boolean selectedText = true;
		// select the warehouse
		List<WebElement> list = se.webDriver.findElements(lstLocator);
		Select dropdown = new Select(list.get(elementPostition));
		dropdown.selectByVisibleText(strText);
		WebElement strOption = dropdown.getFirstSelectedOption();
		// get the value of the warehouse selected
		String strSelText = strOption.getText().trim();
		// verify if the user specified value was selected correctly
		selectedText &= se.assertion.verifyEquals("user selection was as correctly selected", strSelText, strText);
		return selectedText;
	}

    /**
     * Method to validate entered text correctly displayed
     *
     * @param txtLocator
     * @param txtLocator
     * @param strText
     * @return
     */
	public boolean verifyEnteredTextIsCorrectlyDisplayed(By txtLocator, int position, String strText) {
		boolean enteredText = true;
		se.log.testStep("Enter search text on to locator " + txtLocator);
		@SuppressWarnings("unused")
		List<WebElement> list = se.webDriver.findElements(txtLocator);
		// click on the locator
		se.element.clickElement(txtLocator, position);
		// enter the text into the text locator field
		se.element.enterText(txtLocator, position, strText);
		se.log.testStep("Entered search text on to locator " + txtLocator + " as " + strText);
		// get the value displayed on the locator
		String strFieldTextValue = se.element.getAttribute(txtLocator, "value", position).trim();
		// verify if the entered code id was correctly displayed
		enteredText &= se.assertion.verifyEquals("verify if the user entered text was correctly displayed",
				strFieldTextValue, strText);
		return enteredText;
	}

    /**
     * Method to get the displayed text from the disabled dropdown
     *
     * @param Locator
     * @return
     */
	public String getSelectedValue(By Locator) {
		Select dropdown = new Select(se.webDriver.findElement(Locator));
		WebElement option = dropdown.getFirstSelectedOption();
		String content = option.getText();
		return content;
	}

    /**
     * Method to get the displayed text from the disabled dropdown
     *
     * @param element
     * @return
     */
    public String getSelectedValue(WebElement element) {
        Select dropdown = new Select(element);
        WebElement option = dropdown.getFirstSelectedOption();
        String content = option.getText();
        return content;
    }
    
	public boolean processingDelay(final long sec) {
		FluentWait<WebDriver> waitProcess = new FluentWait<WebDriver>(driver);
		waitProcess.pollingEvery(5000, TimeUnit.MILLISECONDS);
		waitProcess.withTimeout(6, TimeUnit.MINUTES);
		waitProcess.ignoring(NoSuchElementException.class);
		Function<WebDriver, Boolean> function = new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver driver) {
				try {
					Thread.sleep(sec * 1000);
				} catch (InterruptedException e) {
					return false;
				}
				return true;
			}
		};
		driver.manage().timeouts().implicitlyWait(globalWaitAvg, TimeUnit.SECONDS);
		return waitProcess.until(function);
	}
    
    public void waitForComponent(Selenium se, WebDriverWait wait, By by){
    	driver.manage().timeouts().implicitlyWait(globalWaitDefault, TimeUnit.SECONDS);
		wait.until(ExpectedConditions.visibilityOfElementLocated(by));
		wait.until(ExpectedConditions.elementToBeClickable(by));	
		se.element.waitForElement(by);
    }
    
    public void scrollIntoView(By by){
    	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", se.webDriver.findElement(by));
    }

    /**
	 * @author Cognizant
	 * @Description Method to open the search menu in Home page
	 * @param testdata
	 * @return Boolean
	 */
    
	public boolean openSearchMenu(Map<String, Object> testdata, String searchKey) {
		Object paramValue = testdata.get(searchKey);
		if (paramValue != null && !"".equals(paramValue)) {
			return openSearchMenu(searchKey);
		}
		return false;
	}
	public boolean openSearchMenu(ApplicationKeys key){
		return openSearchMenu(key.toString());
	}

	public boolean openSearchMenu(String searchKey) {
		try {
			se.log.logTestStep("Starting : openSearchMenu");
			WebDriverWait wait = new WebDriverWait(se.webDriver, globalWaitDefault);
			waitForComponent(se, wait, menuLink);
			se.webDriver.findElement(menuLink).click();

			waitForComponent(se, wait, menuText);
			if (se.webDriver.findElement(menuText).equals(null)) {
				se.webDriver.findElement(menuLink).click();
			}
			waitForComponent(se, wait, menuText);
			se.webDriver.findElement(menuText).click();
			se.webDriver.findElement(menuText).sendKeys(searchKey);
			se.webDriver.findElement(menuText).sendKeys(Keys.RETURN);
			report.updateTestLog("Search Menu ", "Search is Successfull", Status.PASS);

		} catch (Exception ex) {
			se.log.logTestStep("Unable to open search menu" + ex.getMessage());
			report.updateTestLog("Search Menu  ", "Unable to open Search menu", Status.FAIL);
		}
		return true;
	}
	public boolean openSearchMenuSpecific(ApplicationKeys key){
		return openSearchMenuSpecific(key.toString());
	}
	/**
	 * @author Cognizant
	 * @Description Method search with specific key
	 * @param testdata
	 * @param key
	 * @return Boolean
	 */
	public boolean openSearchMenuSpecific(Map<String, Object> testdata, String searchKey) {
		Object paramValue = testdata.get(searchKey);		
	    if(paramValue!=null && !"".equals(paramValue)){
	    	return openSearchMenuSpecific(searchKey);
	    }
	    return false;
	}

	public boolean openSearchMenuSpecific(String searchKey) {
		try {
			WebDriverWait wait = new WebDriverWait(se.webDriver, 20);
			wait.until(ExpectedConditions.elementToBeClickable(menuLink));
			se.element.waitForElement(menuLink);
			se.webDriver.findElement(menuLink).click();
			se.webDriver.findElement(menuText).sendKeys(searchKey.toString());
			se.webDriver.findElement(menuDropSecondEle).click();
			report.updateTestLog("Search Menu ", "Search menu :" + searchKey.toString(), Status.PASS);

		} catch (Exception ex) {
			report.updateTestLog("Search Menu  ", "Unable to search the Specific Element," + ex.getMessage(),
					Status.FAIL);

		}
		return true;
	}
}