package com.nike.automation.wms.common.page;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.cognizant.framework.Status;
import com.nike.automation.wms.common.object.GenericWmsElement;
import com.nike.automation.wms.common.util.ApplicationKeys;
import com.nike.automation.wms.common.util.WmsCustomException;

public class WMSWavePage extends BasePage {
	public By routingWaveRadioButton = By.cssSelector("[id*='checkAll_c_dataForm:lview:dataTable']");
	public By chkRunWaveTemplate = By.cssSelector("[id^='checkAll_c'][type='checkbox']");
	public By runWaveButton = By.cssSelector("[id*='rmButton_1RunWave1']");
	public By saveConfiguration = By.cssSelector("[id=rmbuttons_1]>[id*='rmButton_1SaveConfiguration1']");
	public By runWaveSubmitButton = By.cssSelector("[id=rmbuttons_1]>input:nth-child(2)");
	public By runWaveCancelButton = By.cssSelector("[id*='rmButton_1Cancel1']");
	public By waveNumber = By.id("dataForm:AwvNbrRun");
	public By waveStatus = By.xpath("//*[@id='dataForm:listView:dataTable_body_tr0_td3_edit']/span");
	public By refresh = By.xpath("//*[@id='pghdr']/tbody/tr[1]/td[1]/table/tbody/tr/td[8]/a/img");
	public By viewButton = By.cssSelector("#rmButton_2View1_100662000");
	public By pickingWaveStatus = By.xpath("//*[@id='dataForm:glid2']/tbody/tr/td[1]/span[2]");
	public By waveNumberTextArea = By.id("dataForm:listView:filterId:field0value1");
	public By waveApplyButton = By
			.xpath("//*[@id='dataForm:listView:filterId:filterId_quickFilterGroupButton_mainButton']/input");
	public By wavesMoreButton = By.id("rmbuttons_1moreButton");
	public By taskLink = By.id("rmButton_2Tasks1_100668000");
	public By taskType = By.xpath("//*[@id='dataForm:lview:dataTable_body']/tbody/tr/td[3]/span");
//	public By ruleChkBoxList=By.xpath("//*[@id='dataForm:lview:dataTable_120246_body']/tbody/tr/td[3]/div/input");
	public By ruleChkBoxList=By.xpath("//*[contains(@id,'dataForm:lview:dataTable_') and contains(@id,'_body')]/tbody/tr/td[3]/div/input");
	public By taskViewBtn=By.id("rmButton_1View1_167271343");
	public By taskDestLocation=By.id("dataForm:listView:dtlTabList:0:v9");
	public By pickLocItemInputBox=By.id("dataForm:listView:filterId:itemLookUpId");
	public By pickLocNameInputBox=By.id("dataForm:listView:filterId:locationLookUpId");
	public By pickLocFilterApplyBtn=By.id("dataForm:listView:filterId:filterIdapply");
	public By itemDestLocationType=By.id("dataForm:listView:dataTable:0:iddtn");
	public By taskSearchInputBox=By.id("dataForm:lview:filterId:field1value1");
	public By taskSearchbtnApply = By.cssSelector("[id$='filterIdapply'][type='button']");
	public By lblContainerId=By.id("dataForm:Tab1_D28");
	public By btnAssignToAutoRelease=By.id("rmButton_1AssignForAuto-Release1_167271557");
	public By btnAlertOk=By.id("dataForm:autoReleaseOkButton");
	public By ilpnSearchInputBox=By.id("dataForm:LPNListInOutboundMain_lv:LPNList_Inbound_filterId1:field1value1");
	public By ilpnSearchbtnApply = By.id("dataForm:LPNListInOutboundMain_lv:LPNList_Inbound_filterId1:LPNList_Inbound_filterId1apply");
    
    
	
	public By selectroutingWaveTempChkBox(String str) {
		By routingWaveTempChkBox = By.xpath(
				"//*[contains(text(),'" + str + "')]//parent::td/parent::tr/td[1]/input[contains(@type,'checkbox')]");
		return routingWaveTempChkBox;
	}

	public By selectRadioButton(String str) {
		By runWaveButton = By.xpath("//*[contains(text(),'" + str
				+ "')]//parent::td/parent::tr/td[1]/input[@type='radio']");
		return runWaveButton;
	}

	public By getCompvalue(int i) {
		String xpath = "//*[@id='dataForm:ruleSelDtlDataTable:" + i + ":ruleSelDtlRuleCmparValue']";
		return By.xpath(xpath);
	}

	public By getSelectedTempRow(String str) {
		String xpath = "//tr[1][@class='advtbl_row']/td[2]/span[contains(text()," + str + ")]";
		return By.xpath(xpath);

	}

	public By getWaveStatus(String str) {
		String xpath = "//*[@id='dataForm:listView:dataTable_body_tr0_td3_edit']/span[contains(text(),'" + str + "')]";
		return By.xpath(xpath);
	}

	public By getWaveChkBox(String str) {
		String xpath = "//span[contains(text(),'" + str
				+ "')]//parent::div/parent::td/parent::tr/td[1]/input[contains(@type,'checkbox')]";
		return By.xpath(xpath);
	}

	public By getHeaderStatus(String str) {
		String xpath = "//span[contains(text(),'" + str + "')]//parent::td//parent::tr/td[5]/span[1]";
		return By.xpath(xpath);
	}

	public By getWaveCheckBox(String str) {
		String xpath = "//*[contains(text(),'" + str
				+ "')]//parent::div/parent::td/parent::tr/td[1]/input[contains(@type,'checkbox')]";
		return By.xpath(xpath);
	}

	public By getTaskNumber(String str) {
		String xpath = "//span[contains(text(),'" + str + "')]//parent::td//parent::tr/td[2]/span[1]";
		return By.xpath(xpath);
	}

	public By getPriority(String str) {
		String xpath = "//span[contains(text(),'" + str + "')]//parent::td//parent::tr/td[4]/span";
		return By.xpath(xpath);
	}

	public By getItem(String str) {
		String xpath = "//span[contains(text(),'" + str + "')]//parent::td//parent::tr/td[7]/a";
		return By.xpath(xpath);
	}

	public By getInventoryNeedType(String str) {
		String xpath = "//span[contains(text(),'" + str + "')]//parent::td//parent::tr/td[14]/span[1]";
		return By.xpath(xpath);
	}
	
	public By getTaskChkbox(String str){
    	String xpath="//*[contains(text(),'"+str+"')]//parent::td//parent::tr/td[1]/input[contains(@type,'checkbox')]";
    	return By.xpath(xpath);
    }
	 public By getTaskStatus(String str)
	    {
	    	String xpath="//span[contains(text(),'"+str+"')]//parent::td//parent::tr/td[5]/span";
	    	return By.xpath(xpath);
	    }
	
	public By selectRuleChkbox(String str)
    {
    	return By.xpath("//*[contains(text(),'"+str+"')]//parent::td/parent::tr/td[3]/div/input");    	 
    }
	public By getIlpnCurrentLocation(String str)
    {
    	return By.xpath("//*[contains(text(),'"+str+"')]//parent::td/parent::tr/td[4]/div/span");    	 
    }

	/**
	 * @author RPand8
	 * @param testdata
	 * @param waveType
	 * @return Boolean
	 * @throws WmsCustomException
	 * @Description This method selects the proper wave template for both
	 *              Routing and picking waves
	 */
	public boolean selectWaveTemplate(Map<String, Object> testdata, String waveType) throws WmsCustomException {

		try {
			se.log.logTestStep("Starting Template selection");
			WebDriverWait wait = new WebDriverWait(se.webDriver, globalWaitDefault);
			String template = (String) testdata.get(waveType + "Template");
			waitForComponent(se, wait, selectroutingWaveTempChkBox(template));
			processingDelay(6);
			se.webDriver.findElement(selectroutingWaveTempChkBox(template)).click();
			report.updateTestLog("Template Selection", "" + template + " selected Succesfully", Status.PASS);
			waitForComponent(se, wait, runWaveButton);
			se.element.clickElement(runWaveButton);
			report.updateTestLog("Run Wave Button", "Run wave button clicked", Status.PASS);
		} catch (Exception ex) {
			se.log.logTestStep("Wave template selection is not successfull"+ex.getMessage());
			report.updateTestLog("Template Selection", "Wave template selection is not successfull", Status.FAIL);
			throw new WmsCustomException(ex);
		}

		return true;
	}

	/**
	 * @author Cognizant
	 * @param testdata
	 * @param waveType
	 * @return Boolean
	 * @throws WmsCustomException
	 * @Description Method selects the appropriate rule and Sends DO numbers to
	 *              the comparison values
	 */
	public boolean selectRule(Map<String, Object> testdata, String waveType) throws WmsCustomException {
		try {
			WebDriverWait wait = new WebDriverWait(se.webDriver, globalWaitDefault);
			se.webDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			processingDelay(4);
			String rule = (String) testdata.get(waveType + "Rule");
			waitForComponent(se, wait, selectRadioButton(rule));
			se.webDriver.findElement(selectRadioButton(rule)).click();

			processingDelay(4);
			List<WebElement> lstChkBox = se.element.getElements(ruleChkBoxList);
			for (WebElement chkBox : lstChkBox) {
				if (chkBox.isSelected()) {
					chkBox.click();
				}
			}

			se.element.clickElement(selectRadioButton(rule));
			se.webDriver.findElement(selectRadioButton(rule)).click();
			processingDelay(5);
			waitForComponent(se, wait, selectRuleChkbox(rule));
			se.webDriver.findElement(selectRuleChkbox(rule)).click();
			report.updateTestLog("Rule Selection", "Rule Selection is  successfull", Status.PASS);
			List<GenericWmsElement> doNoList = se.getDriver().getDataReserver(getIdentifier()).getDoIds().getElement();
			String doNo = "";
			for (GenericWmsElement doNoObj : doNoList) {
				if (doNo.equalsIgnoreCase(""))
					doNo = doNoObj.getElementValue();
				else
					doNo = doNo + "," + doNoObj.getElementValue();
			}
			String[] dos = doNo.split(",");
			String compData1 = dos[0].substring(0, 4);
			processingDelay(4);
			waitForComponent(se, wait, getCompvalue(1));
			scrollIntoView(getCompvalue(1));
			wait.until(ExpectedConditions.elementToBeClickable(getCompvalue(1)));

			for (int i = 0; i < dos.length; i++) {

				String dcCode = (String) se.getDriver().getTestcaseParams().get("dcCode");
				if (i == 0 && !dcCode.equalsIgnoreCase("HAM")) {
					se.webDriver.findElement(getCompvalue(0)).click();
					se.webDriver.findElement(getCompvalue(0)).clear();
					se.webDriver.findElement(getCompvalue(0)).sendKeys(compData1);

				}
				se.element.waitForElement(getCompvalue(i + 1));
				se.webDriver.findElement(getCompvalue(i + 1)).clear();
				se.webDriver.findElement(getCompvalue(i + 1)).sendKeys(dos[i]);

			}
			report.updateTestLog("Comparison Value", "Comparison value setting is done", Status.PASS);
			waitForComponent(se, wait, runWaveSubmitButton);
			se.webDriver.findElement(runWaveSubmitButton).click();
			processingDelay(4);
			waitForComponent(se, wait, waveNumber);
			se.webDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			se.webDriver.findElement(waveNumber).click();

			while (!se.webDriver.findElement(waveStatus).getText().equalsIgnoreCase("Ship Wave completed")) {
				se.webDriver.findElement(refresh).click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(refresh));
				wait.until(ExpectedConditions.elementToBeClickable(refresh));
				se.element.clickElement(refresh);
				se.log.logTestStep("done refresh");
				processingDelay(20);
			}

			// String status = (String) testdata.get("status");
			wait.until(ExpectedConditions.visibilityOfElementLocated(getWaveChkBox("Ship wave completed")));
			wait.until(ExpectedConditions.elementToBeClickable(getWaveChkBox("Ship wave completed")));
			

		} catch (Exception ex) {
			report.updateTestLog("Rule Selection", "Rule Selection is  Unsuccessfull", Status.FAIL);
			throw new WmsCustomException(ex);
		}

		return true;
	}

	@SuppressWarnings("unused")
	private boolean doReleaseStatusChk(String taskType, String status) {
		while (!se.webDriver.findElement(getHeaderStatus(taskType)).getText().equalsIgnoreCase(status)) {
			se.webDriver.findElement(refresh).click();
		}
		return true;
	}

	/**
	 * @author Cognizant
	 * @param testdata
	 * @return Boolean
	 * @throws WmsCustomException
	 * @description Selects the appropriate rule for Picking wave
	 */
	public boolean selectRulePicking(final Map<String, Object> testdata) throws WmsCustomException {
		try {
			WebDriverWait wait = new WebDriverWait(se.webDriver, globalWaitAvg);
			se.webDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			String rule = (String) testdata.get("pickRule");
			processingDelay(4);
			wait.until(ExpectedConditions.elementToBeClickable(selectRadioButton(rule)));		
			se.webDriver.findElement(selectRadioButton(rule)).click();
			
			wait.until(ExpectedConditions.elementToBeClickable(selectRuleChkbox(rule)));			
			se.webDriver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
			processingDelay(4);
			List<WebElement> lstChkBox=se.element.getElements(ruleChkBoxList);
			 for(WebElement chkBox:lstChkBox ){
				 if(chkBox.isSelected()){
					 chkBox.click();
				 }
			 }
			se.webDriver.findElement(selectRuleChkbox(rule)).click();
			report.updateTestLog("Rule Selection", "Rule selected", Status.PASS);

			List<GenericWmsElement> mdoNoList=se.getDriver().getDataReserver(getIdentifier()).getMajorDOIds().getElement();
			if (mdoNoList == null || "".equals(mdoNoList))
				throw new WmsCustomException("Major Do number is empty which is invalid");
			String mdoNo="";
			for(GenericWmsElement mdoNoObj:mdoNoList){
				if(mdoNo.equalsIgnoreCase(""))
					mdoNo=mdoNoObj.getElementValue();
				else
					mdoNo=mdoNo+","+mdoNoObj.getElementValue();
			}
			String[] mdos = mdoNo.split(",");

			for (int i = 0; i < mdos.length; i++) {
				String dcCode=(String) se.getDriver().getTestcaseParams().get("dcCode");
					if("HAM".equalsIgnoreCase(dcCode)){
						se.element.waitForElement(getCompvalue(i + 6));
						se.webDriver.findElement(getCompvalue(i + 6)).clear();
						se.webDriver.findElement(getCompvalue(i + 6)).sendKeys(mdos[i]);
					}else {
						se.element.waitForElement(getCompvalue(i + 1));
						se.webDriver.findElement(getCompvalue(i + 1)).clear();
						se.webDriver.findElement(getCompvalue(i + 1)).sendKeys(mdos[i]);
					}
					
				}
			waitForComponent(se, wait, runWaveSubmitButton);
			se.webDriver.findElement(runWaveSubmitButton).click();

			waitForComponent(se, wait, waveNumber);
			processingDelay(globalWaitMin);
			
			String waveNo = se.webDriver.findElement(waveNumber).getText();
			report.updateTestLog("Wave Number", "Wave Number is"+waveNo, Status.PASS);
			getDataReserver().setAppsData(ApplicationKeys.TRANSIT_WAVE_NUMBER, waveNo);
			se.webDriver.findElement(waveNumber).click();
			processingDelay(globalWaitMin);
			waitForComponent(se, wait, waveStatus);

			while (!se.webDriver.findElement(waveStatus).getText().equalsIgnoreCase("Ship Wave completed")) {
				waitForComponent(se, wait, refresh);
				se.webDriver.findElement(refresh).click();
				se.log.logTestStep("done refresh");
				processingDelay(globalWaitAvg);
			}
			report.updateTestLog("Ship wave Status", "Ship Wave completed", Status.PASS);
			String status = (String) testdata.get("status");
			waitForComponent(se, wait, getWaveChkBox(status));
			processingDelay(3);
			se.webDriver.findElement(getWaveChkBox(status)).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(viewButton));
			se.webDriver.findElement(viewButton).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(pickingWaveStatus));
			String waveStatus = (String) testdata.get("waveStatus");
			if (se.webDriver.findElement(pickingWaveStatus).getText().equals(waveStatus)) {
				report.updateTestLog("DO Creation",
						"Wave Pick wave status is" + se.webDriver.findElement(pickingWaveStatus).getText(), Status.PASS);
			}

		} catch (Exception ex) {
			se.log.logTestStep("Picking wave rule selection and Comparison value set is not successful");
			report.updateTestLog("Picking Rule selection", "Picking Rule selection is unsuccessful", Status.FAIL);
			throw new WmsCustomException(ex);
		}

		return true;
	}

	/**
	 * @author Cognizant
	 * @param testdata
	 * @return Boolean
	 * @throws WmsCustomException
	 * @description Generates task after Picking wave
	 */

	public boolean validateGeneratedTask(Map<String, Object> testdata) throws WmsCustomException {
		try {
			WebDriverWait wait = new WebDriverWait(se.webDriver, globalWaitDefault);
			String waveNumber = getDataReserver().getAppsData(ApplicationKeys.TRANSIT_WAVE_NUMBER);
			wait.until(ExpectedConditions.visibilityOfElementLocated(waveNumberTextArea));
			se.webDriver.findElement(waveNumberTextArea).clear();
			se.webDriver.findElement(waveNumberTextArea).sendKeys(waveNumber);
			waitForComponent(se, wait, waveApplyButton);
			se.webDriver.findElement(waveApplyButton).click();
			processingDelay(5);
			wait.until(ExpectedConditions.visibilityOfElementLocated(getWaveCheckBox(waveNumber)));
			wait.until(ExpectedConditions.elementToBeClickable(getWaveCheckBox(waveNumber)));
			se.webDriver.findElement(getWaveCheckBox(waveNumber)).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(wavesMoreButton));
			se.webDriver.findElement(wavesMoreButton).click();
			se.webDriver.findElement(taskLink).click();
			String expTaskType = (String) testdata.get("taskType");
			String priority = (String) testdata.get("priority");
			String inventoryNeedType=(String) testdata.get("inventoryNeedType");
			List<WebElement> taskTypeList = se.webDriver.findElements(taskType);
			for (WebElement taskType : taskTypeList) {
				if (taskType.getText().equalsIgnoreCase(expTaskType)) {
					getDataReserver().getAppsData().put("taskType", taskType.getText());
					report.updateTestLog("Task Type ", "" + taskType.getText(), Status.PASS);
						getDataReserver().getAppsData().put("taskID", se.webDriver.findElement(getTaskNumber(expTaskType)).getText());
						report.updateTestLog("Task ID ",
								"" + se.webDriver.findElement(getTaskNumber(expTaskType)).getText(), Status.PASS);
					}
					if (se.webDriver.findElement(getPriority(expTaskType)).getText().equalsIgnoreCase(priority)) {
						getDataReserver().getAppsData().put("Priority", se.webDriver.findElement(getPriority(expTaskType)).getText());
						report.updateTestLog("Priority",
								"" + se.webDriver.findElement(getPriority(expTaskType)).getText(), Status.PASS);
					}
					else
					{
						report.updateTestLog("Priority ",
								"Unable to Fetch Priority" , Status.FAIL);
					}
					if (!se.webDriver.findElement(getItem(expTaskType)).getText().equalsIgnoreCase(null)) {
						getDataReserver().getAppsData().put("Item", se.webDriver.findElement(getItem(expTaskType)).getText());
						report.updateTestLog("Item", "" + se.webDriver.findElement(getItem(expTaskType)).getText(),
								Status.PASS);
					}
					else
					{
						report.updateTestLog("Item ",
								"Unable to Fetch Item" , Status.FAIL);
					}
					
					scrollIntoView(getInventoryNeedType(expTaskType));
					if (se.webDriver.findElement(getInventoryNeedType(expTaskType)).getText()
							.equalsIgnoreCase(inventoryNeedType)) {
						getDataReserver().getAppsData().put("invNeedType", se.webDriver.findElement(getInventoryNeedType(expTaskType)).getText());
						report.updateTestLog("Inventory Need Type",
								"" + se.webDriver.findElement(getInventoryNeedType(expTaskType)).getText(), Status.PASS);
						scrollIntoView(getTaskChkbox(expTaskType));
					}
					else
					{
						report.updateTestLog("Inventory Need Type ",
								"Unable to Fetch Inventory Need Type" , Status.FAIL);
					}					
					
					break;
				}

		} catch (Exception ex) {
			report.updateTestLog("Task Gen", "Task not Generated", Status.FAIL);
			throw new WmsCustomException(ex);
		}

		return true;

	}
	public boolean validateDestinationLocation(Map<String, Object> testdata) throws WmsCustomException{
		WebDriverWait wait = new WebDriverWait(se.webDriver, 30);
		String expTaskType = (String) testdata.get("taskType");
		se.webDriver.findElement(getTaskChkbox(expTaskType)).click();
		se.webDriver.findElement(taskViewBtn).click();	
		waitForComponent(se, wait, taskDestLocation);
		String item=getDataReserver().getAppsData(ApplicationKeys.ITEMNAME);
		String destLocation=se.webDriver.findElement(taskDestLocation).getText();
		if (destLocation == null || "".equals(destLocation))
			throw new WmsCustomException("Could not find the destination location");
		getDataReserver().setAppsData(ApplicationKeys.DESTINATION_LOCATION, destLocation);	 
		se.element.waitForElement(menuLink);
		se.webDriver.findElement(menuLink).click();
		se.webDriver.findElement(By.xpath("//*[@id='MIDP106']/span/a")).click();
		se.webDriver.findElement(By.xpath("//*[@id='MIDP195']/a")).click();	
		waitForComponent(se, wait, pickLocItemInputBox);
		se.element.waitForElement(pickLocItemInputBox);
		se.webDriver.findElement(pickLocItemInputBox).click();
		se.webDriver.findElement(pickLocItemInputBox).clear();
		se.webDriver.findElement(pickLocItemInputBox).sendKeys(item);
		se.webDriver.findElement(pickLocNameInputBox).click();
		se.webDriver.findElement(pickLocNameInputBox).clear();
		se.webDriver.findElement(pickLocNameInputBox).sendKeys(destLocation);
		se.webDriver.findElement(pickLocFilterApplyBtn).click();
		waitForComponent(se, wait, itemDestLocationType);
		processingDelay(3);
		String destLocationType=se.webDriver.findElement(itemDestLocationType).getText();
		if (destLocationType.equalsIgnoreCase("Temporary")) {
			report.updateTestLog("Destination Location Type","" + destLocationType, Status.PASS);
		}
		else{
			report.updateTestLog("Destination Location Type ",""+ destLocationType , Status.FAIL);
		}	
		
			 
		return true;
	}

	public boolean searchAndReleaseTask(Map<String, Object> params) {
		WebDriverWait wait = new WebDriverWait(se.webDriver, 30);
		String taskId=getDataReserver().getAppsData(ApplicationKeys.TRANSIT_TASKID).toString();		
		report.addTestLogSubSection("Step : Release task :" + taskId);
		openSearchMenuSpecific(ApplicationKeys.APPS_MENU_TASK);
			
		searchTask(taskId);
		waitForComponent(se, wait, getTaskStatus(taskId));
		String taskStatus=se.webDriver.findElement(getTaskStatus(taskId)).getText();
		report.updateTestLog("Task Status", "Task Status :"+taskStatus, Status.PASS);
			
		if(!"Released".equalsIgnoreCase(taskStatus)){
			
			waitForComponent(se, wait, getTaskChkbox(taskId));
			se.webDriver.findElement(getTaskChkbox(taskId)).click();
			
			waitForComponent(se, wait,btnAssignToAutoRelease);
			se.webDriver.findElement(btnAssignToAutoRelease).click();
			waitForComponent(se, wait,btnAlertOk);
			se.webDriver.findElement(btnAlertOk).click();
		}
		
		waitForComponent(se, wait, getTaskStatus(taskId));
		while (!se.webDriver.findElement(getTaskStatus(taskId)).getText().equalsIgnoreCase(ApplicationKeys.TASK_STATUS_RELEASE.toString())) {
			waitForComponent(se, wait, refresh);
			se.webDriver.findElement(refresh).click();
			se.log.logTestStep("done refresh");
			processingDelay(globalWaitAvg);
		}
		
		waitForComponent(se, wait, getTaskStatus(taskId));
		taskStatus=se.webDriver.findElement(getTaskStatus(taskId)).getText();
		report.updateTestLog("Release Task", "Task Status :"+taskStatus, Status.PASS);
		processingDelay(globalWaitAvg);//wait before verifying message in DB
		return true;
	}

	private void searchTask(String taskId) {
		WebDriverWait wait = new WebDriverWait(se.webDriver, 30);		
		wait.until(ExpectedConditions.elementToBeClickable(taskSearchInputBox));
		se.webDriver.findElement(taskSearchInputBox).clear();
		se.webDriver.findElement(taskSearchInputBox).sendKeys(taskId);
		se.webDriver.findElement(taskSearchbtnApply).click();
		wait.until(ExpectedConditions.elementToBeClickable(getTaskChkbox(taskId)));
		report.updateTestLog("Search task","Search task :" + taskId, Status.PASS);		
	}

	public boolean getContainerID(Map<String, Object> params) {
		se.log.logTestStep(getIdentifier());
		String taskId=se.getDriver().getDataReserver(getIdentifier()).getAppsData(ApplicationKeys.TRANSIT_TASKID).toString();
		report.addTestLogSubSection("Step : Search for the task :" + taskId);		
		searchTask(taskId);		
		
		se.webDriver.findElement(getTaskChkbox(taskId)).click();
		se.webDriver.findElement(taskViewBtn).click();
		
		String containerID=se.webDriver.findElement(lblContainerId).getText();
		getDataReserver().setAppsData(ApplicationKeys.TRANSIT_CONTAINERID, containerID);
		report.updateTestLog("Get Container id", "Container id :" +containerID,Status.PASS);
		return true;
	}

	

	public boolean validateTaskStatus(ApplicationKeys expectedTaskStatus) {
		WebDriverWait wait = new WebDriverWait(se.webDriver, globalWaitDefault);
		String taskId=getDataReserver().getAppsData(ApplicationKeys.TRANSIT_TASKID).toString();
		report.addTestLogSubSection("Step : Verify task status :" + taskId);
		if(se.element.exists(getTaskStatus(taskId))){
			se.webDriver.findElement(refresh).click();	
		}else{
			searchTask(taskId);
		}
		waitForComponent(se, wait, getTaskStatus(taskId));
		String taskStatus=se.webDriver.findElement(getTaskStatus(taskId)).getText();
		if(taskStatus.equalsIgnoreCase(expectedTaskStatus.toString())){
			report.updateTestLog("Verify Task", "Expected task status :"+expectedTaskStatus.toString()+" Actual Task Status :"+taskStatus, Status.PASS);
		}else{
			report.updateTestLog("Verify Task", "Expected task status :"+expectedTaskStatus.toString()+" Actual Task Status :"+taskStatus, Status.FAIL);
		}
		return true;
	}

	public boolean verifyIlpnCurrentLocation(Map<String, Object> params) {
		String containerID=getDataReserver().getAppsData(ApplicationKeys.TRANSIT_CONTAINERID).toString();
		openSearchMenu(ApplicationKeys.APPS_MENU_ILPN);
		searchIlpn(containerID);
		String currentLocation=se.webDriver.findElement(getIlpnCurrentLocation(containerID)).getText();
		report.updateTestLog("Search iLPN","iLPN Current location : " + currentLocation, Status.PASS);
		return true;
	}

	public void searchIlpn(String ilpnNo) {
		WebDriverWait wait = new WebDriverWait(se.webDriver, 30);		
		wait.until(ExpectedConditions.elementToBeClickable(ilpnSearchInputBox));
		se.webDriver.findElement(ilpnSearchInputBox).clear();
		se.webDriver.findElement(ilpnSearchInputBox).sendKeys(ilpnNo);
		se.webDriver.findElement(ilpnSearchbtnApply).click();
		report.updateTestLog("Search iLPN","Search iLPN :" + ilpnNo, Status.PASS);		
	}

}
