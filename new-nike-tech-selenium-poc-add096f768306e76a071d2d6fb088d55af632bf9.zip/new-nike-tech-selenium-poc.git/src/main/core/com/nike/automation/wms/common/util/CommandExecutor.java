package com.nike.automation.wms.common.util;

import java.io.IOException;
import java.util.ArrayList;

public class CommandExecutor {
	ArrayList<String> commands = new ArrayList<String>();

	public CommandExecutor(ArrayList<String> commands) {
		this.commands = commands;
	}

	public static String execute(String batFile) throws IOException, InterruptedException {
		Process process = Runtime.getRuntime().exec("cmd /c start /wait " + batFile);
		System.out.println("Waiting for result...");
		process.waitFor();
		System.out.println("Batch execution done!");

		return "Done";
	}

	public static void main(String[] args) {
		try {
			CommandExecutor.execute("D:\\Users\\temp.bat");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
