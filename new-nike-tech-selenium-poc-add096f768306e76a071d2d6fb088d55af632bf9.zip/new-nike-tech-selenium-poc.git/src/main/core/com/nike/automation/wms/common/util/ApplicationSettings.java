package com.nike.automation.wms.common.util;

import java.util.Map.Entry;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

import com.cognizant.framework.Settings;

public class ApplicationSettings {

	public static String INOUT_TRANSIT_PATH = "src/test/resources/wms/ext";
	public static String QUERY_STORAGE_PATH = "src/test/resources/wms/sql";
	public static String QUERY_STORAGE_XML = "QueryLibrary.xml ";
	
	private static ConcurrentHashMap<String, Object> appsSetting;

	private ApplicationSettings() {
	}

	public static ConcurrentHashMap<String, Object> getSettings() {
		if (appsSetting == null) {
			appsSetting = new ConcurrentHashMap<String, Object>();
			Properties properties = Settings.getInstance();

			for (Entry<Object, Object> x : properties.entrySet()) {
				appsSetting.put((String) x.getKey(), (String) x.getValue());
			}
		}
		return appsSetting;
	}
}
