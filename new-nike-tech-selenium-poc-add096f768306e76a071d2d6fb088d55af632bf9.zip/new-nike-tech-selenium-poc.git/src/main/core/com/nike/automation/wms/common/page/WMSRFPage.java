package com.nike.automation.wms.common.page;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.cognizant.framework.Status;
import com.nike.automation.wms.common.object.GenericWmsElement;
import com.nike.automation.wms.common.util.ApplicationKeys;
import com.nike.automation.wms.common.util.WmsCustomException;
import tech.nike.automation.common.framework.core.Data;

public class WMSRFPage extends BasePage{
	    public By rfUserName 			= By.xpath("//input[@name='j_username']");
	    public By rfPassword			= By.xpath("//input[@name='j_password']");
	    public By rfSignIn 				= By.xpath("//input[@type='submit' and @value='Enter']");
	    
	    public By rfInfoIncon 			= By.id("tb_567");    
	    public By rfRefresh 			= By.xpath("//*[@value='Refresh']");
	    public By rfExit 				= By.xpath("//*[@value='Exit']");
	    
	    public By rfClearCache 			= By.xpath("//*[@value='Clear Menu Cache']");
	    public By rfChoice 				= By.id("dataForm:it_1");
	    public By rfReceiving 			= By.linkText("RECEIVING");
	    public By rfRecvBlind 			= By.linkText("RECV BLIND");
	    public By rfDock 				= By.xpath("//*[@id='DockInp']");
	    public By printRequestor		= By.id("dataForm:input1");
	    public By taskId_iLPN_textArea	= By.id("dataForm:input2");
	    public By pcText				= By.id("dataForm:title_text");
	    public By olpnShpText			= By.xpath("//*[@id='dataForm:diviid2']/table/tbody/tr/td/span");
	    public By enterButton			= By.xpath("//div//*[@value='Enter']");
	    public By exitButton			= By.cssSelector("#tool_bar_buttons>table>tbody>tr>td:nth-child(1)>span");
	    public By chnTaskGrp			= By.xpath("//*[@value='Chg Task Grp']"); 
	    public By skipCnclButton		= By.xpath("//*[@value='Skip/Cncl']");
	    public By enterTask				= By.xpath("//*[@value='Enter Task']");
	    public By taskIDTextArea		= By.id("dataForm:input1");
	    public By taskGrpTxtArea		= By.id("dataForm:taskGrp");
	    public By locTxtArea			= By.id("//*[@id='location_Input']");
	    public By itemBarCodeTxtArea	= By.id("itemId1Brcd");
	    public By qtyTextArea			= By.id("input1vp11_sku_qty");
	    public By sLoc					= By.id("subLocationEntryUserDirected18_Input");
	    public By acceptButton			= By.id("rfbtn_dataForm:HCEAcceptKey");
	    public By qntyString			= By.xpath("//*[@id='dataForm:enl2']/div[4]");
	    public By warningDiv			= By.xpath ("//*[@name='SoftCheckErrorerrorMode']/parent::div");
	    public By acceptProceedButton	= By.xpath("//span[@id='rfbtn_dataForm:SCEAcceptKey']");
	    public By slotTextArea			= By.id("dataForm:SlotNbr");
	    public By rfCartNoTextBox		= By.id("barcode");
	    public By rfLpnNoTextBox		= By.id("barcode_lpn");
	    public By rfLpnNoTextBox2		= By.id("tesd3s");	    
	    public By rfSlotNoTextBox		= By.id("dataForm:RFMakeReplPickCart_input");
	    public By rfEndPickCartBtn 		= By.xpath("//*[@value='End Pick Cart']");
	    public By rfClocNoTextBox		= By.id("sublocn1_Input");
	    public By rfLpnTextBox			= By.id("lpninput");
//	    public By acceptProceed			= By.xpath("//span[contains(@value,'Accpt')]");	
	    public By selectSeq				= By.cssSelector("[id*='dataForm:barcode']");
	    public By acceptProceed			= By.xpath("//span[contains(@id,'rfbtn_dataForm:InfoAcceptKey')]");	
	    	
	public boolean verifyWMSRfScreenLogin(Map<String, Object> testdata) throws WmsCustomException {
		try {
			String dcCode = (String) testdata.get("dcCode");
			String strUName = (String) testdata.get(dcCode + "-WMS-UserName");
			String strPassword = (String) testdata.get(dcCode + "-WMS-Password");
			se.webDriver.findElement(rfUserName).sendKeys(strUName);
			se.webDriver.findElement(rfPassword).sendKeys(new Data.EncryptedString(strPassword).getString());
			se.webDriver.findElement(rfSignIn).click();
			report.updateTestLog("RF Login", "Login to RF screen", Status.PASS);
			return true;
		} catch (Exception ex) {
			report.updateTestLog("RF Login", "Unable to verify RF Login", Status.FAIL);
			throw new WmsCustomException(ex);
		}
	}
			
	public boolean verifyWMSRfAction(Map<String, Object> testdata) throws WmsCustomException {

		String testcase = (String) testdata.get("identifier");
		String dcCode = (String) testdata.get("dcCode");
		report = se.getDriver().getReport();

		switch (dcCode + "_" + testcase) {
		case "HTLS_OB_1064_PE01EX_AP_10_PR_INT51_Discretre_Pick_Parital_Short":
			return verify_HTLS_OB_1064_PE01EX_AP_10_PR_INT51_Discretre_Pick_Parital_Short(testdata);
		case "NALC_IB_1014_RECV_ManualRecv_HP_20_Non_Con_Item":
			return verify_NALC_IB_1014_RECV_ManualRecv_HP_20_Non_Con_Item(testdata);
		case "HAM_OB_1064_NDC_PE01TE_HP_05_INT_9_Make_Replen_Cart_And_Replen":
			return verify_HAM_OB_1064_NDC_PE01TE_HP_05_INT_9_Make_Replen_Cart_And_Replen(testdata);

		}
		return true;
	}
    public boolean verify_HAM_OB_1064_NDC_PE01TE_HP_05_INT_9_Make_Replen_Cart_And_Replen(Map<String, Object> testdata) throws WmsCustomException {
		try {
			WebDriverWait wait = new WebDriverWait(se.webDriver, 20);
			String choice1 = (String) testdata.get("choice1");
			String choice2 = (String) testdata.get("choice2");
			waitForComponent(se, wait, rfInfoIncon);
			se.webDriver.findElement(rfInfoIncon).click();
			se.webDriver.findElement(rfRefresh).click();
			report.updateTestLog("RF screen", "Refresh the RF Screen", Status.DONE);

			waitForComponent(se, wait, rfInfoIncon);
			se.webDriver.findElement(rfInfoIncon).click();
			se.webDriver.findElement(rfClearCache).click();
			report.updateTestLog("RF screen", "Clear Cache", Status.DONE);

			waitForComponent(se, wait, rfChoice);
			se.webDriver.findElement(rfChoice).sendKeys(choice1);
			se.webDriver.findElement(rfChoice).sendKeys(Keys.ENTER);
			report.updateTestLog("RF screen", "Select option 5- REPLEN", Status.PASS);
			processingDelay(globalWaitMin);
			se.element.isVisible(rfChoice);
			wait.until(ExpectedConditions.visibilityOfElementLocated(rfChoice));
			se.webDriver.findElement(rfChoice).sendKeys(choice2);
			se.webDriver.findElement(rfChoice).sendKeys(Keys.ENTER);
			report.updateTestLog("RF screen", "Select option 1 - MAKE REPLEN CART", Status.PASS);

			waitForComponent(se, wait, rfCartNoTextBox);
			// any four digit
			Date dNow = new Date();			
			SimpleDateFormat ft = new SimpleDateFormat("SSSs");
			String cartNo = ft.format(dNow);
			se.webDriver.findElement(rfCartNoTextBox).sendKeys(cartNo.substring(0,4));
			se.webDriver.findElement(rfCartNoTextBox).sendKeys(Keys.ENTER);
			report.updateTestLog("RF screen", "Enter cart number", Status.PASS);
			processingDelay(globalWaitMin);

			waitForComponent(se, wait, rfLpnNoTextBox);
			String lnpNo = getDataReserver().getAppsData(ApplicationKeys.TRANSIT_CONTAINERID).toString();
			System.out.println(lnpNo);
			se.webDriver.findElement(rfLpnNoTextBox).click();
			se.webDriver.findElement(rfLpnNoTextBox).sendKeys(lnpNo);
			se.webDriver.findElement(rfSlotNoTextBox).sendKeys("1");
			se.webDriver.findElement(rfSlotNoTextBox).sendKeys(Keys.ENTER);
			report.updateTestLog("RF screen", "Enter LPN number " + lnpNo + "and  slot: 1", Status.PASS);

			waitForComponent(se, wait, rfEndPickCartBtn);
			se.webDriver.findElement(rfEndPickCartBtn).click();
			report.updateTestLog("RF screen", "End pick cart", Status.PASS);

			waitForComponent(se, wait, rfClocNoTextBox);
			String lnpDestLoc = getDataReserver().getAppsData(ApplicationKeys.DESTINATION_LOCATION).toString();
			lnpDestLoc = lnpDestLoc.replaceAll("-", "");
			report.updateTestLog("RF screen", "Enter Destination location: " + lnpDestLoc, Status.PASS);
			se.webDriver.findElement(rfClocNoTextBox).sendKeys(lnpDestLoc);
			se.webDriver.findElement(rfClocNoTextBox).sendKeys(Keys.ENTER);

			waitForComponent(se, wait, rfLpnNoTextBox2);
			se.webDriver.findElement(rfLpnNoTextBox2).sendKeys(lnpNo);
			se.webDriver.findElement(rfLpnNoTextBox2).sendKeys(Keys.ENTER);
			report.updateTestLog("RF screen", "Enter LPN number " + lnpNo, Status.PASS);

		}catch(Exception e){
    		e.printStackTrace();
    		//report.updateTestLog("RF Screen and Pick short ", "RF Screen and Pick short operation is UnSuccessfull," , Status.FAIL);
			//throw new WmsCustomException(e);
    	}
		return true;
	}

	public boolean verify_NALC_IB_1014_RECV_ManualRecv_HP_20_Non_Con_Item(Map<String, Object> testdata)
			throws WmsCustomException {
		try {
			WebDriverWait wait = new WebDriverWait(se.webDriver, globalWaitAvg);
			String choice1 = (String) testdata.get("choice1");
			String choice2 = (String) testdata.get("choice2");

			wait.until(ExpectedConditions.elementToBeClickable(rfInfoIncon));
			se.webDriver.findElement(rfInfoIncon).click();
			se.webDriver.findElement(rfRefresh).click();

			wait.until(ExpectedConditions.elementToBeClickable(rfInfoIncon));
			se.webDriver.findElement(rfInfoIncon).click();
			se.webDriver.findElement(rfClearCache).click();

			waitForComponent(se, wait, rfChoice);
			se.webDriver.findElement(rfChoice).sendKeys(choice1);
			se.webDriver.findElement(rfChoice).sendKeys(Keys.ENTER);
			processingDelay(globalWaitMin);
			se.element.isVisible(rfChoice);
			wait.until(ExpectedConditions.visibilityOfElementLocated(rfChoice));
			se.webDriver.findElement(rfChoice).sendKeys(choice2);
			se.webDriver.findElement(rfChoice).sendKeys(Keys.ENTER);

			se.log.logTestStep("LPNs: " + getDataReserver().getLpnIds().getDetails());

			if (getDataReserver().getLpnIds() == null || getDataReserver().getLpnIds().getElement().size() != 2) {
				report.updateTestLog("LPNs", "There should be two LPN !", Status.FAIL);
				throw new WmsCustomException("There should be two LPN !");
			}

			String firstLpn = getDataReserver().getLpnIds().getElement().get(0).getElementValue();
			String secondLpn = getDataReserver().getLpnIds().getElement().get(1).getElementValue();

			for (GenericWmsElement lpn : getDataReserver().getLpnIds().getElement()) {
				report.updateTestLog("LPNs", "LPN1 is-"+firstLpn, Status.DONE);
				report.updateTestLog("LPNs", "LPN2 is-"+secondLpn, Status.DONE);
				se.log.logTestStep("RF action for LPN " + lpn.getElementValue());
			}

			waitForComponent(se, wait, rfLpnTextBox);
			se.webDriver.findElement(rfLpnTextBox).click();
			se.webDriver.findElement(rfLpnTextBox).sendKeys(firstLpn);
			se.webDriver.findElement(rfLpnTextBox).sendKeys(Keys.ENTER);
			report.updateTestLog("LPNs", "LPN1 is entered "+firstLpn, Status.DONE);
			
			processingDelay(globalWaitMin);
			
			if(se.element.exists(selectSeq)){
				se.webDriver.findElement(selectSeq).sendKeys("1");
				se.webDriver.findElement(selectSeq).sendKeys(Keys.ENTER);
				se.log.logTestStep("seqence no text box present");
			}else{
				processingDelay(globalWaitMin);
				waitForComponent(se, wait, acceptProceed);			
				se.webDriver.findElement(acceptProceed).click();
			}
			processingDelay(globalWaitMin);
			
			waitForComponent(se, wait, rfLpnTextBox);
			se.log.logTestStep("entering lpn 2");
			se.webDriver.findElement(rfLpnTextBox).click();
			se.webDriver.findElement(rfLpnTextBox).sendKeys(secondLpn);
			se.webDriver.findElement(rfLpnTextBox).sendKeys(Keys.ENTER);
			report.updateTestLog("LPNs", "LPN2 is entered "+ secondLpn, Status.DONE);
			processingDelay(globalWaitMin);
			waitForComponent(se, wait, acceptProceed);			
			se.webDriver.findElement(acceptProceed).click();

		} catch (Exception ex) {
			report.updateTestLog("RF Screen and Pick short ", "RF Screen and Pick short operation is UnSuccessfull,",
					Status.FAIL);
			se.log.logTestStep(ex);
			throw new WmsCustomException(ex);
		}
		return true;
	}
    public boolean verify_HTLS_OB_1064_PE01EX_AP_10_PR_INT51_Discretre_Pick_Parital_Short(Map<String, Object> testdata)  throws WmsCustomException {    
		try {
			WebDriverWait wait = new WebDriverWait(se.webDriver, 20);
			String choice1 = (String) testdata.get("choice1");
			String choice2 = (String) testdata.get("choice2");
			String printReq = (String) testdata.get("printReq");
			String taskID = getDataReserver().getAppsData().get("taskID");
			String printConfTxt = (String) testdata.get("printConfTxt");
			String oLPNshp = (String) testdata.get("oLPNshp");
			String tskGrp = (String) testdata.get("tskGrp");
			wait.until(ExpectedConditions.elementToBeClickable(rfInfoIncon));
			se.webDriver.findElement(rfInfoIncon).click();
			se.webDriver.findElement(rfRefresh).click();

			wait.until(ExpectedConditions.elementToBeClickable(rfInfoIncon));
			se.webDriver.findElement(rfInfoIncon).click();
			se.webDriver.findElement(rfClearCache).click();

			se.element.isVisible(rfChoice);
			wait.until(ExpectedConditions.visibilityOfElementLocated(rfChoice));
			se.webDriver.findElement(rfChoice).sendKeys(choice1);
			se.webDriver.findElement(rfChoice).sendKeys(Keys.ENTER);
			processingDelay(globalWaitMin);
			se.element.isVisible(rfChoice);
			wait.until(ExpectedConditions.visibilityOfElementLocated(rfChoice));
			se.webDriver.findElement(rfChoice).sendKeys(choice2);
			se.webDriver.findElement(rfChoice).sendKeys(Keys.ENTER);

			waitForComponent(se, wait, printRequestor);
			se.webDriver.findElement(printRequestor).sendKeys(printReq);
			se.webDriver.findElement(printRequestor).sendKeys(Keys.ENTER);

			waitForComponent(se, wait, taskId_iLPN_textArea);
			processingDelay(2);
			se.webDriver.findElement(taskId_iLPN_textArea).sendKeys(taskID);
			se.webDriver.findElement(taskId_iLPN_textArea).sendKeys(Keys.ENTER);

			se.element.isVisible(pcText);
			se.element.isVisible(olpnShpText);
			if ((se.webDriver.findElement(pcText).getText().equalsIgnoreCase(printConfTxt))
					&& (se.webDriver.findElement(olpnShpText).getText().equalsIgnoreCase(oLPNshp))) {
				se.log.logSeStep("Print Confirmation oLPN Shp Lbl");
				report.updateTestLog("Print Confirm", "Print Confirmation Message displayed", Status.PASS);

			}
			processingDelay(globalWaitMin);
			se.element.isVisible(exitButton);
			wait.until(ExpectedConditions.visibilityOfElementLocated(exitButton));
			se.webDriver.findElement(exitButton).click();

			wait.until(ExpectedConditions.elementToBeClickable(rfInfoIncon));
			se.webDriver.findElement(rfInfoIncon).click();

			se.element.isVisible(chnTaskGrp);
			waitForComponent(se, wait, chnTaskGrp);
			se.webDriver.findElement(chnTaskGrp).click();

			se.element.isVisible(taskGrpTxtArea);
			wait.until(ExpectedConditions.elementToBeClickable(taskGrpTxtArea));
			se.webDriver.findElement(taskGrpTxtArea).sendKeys(tskGrp);

			processingDelay(globalWaitMin);
			se.element.isVisible(enterButton);
			wait.until(ExpectedConditions.visibilityOfElementLocated(enterButton));
			se.webDriver.findElement(enterButton).click();

			wait.until(ExpectedConditions.elementToBeClickable(rfInfoIncon));
			se.webDriver.findElement(rfInfoIncon).click();

			se.element.isVisible(enterTask);
			wait.until(ExpectedConditions.elementToBeClickable(enterTask));
			se.webDriver.findElement(enterTask).click();

			se.element.isVisible(taskIDTextArea);
			wait.until(ExpectedConditions.visibilityOfElementLocated(taskIDTextArea));
			se.webDriver.findElement(taskIDTextArea).sendKeys(taskID);
			se.webDriver.findElement(taskIDTextArea).sendKeys(Keys.ENTER);

			// If the "Task Already in progress" warning comes(put the code here)
			processingDelay(globalWaitMin);
			report.updateTestLog("TASK ID", "TASK ID is entered" + taskID, Status.PASS);
			se.element.isVisible(itemBarCodeTxtArea);
			wait.until(ExpectedConditions.visibilityOfElementLocated(itemBarCodeTxtArea));
			String barcode = getDataReserver().getAppsData(ApplicationKeys.BAR_CODE);
			se.log.logTestStep("Barcode is -" + barcode);
			se.webDriver.findElement(itemBarCodeTxtArea).click();
			se.webDriver.findElement(itemBarCodeTxtArea).sendKeys(barcode);
			se.webDriver.findElement(itemBarCodeTxtArea).sendKeys(Keys.ENTER);
			report.updateTestLog("Barcode", "Barcode is entered" + barcode, Status.DONE);

			processingDelay(globalWaitMin);
			String quantity = se.webDriver.findElement(qntyString).getText();
			String[] qnty = quantity.split(":");
			String[] qntyUnit = qnty[1].split(" ");
			String qntyReq = qntyUnit[1];
			int count = Integer.parseInt(qntyReq);
			if (count > 1) {
				se.log.logSeStep("Count is greater than 1" + count);
				int countNum = count - 1;
				String cntNum = countNum + "";
				waitForComponent(se, wait, qtyTextArea);
				se.webDriver.findElement(qtyTextArea).sendKeys(cntNum);
				se.webDriver.findElement(qtyTextArea).sendKeys(Keys.ENTER);
				se.element.isVisible(qtyTextArea);
				waitForComponent(se, wait, qtyTextArea);
				se.webDriver.findElement(qtyTextArea).sendKeys("0");
				processingDelay(globalWaitMin);

			} else if (count == 1) {
				se.log.logSeStep("Count is 1" + count);
				se.element.isVisible(qtyTextArea);
				wait.until(ExpectedConditions.visibilityOfElementLocated(qtyTextArea));
				se.webDriver.findElement(qtyTextArea).sendKeys("0");

			}
			
			waitForComponent(se, wait, rfInfoIncon);
			se.webDriver.findElement(rfInfoIncon).click();
			waitForComponent(se, wait, skipCnclButton);
			se.webDriver.findElement(skipCnclButton).click();

			waitForComponent(se, wait, slotTextArea);
			String sID = getDataReserver().getAppsData(ApplicationKeys.SLOT_ID);
			se.webDriver.findElement(slotTextArea).sendKeys(sID);
			se.webDriver.findElement(slotTextArea).sendKeys(Keys.ENTER);

			String slocDBValue = getDataReserver().getAppsData(ApplicationKeys.DB_QUERY_RESULT_SLOC);
			if (slocDBValue == null || "".equals(slocDBValue)) {
				throw new WmsCustomException("sLoc should not be null or empty");
			}
			se.element.isVisible(sLoc);
			wait.until(ExpectedConditions.visibilityOfElementLocated(sLoc));
			se.webDriver.findElement(sLoc).sendKeys(slocDBValue);
			se.webDriver.findElement(sLoc).sendKeys(Keys.ENTER);

		}catch(Exception ex)
    	{
    		report.updateTestLog("RF Screen and Pick short ", "RF Screen and Pick short operation is UnSuccessfull," , Status.FAIL);
    		ex.printStackTrace();
    		throw new WmsCustomException(ex);
    		
    		
    	}
		
		return true;
	}
    

}
