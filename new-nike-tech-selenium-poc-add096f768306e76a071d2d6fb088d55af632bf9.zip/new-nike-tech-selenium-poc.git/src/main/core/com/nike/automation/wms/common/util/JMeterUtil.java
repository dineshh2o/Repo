package com.nike.automation.wms.common.util;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class JMeterUtil {
	private Map<String, Object> params;
	public JMeterUtil(Map<String, Object> params){
		this.params=params;
	}
	
	public String sendJmeterMsg(String msgType, String taskId, String containerID, String portNo) throws WmsCustomException {
		
		Object jMeterBinPath=params.get(ApplicationKeys.JMETER_BIN_PATH_KEY.toString());
		if(jMeterBinPath == null || "".equals(jMeterBinPath))
			throw new WmsCustomException("JMeter bin path is empty");
		
		Object jMeterJmxFilePath=params.get(ApplicationKeys.JMETER_JMX_FILE_PATH_KEY.toString());
		if(jMeterJmxFilePath == null || "".equals(jMeterJmxFilePath))
			throw new WmsCustomException("JMeter JMX file path is empty");
		
		Object jMeterResultFilePath=params.get(ApplicationKeys.JMETER_RESULT_FILE_PATH_KEY.toString());
		if(jMeterResultFilePath == null || "".equals(jMeterResultFilePath))
			throw new WmsCustomException("JMeter result file path is empty");
		
		Object jMeterTempBatchFilePath=params.get(ApplicationKeys.JMETER_TEMP_FILE_PATH_KEY.toString());
		if(jMeterTempBatchFilePath == null || "".equals(jMeterTempBatchFilePath))
			throw new WmsCustomException("JMeter temp batch file path is empty");
		
		String result="";
		String msgBody="";
		String strJMeterBinPath=(String)jMeterBinPath;
		String str_JMXfilePath=(String)jMeterJmxFilePath;
		String str_resultFilePath=(String)jMeterResultFilePath;
		String str_TempBatchFilePath=(String)jMeterTempBatchFilePath;
		
		if(ApplicationKeys.JMETER_PULL_MSG.toString().equalsIgnoreCase(msgType)){
			msgBody="CONTAINERSTATUS^"+containerID+"^DIVERTED^PULL^DS^1000^^"+taskId+"^123124";
		}else if(ApplicationKeys.JMETER_DIVERT_MSG.toString().equalsIgnoreCase(msgType)){
			msgBody="CONTAINERSTATUS^"+containerID+"^DIVERTED^DIVERT^DS^1000^3011000001^^123";
		}
		System.out.println(msgBody);
		String jMeterCmd="jmeter-wms -n -t "+str_JMXfilePath+" -JserverIP=nke-lnx-wms-d065.nike.com -JUser_Name= -Jpassword= -JPort_Num="+portNo+" -JMessage=\""+msgBody+"\" -l "+str_resultFilePath;
		System.out.println(jMeterCmd);
		try{
		    PrintWriter writer = new PrintWriter(str_TempBatchFilePath+"/temp.bat", "UTF-8");
		    writer.println("pushd\\");
		    writer.println("pushd "+strJMeterBinPath);
		    writer.println(jMeterCmd);
		    writer.println("popd\\");
		    writer.println("exit");
		    writer.close();
		    Process process = Runtime.getRuntime().exec("cmd /c start /wait "+str_TempBatchFilePath+"/temp.bat");
		    process.waitFor();
		    result = new String(Files.readAllBytes(Paths.get(str_resultFilePath)));
		    
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return result;
		
	}
	
	public static void main(String[] args) throws WmsCustomException {
		Map<String, Object> params=new HashMap<>();
		JMeterUtil obj=new JMeterUtil(params);
		String result = obj.sendJmeterMsg("Pull", "2969201", "00000912016254831082", "20207");
		 System.out.println(result);
		 
	}
}
