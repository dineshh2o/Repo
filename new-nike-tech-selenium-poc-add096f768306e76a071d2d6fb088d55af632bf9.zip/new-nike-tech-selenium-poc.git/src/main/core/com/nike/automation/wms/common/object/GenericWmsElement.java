package com.nike.automation.wms.common.object;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.nike.automation.wms.common.util.ApplicationKeys;

@XmlType(propOrder = {"elementValue", "additionalInfo"})

public class GenericWmsElement {
	private String elementName;
	private String elementValue;
	private String additionalInfo;
	
	public GenericWmsElement(){}
	public GenericWmsElement(String name, String value){
		this.elementName = name;
		this.elementValue = value;
	}
	public GenericWmsElement(String name, String value, String info){
		this.elementName = name;
		this.elementValue = value;
		this.additionalInfo = info;
	}
	public GenericWmsElement(ApplicationKeys name, String value){
		this.elementName = name.toString();
		this.elementValue = value;
	}	
	public GenericWmsElement(ApplicationKeys name, String value, String info){
		this.elementName = name.toString();
		this.elementValue = value;
		this.additionalInfo = info;
	}
	
	public String getElementName() {
		return elementName;
	}
	
	@XmlAttribute(name = "name")
	public void setElementName(String elementName) {
		this.elementName = elementName;
	}
	public String getElementValue() {
		return elementValue;
	}
	
	@XmlElement(name = "value")		
	public void setElementValue(String elementValue) {
		this.elementValue = elementValue;
	}
	public String getAdditionalInfo() {
		return additionalInfo;
	}
	
	@XmlElement(name = "info")	
	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

}
