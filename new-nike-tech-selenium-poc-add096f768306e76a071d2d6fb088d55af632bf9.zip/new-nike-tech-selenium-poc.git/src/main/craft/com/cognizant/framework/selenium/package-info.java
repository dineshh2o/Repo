/**
 * Package containing reusable libraries which are common across Cognizant's CRAFT and CRAFTLite Frameworks, but specific to Selenium
 * @author Cognizant
 */
package com.cognizant.framework.selenium;