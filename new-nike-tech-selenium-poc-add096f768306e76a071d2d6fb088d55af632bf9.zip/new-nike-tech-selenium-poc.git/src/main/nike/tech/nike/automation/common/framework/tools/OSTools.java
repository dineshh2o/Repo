package tech.nike.automation.common.framework.tools;

/**
 * @author Cognizant Technology CoE
 *         <p>
 *         Helper class to detect which OS the tests are running under.
 */
public class OSTools {
    private static final String USER_HOME = System.getProperty("user.dir").replaceAll("\\\\", "/");
    private static final String USER_NAME = System.getProperty("user.name");
    private static final String OS_NAME = System.getProperty("os.name").toLowerCase();

    private OSTools() { /* Static Class not intended to be constructed */ }

    public static boolean isWindows() {
        return OS_NAME.indexOf("win") >= 0;
    }

    public static boolean isMac() {
        return OS_NAME.indexOf("mac") >= 0;
    }

    public static boolean isUnix() {
        return OS_NAME.indexOf("nux") >= 0 || OS_NAME.indexOf("nix") >= 0;
    }

    public static String getUsername() {
        return USER_NAME;
    }

    public static String getUserHome() {
        return USER_HOME;
    }

}
