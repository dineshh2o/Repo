package tech.nike.automation.common.framework.tools;

import tech.nike.automation.common.framework.core.Data;

import javax.swing.*;
import java.io.File;
import java.io.IOException;
import java.security.GeneralSecurityException;

public class EncryptPassword {
    public static void main(String[] a) {
        JLabel jKeyfile = new JLabel("Key File");
        JTextField keyfile = new JTextField();
        String myKeyFile = "";
        //PC
        if (System.getenv("USERPROFILE") != null)
            myKeyFile = "selenium/SeleniumAutomation.key";
        	//myKeyFile = System.getenv("USERPROFILE") + "/selenium/SeleniumAutomation.key";
            //MAC
        else
            myKeyFile = System.getenv("HOME") + "/selenium/SeleniumAutomation.key";
        keyfile.setText(myKeyFile);
        JLabel jPassword = new JLabel("Password");
        JTextField password = new JPasswordField();
        Object[] ob = {jKeyfile, keyfile, jPassword, password};
        int result = JOptionPane.showConfirmDialog(null, ob, "Please input password", JOptionPane.OK_CANCEL_OPTION);

        if (result == JOptionPane.OK_OPTION) {
            String passwordValue = password.getText();
            String keyFile = keyfile.getText();
            try {
                System.out.println(Data.encrypt(passwordValue, new File(keyFile)));
                JTextArea textarea = new JTextArea(Data.encrypt(passwordValue, new File(keyFile)));
                textarea.setEditable(true);
                JOptionPane.showMessageDialog(null, textarea, "Encrypted Password", JOptionPane.INFORMATION_MESSAGE);
            } catch (GeneralSecurityException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }
}
