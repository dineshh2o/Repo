package tech.nike.automation.common.utils.parsers;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.*;
import java.util.*;

/**
 * Simple SAX parser that maps an XML file to a map of maps. Attributes are simply rolled in as key value pairs on the
 * given node that they come in on. For repeated node names, a list is created. The order is maintained as parsed.
 * Everything parsed is treated as simple text, there is no attempt to validate.
 * <p>
 * NOTE: There already exists com.nike.tesla.core.util.XMLToMapParser, but eventually this will become a standalone framework so that parser is duplicated here
 * to implement the DataToMapParser
 *
 * @author Cognizant Technology CoE
 */
@SuppressWarnings("unchecked")
public class XMLToMapParser extends DefaultHandler implements DataToMapParser {
    static final boolean VERBOSE = false;
    private static final Log logger = LogFactory.getLog(XMLToMapParser.class);
    private static final Object NULLOBJECT = new Object();
    private Map<String, Object> map = null; // map holds resource returned
    private Stack<Object> stack = null; // current parent element stack.
    private Stack<Object> names = null;
    private int elementCount = 0;
    private StringBuffer currentValue = null;

    /**
     * default constructor
     */
    public XMLToMapParser() {
        super();
    }

    @Override
    public void startDocument() throws SAXException {
        stack = new Stack<Object>();
        names = new Stack<Object>();
        currentValue = new StringBuffer();
        elementCount = 0;
        if (VERBOSE) {
            log("Start of Doucument called");
        }
    }

    @Override
    public void endDocument() throws SAXException {
        stack = null;
        names = null;
        currentValue = null;
        if (VERBOSE) {
            log("Done");
        }
    }

    /**
     * Public event, trigger each time a value is parsed
     *
     * @param ch     charector array array of element values.
     * @param start  start position.
     * @param length length of the array.
     * @throws org.xml.sax.SAXException if XML document is not well formatted.
     */
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        if (length > 0) {
            // Put element value into a string
            String value = (new String(ch, start, length));
            if (value.length() > 0) {
                currentValue.append(value);
            }
        }
    }

    /**
     * Public event, trigger each time when end element tag is read
     *
     * @param uri
     * @param localName
     * @param qName
     * @throws org.xml.sax.SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (VERBOSE) {
            log("Element " + localName + " ended.  -- URI=" + uri + "  qName=" + qName);
        }

        Object current = stack.pop();
        /**
         * Change from >0 to >=0 to include an empty string in the map if a null value is sent over.
         */
        if (currentValue.length() >= 0) {
            // set current to the string value if an empty object
            if (current == NULLOBJECT) {
                current = currentValue.toString();
            } else if (current instanceof Map) {
                // ignore adding just white space into the map...
                String c = currentValue.toString().trim();
                if (c.length() > 0) ((Map<String, String>) current).put("value", currentValue.toString());
            }
        }

        String stackName = (String) names.pop();
        if (!qName.equals(stackName)) {
            throw new SAXException("Stack name[" + stackName + "] does equal qname[" + qName + "], out of order....");
        }
        // add to parent..
        if (stack.isEmpty()) {
            // Must be last element, just assign it to the map.
            if (current instanceof Map) {
                map = (Map<String, Object>) current;
            } else {
                if (map == null) {
                    map = new HashMap<String, Object>();
                }
                map.put(qName, current);
            }
        } else {
            Object parent = stack.peek();
            if (parent == NULLOBJECT) {
                parent = new HashMap<Object, Object>();
                stack.pop();
                stack.push(parent);
            }

            if (parent instanceof Map) {
                Object o = ((Map<?, ?>) parent).get(qName);
                if (o != null) {
                    if (o instanceof Collection) {
                        if (current != NULLOBJECT) {
                            ((Collection<Object>) o).add(current);
                        }
                    } else {
                        Collection<Object> c = new ArrayList<Object>();
                        /**
                         * Added check to suppress empty string.
                         */
                        if (!("".equals(o.toString()))) {
                            c.add(o);
                        }
                        /**
                         * Added !("".equals(current.toString()) so that we do not add empty elements to the list.
                         */
                        if (current != NULLOBJECT && !("".equals(current.toString()))) {
                            c.add(current);
                        }
                        ((Map<String, Collection<Object>>) parent).put(qName, c);
                    }
                } else if (current != NULLOBJECT) {
                    ((Map<String, Object>) parent).put(qName, current);
                }
            } else if (parent instanceof Collection) {
                if (current != NULLOBJECT) {
                    ((Collection<Object>) parent).add(current);
                }
            } else {
                throw new SAXException("Parent of Node Name[" + qName + "] is not a Map or Collection.");
            }
        }

        // Clear current value.
        currentValue.setLength(0);
    }

    /**
     * Public event, trigger each time a element is encountered first time
     *
     * @param uri
     * @param localName
     * @param qName
     * @param attrs
     * @throws org.xml.sax.SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes attrs) throws SAXException {
        elementCount = elementCount + 1;
        if (VERBOSE) {
            log("Element " + localName + " start.  -- URI=" + uri + "  qName=" + qName);
        }
        // Clear current value.
        currentValue.setLength(0);
        names.push(qName);
        if (attrs != null && attrs.getLength() > 0) {
            // add attributes as flat properties to a 'map'
            Map<String, String> m = new HashMap<String, String>();
            for (int i = 0; i < attrs.getLength(); i++) {
                m.put(attrs.getQName(i), attrs.getValue(i));
            }
            stack.push(m);
        } else {
            stack.push(NULLOBJECT);
        }

    }

    /**
     * Public event, trigger each time when Error is encountered
     *
     * @param ex parsing exception.
     */
    @Override
    public void error(SAXParseException ex) {
        if (VERBOSE) {
            log("ERROR: " + getLocationString(ex) + ": " + ex.getMessage());
        }
    }

    /**
     * Public event, trigger each time when Un recoverable exception is encountered
     *
     * @param ex parsing exception.
     * @throws org.xml.sax.SAXException
     */
    @Override
    public void fatalError(SAXParseException ex) throws SAXException {
        if (VERBOSE) {
            log("FATAL ERROR: " + getLocationString(ex) + ": " + ex.getMessage());
        }
        throw ex;
    }

    /**
     * Public function, get map representation of the xml file.
     *
     * @return HashMap of xml file elements.
     */
    public HashMap<String, Object> getHashMap() {
        return ((HashMap<String, Object>) map);
    }

    public int getElementCount() {
        return elementCount;
    }

    /**
     * Public function, returns where xml file has problem
     *
     * @param ex SAXParseException
     * @return String of error message containing error position.
     */
    public String getLocationString(SAXParseException ex) {
        StringBuffer str = new StringBuffer();
        String systemId = ex.getSystemId();

        // get the position where exception occurs
        if (systemId != null) {
            int index = systemId.lastIndexOf('/');
            if (index != -1) {
                systemId = systemId.substring(index + 1);
            }
            str.append(systemId);
        }
        str.append(':');
        str.append(ex.getLineNumber());
        str.append(':');
        str.append(ex.getColumnNumber());

        return str.toString();
    }

    /**
     * Private function, logs error to screen
     *
     * @param in input string to be print out.
     */
    private void log(String in) {
        if (VERBOSE) {
            logger.debug(in);
        }
    }


    /**
     * Parse the given input Stream.
     *
     * @param in reader with data to parse.
     * @throws javax.xml.parsers.ParserConfigurationException
     * @throws org.xml.sax.SAXException
     * @throws java.io.IOException
     */
    public void parse(Reader in) throws ParserConfigurationException, SAXException, IOException {
        SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
        parser.parse(new InputSource(in), this);
    }


    /**
     * Parse the given input Stream.
     *
     * @param in input stream to parse.
     * @throws javax.xml.parsers.ParserConfigurationException
     * @throws org.xml.sax.SAXException
     * @throws java.io.IOException
     */
    public void parse(InputStream in) throws ParserConfigurationException, SAXException, IOException {
        SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
        parser.parse(in, this);
    }

    /**
     * Parse the given URI.
     *
     * @param uri URI to lookup and parse
     * @throws javax.xml.parsers.ParserConfigurationException
     * @throws org.xml.sax.SAXException
     * @throws java.io.IOException
     */
    public void parse(String uri) throws ParserConfigurationException, SAXException, IOException {
        SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
        parser.parse(uri, this);
    }

    /**
     * Parse the given File into a map.
     *
     * @param f File to parse
     * @throws javax.xml.parsers.ParserConfigurationException
     * @throws org.xml.sax.SAXException
     * @throws java.io.IOException
     */
    public void parse(File f) throws ParserConfigurationException, SAXException, IOException {
        SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
        parser.parse(f, this);
    }

    /**
     * Parse the given input source into a Map
     *
     * @param s InputSource
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     */
    public void parse(InputSource s) throws ParserConfigurationException, SAXException, IOException {
        SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
        parser.parse(s, this);
    }

    /**
     * This simply handles and xml string
     *
     * @param inputXML
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     */
    public void parseXMLString(String inputXML) throws ParserConfigurationException, SAXException, IOException {
        byte currentXMLBytes[] = inputXML.getBytes();
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(currentXMLBytes);
        SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
        parser.parse(byteArrayInputStream, this);
    }
}
