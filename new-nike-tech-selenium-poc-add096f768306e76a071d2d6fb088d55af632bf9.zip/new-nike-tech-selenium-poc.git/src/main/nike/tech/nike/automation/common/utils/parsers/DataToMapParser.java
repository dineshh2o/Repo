package tech.nike.automation.common.utils.parsers;

import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;

/**
 * This is the interface used to parse data in different file formats into a Map that can be used by the Automation Framework.
 * For repeated test names, a list is created. The order is maintained as parsed.
 * Everything parsed is treated as simple text, there is no attempt to validate.
 *
 * @author Cognizant Technology CoE
 */
public interface DataToMapParser {

    /**
     * Public function, get map representation of the underlying data file
     *
     * @return HashMap of the data elements.
     */
    HashMap<String, Object> getHashMap();


    /**
     * Parse the given File into a map.
     *
     * @param f File to parse
     * @throws javax.xml.parsers.ParserConfigurationException
     * @throws org.xml.sax.SAXException
     * @throws java.io.IOException
     */
    void parse(File f) throws ParserConfigurationException, SAXException, IOException;

}
