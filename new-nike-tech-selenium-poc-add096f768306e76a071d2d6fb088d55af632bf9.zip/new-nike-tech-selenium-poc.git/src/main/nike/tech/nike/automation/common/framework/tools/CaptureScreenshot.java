package tech.nike.automation.common.framework.tools;

/**
 * Created by PSibb1 on 8/20/2016.
 */

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.awt.image.BufferedImage;
import java.util.concurrent.TimeUnit;

public class CaptureScreenshot {

    //public static void captureFullScreen() {
    public static void main(String[] a) {
        WebDriver driver;
        System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chromedriver.exe");
        //System.setProperty("webdriver.ie.driver", "C:\\selenium\\IEDriverServer.exe");
        driver = new ChromeDriver();
        // driver = new InternetExplorerDriver();
        // maximize the browser window
        driver.manage().window().maximize();
        driver.get("http://zero.nike.com");
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        // This code will capture screenshot of current screen
        @SuppressWarnings("unused")
		BufferedImage image = null;
        /*try {
            image = new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
            // This will store screenshot on Specific location
            ImageIO.write(image, "png", new File("C:\\AVideo\\CurrentScreenshot.png"));
        } catch (AWTException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }*/
        driver.close();
    }
}