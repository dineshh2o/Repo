package tech.nike.automation.common.framework.core;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.net.URI;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Data {
    private static File myKeyFile;
    private Workbook workbook;
    @SuppressWarnings("unused")
    private Log myLog;

    public Data() {
    }

    /**
     * creates an object array of browser objects from a delimited list
     *
     * @param delimitedString
     * @param delimiter
     * @return
     */
    public static Object[][] createDataProviderFromDelimitedString(String delimitedString, String delimiter) {
        List<List<Object>> returnData = new ArrayList<List<Object>>();
        for (String cellContents : delimitedString.split(delimiter)) {
            List<Object> column = new ArrayList<Object>();
            if (cellContents.equals("Random")) {
                int chosenOption = Util.randomNum(0, 4);
                if (chosenOption == 0)
                    column.add(Browser.Browsers.GridInternetExplorer);
                if (chosenOption == 1)
                    column.add(Browser.Browsers.GridFirefox);
                if (chosenOption == 2)
                    column.add(Browser.Browsers.GridChrome);
                if (chosenOption == 3)
                    column.add(Browser.Browsers.GridSafari);
            } else {
                try {
                    column.add(Browser.Browsers.valueOf(cellContents));
                } catch (IllegalArgumentException e) {
                    System.out.println("unrecognized browser in pom.xml : " + cellContents);
                }
            }

            returnData.add(column);
        }

        Object[][] convertedReturnData = new Object[returnData.size()][];
        for (int row = 0; row < returnData.size(); row++) {
            convertedReturnData[row] = returnData.get(row).toArray();
        }
        return convertedReturnData;
    }

    /**
     * Set the KeyFile for decryption
     *
     * @param fileName
     */
    public static void setKeyFile(String fileName) {
        myKeyFile = new File(fileName);
    }

    /**
     * Encrypts a string, creating a key file, and prints
     * the encrypted key to the console
     *
     * @param value
     * @param keyFile
     * @return String
     * @throws GeneralSecurityException
     * @throws IOException
     */
    public static String encrypt(String value, File keyFile)
            throws GeneralSecurityException, IOException {
        if (!keyFile.exists()) {
            KeyGenerator keyGen = KeyGenerator.getInstance("AES");
            keyGen.init(128);
            SecretKey sk = keyGen.generateKey();
            FileWriter fw = new FileWriter(keyFile);
            fw.write(byteArrayToHexString(sk.getEncoded()));
            fw.flush();
            fw.close();
        }

        SecretKeySpec sks = getSecretKeySpec(keyFile);
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, sks, cipher.getParameters());
        byte[] encrypted = cipher.doFinal(value.getBytes());
        return byteArrayToHexString(encrypted);
    }

    /**
     * Decrypts a string
     *
     * @param message : string to decrypt
     * @param keyFile : file containing the key used to decrypt
     * @return decrypted string
     * @throws GeneralSecurityException
     * @throws IOException
     */
    public static String decrypt(String message, File keyFile) {
        if (keyFile == null) {
            System.out.println("keyFile not set, use setKeyFile(String fileName) to set");
            return null;
        }
        try {
            SecretKeySpec sks = getSecretKeySpec(keyFile);
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE, sks);
            byte[] decrypted = cipher.doFinal(hexStringToByteArray(message));
            return new String(decrypted);
        } catch (Exception e) {
            // TODO: handle exception
            return null;
        }

    }

    /**
     * Opens the keyfile and uses the key to generate an AES secret key
     *
     * @param keyFile : file containing a key
     * @return SecretKeySpec
     * @throws NoSuchAlgorithmException
     * @throws IOException
     */
    private static SecretKeySpec getSecretKeySpec(File keyFile)
            throws NoSuchAlgorithmException, IOException {
        byte[] key = readKeyFile(keyFile);
        SecretKeySpec sks = new SecretKeySpec(key, "AES");
        return sks;
    }

    /**
     * Opens a key file and returns the key as a byte array
     *
     * @param keyFile : path of key file
     * @return byte array representing the key
     * @throws FileNotFoundException
     */
    private static byte[] readKeyFile(File keyFile)
            throws FileNotFoundException {
        //read entire file, \Z means end of string
        Scanner scanner = extracted(keyFile).useDelimiter("\\Z");
        String keyValue = scanner.next();
        scanner.close();
        return hexStringToByteArray(keyValue);
    }

    private static Scanner extracted(File keyFile) throws FileNotFoundException {
        return new Scanner(keyFile);
    }

    /**
     * Converts byte array to string, used by encrypt/decrypt
     *
     * @param b : byte array
     * @return string
     */
    private static String byteArrayToHexString(byte[] b) {
        StringBuffer sb = new StringBuffer(b.length * 2);
        for (int i = 0; i < b.length; i++) {
            int v = b[i] & 0xff;
            if (v < 16) {
                sb.append('0');
            }
            sb.append(Integer.toHexString(v));
        }
        return sb.toString().toUpperCase();
    }

    /**
     * Converts string to byte array, used by encrypt/decrypt
     *
     * @param s : string
     * @return byte array
     */
    private static byte[] hexStringToByteArray(String s) {
        byte[] b = new byte[s.length() / 2];
        for (int i = 0; i < b.length; i++) {
            int index = i * 2;
            int v = Integer.parseInt(s.substring(index, index + 2), 16);
            b[i] = (byte) v;
        }
        return b;
    }

    // Encryption and Decryption of Passwrds
    //	http://www.rgagnon.com/javadetails/java-0400.html

    public void setLog(Log log) {
        myLog = log;
    }

    /**
     * Opens an xls workbook
     *
     * @param filename
     */
    public Workbook openWorkbook(String filename) {
        try {
            //System.out.println(new URI(filename));
            File f = new File(new URI(filename));
            //InputStream f = new FileInputStream(filename);
            return workbook = Workbook.getWorkbook(f);
        } catch (BiffException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Opens an xls workbook
     *
     * @param stream
     */
    public Workbook openWorkbook(InputStream stream) {
        try {
            //System.out.println(new URI(filename));
            //File f = new File(filename);
            //InputStream f = new FileInputStream(filename);
            return workbook = Workbook.getWorkbook(stream);
        } catch (BiffException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
    }

    public String[][] parseXLSSheet(String filename, int sheetNumber) {
        openWorkbook(filename);
        Sheet sheet = workbook.getSheet(sheetNumber);
        int rows = sheet.getRows();
        int cols = sheet.getColumns();
        String[][] data = new String[rows][cols];
        //for each row
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                data[row][col] = sheet.getCell(col, row).getContents();
            }
        }

        closeWorkbook();

        return data;
    }

    public String[][] parseXLSSheet(InputStream stream, int sheetNumber) {
        openWorkbook(stream);
        Sheet sheet = workbook.getSheet(sheetNumber);
        int rows = sheet.getRows();
        int cols = sheet.getColumns();
        String[][] data = new String[rows][cols];
        //for each row
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                data[row][col] = sheet.getCell(col, row).getContents();
            }
        }

        closeWorkbook();

        return data;
    }

    /**
     * Closes the workbook
     */
    public void closeWorkbook() {
        workbook.close();
    }

    /**
     * Encrypted string subclass
     *
     * @author Cognizant Technology CoE
     */
    public static class EncryptedString {
        private String myString = null;

        public EncryptedString(String string) {
            myString = string;
        }

        public String getString() {
            //PC
            if (System.getenv("USERPROFILE") != null){
//                myKeyFile = new File(System.getenv("USERPROFILE") + "/selenium/SeleniumAutomation.key");
            	myKeyFile = new File("selenium/SeleniumAutomation.key");
            }
                //MAC
            else{
//                myKeyFile = new File(System.getenv("HOME") + "/selenium/SeleniumAutomation.key");
                myKeyFile = new File("selenium/SeleniumAutomation.key");
            }
            return decrypt(myString, myKeyFile);
        }
    }


}
