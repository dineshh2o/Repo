package tech.nike.automation.common.framework.tools;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import tech.nike.automation.common.framework.core.Data;

import javax.swing.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by psibb1 on 8/5/2016.
 */
public class ResetWMSUserPassword {
    public static void main(String[] a) {

        //locators instantiation
        By txtWMSLoginUserName = By.id("j_username");
        By txtWMSLoginPassword = By.id("j_password");
        By btnWMSSignIn = By.name("btnEnter");
        By txtCompanyName = By.cssSelector("[alt='Find CompanyName'][type='text']");
        By lnkMenu = By.id("phMenu");
        By lnkCompanies = By.linkText("Companies");
        By btnApplyCompany = By.cssSelector("[id$='filterIdapply'][type='button']");
        By lnkUsers = By.cssSelector("[id$='opt_pUsers']");
        By txtUserID = By.cssSelector("[id*='filterIdUser'][type='text']");
        By btnApplyUserId = By.cssSelector("[id$='filterIdUserapply'][type='button']");
        By chkUserId = By.cssSelector("[id$='usertable'][type='checkbox']");
        By btnEdit = By.id("dataForm:UserList_Button_Panel_Edit");
        By collTxtPwd = By.cssSelector("[id^='dataForm:g']  [type='password']");
        By btnSaveUserDetails = By.cssSelector("[id$='SaveUserDetails'][alt='Save']");
        By lnkSignOut = By.linkText("Sign Out");
        By btnConfirmSignOut = By.id("SignoutOK");

        //parameters instantiation
        String strSuperUser = "system";
        String strPasswordUser = "13DF012D4F8A313B080719FB799AF9BB";
        int intGlobalTimeOut = 2000;
        final JPanel panel = new JPanel();
        String systemusername = System.getProperty("user.name");
        String searchCompanyName = "NIKE";

        //writing to file output
        File file = new File("C:\\Users\\" + systemusername + "\\selenium\\ResetWMSUserPassword" + getDateTime() + ".txt");
        FileOutputStream fis = null;
        try {
            fis = new FileOutputStream(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        PrintStream out = new PrintStream(fis);
        System.setOut(out);

        // objects and variables instantiation
        WebDriver driver;
        System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chromedriver.exe");
        driver = new ChromeDriver();
        // maximize the browser window
        driver.manage().window().maximize();

        //url input
        String appUrl = JOptionPane.showInputDialog(panel, "Please input environment URL to continue", "Enter the URL");
        while (appUrl == JOptionPane.UNINITIALIZED_VALUE) {
            waitForPageLoad(intGlobalTimeOut);
        }
        // launch the firefox browser and open the application url
        driver.get(appUrl);
        //wait for the page load to complete
        waitForPageLoad(intGlobalTimeOut);
        //verify if the environment is not null
        if (appUrl != null) {
            // enter a valid username in the email text box
            WebElement username = driver.findElement(txtWMSLoginUserName);
            username.isDisplayed();
            username.clear();
            username.sendKeys(strSuperUser);
            // enter a valid password in the password text box
            WebElement password = driver.findElement(txtWMSLoginPassword);
            password.isDisplayed();
            password.clear();
            //decrypt the user provided encrypted password
            Data.EncryptedString es = new Data.EncryptedString(strPasswordUser);
            strPasswordUser = es.getString();
            password.sendKeys(strPasswordUser);
            // click on the Sign in button
            WebElement signInButton = driver.findElement(btnWMSSignIn);
            signInButton.isDisplayed();
            signInButton.click();
            System.out.println("Super user logged in successfully");
            //wait for the page load to complete
            waitForPageLoad(intGlobalTimeOut);
            //navigate to menu companies
            WebElement menu = driver.findElement(lnkMenu);
            menu.isDisplayed();
            menu.click();
            //navigate to companies
            WebElement companies = driver.findElement(lnkCompanies);
            companies.isDisplayed();
            companies.click();
            System.out.println("Super user navigated to companies successfully");
            //wait for the page load to complete
            waitForPageLoad(intGlobalTimeOut);
            //enter the company name
            WebElement companyname = driver.findElement(txtCompanyName);
            companyname.isDisplayed();
            companyname.sendKeys(searchCompanyName);
            //click on the apply button
            WebElement applybtn = driver.findElement(btnApplyCompany);
            applybtn.isDisplayed();
            applybtn.click();
            //wait for the page load to complete
            waitForPageLoad(intGlobalTimeOut);
            System.out.println("Super searched for " + searchCompanyName + " users successfully");
            waitForPageLoad(5000);
            //click on the users link
            WebElement users = driver.findElement(lnkUsers);
            users.isDisplayed();
            users.click();
            //wait for the page load to complete
            waitForPageLoad(intGlobalTimeOut);
            //enter the user name
            WebElement userid = driver.findElement(txtUserID);
            userid.isDisplayed();
            String strid = JOptionPane.showInputDialog(panel, "Please input user id to continue",
                    "Enter the User ID");
            userid.sendKeys(strid);
            //click on the apply button
            WebElement applyUserid = driver.findElement(btnApplyUserId);
            applyUserid.isDisplayed();
            applyUserid.click();
            //wait for the page load to complete
            waitForPageLoad(intGlobalTimeOut);
            //select user id
            WebElement checkbox = driver.findElement(chkUserId);
            checkbox.isDisplayed();
            checkbox.click();
            //click on the edit
            WebElement edit = driver.findElement(btnEdit);
            edit.isDisplayed();
            edit.click();
            int confirm = 1;
            while (confirm == JOptionPane.NO_OPTION) {
                //enter the password
                String pwd = JOptionPane.showInputDialog(panel,
                        "Please input password to reset, make sure this is not previous 10 passwords",
                        "Enter the Password");
                List<WebElement> weAllPwds = driver.findElements(collTxtPwd);
                for (WebElement we : weAllPwds) {
                    we.isDisplayed();
                    we.sendKeys(pwd);
                }
                confirm = JOptionPane.showConfirmDialog(panel,
                        "Are you sure, your password is not from last 10 passwords", "Confirmation Dialog",
                        JOptionPane.YES_NO_OPTION);
            }
            //click on the save button
            WebElement save = driver.findElement(btnSaveUserDetails);
            save.isDisplayed();
            save.click();
            //wait for the alert to display
            waitForPageLoad(intGlobalTimeOut);
            System.out.println("Super user reset the password for user ID " + strid + "  successfully");
            JOptionPane.showMessageDialog(null, strid +
                            "  user password was reset successfully, please after 2 minutes",
                    "User Enabled Status", JOptionPane.INFORMATION_MESSAGE);
        } else {
            System.exit(0);
        }
        System.out.println(systemusername.toUpperCase() + "  confirmed that password was not from previous 10 passwords");
        //sign out
        WebElement signoutlink = driver.findElement(lnkSignOut);
        signoutlink.isDisplayed();
        signoutlink.click();
        System.out.println("Super user signing out");
        //wait for page load
        waitForPageLoad(intGlobalTimeOut);
        WebElement signoutOkBtn = driver.findElement(btnConfirmSignOut);
        signoutOkBtn.isDisplayed();
        signoutOkBtn.click();
        System.out.println("Super user signed out successfully");
        waitForPageLoad(intGlobalTimeOut);
        driver.quit();
        System.out.println("Closing down browser");
        System.exit(0);
    }

    public static void waitForPageLoad(int timeOut) {
        try {
            Thread.sleep(timeOut);
        } catch (InterruptedException ie) {
        }

    }

    public static String getDateTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("ddmmyyyy_hhmmss");
        String date = sdf.format(new Date());
        return date;
    }
}
