package tech.nike.automation.common.utils.parsers;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Created by psibb1 on 6/27/2016.
 */
public class XLToMapParser implements DataToMapParser {


    static final boolean VERBOSE = false;
    @SuppressWarnings("unused")
    private static final Log logger = LogFactory.getLog(XLToMapParser.class);

    private Map<String, Object> map = null; // map holds resource returned


    /**
     * Public function, get map representation of the xl file.
     *
     * @return HashMap of xl file elements.
     */
    public HashMap<String, Object> getHashMap() {
        return ((HashMap<String, Object>) map);
    }


    @SuppressWarnings("resource")
	public void parse(File f) throws IOException {
        String newF = f.toString();
        FileInputStream file = new FileInputStream(new File(newF));
        Workbook workbook = null;
        Sheet sheet = null;

        if (newF.endsWith("xlsx")) {
            //Create Workbook instance holding reference to .xlsx file
            workbook = new XSSFWorkbook(file);
        } else if (newF.endsWith("xls")) {
            //Create Workbook instance holding reference to .xls file
            workbook = new HSSFWorkbook(file);
        } else {
            throw new IllegalArgumentException("The specified file is not Excel file");
        }

        //Get first/desired sheet from the workbook
        sheet = workbook.getSheetAt(0);
        map = new HashMap<String, Object>();

        //parsing individual tests
        ArrayList<Object> testList = new ArrayList<Object>();

        //Iterate through each rows one by one
        Iterator<Row> iterator = sheet.iterator();

        while (iterator.hasNext()) {
            Row nextRow = iterator.next();
            Iterator<Cell> cellIterator = nextRow.cellIterator();

            //test values map for each test
            HashMap<String, Object> testValuesMap = new HashMap<String, Object>();

            String columnName = null;
            int index = 0;
            while (cellIterator.hasNext()) {
                Cell cell = cellIterator.next();
                columnName = cell.getSheet().getRow(0).getCell(index).getRichStringCellValue().toString();
                //Check the cell type and format accordingly
                switch (cell.getCellType()) {
                    case Cell.CELL_TYPE_STRING:
                        testValuesMap.put(columnName, cell.getStringCellValue());
                        break;
                    case Cell.CELL_TYPE_BOOLEAN:
                        testValuesMap.put(columnName, cell.getBooleanCellValue());
                        break;
                    case Cell.CELL_TYPE_NUMERIC:
                        testValuesMap.put(columnName, cell.getNumericCellValue());
                        break;
                }
                index = index + 1;
                testList.add(testValuesMap);
            }
        }
        //finally put all the tests into the overall map
        map.put("test", testList);
        workbook.close();
        file.close();
    }
}