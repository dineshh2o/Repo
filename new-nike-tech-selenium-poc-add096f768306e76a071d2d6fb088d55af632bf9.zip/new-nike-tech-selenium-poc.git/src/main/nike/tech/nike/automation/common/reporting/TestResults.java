package tech.nike.automation.common.reporting;

import org.testng.*;

import java.util.*;

/**
 * Holds sorted collections of test results
 */
public class TestResults {
    private static final Comparator<ITestResult> RESULT_ARGUMENT_COMPARATOR = new TestResultArgumentComparator();
    private static final Comparator<ITestNGMethod> METHOD_COMPARATOR = new TestMethodComparator();
    private static final Comparator<IClass> CLASS_COMPARATOR = new TestClassComparator();

    private SortedMap<ITestClass, SortedMap<ITestNGMethod, SortedSet<ITestResult>>> skipped = new TreeMap<ITestClass, SortedMap<ITestNGMethod, SortedSet<ITestResult>>>(CLASS_COMPARATOR);
    private SortedMap<ITestClass, SortedMap<ITestNGMethod, SortedSet<ITestResult>>> failed = new TreeMap<ITestClass, SortedMap<ITestNGMethod, SortedSet<ITestResult>>>(CLASS_COMPARATOR);
    private SortedMap<ITestClass, SortedMap<ITestNGMethod, SortedSet<ITestResult>>> passed = new TreeMap<ITestClass, SortedMap<ITestNGMethod, SortedSet<ITestResult>>>(CLASS_COMPARATOR);
    private SortedMap<ITestClass, SortedMap<ITestNGMethod, SortedSet<ITestResult>>> skippedConfigurations = new TreeMap<ITestClass, SortedMap<ITestNGMethod, SortedSet<ITestResult>>>(CLASS_COMPARATOR);
    private SortedMap<ITestClass, SortedMap<ITestNGMethod, SortedSet<ITestResult>>> failedConfigurations = new TreeMap<ITestClass, SortedMap<ITestNGMethod, SortedSet<ITestResult>>>(CLASS_COMPARATOR);

    public TestResults(ITestContext context) {
        // Build Sorted collection of SkippedConfigurations
        for (ITestNGMethod method : context.getSkippedConfigurations().getAllMethods()) {
            SortedSet<ITestResult> skippedConfigs = new TreeSet<ITestResult>(RESULT_ARGUMENT_COMPARATOR);
            skippedConfigs.addAll(context.getSkippedConfigurations().getResults(method));
            if (!skippedConfigs.isEmpty())
                addMethod(skippedConfigurations, method, skippedConfigs);
        }

        // Build Sorted collection of FailedConfigurations
        for (ITestNGMethod method : context.getFailedConfigurations().getAllMethods()) {
            SortedSet<ITestResult> failedConfigs = new TreeSet<ITestResult>(RESULT_ARGUMENT_COMPARATOR);
            failedConfigs.addAll(context.getFailedConfigurations().getResults(method));
            if (!failedConfigs.isEmpty())
                addMethod(failedConfigurations, method, failedConfigs);
        }

        // For each TestMethod, find all results (failed/passed/skipped) and then group that method into the
        // appropriate status collection
        for (ITestNGMethod method : context.getAllTestMethods()) {
            SortedSet<ITestResult> allResults = new TreeSet<ITestResult>(RESULT_ARGUMENT_COMPARATOR);
            allResults.addAll(context.getFailedTests().getResults(method));
            allResults.addAll(context.getPassedTests().getResults(method));
            allResults.addAll(context.getSkippedTests().getResults(method));

            // Method is considered SUCCESS if it has no Skipped param runs and at least one successful param run
            int methodStatus = ITestResult.SUCCESS;
            SortedMap<String, List<ITestResult>> groupedByTestParams = groupByTestParams(allResults);
            for (List<ITestResult> paramResults : groupedByTestParams.values()) {
                if (hasSkipped(paramResults)) {
                    methodStatus = ITestResult.SKIP;
                    break;
                } else if (!hasSuccess(paramResults)) {
                    methodStatus = ITestResult.FAILURE;
                    break;
                }
            }
            switch (methodStatus) {
                case ITestResult.SUCCESS:
                    addMethod(passed, method, allResults);
                    break;
                case ITestResult.FAILURE:
                    addMethod(failed, method, allResults);
                    break;
                case ITestResult.SKIP:
                    addMethod(skipped, method, allResults);
                    break;
            }
        }
    }

    // Does a deep count of the complicated maps
    private static int countMethods(SortedMap<ITestClass, SortedMap<ITestNGMethod, SortedSet<ITestResult>>> methodsCollection) {
        int skippedTestCount = 0;
        for (SortedMap<ITestNGMethod, SortedSet<ITestResult>> method : methodsCollection.values()) {
            skippedTestCount += method.size();
        }
        return skippedTestCount;
    }

    // Adds a new method to a collection, if the class reference for that method doesn't already exist, pre-create it.
    private static void addMethod(SortedMap<ITestClass, SortedMap<ITestNGMethod, SortedSet<ITestResult>>> collection, ITestNGMethod method, SortedSet<ITestResult> results) {
        if (!collection.containsKey(method.getTestClass())) {
            collection.put(method.getTestClass(), new TreeMap<ITestNGMethod, SortedSet<ITestResult>>(METHOD_COMPARATOR));
        }
        collection.get(method.getTestClass()).put(method, results);
    }

    // Groups a collection of TestResults by there parameters
    private static SortedMap<String, List<ITestResult>> groupByTestParams(Collection<ITestResult> testResults) {
        SortedMap<String, List<ITestResult>> groupedResults = new TreeMap<String, List<ITestResult>>();
        for (ITestResult result : testResults) {
            String arguments = ReportNGUtils.getArguments(result);
            if (!groupedResults.containsKey(arguments)) {
                groupedResults.put(arguments, new ArrayList<ITestResult>());
            }
            groupedResults.get(arguments).add(result);
        }
        return groupedResults;
    }

    /**
     * Checks if there are any successful results in a collection of TestResults
     *
     * @param testResults Collection of TestResults to check for success
     * @return True if any TestResult with success, else false
     */
    public static boolean hasSuccess(Collection<ITestResult> testResults) {
        for (ITestResult result : testResults) {
            if (result.isSuccess())
                return true;
        }
        return false;
    }

    /**
     * Checks if there are any skipped results in a collection of TestResults
     *
     * @param testResults Collection of TestResults to check for skipped
     * @return True if any TestResult with skipped, else false
     */
    public static boolean hasSkipped(Collection<ITestResult> testResults) {
        for (ITestResult result : testResults) {
            if (result.getStatus() == ITestResult.SKIP)
                return true;
        }
        return false;
    }

    public SortedMap<ITestClass, SortedMap<ITestNGMethod, SortedSet<ITestResult>>> getSkipped() {
        return skipped;
    }

    public SortedMap<ITestClass, SortedMap<ITestNGMethod, SortedSet<ITestResult>>> getFailed() {
        return failed;
    }

    public SortedMap<ITestClass, SortedMap<ITestNGMethod, SortedSet<ITestResult>>> getPassed() {
        return passed;
    }

    public SortedMap<ITestClass, SortedMap<ITestNGMethod, SortedSet<ITestResult>>> getSkippedConfigurations() {
        return skippedConfigurations;
    }

    public SortedMap<ITestClass, SortedMap<ITestNGMethod, SortedSet<ITestResult>>> getFailedConfigurations() {
        return failedConfigurations;
    }

    public int getSkippedTestsCount() {
        return countMethods(skipped);
    }

    public int getFailedTestsCount() {
        return countMethods(failed);
    }

    public int getPassedTestsCount() {
        return countMethods(passed);
    }

    public int getSkippedConfigurationsCount() {
        return countMethods(skippedConfigurations);
    }

    public int getFailedConfigurationsCount() {
        return countMethods(failedConfigurations);
    }
}
