package com.nike.automation.wms.testset.model;

import java.util.concurrent.ConcurrentHashMap;

import org.testng.annotations.Test;

import com.cognizant.framework.selenium.SeleniumTestParameters;
import com.nike.automation.wms.common.util.ExtendedBaseTest;
import com.nike.automation.wms.functional.library.WebComponent;

import supportlibraries.DriverScript;

public class TESTSET_WMS_ANYDC_SAMPLE extends ExtendedBaseTest {
	private WebComponent component;
	@Test(dataProvider = "xmlData")
	@TestData(fileName = "wms/data/other/any_dc_model_testcase_a.xml")
	public void test_otherdc_model_testcase_a(ConcurrentHashMap<String, Object> params) {
		SeleniumTestParameters testParameters = new SeleniumTestParameters(new Object() {}.getClass());
		testParameters.setCurrentTestInstance("MODEL-TC-A");
		DriverScript driverScript = getDefaultScriptSettings(testParameters, params);
		driverScript.getTestParameters().setCurrentTestDescription(testParameters.getCurrentTestInstance().replace("_", " "));
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}
	
	@Test(dataProvider = "xmlData", dependsOnMethods = {"test_otherdc_model_testcase_a" })	
	@TestData(fileName = "wms/data/other/any_dc_model_testcase_b.xml")
	public void test_otherdc_model_testcase_b(ConcurrentHashMap<String, Object> params) {
		SeleniumTestParameters testParameters = new SeleniumTestParameters(new Object() {}.getClass());
		testParameters.setCurrentTestInstance("MODEL-TC-B");
		DriverScript driverScript = getDefaultScriptSettings(testParameters, params);
		driverScript.getTestParameters().setCurrentTestDescription(testParameters.getCurrentTestInstance().replace("_", " "));
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}	
	
	@Override
	public void executeTest() {
		component = new WebComponent(driver);
		switch (driver.getTestParameters().getTcIdentifier()) {
		case "test_otherdc_model_testcase_a":
			test_otherdc_model_testcase_a();
			break;
		case "test_otherdc_model_testcase_b":
			test_otherdc_model_testcase_b();
			break;
		}
	}	
	
	public void test_otherdc_model_testcase_a() {
		component.preparePostXml();
		//component.verifyWmsLoginProcess();
		//component.storeApplicationData();
	}
	
	public void test_otherdc_model_testcase_b(){
		component.verifyWmsLoginProcess();
		component.readApplicationData();
	}
}
