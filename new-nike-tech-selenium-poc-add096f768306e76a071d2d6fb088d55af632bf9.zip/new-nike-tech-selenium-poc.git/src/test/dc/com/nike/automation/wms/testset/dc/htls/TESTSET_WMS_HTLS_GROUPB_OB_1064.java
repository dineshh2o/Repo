package com.nike.automation.wms.testset.dc.htls;

import java.util.concurrent.ConcurrentHashMap;
import org.testng.annotations.Test;
import com.cognizant.framework.selenium.SeleniumTestParameters;
import com.nike.automation.wms.common.util.ExtendedBaseTest;
import com.nike.automation.wms.functional.library.WebComponent;
import supportlibraries.DriverScript;


/**
 * HTLS Out bound Test case
 * 
 * @author Cognizant 
 */

public class TESTSET_WMS_HTLS_GROUPB_OB_1064 extends ExtendedBaseTest {
	private WebComponent component;

	@Test(dataProvider = "xmlData")
	@TestData(fileName = "wms/data/htls/htls_ob_1064_pw03at_hp_20_int51_alloc_and_task_creation_promo.xml")
	public void test_PW03AT_HP_20_INT51_Alloc_and_Task_Creation_PROMO(ConcurrentHashMap<String, Object> params) {
		SeleniumTestParameters testParameters = new SeleniumTestParameters(new Object() {
		}.getClass());
		testParameters.setCurrentTestInstance("INT51_Alloc_Task");
		DriverScript driverScript = getDefaultScriptSettings(testParameters, params);
		driverScript.getTestParameters()
				.setCurrentTestDescription(testParameters.getCurrentTestInstance().replace("_", " "));
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "xmlData",dependsOnMethods = {"test_PW03AT_HP_20_INT51_Alloc_and_Task_Creation_PROMO" })
	@TestData(fileName = "wms/data/htls/htls_ob_1064_pe01ex_ap_10_pr_int51_discretre_pick_parital_short.xml")
	public void test_PE01EX_AP_10_PR_INT51_Discretre_Pick_Parital_Short(ConcurrentHashMap<String, Object> params) {
		SeleniumTestParameters testParameters = new SeleniumTestParameters(new Object() {
		}.getClass());
		testParameters.setCurrentTestInstance("INT51_Discretre_Pick");
		DriverScript driverScript = getDefaultScriptSettings(testParameters, params);
		driverScript.getTestParameters()
				.setCurrentTestDescription(testParameters.getCurrentTestInstance().replace("_", " "));
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	// @Test(groups = {dataProvider = "xmlData", dependsOnMethods = {"test_PE01EX_AP_10_PR_INT51_Discretre_Pick_Parital_Short" })
	@TestData(fileName = "wms/data/htls/htls_ib_1064_pre_recv_initiateshipment_hp_04_multiasn.xml")
	public void test_CC01EX_AP_03_PR_INT51_PR_Parital_Short_Chase_completion(ConcurrentHashMap<String, Object> params) {
		SeleniumTestParameters testParameters = new SeleniumTestParameters(new Object() {
		}.getClass());
		testParameters.setCurrentTestInstance("INT51_PR_Parital");
		DriverScript driverScript = getDefaultScriptSettings(testParameters, params);
		driverScript.getTestParameters()
				.setCurrentTestDescription(testParameters.getCurrentTestInstance().replace("_", " "));
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}


/**
 * @author Cognizant 
 * Method to trigger the actual test method
*/	@Override
	public void executeTest() {
		component = new WebComponent(driver);
		switch (driver.getTestParameters().getTcIdentifier()) {
		case "test_PW03AT_HP_20_INT51_Alloc_and_Task_Creation_PROMO":
			test_PW03AT_HP_20_INT51_Alloc_and_Task_Creation_PROMO();
			break;
		case "test_PE01EX_AP_10_PR_INT51_Discretre_Pick_Parital_Short":
			test_PE01EX_AP_10_PR_INT51_Discretre_Pick_Parital_Short();
			break;
		case "test_CC01EX_AP_03_PR_INT51_PR_Parital_Short_Chase_completion":
			test_CC01EX_AP_03_PR_INT51_PR_Parital_Short_Chase_completion();
			break;
		}
	}


/**
 * @author Cognizant 
 * QC TC Name : OB_1064_PW03AT_HP_20_INT51_Alloc_and_Task_Creation_PROMO
 * Application : HTLS
 * QC TC id : 59479
 * 
*/	public void test_PW03AT_HP_20_INT51_Alloc_and_Task_Creation_PROMO() {
		component.preparePostXml();
		component.verifyWmsLoginProcess();
		component.verifyPostXml();
		component.verifyDOCreation();
		component.runRoutingWave();
		component.updatePassReport("PRE-REQUISIT", "Routing wave configured properly.");
		component.runPickingWave();
		component.verifyDoAfterPickingWave();

	}

/**
 * @author Cognizant 
 * QC TC Name : OB_1064_PE01EX_AP_10_PR_INT51_Discretre_Pick_Parital_Short
 * Application : HTLS
 * QC TC id : 67054
 * 
*/	public void test_PE01EX_AP_10_PR_INT51_Discretre_Pick_Parital_Short() {
	 	component.verifyWmsLoginProcess();
	 	component.verifyTaskBeforeRF();
		component.verifyRFTask();
//		component.verifyPickShort();
	}

/**
 * @author Cognizant 
 * QC TC Name : OB_1064_CC01EX_AP_03_PR_INT51_PR_Parital_Short_Chase_completion
 * Application : HTLS
 * QC TC id : 67057
 * 
*/	public void test_CC01EX_AP_03_PR_INT51_PR_Parital_Short_Chase_completion() {
		component.verifyWmsLoginProcess();
	}
}
