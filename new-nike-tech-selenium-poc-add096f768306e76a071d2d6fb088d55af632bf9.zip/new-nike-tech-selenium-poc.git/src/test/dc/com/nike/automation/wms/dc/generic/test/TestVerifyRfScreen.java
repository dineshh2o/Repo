package com.nike.automation.wms.dc.generic.test;

import org.testng.annotations.Test;

import com.cognizant.framework.selenium.CraftDriver;
import com.cognizant.framework.selenium.SeleniumTestParameters;
import com.nike.automation.wms.common.page.WMSHomePage;
import com.nike.automation.wms.common.page.WMSLoginPage;
import com.nike.automation.wms.common.util.ExtendedBaseTest;
import com.nike.automation.wms.common.util.BasePageFactory;
import com.nike.automation.wms.common.util.CommonUtils;

import supportlibraries.DriverScript;
import tech.nike.automation.common.framework.core.Selenium;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;


public class TestVerifyRfScreen extends ExtendedBaseTest {


	@Test (groups={"HTLS_GROUPA"}, dataProvider = "xmlData")    
    @TestData(fileName= "wms/data/htls/wmsHtlsLpn.xml")   
    public void verifyRfScreenOperation(ConcurrentHashMap<String, Object> params) {
		Class<? extends Object> currentClass = new Object(){}.getClass();
		
		SeleniumTestParameters testParameters = new SeleniumTestParameters(
				CommonUtils.getPackageName(currentClass),CommonUtils.getClassName(currentClass));
		testParameters.setCurrentTestInstance(CommonUtils.getMethodName(currentClass));
		DriverScript driverScript = getDefaultScriptSettings(testParameters, params);
		driverScript.getTestParameters().setCurrentTestDescription("Test-"+testParameters.getCurrentTestInstance());
		driverScript.driveTestExecution();
		
		tearDownTestRunner(testParameters, driverScript);	
	}
	
	@Override
	public void executeTest() {    
	    switch(driver.getTestParameters().getCurrentTestInstance()){
	    	case "verifyRfScreenOperation":verifyRfScreenOperation(driver);	    	
	    }	        
	}    
	
	public void verifyRfScreenOperation(CraftDriver driver) {	
	    Selenium se = driver.getSelenium();
	    Map<String, Object> params = driver.getTestcaseParams();
        String rfsceenUrl=(String)params.get("rfsceen");
        se.webDriver.get(rfsceenUrl);
        se.webDriver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        WMSLoginPage wmsLoginPageObject = BasePageFactory.initElements(driver, WMSLoginPage.class);
        @SuppressWarnings("unused")
		WMSHomePage wmsHomePageObject = BasePageFactory.initElements(driver, WMSHomePage.class);
        se.log.logTestStep("Start - Test verifyAssignAsnData");

        se.assertion.verifyTrue("User Logged into RF", wmsLoginPageObject.verifyWMSRfScreenLogin(params));
        se.assertion.verifyTrue("RF Action", wmsLoginPageObject.verifyWMSRfAction(params));
        //se.assertion.verifyTrue("post xml", wmsHomePageObject.verifyAssignAsn(params));


        //Garbage collection of failed steps
        testTearDown(se);
        se.log.logTestStep("End - Tes");
    }
}
