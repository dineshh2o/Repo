package com.nike.automation.wms.dc.generic.test;

import org.testng.annotations.Test;

import com.cognizant.framework.selenium.SeleniumTestParameters;
import com.nike.automation.wms.common.page.WMSAsnShipmentPage;
import com.nike.automation.wms.common.page.WMSHomePage;
import com.nike.automation.wms.common.page.WMSLoginPage;
import com.nike.automation.wms.common.util.ExtendedBaseTest;
import com.nike.automation.wms.common.util.BasePageFactory;
import com.nike.automation.wms.common.util.CommonUtils;

import supportlibraries.DriverScript;
import tech.nike.automation.common.framework.core.Selenium;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;


public class TestVerifyAssignAsn extends ExtendedBaseTest {
    /**Method to post synthetic data into WMS
     *
     * @param myBrowser : browser type used for test
     * @param se : driver type used for test
     * @param params : external file data parameters
     */

	@Test (groups={"HTLS_GROUPA"}, dataProvider = "xmlData")    
    @TestData(fileName= "wms/data/htls/wmsHtlsLpn.xml")        
    public void verifyAssignAsnData(ConcurrentHashMap<String, Object> params) {
	
		Class<? extends Object> currentClass = new Object(){}.getClass();
		
		SeleniumTestParameters testParameters = new SeleniumTestParameters(
				CommonUtils.getPackageName(currentClass),CommonUtils.getClassName(currentClass));
		testParameters.setCurrentTestInstance(CommonUtils.getMethodName(currentClass));
		DriverScript driverScript = getDefaultScriptSettings(testParameters, params);
		driverScript.getTestParameters().setCurrentTestDescription("Test-"+testParameters.getCurrentTestInstance());
		driverScript.driveTestExecution();
		
		tearDownTestRunner(testParameters, driverScript);	
	}
	
	@Override
	public void executeTest() {    
	    switch(driver.getTestParameters().getCurrentTestInstance()){
	    	case "verifyAssignAsnData":verifyAssignAsnData();	    	
	    }	        
	}    
    public void verifyAssignAsnData() {
	    Selenium se = driver.getSelenium();
	    Map<String, Object> params = driver.getTestcaseParams();
        String environment=(String)params.get("environment");
        
        se.webDriver.get(environment);
        se.webDriver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        WMSLoginPage wmsLoginPageObject = BasePageFactory.initElements(driver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = BasePageFactory.initElements(driver, WMSHomePage.class);
		WMSAsnShipmentPage wmsAsnShipmentObject = BasePageFactory.initElements(driver, WMSAsnShipmentPage.class);
        se.log.logTestStep("Start - Test verifyAssignAsnData");

        se.assertion.verifyTrue("User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));
        se.assertion.verifyTrue("Open Assign", wmsAsnShipmentObject.openAssignAsn(params));
        se.assertion.verifyTrue("Assign Asn", wmsHomePageObject.verifyAssignAsn(params));


        //Garbage collection of failed steps
        testTearDown(se);
        se.log.logTestStep("End - Tes");
    }
}
