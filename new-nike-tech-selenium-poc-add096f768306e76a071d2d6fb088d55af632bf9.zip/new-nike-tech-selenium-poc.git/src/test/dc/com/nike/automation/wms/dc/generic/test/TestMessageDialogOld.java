package com.nike.automation.wms.dc.generic.test;

import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Test;
import com.nike.automation.wms.common.page.WMSAsnShipmentPage;
import com.nike.automation.wms.common.page.WMSLoginPage;
import com.nike.automation.wms.common.util.ExtendedBaseTest;
import com.nike.automation.wms.common.util.BasePageFactory;
import tech.nike.automation.common.framework.core.Selenium;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

/**
 * Created by psibb1 on 6/23/2016.
 */
public class TestMessageDialogOld extends ExtendedBaseTest {
    /**Method to post synthetic data into WMS
     *
     * @param myBrowser : browser type used for test
     * @param se : driver type used for test
     * @param params : external file data parameters
     */
	
	@Test (groups={"HTLS_GROUPA"}, dataProvider = "xmlData")    
    @TestData(fileName= "wms/data/nalc/wmsNalcLpn.xml")        
    public void verifyMessageDialog(ConcurrentHashMap<String, Object> params) {
	    Selenium se = new Selenium();
	    se.webDriver = new InternetExplorerDriver();
        String environment=(String)params.get("environment");
        
        se.webDriver.get(environment);
        se.webDriver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        WMSLoginPage wmsLoginPageObject = BasePageFactory.initElements(driver, WMSLoginPage.class);
		WMSAsnShipmentPage wmsAsnShipmentObject = BasePageFactory.initElements(driver, WMSAsnShipmentPage.class);
        se.log.logTestStep("Start - Test verifyAssignAsnData");

        se.assertion.verifyTrue("User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));
        se.assertion.verifyTrue("Open Assign ASn", wmsAsnShipmentObject.openAssignAsn(params));
        se.assertion.verifyTrue("Message Dialog", wmsAsnShipmentObject.checkMessageDioalog(params));

        //Garbage collection of failed steps
        testTearDown(se);
    }
	
	@Override
	public void setUp() {
		report.addTestLogSection("Setup");

		// Setup logic

	}

	@Override
	public void executeTest() {
		// main logic
	}

	@Override
	public void tearDown() {
		report.addTestLogSection("Teardown");

		// Tear Down Logic
	}	
}
