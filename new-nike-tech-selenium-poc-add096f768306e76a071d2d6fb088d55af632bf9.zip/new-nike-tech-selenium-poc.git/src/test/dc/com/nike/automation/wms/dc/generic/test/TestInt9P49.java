package com.nike.automation.wms.dc.generic.test;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.testng.annotations.Test;

import com.cognizant.framework.selenium.SeleniumTestParameters;
import com.nike.automation.wms.common.object.GenericWmsElement;
import com.nike.automation.wms.common.util.ApplicationKeys;
import com.nike.automation.wms.common.util.ExtendedBaseTest;
import com.nike.automation.wms.functional.library.WebComponent;

import supportlibraries.DriverScript;

public class TestInt9P49 extends ExtendedBaseTest {
	private WebComponent component;
	@Test(dataProvider = "xmlData")
	@TestData(fileName = "wms/data/ham/ham_ob_1064ndc_pw03at_hp_28_int9_p40_maxfromdyn.xml")
	public void test_PW03AT_HP_28_INT9_P40_MaxFromDyn(ConcurrentHashMap<String, Object> params) {
		SeleniumTestParameters testParameters = new SeleniumTestParameters(new Object() {}.getClass());
		testParameters.setCurrentTestInstance("pw03at_hp_28_int9");
		DriverScript driverScript = getDefaultScriptSettings(testParameters, params);
		driverScript.getTestParameters().setCurrentTestDescription(testParameters.getCurrentTestInstance().replace("_", " "));
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Override
	public void executeTest() {
		component = new WebComponent(driver);
		System.out.println("ID:"+driver.getTestParameters().getTcIdentifier());
		switch (driver.getTestParameters().getTcIdentifier()) {
		case "test_PW03AT_HP_28_INT9_P40_MaxFromDyn":
			test_PW03AT_HP_28_INT9_P40_MaxFromDyn();
			break;
		}
	}
	
	/**
	 * @author Cognizant 
	 * QC TC Name : OB_1064NDC_PW03AT_HP_28_INT9_P40_MaxFromDyn
	 * Application : HAM
	 * QC TC id : 59487
	 * 
	*/
	public void test_PW03AT_HP_28_INT9_P40_MaxFromDyn() {
		
	    Map<String, Object> params = driver.getTestcaseParams();
	    String identifier = (String) params.get("identifier");
	    
		driver.getDataReserver(identifier).getDoIds().getElement().add(new GenericWmsElement("DistributionId", "AUTO008805551"));
		driver.getDataReserver(identifier).getDoIds().getElement().add(new GenericWmsElement("DistributionId", "AUTO108805551"));
		driver.getDataReserver(identifier).setAppsData(ApplicationKeys.TRANSIT_WAVE_NUMBER, "201701200003");
//		component.preparePostXml();
		component.verifyWmsLoginProcess();
//		component.verifyPostXml();				
//		component.verifyDOCreation();
//		component.runRoutingWave();
//		component.updatePassReport("PRE-REQUISIT", "Routing wave configured properly.");
//		component.runPickingWave();
		component.verifyTaskAndItemLocation();
		component.signOut();	
	}
	
	
}
