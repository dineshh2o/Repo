package com.nike.automation.wms.dc.generic.test;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.testng.annotations.Test;
import com.cognizant.framework.selenium.SeleniumTestParameters;
import com.nike.automation.wms.common.util.ExtendedBaseTest;
import com.nike.automation.wms.functional.library.WebComponent;
import supportlibraries.DriverScript;

public class TestVerifyDO  extends ExtendedBaseTest {
	private WebComponent component;
	@Test(dataProvider = "xmlData")
	@TestData(fileName = "wms/data/htls/htls_ob_1064_pw03at_hp_20_int51_alloc_and_task_creation_promo.xml")
	public void test_PW03AT_HP_20_INT51_Alloc_and_Task_Creation_PROMO(ConcurrentHashMap<String, Object> params) {
		SeleniumTestParameters testParameters = new SeleniumTestParameters(new Object() {
		}.getClass());
		testParameters.setCurrentTestInstance("INT51_Alloc_Task");
		DriverScript driverScript = getDefaultScriptSettings(testParameters, params);
		driverScript.getTestParameters()
				.setCurrentTestDescription(testParameters.getCurrentTestInstance().replace("_", " "));
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Override
	public void executeTest() {
		component = new WebComponent(driver);
		switch (driver.getTestParameters().getTcIdentifier()) {
		case "test_PW03AT_HP_20_INT51_Alloc_and_Task_Creation_PROMO":
			test_PW03AT_HP_20_INT51_Alloc_and_Task_Creation_PROMO();
			break;
		
		}
	}
		public void test_PW03AT_HP_20_INT51_Alloc_and_Task_Creation_PROMO() {
		    Map<String, Object> params = driver.getTestcaseParams();
		    String identifier = (String) params.get("identifier");			
//			component.preparePostXml();
			component.verifyWmsLoginProcess();
//			component.verifyPostXml();
//			component.verifyDOCreation();
			driver.getDataReserver(identifier).getAppsData().put("DistributionOrderId-1", "AUTO015440330");
			driver.getDataReserver(identifier).getAppsData().put("majorDOId", "951101954");
			component.runRoutingWave();
//			component.verifyPickingWave();

		}

	}

