package com.nike.automation.wms.testset.dc.ham;

import java.util.concurrent.ConcurrentHashMap;
import org.testng.annotations.Test;
import com.cognizant.framework.selenium.SeleniumTestParameters;
import com.nike.automation.wms.common.util.ExtendedBaseTest;
import com.nike.automation.wms.functional.library.WebComponent;

import supportlibraries.DriverScript;
/**
 * HAM Out bound Test case 
 * @author Cognizant 
 */
public class TESTSET_WMS_HAM_GROUPA_OB_1064 extends ExtendedBaseTest {
	private WebComponent component;
	@Test(dataProvider = "xmlData")
	@TestData(fileName = "wms/data/ham/ham_ob_1064ndc_pw03at_hp_28_int9_p40_maxfromdyn.xml")
	public void test_PW03AT_HP_28_INT9_P40_MaxFromDyn(ConcurrentHashMap<String, Object> params) {
		SeleniumTestParameters testParameters = new SeleniumTestParameters(new Object() {}.getClass());
		testParameters.setCurrentTestInstance("P40_MaxFromDyn");
		DriverScript driverScript = getDefaultScriptSettings(testParameters, params);
		driverScript.getTestParameters().setCurrentTestDescription(testParameters.getCurrentTestInstance().replace("_", " "));
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}
	
	@Test(dataProvider = "xmlData", dependsOnMethods = {"test_PW03AT_HP_28_INT9_P40_MaxFromDyn" })	
	@TestData(fileName = "wms/data/ham/ham_ob_1064_ndc_pe01te_hp_04_int9_ilpn_pull_to_replen_spur.xml")
	public void test_PE01TE_HP_04_INT9_iLPN_Pull_To_Replen_Spur(ConcurrentHashMap<String, Object> params) {
		SeleniumTestParameters testParameters = new SeleniumTestParameters(new Object() {}.getClass());
		testParameters.setCurrentTestInstance("INT9_ilpn_pull_to_replen_spur");
		DriverScript driverScript = getDefaultScriptSettings(testParameters, params);
		driverScript.getTestParameters().setCurrentTestDescription(testParameters.getCurrentTestInstance().replace("_", " "));
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}	
	
	@Test(dataProvider = "xmlData", dependsOnMethods = {"test_PE01TE_HP_04_INT9_iLPN_Pull_To_Replen_Spur" })	
	@TestData(fileName = "wms/data/ham/ham_ob_1064_ndc_pe01te_hp_05_int_9_make_replen_cart_and_replen.xml")
	public void test_PE01TE_HP_05_INT_9_Make_Replen_Cart_And_Replen(ConcurrentHashMap<String, Object> params) {
		SeleniumTestParameters testParameters = new SeleniumTestParameters(new Object() {}.getClass());
		testParameters.setCurrentTestInstance("INT_9_Make_Replen_Cart_And_Replen");
		DriverScript driverScript = getDefaultScriptSettings(testParameters, params);
		driverScript.getTestParameters().setCurrentTestDescription(testParameters.getCurrentTestInstance().replace("_", " "));
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	
	/**
	 * @author Cognizant 
	 * Method to trigger the actual test method
	*/
	@Override
	public void executeTest() {
		component = new WebComponent(driver);
		System.out.println("ID:"+driver.getTestParameters().getTcIdentifier());
		switch (driver.getTestParameters().getTcIdentifier()) {
		case "test_PW03AT_HP_28_INT9_P40_MaxFromDyn":
			test_PW03AT_HP_28_INT9_P40_MaxFromDyn();
			break;
		case "test_PE01TE_HP_04_INT9_iLPN_Pull_To_Replen_Spur":
			test_PE01TE_HP_04_INT9_iLPN_Pull_To_Replen_Spur();
			break;
		case "test_PE01TE_HP_05_INT_9_Make_Replen_Cart_And_Replen":
			test_PE01TE_HP_05_INT_9_Make_Replen_Cart_And_Replen();
			break;
	
		}
	}
	
	/**
	 * @author Cognizant 
	 * QC TC Name : OB_1064NDC_PW03AT_HP_28_INT9_P40_MaxFromDyn
	 * Application : HAM
	 * QC TC id : 59487
	 * 
	*/
	public void test_PW03AT_HP_28_INT9_P40_MaxFromDyn() {
		component.preparePostXml();
		component.verifyWmsLoginProcess();
		component.verifyPostXml();				
		component.verifyDOCreation();
		component.runRoutingWave();
		component.updatePassReport("PRE-REQUISIT", "Routing wave configured properly.");
		component.runPickingWave();
		component.verifyTaskAndItemLocation();
		component.signOut();
	}
	
	/**
	 * @author Cognizant 
	 * QC TC Name : OB_1064_NDC_PE01TE_HP_04_INT 9_iLPN_Pull_To_Replen_Spur
	 * Application : HAM
	 * QC TC id : 66699
	 * 
	*/
	public void test_PE01TE_HP_04_INT9_iLPN_Pull_To_Replen_Spur(){
		component.verifyWmsLoginProcess();
		component.releaseTask();
		component.assembleTask();
	}
	
	/**
	 * @author Cognizant 
	 * QC TC Name : OB_1064_NDC_PE01TE_HP_04_INT 9_iLPN_Pull_To_Replen_Spur
	 * Application : HAM
	 * QC TC id : 66699
	 * 
	*/
	public void test_PE01TE_HP_05_INT_9_Make_Replen_Cart_And_Replen(){
		component.verifyWmsLoginProcess();
		component.makeReplenCart();
		component.verifyReplenishment();
	}

}
