package com.nike.automation.wms.testset.dc.htls;

import java.util.concurrent.ConcurrentHashMap;
import org.testng.annotations.Test;
import com.cognizant.framework.selenium.SeleniumTestParameters;
import com.nike.automation.wms.common.util.ExtendedBaseTest;
import com.nike.automation.wms.functional.library.WebComponent;
import supportlibraries.DriverScript;

public class TESTSET_WMS_HTLS_GROUPA_IB_1064 extends ExtendedBaseTest {

	@Test(groups = { "htls-groupa" }, dataProvider = "xmlData")
	@TestData(fileName = "wms/data/htls/htls_ib_1064_pre_recv_initiateshipment_hp_04_multiasn.xml")
	public void test_PRE_RECV_InitiateShipment_HP_04_MultiASN(ConcurrentHashMap<String, Object> params) {
		SeleniumTestParameters testParameters = new SeleniumTestParameters(new Object() {}.getClass());
		testParameters.setCurrentTestInstance("PRE_RECV_InitiateShipment");
		DriverScript driverScript = getDefaultScriptSettings(testParameters, params);
		driverScript.getTestParameters().setCurrentTestDescription(testParameters.getCurrentTestInstance().replace("_", " "));
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(groups = { "htls-groupa" }, dataProvider = "xmlData", dependsOnMethods = {
			"test_PRE_RECV_InitiateShipment_HP_04_MultiASN" })
	@TestData(fileName = "wms/data/htls/htls_ib_1064_recv_manualrecv_hp_06_multiasn_multilpn.xml")
	public void test_RECV_ManualRecv_HP_06_MultiASN_MultiLPN_MultiItem_SingleShip_Sorted_SinPalLocn_MixPalLocn(
			ConcurrentHashMap<String, Object> params) {
		SeleniumTestParameters testParameters = new SeleniumTestParameters(new Object() {}.getClass());
		testParameters.setCurrentTestInstance("PRE_RECV_Manual");
		DriverScript driverScript = getDefaultScriptSettings(testParameters, params);
		driverScript.getTestParameters().setCurrentTestDescription(testParameters.getCurrentTestInstance().replace("_", " "));
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

//	@Test(groups = { "htls-groupa" }, dataProvider = "xmlData", dependsOnMethods = {
//			"test_RECV_ManualRecv_HP_06_MultiASN_MultiLPN_MultiItem_SingleShip_Sorted_SinPalLocn_MixPalLocn" })
	@TestData(fileName = "wms/data/htls/htls_ib_1064_ptwy_hp_01_sugg_ptwy_fr_casestg.xml")
	public void test_PTWY_HP_01_Sugg_Ptwy_fr_CaseStg_2_CaseResv_LocEmpty(ConcurrentHashMap<String, Object> params) {
		SeleniumTestParameters testParameters = new SeleniumTestParameters(new Object() {}.getClass());
		testParameters.setCurrentTestInstance("Sugg_Ptwy_fr");
		DriverScript driverScript = getDefaultScriptSettings(testParameters, params);
		driverScript.getTestParameters().setCurrentTestDescription(testParameters.getCurrentTestInstance().replace("_", " "));
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Override
	public void executeTest() {
		System.out.println("ID:"+driver.getTestParameters().getTcIdentifier());
		switch (driver.getTestParameters().getTcIdentifier()) {
		case "test_PRE_RECV_InitiateShipment_HP_04_MultiASN":
			test_PRE_RECV_InitiateShipment_HP_04_MultiASN();
			break;
		case "test_RECV_ManualRecv_HP_06_MultiASN_MultiLPN_MultiItem_SingleShip_Sorted_SinPalLocn_MixPalLocn":
			test_RECV_ManualRecv_HP_06_MultiASN_MultiLPN_MultiItem_SingleShip_Sorted_SinPalLocn_MixPalLocn();
			break;
		case "test_PTWY_HP_01_Sugg_Ptwy_fr_CaseStg_2_CaseResv_LocEmpty":
			test_PTWY_HP_01_Sugg_Ptwy_fr_CaseStg_2_CaseResv_LocEmpty();
			break;			
		}
	}

	public void test_PRE_RECV_InitiateShipment_HP_04_MultiASN() {
		WebComponent component = new WebComponent(driver);
		component.verifyWmsLoginProcess();
		//component.verifyMessageDialog();	
	}

	public void test_RECV_ManualRecv_HP_06_MultiASN_MultiLPN_MultiItem_SingleShip_Sorted_SinPalLocn_MixPalLocn() {
		WebComponent component = new WebComponent(driver);
		component.verifyWmsLoginProcess();
		//component.verifyPixTransaction();		
	}

	public void test_PTWY_HP_01_Sugg_Ptwy_fr_CaseStg_2_CaseResv_LocEmpty() {
		WebComponent component = new WebComponent(driver);
		component.verifyWmsLoginProcess();
		component.verifyRfScreenOperation();	
	}
}
