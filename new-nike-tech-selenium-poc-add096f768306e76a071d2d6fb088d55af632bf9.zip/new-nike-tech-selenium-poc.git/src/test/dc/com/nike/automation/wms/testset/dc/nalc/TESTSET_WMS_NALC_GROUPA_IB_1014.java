package com.nike.automation.wms.testset.dc.nalc;

import java.util.concurrent.ConcurrentHashMap;
import org.testng.annotations.Test;
import com.cognizant.framework.selenium.Browser;
import com.cognizant.framework.selenium.SeleniumTestParameters;
import com.nike.automation.wms.common.util.ExtendedBaseTest;
import com.nike.automation.wms.functional.library.WebComponent;
import supportlibraries.DriverScript;

public class TESTSET_WMS_NALC_GROUPA_IB_1014 extends ExtendedBaseTest {
	private WebComponent component;

	@Test(dataProvider = "xmlData")
	@TestData(fileName = "wms/data/nalc/nalc_ib_1014_pre_recv_initiateshipment_hp_05_singleasn.xml")
	public void test_PRE_RECV_InitiateShipment_HP_05_SingleASN(ConcurrentHashMap<String, Object> params) {
		SeleniumTestParameters testParameters = new SeleniumTestParameters(new Object() {}.getClass());
		testParameters.setCurrentTestInstance("PRE_RECV_InitiateShipment");
		DriverScript driverScript = getDefaultScriptSettings(testParameters, params);
		driverScript.getTestParameters().setBrowser(Browser.INTERNET_EXPLORER);
		driverScript.getTestParameters()
				.setCurrentTestDescription(testParameters.getCurrentTestInstance().replace("_", " "));
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}
	
	@Test(dataProvider = "xmlData")
	@TestData(fileName = "wms/data/nalc/nalc_ib_1014_recv_manualrecv_hp_20_non_con_item.xml")
	public void test_PRE_RECV_ManualRecv_HP_20_Non_Con_Item(ConcurrentHashMap<String, Object> params) {
		SeleniumTestParameters testParameters = new SeleniumTestParameters(new Object() {
		}.getClass());
		testParameters.setCurrentTestInstance("PRE_RECV_ManualRecv");
		DriverScript driverScript = getDefaultScriptSettings(testParameters, params);
		driverScript.getTestParameters().setBrowser(Browser.INTERNET_EXPLORER);
		driverScript.getTestParameters()
				.setCurrentTestDescription(testParameters.getCurrentTestInstance().replace("_", " "));
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}
	
	@Override
	public void executeTest() {
		component = new WebComponent(driver);
		switch (driver.getTestParameters().getTcIdentifier()) {
		case "test_PRE_RECV_InitiateShipment_HP_05_SingleASN":
			test_PRE_RECV_InitiateShipment_HP_05_SingleASN();
			break;
		case "test_PRE_RECV_ManualRecv_HP_20_Non_Con_Item":
			test_PRE_RECV_ManualRecv_HP_20_Non_Con_Item();
			break;
		}
	}
	public void test_PRE_RECV_InitiateShipment_HP_05_SingleASN() {
		component.preparePostXml();
		component.verifyWmsLoginProcess();
		component.verifyPostXml();
		component.verifyShipmentAsn();
		component.signOut();
	}
	public void test_PRE_RECV_ManualRecv_HP_20_Non_Con_Item() {
		component.preparePostXml();
		component.verifyWmsLoginProcess();
		component.verifyPostXml();
		component.verifyShipmentAsn();
		component.asnMannualRecv();
		component.verifyShiAsnAndLpn();

	}
}
