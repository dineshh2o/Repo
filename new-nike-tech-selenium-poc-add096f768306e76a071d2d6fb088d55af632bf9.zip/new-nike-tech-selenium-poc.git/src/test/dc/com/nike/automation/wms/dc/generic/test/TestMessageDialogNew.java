package com.nike.automation.wms.dc.generic.test;

import org.testng.annotations.Test;
import com.cognizant.framework.selenium.CraftDriver;
import com.cognizant.framework.selenium.SeleniumTestParameters;
import com.nike.automation.wms.common.util.CommonUtils;
import com.nike.automation.wms.common.util.ExtendedBaseTest;
import com.nike.automation.wms.functional.library.WebComponent;
import supportlibraries.DriverScript;
import java.util.concurrent.ConcurrentHashMap;

public class TestMessageDialogNew extends ExtendedBaseTest {
    /**Method to post synthetic data into WMS
     *
     * @param myBrowser : browser type used for test
     * @param se : driver type used for test
     * @param params : external file data parameters
     */

	@Test (groups={"HTLS_GROUPA"}, dataProvider = "xmlData")    
    @TestData(fileName= "wms/data/nalc/wmsNalcLpn.xml")        
    public void verifyMessageDialog(ConcurrentHashMap<String, Object> params) {
		Class<? extends Object> currentClass = new Object(){}.getClass();
		
		SeleniumTestParameters testParameters = new SeleniumTestParameters(
				CommonUtils.getPackageName(currentClass),CommonUtils.getClassName(currentClass));
		testParameters.setCurrentTestInstance(CommonUtils.getMethodName(currentClass));
		DriverScript driverScript = getDefaultScriptSettings(testParameters, params);
		driverScript.getTestParameters().setCurrentTestDescription("Test-"+testParameters.getCurrentTestInstance());
		driverScript.driveTestExecution();
		
		tearDownTestRunner(testParameters, driverScript);	
	}	

	@Override
	public void executeTest() {    
	    switch(driver.getTestParameters().getCurrentTestInstance()){
	    	case "verifyMessageDialog":verifyMessageDialog(driver);	    	
	    }	        
	}	
	
	public void verifyMessageDialog(CraftDriver driver){
		WebComponent component = new WebComponent(driver);
		component.verifyWmsLoginProcess();
		component.verifyMessageDialog();			
	}
}
