/*
 * Copyright (c) Nike Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Nike Inc. ("Confidential Information"). 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Nike.
 *
 * NIKE MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES
 */
package org.nike.wms.tests.testdata.xmlgenerator.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.nike.wms.tests.testdata.xmlgenerator.config.TestDataConfig;
import org.nike.wms.tests.testdata.xmlgenerator.db.ColumnsOfIntrest;
import org.nike.wms.tests.testdata.xmlgenerator.db.QueryExecutor;
import org.nike.wms.tests.testdata.xmlgenerator.db.StatementManager;

/**
 * This class process the avaialbe test data configs and partitions into
 * depedendent and indepdent queries and returns a queryexecution that can be
 * used to retrieve data.
 * 
 * @author CTho50
 * @version 1.0
 */
public class QueryPartitionAlgo {

	private final Map<Integer, TestDataConfig> testDataConfigs;
	private final StatementManager manager;
	private final int resultSize;

	/**
	 * Initialize with the selected test data configurtion
	 * 
	 * @param testDataConfigs
	 */
	public QueryPartitionAlgo(Map<Integer, TestDataConfig> testDataConfigs, StatementManager manager,int resultSize) {
		this.testDataConfigs = testDataConfigs;
		this.manager = manager;
		this.resultSize = resultSize;
	}

	/**
	 * Partitions and returns a list of queries based on whether the queries are
	 * dependent or independent.
	 * 
	 * @return List<QueryExcutor>
	 * @throws Exception
	 */
	public List<QueryExecutor> partition(ColumnsOfIntrest cols) {
		List<QueryExecutor> executors = new ArrayList<>();
		testDataConfigs.forEach((key, value) -> {
			//String[] dependentSqls = value.getDependentSQLS();
			String[] sqls = value.getSQLS();
			if (sqls != null && sqls.length != 0) {
				executors.add(new QueryExecutor(testDataConfigs, key, manager, "dependent",resultSize,cols));
			}
			/*if (sqls != null && sqls.length != 0) {
				for (int idx = 0; idx < value.getSQLS().length; idx++) {
					executors.add(new QueryExecutor(testDataConfigs, key, idx, manager, "independent",resultSize,cols));
				}
			}*/
		});
		return executors;
	}
}
