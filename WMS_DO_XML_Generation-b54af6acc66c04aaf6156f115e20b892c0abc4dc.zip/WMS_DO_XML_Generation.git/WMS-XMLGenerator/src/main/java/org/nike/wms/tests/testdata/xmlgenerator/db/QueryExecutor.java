/*
 * Copyright (c) Nike Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Nike Inc. ("Confidential Information"). 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Nike.
 *
 * NIKE MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES
 */
package org.nike.wms.tests.testdata.xmlgenerator.db;

import org.apache.commons.lang.StringUtils;
import org.nike.wms.tests.testdata.xmlgenerator.config.TestDataConfig;
import org.nike.wms.tests.testdata.xmlgenerator.core.Task;
import org.nike.wms.tests.testdata.xmlgenerator.core.XMLGenerator;
import org.nike.wms.tests.testdata.xmlgenerator.exception.FrameworkException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.*;

/**
 * Query executor task that will execute dependent or independent queries.
 * 
 * @author CTho50
 *
 */
public class QueryExecutor implements Task {

	private static final Logger frameworkLogger = LoggerFactory.getLogger(XMLGenerator.class);

	private final StatementManager statementManager;
	private final Integer configKey;
	private final TestDataConfig testConfig;
	private final int requiredResultSize;
	private final ColumnsOfIntrest cols;
    //private Integer queryIndex;
    private String executionType;
    private TestDataInfoList results;

	/**
	 * 
	 * @param testDataConfigs
	 * @param key
	 * @param manager
     * @param cols(propUtils)
     * @param executionType
	 */
	public QueryExecutor(Map<Integer, TestDataConfig> testDataConfigs, Integer key, StatementManager manager,
			String executionType,int requiredResultSize,ColumnsOfIntrest cols) {
		this.testConfig = testDataConfigs.get(key);
		this.configKey = key;
		this.results = new TestDataInfoList(this.testConfig.getRequiredCount());
		this.statementManager = manager;
		this.executionType = executionType;
		this.requiredResultSize = requiredResultSize;
		this.cols = cols;
	}

	/**
	 * 
	 * @param testDataConfigs
	 * @param key
	 * @param manager
	 */
	public QueryExecutor(Map<Integer, TestDataConfig> testDataConfigs, Integer key, int index, StatementManager manager,
			String executionType,int resultSize,ColumnsOfIntrest cols) {
		this.testConfig = testDataConfigs.get(key);
		this.configKey = key;
		//this.queryIndex = index;
		this.statementManager = manager;
		this.executionType = executionType;
		this.requiredResultSize = resultSize;
		this.results = new TestDataInfoList(this.testConfig.getRequiredCount());
		this.cols = cols;
		if(requiredResultSize < this.testConfig.getRequiredCount()) {
			throw new FrameworkException("Invalid requiredResults property less than the requiredCount property in json for " + this.testConfig.getTemplateName());
		}
	}

	/**
	 * Overridden method to implement task execution.
	 */
	@Override
	public void execute() {
		/*if (this.getExecutionType().equalsIgnoreCase(QueryType.D.getValue())) {
			executeDependentQueries();
		} else {
			executeParallelQueries();
		}*/
	    executeDependentQueries();
	}

	/**
	 * method to execute the Independent queries parallely.
	 */
	/*private void executeParallelQueries() {
		frameworkLogger.info("Current test case - " + testConfig.getTemplateName());
		executeQueries(testConfig.getSQLS()[this.queryIndex]);
	}*/

	private void cleanUp(List<PreparedStatement> prepStmts) {
		for (PreparedStatement prepStmt : prepStmts) {
			try {
				if (prepStmt != null) {
					statementManager.releaseStatement(prepStmt);
				}
			} catch (SQLException sqe) {
				frameworkLogger.error("Error while releasing Prepared Statement", sqe);
			}
		}
	}

	private void executeQueries(String... sqls) {
		List<PreparedStatement> prepStmts = new ArrayList<>();
		try {
			long start = System.currentTimeMillis();
			for (String sql : sqls) {
				sql = sql.replace("${rowNum}", String.valueOf(requiredResultSize));
				frameworkLogger.info("Executing sql {} for test {}",sql,testConfig.getTemplateName());
				prepStmts.add(statementManager.getStatement(sql));
				int currStmtIdx = prepStmts.size() - 1;
                prepStmts.get(currStmtIdx).setMaxRows(requiredResultSize + 1);
				prepStmts.get(currStmtIdx).executeQuery();
			}
			frameworkLogger.info("Completed execution of sqls for test {}, time taken = {}",testConfig.getTemplateName(),(System.currentTimeMillis() - start));
			start = System.currentTimeMillis();
			for (PreparedStatement stmt : prepStmts) {
				processResult(stmt);
			}
			frameworkLogger.info("Completed traversal of resultset for test {}, time taken = {}",testConfig.getTemplateName(),(System.currentTimeMillis() - start));
		} catch (SQLException sexcp) {
			frameworkLogger.error("Error while processing sqls {}", Arrays.asList(sqls), sexcp);
		} finally {
			cleanUp(prepStmts);
		}
	}

	private void processResult(PreparedStatement stmt) throws SQLException {
		ResultSet resultSet = stmt.getResultSet();
		HashSet<String> columns = extractColumnNames(resultSet);
		if (resultSet.getFetchSize() == 0) {
			frameworkLogger.info("No records found for the current test case {}",testConfig.getTemplateName());
		}
		int count = 0;
		while (resultSet.next() && count < requiredResultSize) {
			TestDataInfo info = new TestDataInfo(this);
			for (String column : columns) {
				String val = resultSet.getString(column);
				if(!StringUtils.isEmpty(val)) {
					info.addData(column,val);
				}
			}
			results.getTestDataInfos().add(info);
			count++;
		}
		frameworkLogger.info("Number of records found for test {} = {} in db = {}",testConfig.getTemplateName(),results.allTotal(),results.getTestDataInfos());
	}
	
/*
	private TestDataInfo selectTestDataInfo(int count) {
		TestDataInfo info;
		if (results.allTotal() < count + 1) {
			info = new TestDataInfo(this);
			results.getTestDataInfos().add(info);
		} else {
			info = results.getTestDataInfos().get(count);
		}
		return info;
	}*/

	/*
	 * Ensures that column names being looked up are available in the resultset
	 * and only columns of interest are looked up
	 */
	private HashSet<String> extractColumnNames(ResultSet queryResult) throws SQLException {
		ResultSetMetaData metaData = queryResult.getMetaData();
		HashSet<String> resultColumns = new HashSet<>();
		for (int count = 0; count < metaData.getColumnCount(); count++) {
			String columnName = metaData.getColumnName(count + 1).toUpperCase();
			if (cols.getColumnsOfInterest().contains(columnName)) {
				resultColumns.add(columnName);
			}
		}
		return resultColumns;
	}

	/**
	 * method to execute the dependent queries sequentially.
	 */
	private void executeDependentQueries() {
		executeQueries(testConfig.getSQLS());
	}

	/**
	 * @return the executionType
	 */
	public String getExecutionType() {
		return executionType;
	}

	/**
	 * @param executionType
	 *            the executionType to set
	 */
	public void setExecutionType(String executionType) {
		this.executionType = executionType;
	}

	/**
	 * 
	 * @return
	 */
	public TestDataConfig getTestConfig() {
		return testConfig;
	}

	/**
	 * 
	 * @return
	 */
	public Integer getConfigKey() {
		return configKey;
	}

	/**
	 * 
	 * @return
	 */
	public TestDataInfoList getResults() {
		return results;
	}
}