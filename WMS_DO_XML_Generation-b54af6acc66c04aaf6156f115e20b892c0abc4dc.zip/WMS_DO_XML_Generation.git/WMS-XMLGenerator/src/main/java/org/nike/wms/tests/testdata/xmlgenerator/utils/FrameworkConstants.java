/*
 * Copyright (c) Nike Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Nike Inc. ("Confidential Information"). 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Nike.
 *
 * NIKE MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES
 */
package org.nike.wms.tests.testdata.xmlgenerator.utils;

/**
 * Holds the constants used in the framework.
 * 
 * @author CTho50
 * @version 1.0
 */
public class FrameworkConstants {

	public static final PropertyUtils myPropertyUtils = PropertyUtils.getInstance("connection.properties");

	public static final String DRIVER_CLASS = myPropertyUtils.getProperty("driverClass");
	public static final String JDBC_URL = myPropertyUtils.getProperty("jdbcURL");
	public static final String DB_USER_NAME = myPropertyUtils.getProperty("userName");
	public static final String DB_PASSWORD = myPropertyUtils.getProperty("password");

	public static final String MIN_POOL_SIZE = myPropertyUtils.getProperty("minPoolSize");
	public static final String MAX_POOL_SIZE = myPropertyUtils.getProperty("maxPoolsize");
	public static final String ACQUIRE_INCREMENT = myPropertyUtils.getProperty("acquireIncrement");
	public static final String MAX_STATEMENTS = myPropertyUtils.getProperty("maxStatements");
    public static final String MAX_STATEMENTS_PER_CONNECTION = myPropertyUtils.getProperty("maxStatementsPerConnection");

	public static final String ITEM_NAME = "ITEM_NAME";
	public static final String COUNTRY_OF_ORIGIN = "CNTRY_OF_ORGN";
	public static final String ITEM_ATTRIBUTE1 = "ITEM_ATTR_1";
	public static final String QUANTITY = "QTY";
	public static final String VAS_CODE = "VAS_CODE";
	public static final String DESCRIPTION = "DESCRIPTION";
    public static final String ALLOC_QTY = "ALLOC_QTY";
    public static final String STD_PACK_QTY = "STD_PACK_QTY";
    public static final String ALLOCATABLE_QTY = "ALLOCATABLE_QTY";
    public static final String ORD_QTY = "ORD_QTY";
    public static final String MAX_INVN_QTY = "MAX_INVN_QTY";
    public static final String LPN_QTY = "LPN_QTY";
    public static final String STD_QTY = "STD_QTY";
    public static final String CNTRY_OF_ORGN = "CNTRY_OF_ORGN";
    public static final String CUSTOMER = "CUSTOMER";
    public static final String BUSINESS_PARTNER_ID = "BUSINESS_PARTNER_ID";
    public static final String ORDER_QTY_LAST_DO = "ORDER_QTY_LAST_DO";
    public static final String UNIT_VOLUME = "UNIT_VOLUME";
    public static final String FACILITY_ALIAS_ID = "FACILITY_ALIAS_ID";

	private FrameworkConstants() {

	}

}
