/**
 * 
 */
package org.nike.wms.tests.testdata.xmlgenerator.db;

import java.util.ArrayList;
import java.util.List;

/**
 * List of test data infos
 * @author MSivap
 * @version 1.0
 */
public class TestDataInfoList {

	private final List<TestDataInfo> testDataInfos;

	private final int queryRecordNeeds;
	
	/**
	 * Initialize with list of test data infos.
	 * @param testDataInfos
	 */
	public TestDataInfoList(int queryRecordNeeds) {
		this.testDataInfos = new ArrayList<>();
		this.queryRecordNeeds = queryRecordNeeds;
	}
	
	/**
	 * Return the available needs
	 * @return
	 */
	public int availableTotal() {
		return testDataInfos.size() - queryRecordNeeds;
	}
	
	/**
	 * 
	 * @return
	 */
	public int allTotal() {
		return this.testDataInfos.size();
	}

	/**
	 * @return the testDataInfos
	 */
	public List<TestDataInfo> getTestDataInfos() {
		return testDataInfos;
	}
}