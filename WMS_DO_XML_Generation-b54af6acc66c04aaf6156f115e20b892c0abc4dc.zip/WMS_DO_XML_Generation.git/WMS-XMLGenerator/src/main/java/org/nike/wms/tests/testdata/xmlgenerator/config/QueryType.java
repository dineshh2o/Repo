/*
 * Copyright (c) Nike Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Nike Inc. ("Confidential Information"). 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Nike.
 *
 * NIKE MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES
 */
package org.nike.wms.tests.testdata.xmlgenerator.config;

/**
 * Enum to identify whether the Query to execute is a dependent or independent.
 * 
 * @author ctho50
 * @version 1.0
 */
public enum QueryType {

	D("DEPENDENT"), I("INDEPENDENT");

	private String value;

	QueryType(String value) {
		this.setValue(value);
	}

	/**
	 * @return the executionType
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param executionType
	 *            the executionType to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
}
