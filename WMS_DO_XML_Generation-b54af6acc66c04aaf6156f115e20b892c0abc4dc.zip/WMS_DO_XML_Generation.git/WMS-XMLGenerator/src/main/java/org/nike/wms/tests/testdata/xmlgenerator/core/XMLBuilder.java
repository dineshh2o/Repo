/*
 * Copyright (c) Nike Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Nike Inc. ("Confidential Information"). 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Nike.
 *
 * NIKE MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES
 */
package org.nike.wms.tests.testdata.xmlgenerator.core;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.jexl3.JexlBuilder;
import org.apache.commons.jexl3.JexlEngine;
import org.apache.commons.jexl3.MapContext;
import org.nike.wms.tests.testdata.xmlgenerator.config.TestDataConfig;
import org.nike.wms.tests.testdata.xmlgenerator.db.ColumnsOfIntrest;
import org.nike.wms.tests.testdata.xmlgenerator.db.TestDataInfo;
import org.nike.wms.tests.testdata.xmlgenerator.exception.FrameworkException;
import org.nike.wms.tests.testdata.xmlgenerator.utils.DONumberGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Class to update the input XML templates with the values obtained from Query results
 * 
 * @author CTho50
 * @version 1.0
 */
public class XMLBuilder {

    private static final Logger frameworkLogger = LoggerFactory.getLogger(XMLBuilder.class);
    private static final JexlEngine jexl = new JexlBuilder().cache(512).strict(true).silent(false).create();
    private static final Pattern funcPattern = Pattern.compile("@([^@]+)@");

    private Map<TestDataConfig, List<TestDataInfo>> myTestDataInfoMap;
    private Options myConfigOptions;
    private DONumberGenerator generator;
    private ColumnsOfIntrest cols;

    /**
     * 
     * @param testDataInfoMap
     * @param configOptions
     */
    public XMLBuilder(Map<TestDataConfig, List<TestDataInfo>> testDataInfoMap, Options configOptions, DONumberGenerator generator,
            ColumnsOfIntrest cols) {
        this.generator = generator;
        this.myTestDataInfoMap = testDataInfoMap;
        this.myConfigOptions = configOptions;
        this.cols = cols;
    }

    /**
     * Method to replace the variables defined in input XML templates with the values obtained from TestDataInfoMap
     */
    public void execute() {

        Charset charSet = StandardCharsets.UTF_8;

        for (Map.Entry<TestDataConfig, List<TestDataInfo>> eachTemplateEntry : myTestDataInfoMap.entrySet()) {
            List<TestDataInfo> testDataInfos = eachTemplateEntry.getValue();

            Path inputTemplateFilePath = Paths
                    .get(myConfigOptions.getTemplateDirectory() + "//" + eachTemplateEntry.getKey().getTemplateName() + ".xml");

            boolean isXMLTemplateFound = inputTemplateFilePath.toFile().exists();

            Path outputFilePath = Paths
                    .get(myConfigOptions.getOutputFilesDirectory() + "//" + eachTemplateEntry.getKey().getTemplateName() + ".xml");

            frameworkLogger.info("Generating xmls for {}", eachTemplateEntry.getKey().getTemplateName());

            if (isXMLTemplateFound && testDataInfos != null) {
                try {
                    byte[] encodedContent = Files.readAllBytes(Paths.get(inputTemplateFilePath.toUri()));
                    String fileContents = new String(encodedContent, charSet);
                    int count = 0;
                    for (TestDataInfo testDataInfo : testDataInfos) {
                        String appendKey = "";
                        if (count > 0) {
                            appendKey = "_" + count;
                        }
                        for (String dataValue : cols.getColumnsOfInterest()) {
                            if (testDataInfo.getData(dataValue) != null && !testDataInfo.getData(dataValue).isEmpty()) {
                                String xmlKey = "${" + dataValue + appendKey + "}";
                                fileContents = fileContents.replace(xmlKey, testDataInfo.getData(dataValue));
                            } else {
                                frameworkLogger.info("Property {} is empty for {}", dataValue, inputTemplateFilePath);
                            }
                        }
                        String doKey = "${DSTR_ORDER_ID" + appendKey + "}";
                        fileContents = fileContents.replace(doKey, generator.genDONumber());
                        count++;
                    }
                    fileContents = fileContents.replace("${REF_ID}", generator.genRefID());
                    fileContents = replaceDynamicFuncContent(fileContents);
                    Files.write(outputFilePath, fileContents.getBytes(charSet));
                    frameworkLogger.info("Generated xmls for {}", eachTemplateEntry.getKey());
                } catch (IOException ioe) {
                    throw new FrameworkException("IO Exception", ioe);
                }
            }
        }
    }

    private String replaceDynamicFuncContent(String input) {
        StringBuilder builder = new StringBuilder(input);
        Matcher matcher = funcPattern.matcher(input);
        int offset = builder.length() - input.length();
        while (matcher.find()) {
            MapContext context = new MapContext();
            context.set("xmlfunc", new XMLFunctions(myConfigOptions.getUnqiueId()));
            int start = matcher.start();
            int end = matcher.end();
            offset = builder.length() > input.length() ? builder.length() - input.length() : -1 * (input.length() - builder.length());
            String exprEval = jexl.createExpression(matcher.group(1)).evaluate(context).toString();
            frameworkLogger.debug("Found a expr match {} with value {} and replace idx {},{},{}", matcher.group(1), exprEval, start, end, offset);
            builder.replace(start + offset, end + offset, exprEval);
        }
        return builder.toString();
    }
}