package org.nike.wms.tests.testdata.xmlgenerator.utils;

/**
 * This class generates the DO number
 * @author MSivap
 *
 */
public class DONumberGenerator {

	private final String uniqueId;
	
	/**
	 * Initialize with unique id
	 * @param uniqueID
	 */
	public DONumberGenerator(String uniqueID) {
		this.uniqueId = uniqueID;
	}
	
	/**
	 * Generates a Random Number
	 * @return
	 */
	public String genDONumber() {
		return new StringBuilder(uniqueId).append(String.valueOf(System.currentTimeMillis()).substring(4)).toString();
	}
	
	/**
	 * Generates a Random Number
	 * @return
	 */
	public String genRefID() {
		return new StringBuilder(uniqueId).append(String.valueOf(System.currentTimeMillis()).substring(7)).toString();
	}
}