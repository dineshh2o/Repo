/*
 * Copyright (c) Nike Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Nike Inc. ("Confidential Information"). 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Nike.
 *
 * NIKE MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES
 */
package org.nike.wms.tests.testdata.xmlgenerator.core;

/**
 * Represents a tasks that can be executed by the WorkerManager.
 * 
 * @author CTho50
 * @version 1.0
 */
@FunctionalInterface
public interface Task {

	/**
	 * Operation to be performed by the WorkerManager.
	 */
	public void execute();

}
