package org.nike.wms.tests.testdata.xmlgenerator.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.Set;

import org.nike.wms.tests.testdata.xmlgenerator.exception.FrameworkException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PropertyUtils {

	private static final Logger frameworkLogger = LoggerFactory.getLogger(PropertyUtils.class);

	private final Properties myConfigProperties = new Properties();

	private PropertyUtils() {

	}

	private PropertyUtils(final String aPropFile) {

		InputStream inputResource = ClassLoader.getSystemResourceAsStream(aPropFile);
		try {
			myConfigProperties.load(inputResource);
			closeResource(inputResource);
		} catch (IOException ioe) {
			throw new FrameworkException("IO Exception", ioe);
		} finally {
			closeResource(inputResource);
		}
	}

	public static void closeResource(InputStream inputResource) {
		try {
			inputResource.close();
		} catch (IOException ioe) {
			frameworkLogger.error("IO Exception {}", ioe.getMessage());
		}
	}

	public static PropertyUtils getInstance(final String propFile) {
		return new PropertyUtils(propFile);
	}

	public String getProperty(final String key) {
		return myConfigProperties.getProperty(key);
	}

	public Set<String> getAllPropertyNames() {
		return myConfigProperties.stringPropertyNames();
	}

	public boolean containsKey(final String key) {
		return myConfigProperties.containsKey(key);
	}

}
