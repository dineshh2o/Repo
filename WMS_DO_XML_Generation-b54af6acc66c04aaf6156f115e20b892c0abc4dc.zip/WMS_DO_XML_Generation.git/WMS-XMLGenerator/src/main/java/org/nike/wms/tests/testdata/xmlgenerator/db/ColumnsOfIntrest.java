/**
 * 
 */
package org.nike.wms.tests.testdata.xmlgenerator.db;

import java.util.HashSet;
import java.util.Properties;

/**
 * This class represents columns of interest that will be used to identify which columns the framework will
 * use.
 * @author MSivap
 * @version 1.0
 */
public class ColumnsOfIntrest {

	private final HashSet<String> columnsOfInterest;
	
	/**
	 * Initialize the data object
	 * @param config
	 */
	public ColumnsOfIntrest(Properties config) {
		columnsOfInterest = new HashSet<>();
		String[] columns = config.getProperty("columnsOfInterest","").split(",");
		for(String column : columns) {
			columnsOfInterest.add(column);
		}
	}
	
	/**
	 * @return the columnsOfInterest
	 */
	public HashSet<String> getColumnsOfInterest() {
		return columnsOfInterest;
	}
}
