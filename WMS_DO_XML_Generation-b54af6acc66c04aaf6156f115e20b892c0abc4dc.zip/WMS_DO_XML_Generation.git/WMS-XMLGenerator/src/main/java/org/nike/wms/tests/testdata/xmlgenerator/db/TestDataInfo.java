/*
 * Copyright (c) Nike Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Nike Inc. ("Confidential Information"). 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Nike.
 *
 * NIKE MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES
 */
package org.nike.wms.tests.testdata.xmlgenerator.db;

import java.util.HashMap;
import java.util.Map;

/**
 * Bean class to hold the values to be updated in the XML templates.
 * 
 * @author CTho50
 * @version 1.0
 */
public class TestDataInfo {

	private final Map<String, String> dataValues = new HashMap<>();

	private final QueryExecutor parent;

	/**
	 * @param parent
	 */
	public TestDataInfo(QueryExecutor parent) {
		this.parent = parent;
	}

	/**
	 * Adds a value for the column retrived from db
	 * 
	 * @param columnName
	 * @param value
	 */
	public void addData(String columnName, String value) {
		this.dataValues.put(columnName, value);
	}

	/**
	 * Gets the values for the given column name.
	 * 
	 * @param columnName
	 * @return
	 */
	public String getData(String columnName) {
		return dataValues.get(columnName);
	}

	/**
	 * Copies all data from the provided result to current.
	 * 
	 * @param data
	 */
	public void copyData(TestDataInfo data) {
		this.dataValues.putAll(data.dataValues);
	}

	/**
	 * 
	 * @return
	 */
	public QueryExecutor getParent() {
		return parent;
	}

	/**
	 * Stringify object.
	 */
	@Override
	public String toString() {
		return "TestDataInfo [dataValues=" + dataValues + "]";
	}
}