/*
 * Copyright (c) Nike Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Nike Inc. ("Confidential Information"). 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Nike.
 *
 * NIKE MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES
 */
package org.nike.wms.tests.testdata.xmlgenerator.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Class to manage the Statement creation and release.
 * 
 * @author CTho50
 * @version 1.0
 */
public class StatementManager {

	private final ConnectionManager connectionManager;

	/**
	 * Initialize the Statement manager.
	 * 
	 * @param manager
	 */
	public StatementManager(ConnectionManager connectionManager) {
		this.connectionManager = connectionManager;
	}

	/**
	 * Prepares and returns the PreparedStatement for the given sql.
	 * 
	 * @param sql
	 * @return
	 * @throws SQLException
	 */
	public PreparedStatement getStatement(String sql) throws SQLException {
		Connection dbConnection = this.connectionManager.getConnection();
		return dbConnection.prepareStatement(sql);
	}

	/**
	 * Releases the statement.
	 * 
	 * @param statement
	 * @throws SQLException
	 */
	public void releaseStatement(Statement statement) throws SQLException {
		if (statement != null) {
			statement.close();
		}
	}

	/**
	 * calls the connection manager to destroy an existing connection.
	 */
	public void destroy() {
		connectionManager.destroy();
	}

	/**
	 * Creates a Statement Manager instance.
	 * 
	 * @param connectionManager
	 * @param configProperties
	 * @return
	 */
	public static StatementManager create(ConnectionManager connectionManager) {
		return new StatementManager(connectionManager);
	}
	
}
