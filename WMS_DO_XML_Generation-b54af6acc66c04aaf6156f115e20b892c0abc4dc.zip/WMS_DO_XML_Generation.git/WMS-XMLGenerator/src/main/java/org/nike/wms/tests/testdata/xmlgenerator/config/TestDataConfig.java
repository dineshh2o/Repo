/*
 * Copyright (c) Nike Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Nike Inc. ("Confidential Information"). 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Nike.
 *
 * NIKE MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES
 */
package org.nike.wms.tests.testdata.xmlgenerator.config;

/**
 * Class to hold the data parsed by the config parser. It contains two arrays -
 * the SQL queries which qualify for parallel execution, the dependent SQL
 * queries that have to be executed sequentially and the template name that
 * corresponds to the XML file name
 * 
 * @author ctho50
 * @version 1.0
 */
public class TestDataConfig {

	private String[] mySQLS;
	private String[] myDependentSQLS;
	private String myTemplateName;
	private int requiredCount;
	private boolean unqiueSkus;
	
	private final int configKey;
	
	
	/**
	 * Initialize with config key
	 * @param configKey
	 */
	public TestDataConfig(int configKey) {
		this.configKey = configKey;
	}

	/**
	 * @return the mySQLS
	 */
	public String[] getSQLS() {
		return mySQLS;
	}

	/**
	 * @param mySQLS
	 *            the mySQLS to set
	 */
	public void setSQLS(String[] sQLS) {
		this.mySQLS = sQLS;
	}

	/**
	 * @return the myDependentSQLS
	 */
	public String[] getDependentSQLS() {
		return myDependentSQLS;
	}

	/**
	 * @param myDependentSQLS
	 *            the myDependentSQLS to set
	 */
	public void setDependentSQLS(String[] dependentSQLS) {
		this.myDependentSQLS = dependentSQLS;
	}

	/**
	 * @return the templateName
	 */
	public String getTemplateName() {
		return myTemplateName;
	}

	/**
	 * @param templateName
	 *            the templateName to set
	 */
	public void setTemplateName(String templateName) {
		this.myTemplateName = templateName;
	}

	/**
	 * 
	 * @return unique id
	 */
	public int getConfigKey() {
		return configKey;
	}

	/**
	 * @return the requiredCount
	 */
	public int getRequiredCount() {
		return requiredCount;
	}

	/**
	 * @param requiredCount the requiredCount to set
	 */
	public void setRequiredCount(int requiredCount) {
		this.requiredCount = requiredCount;
	}

    /**
     * @return the unqiueSkus
     */
    public boolean isUnqiueSkus() {
        return unqiueSkus;
    }

    /**
     * @param unqiueSkus the unqiueSkus to set
     */
    public void setUnqiueSkus(boolean unqiueSkus) {
        this.unqiueSkus = unqiueSkus;
    }
}
