/*
 * Copyright (c) Nike Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Nike Inc. ("Confidential Information"). 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Nike.
 *
 * NIKE MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES
 */
package org.nike.wms.tests.testdata.xmlgenerator.config;

import java.util.Arrays;

import org.codehaus.jackson.annotate.JsonCreator;
import org.codehaus.jackson.annotate.JsonProperty;

/**
 * value bean class to hold each QueryInfo available in the input JSON files.
 * Contains selectionParams, queries, dependentQueries and the templateName as
 * the properties
 * 
 * @author ctho50
 * @version 1.0
 */
public class QueryInfo {

	private String[] selectionParams;
	private String[] queries;
	private String[] dependentQueries;
	private String templateName;
	private int requiredCount = 1;
	private boolean uniqueSkus = true;
	
	@JsonCreator
	public QueryInfo(@JsonProperty("selectionParams") String[] selectionParams,
			@JsonProperty("queries") String[] queries, @JsonProperty("dependentQueries") String[] dependentQueries,
			@JsonProperty("templateName") String templateName, @JsonProperty("requiredCount") Integer requiredCount,@JsonProperty("unqiueSkus") Boolean uniqueSkus) {
		this.setSelectionParams(selectionParams);
		this.queries = queries;
		this.dependentQueries = dependentQueries;
		this.templateName = templateName;
		if(requiredCount != null) {
		    this.requiredCount = requiredCount;
		}
		if(uniqueSkus != null) {
		    this.uniqueSkus = uniqueSkus;
		}
	}

	/**
	 * @return the selectionParams
	 */
	public String[] getSelectionParams() {
		return selectionParams;
	}

	/**
	 * @param selectionParams
	 *            the selectionParams to set
	 */
	public void setSelectionParams(String[] selectionParams) {
		this.selectionParams = selectionParams;
	}

	/**
	 * @return the queries
	 */
	public String[] getQueries() {
		return queries;
	}

	/**
	 * @param queries
	 *            the queries to set
	 */
	public void setQueries(String[] queries) {
		this.queries = queries;
	}

	/**
	 * @return the dependentQueries
	 */
	public String[] getDependentQueries() {
		return dependentQueries;
	}

	/**
	 * @param dependentQueries
	 *            the dependentQueries to set
	 */
	public void setDependentQueries(String[] dependentQueries) {
		this.dependentQueries = dependentQueries;
	}

	/**
	 * @return the templateName
	 */
	public String getTemplateName() {
		return templateName;
	}

	/**
	 * @param templateName
	 *            the templateName to set
	 */
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	/**
	 * @return the requiredCount
	 */
	public int getRequiredCount() {
		return requiredCount;
	}

	/**
     * @return the uniqueSkus
     */
    public boolean isUniqueSkus() {
        return uniqueSkus;
    }

    /* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "QueryInfo [selectionParams=" + Arrays.toString(selectionParams) + ", queries="
				+ Arrays.toString(queries) + ", dependentQueries=" + Arrays.toString(dependentQueries)
				+ ", templateName=" + templateName + ", requiredCount=" + requiredCount + "]";
	}
}
