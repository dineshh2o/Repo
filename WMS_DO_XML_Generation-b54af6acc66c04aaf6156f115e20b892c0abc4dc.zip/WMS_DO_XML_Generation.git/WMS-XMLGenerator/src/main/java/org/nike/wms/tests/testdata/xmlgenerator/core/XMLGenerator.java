/*
 * Copyright (c) Nike Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Nike Inc. ("Confidential Information"). 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Nike.
 *
 * NIKE MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES
 */
package org.nike.wms.tests.testdata.xmlgenerator.core;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.nike.wms.tests.testdata.xmlgenerator.config.ConfigParser;
import org.nike.wms.tests.testdata.xmlgenerator.config.TestDataConfig;
import org.nike.wms.tests.testdata.xmlgenerator.db.ColumnsOfIntrest;
import org.nike.wms.tests.testdata.xmlgenerator.db.ConnectionManager;
import org.nike.wms.tests.testdata.xmlgenerator.db.QueryExecutor;
import org.nike.wms.tests.testdata.xmlgenerator.db.StatementManager;
import org.nike.wms.tests.testdata.xmlgenerator.db.TestDataInfo;
import org.nike.wms.tests.testdata.xmlgenerator.db.TestDataInfoList;
import org.nike.wms.tests.testdata.xmlgenerator.exception.FrameworkException;
import org.nike.wms.tests.testdata.xmlgenerator.utils.DONumberGenerator;
import org.nike.wms.tests.testdata.xmlgenerator.utils.FrameworkConstants;
import org.nike.wms.tests.testdata.xmlgenerator.utils.PropertyUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Class to generate the xml input data required for the functional test case
 * execution of Nike - warehouse management system. This class receives the
 * input json files and the test case selection parameters as system properties.
 * 
 * @author ctho50
 * @version 1.0
 */
public class XMLGenerator {

	private static final Logger frameworkLogger = LoggerFactory.getLogger(XMLGenerator.class);

	private Properties configProperties;
	private Map<Integer, TestDataConfig> testDataConfigs;
	private List<QueryExecutor> queryExecutors;
	private Options configOptions;
	private ConfigParser configParser;
	private final DONumberGenerator generator;
	private long startTime;
	private ColumnsOfIntrest columnsOfIntrest;

	/**
	 * 
	 * @param systemProperties
	 * @param propFile
	 */
	public XMLGenerator(Properties systemProperties, String propFile) {
		startTime = System.currentTimeMillis();

		testDataConfigs = new HashMap<>();
		queryExecutors = new ArrayList<>();
		configOptions = new Options(systemProperties);
		configParser = new ConfigParser(configOptions);
		generator = new DONumberGenerator(System.getProperty("unqiueDOId"));
		testDataConfigs = configParser.parse();
		configProperties = new Properties();
		InputStream inputResource = ClassLoader.getSystemResourceAsStream(propFile);
		try {
			configProperties.load(inputResource);
			PropertyUtils.closeResource(inputResource);
		} catch (IOException ioe) {
			throw new FrameworkException("IO Exception", ioe);
		} finally {
			PropertyUtils.closeResource(inputResource);
		}
		columnsOfIntrest= new ColumnsOfIntrest(configProperties);
	}

	/**
	 * Method to generate the XMLs with Unique SKUs
	 * 
	 * @throws Exception
	 */
	public void runXMLGenerator() {
		StatementManager statementManager = null;
		WorkerManager workerManager = null;
		try {
			statementManager = StatementManager.create(ConnectionManager.create(configOptions.getDbEnv(),
					configProperties, configOptions.getThreadPoolSize()));
			QueryPartitionAlgo queryPartitionAlgo = new QueryPartitionAlgo(testDataConfigs, statementManager,
					configOptions.getRequiredResultSize());
			queryExecutors = queryPartitionAlgo.partition(columnsOfIntrest);
			workerManager = new WorkerManager(configOptions);

			for (QueryExecutor executor : queryExecutors) {
				workerManager.submitTask(executor);
			}

			workerManager.waitForTasksToComplete();

			Map<TestDataConfig, List<TestDataInfo>> results = new HashMap<>();

			getUnqiueSkuRecords(results);

			long timeUptoQueryExecution = System.currentTimeMillis();
			frameworkLogger.info("Time upto Query Execution: " + (timeUptoQueryExecution - startTime));

			// Generate the final Distribution Order XML by replacing the SKU
			// related fields with the values obtained from the query results.
			XMLBuilder doXMLBuilder = new XMLBuilder(results, configOptions, generator,columnsOfIntrest);
			doXMLBuilder.execute();

			long endTime = System.currentTimeMillis();
			frameworkLogger.info("Total time for Execution: " + (endTime - startTime));
		}catch(Exception excp) {
			frameworkLogger.info("Total time for Execution: " + (System.currentTimeMillis() - startTime));
			frameworkLogger.error("Error while executing the framework",excp);
		} finally {
			if (workerManager != null) {
				workerManager.destroy();
			}
			if (statementManager != null) {
				statementManager.destroy();
			}
		}
	}

	private void getUnqiueSkuRecords(Map<TestDataConfig, List<TestDataInfo>> results) {
		Set<String> foundSkus = new HashSet<>();
		Map<String, List<String>> allSkus = new LinkedHashMap<>();
		List<TestDataInfoList> uniqueSkuResults = new ArrayList<>();
		for (QueryExecutor executor : queryExecutors) {
			TestDataInfoList currReslt = executor.getResults();
			uniqueSkuResults.add(currReslt);
		}
		//allocate to the lease available total as it is more scarce.
		uniqueSkuResults.sort((result1, result2) -> {
			return Integer.valueOf(result1.availableTotal()).compareTo(result2.availableTotal());
		});
		List<String> noDataFoundSkus = handleUniqueSkus(results, foundSkus, allSkus, uniqueSkuResults);
		frameworkLogger.info("Generated skus for {}", results.keySet());
		frameworkLogger.info("Found skus " + foundSkus);
		frameworkLogger.info("Data not found for " + noDataFoundSkus);
		frameworkLogger.info("All found skus " + allSkus);

	}

    private List<String> handleUniqueSkus(Map<TestDataConfig, List<TestDataInfo>> results, Set<String> foundSkus,
            Map<String, List<String>> allSkus, List<TestDataInfoList> allResults) {
        List<String> noDataFoundSkus = new ArrayList<>();
		for (TestDataInfoList result : allResults) {
			String testName = "";
			Boolean skuFound = null;
			int count = 0;
			for (TestDataInfo info : result.getTestDataInfos()) {
				skuFound = Boolean.FALSE;
				String sku = info.getData(FrameworkConstants.ITEM_NAME);
				//does not require unique skus so just add to the 
				if(!info.getParent().getTestConfig().isUnqiueSkus()) {
				    if(count < info.getParent().getTestConfig().getRequiredCount()) {
	                    addToResults(results, info);
				        continue;
				    } else {
				        break;
				    }
				}
				if(StringUtils.isEmpty(sku)) {
				    frameworkLogger.debug("Empty sku found for {}",info.getParent().getTestConfig().getTemplateName());
					continue;
				}
				testName = info.getParent().getTestConfig().getTemplateName().trim();
				allSkus.putIfAbsent(info.getParent().getTestConfig().getTemplateName().trim(), new ArrayList<>());
				allSkus.get(info.getParent().getTestConfig().getTemplateName())
						.add(info.getData(FrameworkConstants.ITEM_NAME));

				if (!foundSkus.contains(sku)) {
					addToResults(results, info);
					foundSkus.add(info.getData(FrameworkConstants.ITEM_NAME));
					if(count >= info.getParent().getTestConfig().getRequiredCount()) {
						skuFound = true;
						break;
					}
					count++;
				}
			}
			if (Boolean.FALSE.equals(skuFound)) {
				noDataFoundSkus.add(testName + ">" + count);
			}
		}
        return noDataFoundSkus;
    }

    private void addToResults(Map<TestDataConfig, List<TestDataInfo>> results, TestDataInfo info) {
        results.putIfAbsent(info.getParent().getTestConfig(), new ArrayList<>());
        results.get(info.getParent().getTestConfig()).add(info);
    }
}