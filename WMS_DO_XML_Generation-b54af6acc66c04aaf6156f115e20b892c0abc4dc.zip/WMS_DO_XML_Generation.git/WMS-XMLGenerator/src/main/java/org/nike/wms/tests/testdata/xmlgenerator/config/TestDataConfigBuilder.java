/*
 * Copyright (c) Nike Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Nike Inc. ("Confidential Information"). 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Nike.
 *
 * NIKE MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES
 */
package org.nike.wms.tests.testdata.xmlgenerator.config;

import java.util.List;

import org.apache.commons.lang.ArrayUtils;

/**
 * Class to build the TestDataConfig from QueryInfo object contents matching the
 * command line selection parameters.
 * 
 * @author ctho50
 * @version 1.0
 */
public class TestDataConfigBuilder {

	private int count = 0;

	/**
	 * 
	 * @param queryInfos
	 * @param commandLineSelectionParams
	 * @param testDataConfigList
	 */
	public void buildTestDataConfigs(ListOfQueryInfos queryInfos, String[] commandLineSelectionParams,
			List<TestDataConfig> testDataConfigList) {
		List<QueryInfo> listOfQueryInfos = queryInfos.getQueryInfos();

		for (QueryInfo queryInfo : listOfQueryInfos) {
			build(queryInfo, commandLineSelectionParams, testDataConfigList);
		}
	}

	/**
	 * Method that builds the list of TestDataConfig from the QueryInfo Object.
	 * 
	 * @param queryInfo
	 * @param commandLineSelectionParams
	 * @param testDataConfigList
	 */
	private void build(QueryInfo queryInfo, String[] commandLineSelectionParams,
			List<TestDataConfig> testDataConfigList) {
		boolean isMatched = true;
		for (int paramCount = 0; paramCount < commandLineSelectionParams.length; paramCount++) {
			if (!ArrayUtils.contains(queryInfo.getSelectionParams(), commandLineSelectionParams[paramCount])
					&& !queryInfo.getTemplateName().equals(commandLineSelectionParams[paramCount])) {
				isMatched = false;
				break;
			}
		}
		if (isMatched) {
			TestDataConfig testDataConfig = new TestDataConfig(count++);
			testDataConfig.setSQLS(queryInfo.getQueries());
			testDataConfig.setDependentSQLS(queryInfo.getDependentQueries());
			testDataConfig.setTemplateName(queryInfo.getTemplateName());
			testDataConfig.setRequiredCount(queryInfo.getRequiredCount());
			testDataConfig.setUnqiueSkus(queryInfo.isUniqueSkus());
			testDataConfigList.add(testDataConfig);
		}
	}
}
