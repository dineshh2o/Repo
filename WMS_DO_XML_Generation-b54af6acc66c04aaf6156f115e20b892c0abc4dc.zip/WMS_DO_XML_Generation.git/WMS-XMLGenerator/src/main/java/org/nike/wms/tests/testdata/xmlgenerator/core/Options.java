/*
 * Copyright (c) Nike Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Nike Inc. ("Confidential Information"). 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Nike.
 *
 * NIKE MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES
 */
package org.nike.wms.tests.testdata.xmlgenerator.core;

import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Class to generate the xml input data required for the functional test case
 * execution of Nike - warehouse management system. This class receives the
 * input json files and the test case selection parameters as system properties.
 * 
 * @author ctho50
 * @version 1.0
 */
public class Options {

	private static final Logger frameworkLogger = LoggerFactory.getLogger(Options.class);
	
	private String[] myConfigFiles;
	private String[] myCommandLineSelectionParams;
	private Map<String, String> myPoolProperties;
	private String myTemplateDirectory;
	private String myOutputFilesDirectory;
	private final int requiredResultSize;
	private final int threadPoolSize;
	private final String dbEnv;
	private final String unqiueId;
	
	/**
	 * 
	 * @param properties
	 */
	public Options(Properties properties) {
		frameworkLogger.info("Configured Options {}",properties);
		myConfigFiles = properties.getProperty("jsonFiles").split(",");
		myCommandLineSelectionParams = properties.getProperty("selectionParams","").split(",");
		myTemplateDirectory = properties.getProperty("templateDir");
		myOutputFilesDirectory = properties.getProperty("outputDir");
		this.requiredResultSize = Integer.parseInt(properties.getProperty("requiredResults", "50"));
		this.threadPoolSize = Integer.parseInt(properties.getProperty("threadpoolsize", "1"));
		this.dbEnv = properties.getProperty("dbEnv","");
		this.unqiueId = properties.getProperty("unqiueDOId","");
	}

	/**
	 * @return the configFiles
	 */
	public String[] getConfigFiles() {
		return myConfigFiles;
	}

	/**
	 * @return the poolProperties
	 */
	public Map<String, String> getPoolProperties() {
		return myPoolProperties;
	}

	/**
	 * @return the mySelectionParameters
	 */
	public String[] getCommandLineSelectionParams() {
		return myCommandLineSelectionParams;
	}

	/**
	 * @return the myTemplateDirectory
	 */
	public String getTemplateDirectory() {
		return myTemplateDirectory;
	}

	/**
	 * @param myTemplateDirectory
	 *            the myTemplateDirectory to set
	 */
	public void setTemplateDirectory(String templateDirectory) {
		this.myTemplateDirectory = templateDirectory;
	}

	/**
	 * @return the myOutputFilesDirectory
	 */
	public String getOutputFilesDirectory() {
		return myOutputFilesDirectory;
	}

	/**
	 * @param myOutputFilesDirectory
	 *            the myOutputFilesDirectory to set
	 */
	public void setOutputFilesDirectory(String outputFilesDirectory) {
		this.myOutputFilesDirectory = outputFilesDirectory;
	}

	/**
	 * @return the requiredResultSize
	 */
	public int getRequiredResultSize() {
		return requiredResultSize;
	}

	/**
	 * @return the threadPoolSize
	 */
	public int getThreadPoolSize() {
		return threadPoolSize;
	}

	/**
	 * @return the dbEnv
	 */
	public String getDbEnv() {
		return dbEnv;
	}

    /**
     * @return the unqiueId
     */
    public String getUnqiueId() {
        return unqiueId;
    }
}
