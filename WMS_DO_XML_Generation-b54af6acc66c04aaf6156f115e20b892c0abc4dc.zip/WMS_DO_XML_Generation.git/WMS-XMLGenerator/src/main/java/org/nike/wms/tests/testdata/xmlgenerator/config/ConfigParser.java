/*
 * Copyright (c) Nike Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Nike Inc. ("Confidential Information"). 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Nike.
 *
 * NIKE MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES
 */
package org.nike.wms.tests.testdata.xmlgenerator.config;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.nike.wms.tests.testdata.xmlgenerator.core.Options;
import org.nike.wms.tests.testdata.xmlgenerator.exception.FrameworkException;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Class to parse the input JSON files based on the WM parameters and generate
 * the Test Data Config for the functional test case execution of Nike -
 * warehouse management system. This class receives an instance of Options which
 * holds the input json files and the test case properties.
 * 
 * @author ctho50
 * @version 1.0
 */
public class ConfigParser {

	private final Options myOptions;

	/**
	 * Initialize with the given command line arguments.
	 * 
	 * @param options
	 */
	public ConfigParser(Options options) {
		myOptions = options;
	}

	/**
	 * parses the json config files and returns a list of Test Data Configs
	 * matching the input selection parameters.
	 * 
	 * @return map<Integer, TestDataConfig>
	 */
	public Map<Integer, TestDataConfig> parse() {
		Map<Integer, TestDataConfig> testDataConfigs = new HashMap<>();
		ObjectMapper jsonToJavaMapper = new ObjectMapper();
		ListOfQueryInfos queryInfos;
		List<TestDataConfig> testDataConfigList;

		TestDataConfigBuilder testDataConfigBuilder = new TestDataConfigBuilder();
		for (String configFile : myOptions.getConfigFiles()) {
			try {
				queryInfos = jsonToJavaMapper.readValue(new File(configFile), ListOfQueryInfos.class);
				testDataConfigList = new ArrayList<>();
				testDataConfigBuilder.buildTestDataConfigs(queryInfos, myOptions.getCommandLineSelectionParams(),
						testDataConfigList);
				for (TestDataConfig testDataConfig : testDataConfigList) {
					testDataConfigs.put(testDataConfig.getConfigKey(), testDataConfig);
				}
			} catch (JsonParseException jpe) {
				throw new FrameworkException("Exception while parsing the JSON file", jpe);
			} catch (JsonMappingException jme) {
				throw new FrameworkException("Exception while mapping the contents of JSON file into an Object", jme);
			} catch (IOException ioe) {
				throw new FrameworkException("IO Exception", ioe);
			}
		}

		return testDataConfigs;
	}

	/**
	 * @return the myOptions
	 */
	public Options getOptions() {
		return myOptions;
	}
}
