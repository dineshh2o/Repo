/*
 * Copyright (c) Nike Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Nike Inc. ("Confidential Information"). 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Nike.
 *
 * NIKE MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES
 */
package org.nike.wms.tests.testdata.xmlgenerator.config;

import java.util.List;

/**
 * value bean class to hold the List of QueryInfo.
 * 
 * @author ctho50
 * @version 1.0
 */
public class ListOfQueryInfos {

	private List<QueryInfo> queryInfos;

	/**
	 * @return the queryInfos
	 */
	public List<QueryInfo> getQueryInfos() {
		return queryInfos;
	}

	/**
	 * @param queryInfos
	 *            the queryInfos to set
	 */
	public void setQueryInfos(List<QueryInfo> queryInfos) {
		this.queryInfos = queryInfos;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "QueryInfos [QueryInfos=" + queryInfos + "]";
	}
}
