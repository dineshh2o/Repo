/*
 * Copyright (c) Nike Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Nike Inc. ("Confidential Information"). 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Nike.
 *
 * NIKE MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES
 */
package org.nike.wms.tests.testdata.xmlgenerator.core;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Class to manage the tasks that are executed.
 * 
 * @author CTho50
 * @version 1.0
 */
public class WorkerManager {

	private static final Logger frameworkLogger = LoggerFactory.getLogger(WorkerManager.class);
	
	private boolean allTasksComplete;
	private final ExecutorService service;
	private final List<Future<?>> futures;
	/**
	 * Initialize the work manager.
	 * @param options
	 */
	public WorkerManager(Options options) {
		service = Executors.newFixedThreadPool(options.getThreadPoolSize());
		futures = new ArrayList<>();
	}

	/**
	 * Submits the query execution task.
	 * 
	 * @param task
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public void submitTask(Task task) {
		futures.add(service.submit( () -> {
			task.execute();
		}));
		
	}

	/**
	 * Returns true if the all the tasks are complete
	 * 
	 * @return
	 */
	public boolean waitForTasksToComplete() {
		frameworkLogger.info("Tasks to complete {} {}", futures.size(),allTasksComplete);
		while(!allTasksComplete) {
			boolean allComplete = true;
			for(Future<?> future : futures) {
				if(!future.isDone()) {
					allComplete = false;
					break;
				}
			}
			try {
				Thread.sleep(1000);
			} catch (InterruptedException excp) {
				frameworkLogger.debug("Thread sleep error");
			}
			allTasksComplete = allComplete;
		}
		frameworkLogger.info("All tasks completed");
		return allTasksComplete;
	}
	
	/**
	 * Shutsdown all threads.
	 */
	public void destroy() {
		service.shutdown();
		frameworkLogger.info("Workmanager shutdown complete");
	}
}
