/*
 * Copyright (c) Nike Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Nike Inc. ("Confidential Information"). 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Nike.
 *
 * NIKE MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES
 */
package org.nike.wms.tests.testdata.xmlgenerator.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicInteger;

import org.nike.wms.tests.testdata.xmlgenerator.core.WorkerManager;
import org.nike.wms.tests.testdata.xmlgenerator.exception.FrameworkException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Class to manage the DB Connection creation, allocation and release.
 * 
 * @author CTho50
 *
 */
public class ConnectionManager {

	private static final Logger frameworkLogger = LoggerFactory.getLogger(WorkerManager.class);
	
	private Properties connProps;

	private Connection cachedDBConnection;
	private static boolean usePool;
	private final String dbEnv;
	private int poolSize;
	private final AtomicInteger connIdx = new AtomicInteger(0);
	private Connection[] connList;
	

	/**
	 * 
	 * @param connProperties
	 */
	private ConnectionManager(String prefix, Properties connProperties, int threadPoolsize) {
		connProps = connProperties;
		this.dbEnv = prefix;
		this.poolSize = threadPoolsize;
	}

	/**
	 * Method to create the Connection Manager instance.
	 * 
	 * @param connProperties
	 * @return
	 */
	public static ConnectionManager create(String prefix, Properties connProperties, int threadPoolsize) {
		ConnectionManager manager = new ConnectionManager(prefix, connProperties, threadPoolsize);
		usePool = "true".equals(manager.connProps.getProperty("useConnectionPool"));
		if (usePool) {
			manager.configurePooledConnection();

		} else {
			manager.configureCachedConnection();
		}
		return manager;
	}

	/**
	 * Method to return a cached DB Connection.
	 */
	private void configureCachedConnection() {
		this.cachedDBConnection = createConnection();
	}

	private Connection createConnection() {
		try {
			Class.forName(connProps.getProperty("driverClass"));
			Connection dbConnection = DriverManager.getConnection(dbProperty("jdbcURL"), dbProperty("userName"),
					dbProperty("password"));
			dbConnection.setSchema(dbProperty("dbSchema"));
			return dbConnection;
		} catch (ClassNotFoundException | SQLException excp) {
			throw new FrameworkException("Error while opening the db connection ", excp);
		}
	}

	/**
	 * Method to return a pooled Data Source.
	 */
	private void configurePooledConnection() {
		int maxConnection = Integer.parseInt(dbProperty("maxConnection"));
		if (poolSize > maxConnection) {
			poolSize = maxConnection;
		}
		connList = new Connection[poolSize];
		for (int count = 0; count < poolSize; count++) {
			connList[count] = createConnection();
		}
	}

	private String dbProperty(String propName) {
		String prop = connProps.getProperty(this.dbEnv + "_" + propName, connProps.getProperty(propName, ""));
		return prop;
	}

	/**
	 * Returns the cached DB Connection object any time.
	 * 
	 * @return
	 * @throws SQLException
	 */
	public Connection getConnection() throws SQLException {
		if (usePool) {
			int idx = connIdx.get() % poolSize;
			connIdx.incrementAndGet();
			return connList[idx];
		} else {
			return cachedDBConnection;
		}
	}

	/**
	 * destroys an existing DB Connection.
	 * 
	 * @param dbConnection
	 */
	public void destroy() {
		int count = 0;
		try {
			if (usePool) {
				for (;count < connList.length; count++) {
					try {
						if (connList[count] != null) {
							connList[count].close();
						}
					} catch (SQLException sexcp) {
						//ignore exception
					}
				}
			} else {
				if (cachedDBConnection != null) {
					cachedDBConnection.close();
				}
			}
		} catch (SQLException sqe) {
			frameworkLogger.error("Error while closing connection",sqe);
			throw new FrameworkException("Error while closing the connection", sqe);
		}
		frameworkLogger.info("Connection Manager shutdown complete {} {}",usePool,count + 1);
	}
}
