/**
 * 
 */
package org.nike.wms.tests.testdata.xmlgenerator.core;

import java.util.Random;

/**
 * Represents a functions class that wraps many of the utility functions that
 * can be specified as part of the input xmls.
 * 
 * @author MSivap
 *
 */
public class XMLFunctions {

	private final String prefix;
	private static final String LONG_BOUND_VALUE = "99999999999999999999999999999999999999999999999999999999999999999999999999999999999";

	/**
	 * @param prefix
	 */
	public XMLFunctions(String prefix) {
		this.prefix = prefix;
	}

	/**
	 * Returns the unique id starting with prefix and length equal to that of
	 * given size.
	 * 
	 * @param prefix
	 * @param size
	 * @return
	 */
	public String uniqueId(int size) {
		String addtlTxt = "";
		String dateBasedUniqueId = "";
		if (size > 13) {
			addtlTxt = String.valueOf(new Random().nextInt(Integer.parseInt(LONG_BOUND_VALUE.substring(0, size - 13))));
			dateBasedUniqueId = String.valueOf(System.currentTimeMillis()).substring(0);
		}else {
			dateBasedUniqueId = String.valueOf(System.currentTimeMillis()).substring(13 - size);
		}
		return new StringBuilder(prefix).append(addtlTxt)
				.append(dateBasedUniqueId).toString();
	}
}