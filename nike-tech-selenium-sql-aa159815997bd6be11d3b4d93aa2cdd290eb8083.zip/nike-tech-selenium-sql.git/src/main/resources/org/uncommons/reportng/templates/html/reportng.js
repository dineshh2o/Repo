// Makes all Images, auto-expandy
$( document ).ready(function() {
    $('a.crop').click(function(e) {
        e.preventDefault();
        if ($(this).hasClass("full")) {
            $(this).removeClass('expand full');
            var offset = $(this).offset();
            $('html, body').animate({
                scrollTop: offset.top - 20,
                scrollLeft: offset.left - 20
            });
        } else if ($(this).hasClass("expand")) {
            $(this).addClass('full');
        } else {
            $(this).addClass('expand');
        }

    });
});

function toggleElement(elementId, isolate)
{
    var el = $( "#" + elementId);
    el.find('span.imgplaceholder').replaceWith( function() {
       return "<img src='" + $(this).data('src') + "'>";
    });
    if (isolate) {
        $("*[id*=" + elementId.replace(/-\d+$/, "") + "]").each( function() {
            if ($(this).attr("id") != elementId) {
                $(this).hide();
            }
        })
    }
    el.toggle(400);
}