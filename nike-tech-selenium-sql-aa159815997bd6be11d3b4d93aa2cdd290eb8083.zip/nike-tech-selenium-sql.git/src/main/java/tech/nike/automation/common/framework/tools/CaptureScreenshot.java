package tech.nike.automation.common.framework.tools;

/**
 * Created by PSibb1 on 8/20/2016.
 */
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class CaptureScreenshot {

    public static void captureFullScreen() {

        // This code will capture screenshot of current screen
        BufferedImage image = null;
        try {
            image = new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
            // This will store screenshot on Specific location
            ImageIO.write(image, "png", new File("C:\\Screenshot\\CurrentScreenshot.png"));
        } catch (AWTException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}