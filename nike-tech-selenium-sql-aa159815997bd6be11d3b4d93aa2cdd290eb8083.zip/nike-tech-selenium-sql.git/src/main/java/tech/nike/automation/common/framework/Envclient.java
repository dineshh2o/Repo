package tech.nike.automation.common.framework;

/**
 * Created by psibb1 on 3/18/2016.
 */
public class Envclient {
    Env testEnv;

    public Envclient(Env testEnv) {
        this.testEnv = testEnv;
    }

    public String getEnvUrl() {
        String strHost = null;
        switch (testEnv) {
            case d031:
                strHost = "http://nke-lnx-wms-" + testEnv + ".nike.com:10000";
                break;

            case x103:
                strHost = "http://nke-lnx-wms-" + testEnv + ".nike.com:10000";
                break;

            case x102:
                strHost = "http://nke-lnx-wms-" + testEnv + ".nike.com:10000";
                break;

            case d050:
                strHost = "http://nke-lnx-wms-" + testEnv + ".nike.com:10000";
                break;

            default:
                break;
        }
        return strHost;
    }

    public enum Env {
        d031, x103, x102, d050
    }
}