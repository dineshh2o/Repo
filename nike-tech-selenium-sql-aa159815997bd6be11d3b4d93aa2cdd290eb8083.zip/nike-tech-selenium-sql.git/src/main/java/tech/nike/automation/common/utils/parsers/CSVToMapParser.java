package tech.nike.automation.common.utils.parsers;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Simple CSV parser that reads in a CSV file to a map of maps.  This class simulates
 * data being fed into to ParameterizedTestConfigUtil.  It matches how the XMlToMapParser converts
 * data into HashMaps/Lists.
 *
 * @author Cognizant Technology CoE
 */
public class CSVToMapParser implements DataToMapParser {
    static final boolean VERBOSE = false;
    @SuppressWarnings("unused")
    private static final Log logger = LogFactory.getLog(CSVToMapParser.class);

    private Map<String, Object> map = null; // map holds resource returned


    /**
     * Public function, get map representation of the xml file.
     *
     * @return HashMap of xml file elements.
     */
    public HashMap<String, Object> getHashMap() {
        return ((HashMap<String, Object>) map);
    }


    public void parse(File f) throws IOException {
        FileReader reader = new FileReader(f);
        BufferedReader bufferedReader = new BufferedReader(reader);
        map = new HashMap<String, Object>();

        //parsing individual tests
        ArrayList<Object> testList = new ArrayList<Object>();

        String nextLine;
        while ((nextLine = bufferedReader.readLine()) != null) {
            String[] currentLine = nextLine.split(",");

            //test values map for each test
            HashMap<String, Object> testValuesMap = new HashMap<String, Object>();

            for (int i = 0; i < currentLine.length; i += 2) {
                testValuesMap.put(currentLine[i], currentLine[i + 1]);
            }
            testList.add(testValuesMap);
        }

        //finally put all the tests into the overall map
        map.put("test", testList);
        bufferedReader.close();
    }
}
