//package tech.nike.automation.common.framework.QcUtils;

/*public class QcLib {
    private Selenium se;
    static String test_id = null;
    static HashMap<String, String> getQCData = new HashMap<String, String>();
    public String qcwrflag;
    public String qctestid = null;
    private String qcuserid, qcpwd,
            qcdomain, qcproject,
            qchost, qcport, qctestsetid, qcversion;
    private RestConnector connection;
    private String runId = null;
    private ArrayList<String> testConfigIdArray = new ArrayList<String>();
    private ArrayList<String> testCaseNameArray = new ArrayList<String>();
    private ArrayList<String> testInstanceIdArray = new ArrayList<String>();
    private ArrayList<String> cycleIdArray = new ArrayList<String>();
    private ArrayList<String> testIdArray = new ArrayList<String>();
    private String testInstanceId = null;
    private String runId_beforeUpdate = null;
    private String oldStatus = null;
    private String testConfigId = null;
    private String testCycleId = null;
    private String runId_created = null;
    private byte[] file_contents;

    QcLib() {

        //getQCData = MainDriver.xmlLib.getQCProperties();
        qcwrflag = SystemUtil.getQCRun();
        qcuserid = SystemUtil.getQCUser();
        qcpwd = SystemUtil.getQCPassword();
        qcdomain = SystemUtil.getQCDomain();
        qcproject = SystemUtil.getQCProject();
        qcversion = SystemUtil.getQCVersion();
        //for time being declaring qc testid taking from config file
        qctestsetid = getQCData.get("QCTestSetid");
        connection = RestConnector.getInstance();
        connection = RestConnector.getInstance().init(
                new HashMap<String, String>(),
                qchost,
                qcport,
                qcdomain,
                qcproject);

    }*/

    /**
     *
     * @return
     * @throws Exception
     */
   /* public boolean qclogin() throws Exception {
        //Create a string that looks like "Basic ((username:password)lt;as bytesgt;)lt;64encodedgt;"
        String authenticationPoint = qcisAuthenticated();
        byte[] credBytes = (qcuserid + ":" + qcpwd).getBytes();
        String credEncodedString = "Basic " + new BASE64Encoder().encode(credBytes);
        //String credString = new String(credEncodedString);
        Map<String, String> map = new HashMap<String, String>();
        map.put("Authorization", credEncodedString);
        Response response = connection.httpGet(authenticationPoint, null, map);

        boolean ret = response.getStatusCode() == HttpURLConnection.HTTP_OK;
        return ret;

    }*/

    /**
     * @return true if logout successful
     * @throws Exception close session on server and clean session cookies on client
     */
   /* public boolean qclogout() throws Exception {
        //New that the get operation logs us out by setting authentication cookies to: LWSSO_COOKIE_KEY="" using server response header Set-Cookie
        Response response =
                connection.httpGet(connection.buildUrl("qcbin/authentication-point/logout"), null, null);
        return (response.getStatusCode() == HttpURLConnection.HTTP_OK);
    }*/

    /**
     * @return null if authenticated.<br>
     * a url to authenticate against if not authenticated.
     * @throws Exception
     */
   /* public String qcisAuthenticated() throws Exception {
        String isAuthenticateUrl = connection.buildUrl("qcbin/rest/is-authenticated");
        String ret;
        Response response = connection.httpGet(isAuthenticateUrl, null, null);
        int responseCode = response.getStatusCode();
        //If already authenticated
        if (responseCode == HttpURLConnection.HTTP_OK) {
            ret = null;
        }
        //If not authenticated - get the address where to authenticate via WWW-Authenticate
        else if (responseCode == HttpURLConnection.HTTP_UNAUTHORIZED) {
            Iterable<String> authenticationHeader =
                    response.getResponseHeaders().get("WWW-Authenticate");
            String newUrl = authenticationHeader.iterator().next().split("=")[1];
            newUrl = newUrl.replace("\"", "");
            newUrl += "/authenticate";
            ret = newUrl;
        }
        //Not OK and not unauthorized - means some kind of error, like 404, or 500
        else {
            throw response.getFailure();
        }
        return ret;
    }
*/
    /**
     *
     * @param tcName
     * @return
     */
    /*public boolean qctcparsexml(String tcName) {
        String value;
        String retxml;
        boolean tcfound = false;
        try {

            Map<String, String> requestHeaders = new HashMap<String, String>();
            requestHeaders.put("Accept", "application/xml");
            retxml = connection.httpGet(connection.buildUrl("qcbin/rest//domains/"
                            + qcdomain + "/projects/" + qcproject
                            + "/tests?query={name[" + tcName + "]}"),
                    null, requestHeaders).toString();
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory
                    .newInstance();
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            Document doc = docBuilder
                    .parse(new InputSource(new StringReader(retxml)));
            NodeList listOfEntity = doc.getElementsByTagName("Entity");

            for (int i = 0; i < listOfEntity.getLength(); i++) {
                NodeList listOfFields = doc.getElementsByTagName("Field");
                for (int x = 0, size = listOfFields.getLength(); x < size; x++) {
                    NodeList listOfValues = listOfFields.item(x)
                            .getChildNodes();

                    for (int j = 0; j < listOfValues.getLength(); j++) {
                        value = listOfValues.item(j).getTextContent();

                        if (listOfFields.item(x).getAttributes()
                                .getNamedItem("Name").getNodeValue() != null
                                && listOfFields.item(x).getAttributes()
                                .getNamedItem("Name").getNodeValue()
                                .trim().equalsIgnoreCase("id")) {
                            //if (p != noOfEntities) {
                            //ID[p++] = value;
                            qctestid = value;
                            //System.out.println(value);
                            //System.out.println(ID[p++]);
                            //}

                        }
                        if (listOfFields.item(x).getAttributes()
                                .getNamedItem("Name").getNodeValue() != null
                                && listOfFields.item(x).getAttributes()
                                .getNamedItem("Name").getNodeValue()
                                .trim().equalsIgnoreCase("name")) {
                            //if (q != noOfEntities) {
                            //testCaseNameFrmXML[q++] = value;
                            if (tcName.trim().equalsIgnoreCase(value))
                                System.out.println("TestCase found in QC:  " + value);
                            tcfound = true;
                            //System.out.println(testCaseNameFrmXML[q++]);
                            //}
                        }

                    }
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return tcfound;
    }*/

    /**
     *
     */
   /* public void parsetestinstancexml() {
        String retxml;
        try {
            Map<String, String> requestHeaders = new HashMap<String, String>();
            requestHeaders.put("Accept", "application/xml");
            retxml = connection.httpGet(connection.buildUrl("qcbin/rest//domains/" +
                            qcdomain + "/projects/" +
                            qcproject + "/test-instances?query={cycle-id[" + qctestsetid + "]}"),
                    null, requestHeaders).toString();
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(new InputSource(new StringReader(retxml)));
            NodeList listOfEntity = doc.getElementsByTagName("Entity");
            retxml = null;
            for (int i = 0; i < listOfEntity.getLength(); i++) {
                NodeList listOfFields = doc.getElementsByTagName("Field");
                for (int x = 0, size = listOfFields.getLength(); x < size; x++) {
                    NodeList listOfValues = listOfFields.item(x).getChildNodes();
                    for (int j = 0; j < listOfValues.getLength(); j++) {
                        if (listOfFields.item(x).getAttributes().getNamedItem("Name").getNodeValue().equalsIgnoreCase("test-config-id")) {
                            if (!testConfigIdArray.contains(listOfValues.item(j).getTextContent()))
                                testConfigIdArray.add(listOfValues.item(j).getTextContent());

                            Map<String, String> requestHeaders1 = new HashMap<String, String>();
                            requestHeaders1.put("Accept", "application/xml");
                            String config_id = listOfValues.item(j)
                                    .getTextContent();
                            String testConfigsWeWantToRead = connection
                                    .buildUrl("qcbin/rest//domains/" + qcdomain + "/projects/" + qcproject + "/test-configs"
                                            + "/" + config_id);
                            retxml = connection.httpGet(testConfigsWeWantToRead, null,
                                    requestHeaders1).toString();
                            String testInstanceName = parsetestconfigxml(retxml);
                            if (!testCaseNameArray.contains(testInstanceName)) {
                                testCaseNameArray.add(testInstanceName);

                            }
                        }

                        if (listOfFields.item(x).getAttributes().getNamedItem("Name").getNodeValue().equalsIgnoreCase("id")) {
                            if (!testInstanceIdArray.contains(listOfValues.item(j).getTextContent()))
                                testInstanceIdArray.add(listOfValues.item(j).getTextContent());
                        }
                        if (listOfFields.item(x).getAttributes().getNamedItem("Name").getNodeValue().equalsIgnoreCase("cycle-id")) {
                            if (!cycleIdArray.contains(listOfValues.item(j).getTextContent()))
                                cycleIdArray.add(listOfValues.item(j).getTextContent());
                        }
                        if (listOfFields.item(x).getAttributes().getNamedItem("Name").getNodeValue().equalsIgnoreCase("test-id")) {
                            if (!testIdArray.contains(listOfValues.item(j).getTextContent()))
                                testIdArray.add(listOfValues.item(j).getTextContent());
                        }


                    }

                }

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }*/

    /**
     *
     * @param s
     * @return
     */
   /* private String parsetestconfigxml(String s) {
        String test_name = null;
        try {

            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory
                    .newInstance();
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            Document doc = docBuilder
                    .parse(new InputSource(new StringReader(s)));

            // normalize text representation and print the root element
            doc.getDocumentElement().normalize();
            NodeList listOfEntity = doc.getElementsByTagName("Entity");
            for (int i = 0; i < listOfEntity.getLength(); i++) {

                //Node firstEntity = listOfEntity.item(i);
                //Element entity = (org.w3c.dom.Element) firstEntity;
                //String type_id = entity.getAttribute("Type");
                NodeList listOfFields = doc.getElementsByTagName("Field");

                for (int x = 0, size = listOfFields.getLength(); x < size; x++) {
                    NodeList listOfValues = listOfFields.item(x)
                            .getChildNodes();

                    for (int j = 0; j < listOfValues.getLength(); j++) {
                        if (listOfFields.item(x).getAttributes()
                                .getNamedItem("Name").getNodeValue()
                                .equalsIgnoreCase("test-name")) {
                            test_name = listOfValues.item(j).getTextContent();
                        }

                    }

                }

            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return test_name;
    }*/

    /**
     *
     * @param tcName
     */
    /*public void qcupdatestatus(String tcName) {
        String execution_status, checkout, lock;
        boolean checkin, unlock;
        String status = null;
        try {
            //Check whether test case is exist in QC in test set
            if (!qctcparsexml(tcName)) {
                se.log.logSeStep("Test case not found in QC under test set id:" + qctestsetid, "Fail");
                return;
            }
            parsetestinstancexml();
            // Added by Sangeeta - start
            for (int l = 0; l < testCaseNameArray.size(); l++) {
                if (testCaseNameArray.get(l).equalsIgnoreCase(tcName)) {
                    testConfigId = testConfigIdArray.get(l);
                    testCycleId = cycleIdArray.get(0);
                    break;
                }

            }
            //		String runResourcesWeWantToRead = con.buildUrl("qcbin/rest//domains/"+MainDriverInQC.strQCDomain+"/projects/"+MainDriverInQC.strQCProject+"/runs?query={test-config-id["+"196798"+"];cycle-id["+"26751"+"]}");
            String runResourcesWeWantToRead = connection.buildUrl("qcbin/rest//domains/" + qcdomain + "/projects/" + qcproject + "/runs?query={test-config-id[" + testConfigId + "];cycle-id[" + testCycleId + "]}");
            System.out.println(runResourcesWeWantToRead);
            Map<String, String> requestHeaders = new HashMap<String, String>();
            requestHeaders.put("Accept", "application/xml");
            String postedEntitiesReturnedXml = connection.httpGet(runResourcesWeWantToRead, null, requestHeaders).toString();
            System.out.println(postedEntitiesReturnedXml);
            //   parseXML(postedEntitiesReturnedXml);
            qcparserunidxml(postedEntitiesReturnedXml);
            runId_beforeUpdate = runId;
            System.out.println("Run ID before updating status -" + runId_beforeUpdate);
            String runResourcesWeWantToRead_oldrun = connection.buildUrl("qcbin/rest//domains/" + qcdomain + "/projects/" + qcproject + "/runs/" + runId_beforeUpdate);
            requestHeaders = new HashMap<String, String>();
            requestHeaders.put("Accept", "application/xml");
            postedEntitiesReturnedXml = connection.httpGet(runResourcesWeWantToRead_oldrun, null, requestHeaders).toString();
            System.out.println(postedEntitiesReturnedXml);
            *//*if (postedEntitiesReturnedXml != null && postedEntitiesReturnedXml.contains("Passed"))
            {
		    	 oldStatus = "Passed";
		    }
		    else if(postedEntitiesReturnedXml != null && postedEntitiesReturnedXml.contains("Failed"))
		    {
		    	 oldStatus = "Failed";
		    }
		    System.out.println(oldStatus);

			for(int l=0;l<testCaseNameArray.size();l++)
			{
				if(testCaseNameArray.get(l).equalsIgnoreCase(tcName))
				{
					testInstanceId=testInstanceIdArray.get(l);
					break;
				}

			}*//*
            // Added by Sangeeta - end

            execution_status = qcretteststatus(tcName);
            DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String date = formatter.format(new Date()).toString();
            String exec_date = date.substring(0, 10);
            String exec_time = date.substring(10, date.length());
            System.out.println("Building the URL for updating the Test-Instance");
            String testInstanceURL = connection.buildEntityCollectionUrl("test-instance");

            for (int l = 0; l < testCaseNameArray.size(); l++) {
                if (testCaseNameArray.get(l).equalsIgnoreCase(tcName)) {
                    testInstanceId = testInstanceIdArray.get(l);
                    break;
                }

            }

            if (execution_status.equalsIgnoreCase("Passed"))
                status = "Passed";
            if (execution_status.equalsIgnoreCase("Failed"))
                status = "Failed";

            String updatedEntityXml = generateUpdateXml("status", status);
            String updatedEntityExecDateXml = generateUpdateXml("exec-time", exec_time);
            String updatedEntityExecTimeXml = generateUpdateXml("exec-date", exec_date);
            String newEntityToUpdateUrl = testInstanceURL + "/" + testInstanceId;

            if (qcversion.equalsIgnoreCase("true")) {
                //Note that we selected an entity that supports versioning on a project that supports versioning. Otherwise, this call would fail.
                checkout = checkout(newEntityToUpdateUrl, "check out comment1", -1);

            } else {
                lock = lock(newEntityToUpdateUrl);

            }

            //Update the entity
            String put = update(newEntityToUpdateUrl, updatedEntityXml).toString();
            put = update(newEntityToUpdateUrl, updatedEntityExecDateXml).toString();
            put = update(newEntityToUpdateUrl, updatedEntityExecTimeXml).toString();

            System.out.println("Updated The TestCase Execution-Status....");
            System.out.println("entity updated: " + put.trim());

            // If versioning is enabled, check out the entity. Otherwise, lock it.
            if (qcversion.equalsIgnoreCase("true")) {
                checkin = checkin(newEntityToUpdateUrl);

            } else {
                unlock = unlock(newEntityToUpdateUrl);

            }
        } catch (Exception e) {
            e.printStackTrace();
            se.log.logSeStep("Test Case status has NOT Updated" +
                    " in QC due to Exception name:" + e.getMessage(), "Fail");
            return;
        }
    }*/

    /*public void qcattachLog(String tcName) throws Exception {
        String testConfigId = null;
        String testCycleId = null;
        try {
            for (int l = 0; l < testCaseNameArray.size(); l++) {
                if (testCaseNameArray.get(l).equalsIgnoreCase(tcName)) {
                    testConfigId = testConfigIdArray.get(l);
                    testCycleId = cycleIdArray.get(0);
                    break;
                }
            }

            String runResourcesWeWantToRead = connection.buildUrl("qcbin/rest//domains/" + qcdomain + "/projects/" + qcproject + "/runs?query={test-config-id[" + testConfigId + "];cycle-id[" + testCycleId + "]}");
            //String runResourcesWeWantToRead = con.buildUrl("qcbin/rest//domains/"+"DEFAULT"+"/projects/"+"QC_Test"+"/runs?query={test-config-id["+testConfigId+"];cycle-id["+testCycleId+"]}");
            Map<String, String> requestHeaders = new HashMap<String, String>();
            requestHeaders.put("Accept", "application/xml");
            String postedEntitiesReturnedXml = connection.httpGet(runResourcesWeWantToRead, null, requestHeaders).toString();
            qcparserunidxml(postedEntitiesReturnedXml);

            System.out.println("Building the URL for attaching Logs in Run");
            String testRunURL = connection.buildEntityCollectionUrl("run");
            String createdEntityUrl = testRunURL + "/" + runId;

            String file_path = MainDriver.testsRes.resultDirectory + tcName.trim() + ".txt";
            //file_name = file_path.substring(file_path.indexOf("AutoResults")+3, file_path.indexOf("log")+2);
            String multipartFileName = file_path.substring(file_path.indexOf("AutoResults") + 32, file_path.indexOf("txt") + 3);
            //String multipartFileName = tcName+".log";
            String execution_status = qcretteststatus(tcName);


            // Added by Sangeeta - start
            // If after updating the status, a new run is created automatically , that means the status are diff and we dont need to add any more run explicitely.
            // Only if after and before status update, run id remains same, we need to add a new run.
            if (runId != null && runId_beforeUpdate != null && runId.trim().equalsIgnoreCase(runId_beforeUpdate.trim()))

            //    if (testStatus != null && UpdateStatus.oldStatus != null && testStatus.trim().equalsIgnoreCase(UpdateStatus.oldStatus.trim()))
            {
                String entityToPostXml =
                        ("<Entity Type=\"defect\"><Fields>" +
                                "<Field Name=\"user-01\"><Value>" + "</Value></Field>" +
                                "<Field Name=\"user-02\"><Value>" + "</Value></Field>" +
                                "<Field Name=\"test-instance\"><Value>1" + "</Value></Field>" +
                                "<Field Name=\"execution-date\"><Value>2012-11-29" + "</Value></Field>" +
                                "<Field Name=\"test-config-id\"><Value>" + testConfigId + "</Value></Field>" +
                                "<Field Name=\"name\"><Value>Fast_Run_10-29_1-23-16" + "</Value></Field>" +
                                "<Field Name=\"testcycl-id\"><Value>" + testInstanceId + "</Value></Field>" +
                                "<Field Name=\"cycle-id\"><Value>" + testCycleId + "</Value></Field>" +
                                "<Field Name=\"last-modified\"><Value>2012-11-29 02:37:31" + "</Value></Field>" +
                                "<Field Name=\"status\"><Value>" + execution_status + "</Value></Field>" +
                                //	"<Field Name=\"test-id\"><Value>"+"195801"+ "</Value></Field>" +
                                "<Field Name=\"test-id\"><Value>" + test_id + "</Value></Field>" +
                                "<Field Name=\"owner\"><Value>vkuru1</Value></Field>" +
                                "<Field Name=\"execution-time\"><Value>02:37:31AM</Value></Field>" +
                                "<Field Name=\"attachment\"><Value>Y</Value></Field>" +
                                "<Field Name=\"duration\"><Value>0</Value></Field>" +
                                "<Field Name=\"draft\"><Value>N</Value></Field>" +
                                "<Field Name=\"host\"><Value></Value></Field>" +
                                "<Field Name=\"cycle\"><Value></Value></Field>" +
                                "<Field Name=\"iters-sum-status\"><Value></Value></Field>" +
                                "<Field Name=\"subtype-id\"><Value>hp.qc.run.VAPI-XP-TEST</Value></Field>" +

                                "</Fields></Entity>");
                requestHeaders = new HashMap<String, String>();
                requestHeaders.put("Content-Type", "application/xml");
                requestHeaders.put("Accept", "application/xml");
                Response postedEntityResponse =
                        connection.httpPost(testRunURL, entityToPostXml.getBytes(), requestHeaders);
                System.out.println(postedEntityResponse);
                String postedEntityResponseXml = postedEntityResponse.toString();
                // Getting the current run and adding log file to it
                runResourcesWeWantToRead = connection.buildUrl("qcbin/rest//domains/" + qcdomain + "/projects/" + qcproject + "/runs?query={test-config-id[" + testConfigId + "];cycle-id[" + testCycleId + "]}");
                requestHeaders = new HashMap<String, String>();
                requestHeaders.put("Accept", "application/xml");
                postedEntitiesReturnedXml = connection.httpGet(runResourcesWeWantToRead, null, requestHeaders).toString();
                qcparserunidxml(postedEntitiesReturnedXml);
                runId_created = runId;
                System.out.println("Run Id created -" + runId_created);
                System.out.println(postedEntitiesReturnedXml);
                testRunURL = connection.buildEntityCollectionUrl("run");
                createdEntityUrl = testRunURL + "/" + runId_created;
                System.out.println(createdEntityUrl);
                file_read(tcName);
                String newMultiPartAttachmentUrl = qcattachfile(createdEntityUrl,
                        file_contents,
                        "text/plain",
                        multipartFileName,
                        "Log file attach");
                System.out.println("multipart attachment url: " + newMultiPartAttachmentUrl);
            } else {
                file_read(tcName);
                String newMultiPartAttachmentUrl = qcattachfile(createdEntityUrl,
                        file_contents,
                        "text/plain",
                        multipartFileName,
                        "Log file attach");
                System.out.println("multipart attachment url: " + newMultiPartAttachmentUrl);
            }
            // Added by Sangeeta - end


        } catch (Exception e) {
            e.printStackTrace();
            MainDriver.testsRes.writeLog("Test case Log has NOT attached" +
                    " in QC due to Exception name:" + e.getMessage(), "Fail");
            return;
        }

    }*/

    /*private String qcattachfile(String entityUrl,
                                byte[] fileData,
                                String contentType,
                                String filename,
                                String description) {
        String strResp = null;
        try {
            //This can be pretty much any string - it's used to signify the different mime parts
            String boundary = "exampleboundary";
            //Template to use when sending field data (assuming non-binary data)
            String fieldTemplate =
                    "--%1$s\r\n"
                            + "Content-Disposition: form-data; name=\"%2$s\" \r\n\r\n"
                            + "%3$s"
                            + "\r\n";
            //Template to use when sending file data (binary data still needs to be suffixed)
            String fileDataPrefixTemplate =
                    "--%1$s\r\n"
                            + "Content-Disposition: form-data; name=\"%2$s\"; filename=\"%3$s\"\r\n"
                            + "Content-Type: %4$s\r\n\r\n";
            String filenameData = String.format(fieldTemplate, boundary, "filename", filename);
            String descriptionData = String.format(fieldTemplate, boundary, "description", description);
            String fileDataSuffix = "\r\n--" + boundary + "--";
            String fileDataPrefix =
                    String.format(fileDataPrefixTemplate, boundary, "file", filename, contentType);
            //The order is extremely important: The filename and description come before file data. The name of the file in the file part and in the filename part value MUST MATCH.
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            bytes.write(filenameData.getBytes());
            bytes.write(descriptionData.getBytes());
            bytes.write(fileDataPrefix.getBytes());
            bytes.write(fileData);
            bytes.write(fileDataSuffix.getBytes());
            bytes.close();
            Map<String, String> requestHeaders = new HashMap<String, String>();
            requestHeaders.put("Content-Type", "multipart/form-data; boundary=" + boundary);
            Response response = connection.httpPost(entityUrl + "/attachments", bytes.toByteArray(), requestHeaders);
            strResp = response.getResponseHeaders().get("Location").iterator().next();

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            MainDriver.testsRes.writeLog("Test case Log has NOT attached" +
                    " in QC due to Exception name:" + e.getMessage(), "Fail");
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            MainDriver.testsRes.writeLog("Test case Log has NOT attached" +
                    " in QC due to Exception name:" + e.getMessage(), "Fail");
        }
        return strResp;
    }*/

    //@SuppressWarnings("finally")
   /* public byte[] file_read(String testName) {
        String contents = null;
        //String tcName = "";
        try {
            String file_name = MainDriver.testsRes.resultDirectory + testName.trim() + ".txt";
            FileInputStream fstream = new FileInputStream(file_name);
            // Get the object of DataInputStream
            DataInputStream in = new DataInputStream(fstream);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String strLine;
            String separator = System.getProperty("line.separator");
            //Read File Line By Line
            while ((strLine = br.readLine()) != null) {
                contents = contents + strLine + separator;
            }
            if (contents.contains("null")) {
                if (contents.indexOf("null") == 0) {
                    contents = contents.replaceFirst("null", "");
                }
            }
            file_contents = contents.getBytes();
            //Close the input stream
            in.close();
        } catch (Exception e) {//Catch exception if any
            System.err.println("Error in file_read() function in QualityCenterLib.java: " + e.getMessage());
        } finally {
            return file_contents;
        }
    }*/

    /*public void qcparserunidxml(String s) {
        try {
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(new InputSource(new StringReader(s)));
            NodeList listOfEntity = doc.getElementsByTagName("Entity");
            for (int i = 0; i < listOfEntity.getLength(); i++) {
                NodeList listOfFields = doc.getElementsByTagName("Field");
                for (int x = 0, size = listOfFields.getLength(); x < size; x++) {
                    NodeList listOfValues = listOfFields.item(x).getChildNodes();
                    for (int j = 0; j < listOfValues.getLength(); j++) {
                        if (listOfFields.item(x).getAttributes().getNamedItem("Name").getNodeValue().equalsIgnoreCase("id")) {
                            runId = listOfValues.item(j).getTextContent();
                        }
                        // Added by Sangeeta - we need the test-id for building the xml to post a run - start
                        if (listOfFields.item(x).getAttributes().getNamedItem("Name").getNodeValue().equalsIgnoreCase("test-id")) {
                            test_id = listOfValues.item(j).getTextContent();

                        }
                        // Added by Sangeeta - end
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }*/

   /* public String qcretteststatus(String tcName) {
        String status = null;
        String file_path = null;
        boolean b1, b2 = false;
        //String file_name = null;
        try {
            file_path = MainDriver.testsRes.resultDirectory + tcName + ".txt";
            //File fexist = new File(file_path);
            //boolean bn = fexist.exists();
            Scanner sc2 = null;
            sc2 = new Scanner(new File(file_path));

            while (sc2.hasNextLine()) {
                Scanner s2 = new Scanner(sc2.nextLine());
                //System.out.println(s2.next());
                while (b1 = s2.hasNext()) {
                    String s = s2.next();
                    if ((s.contains("Fail")) || (s.contains("FAIL"))) {
                        b2 = true;
                        break;
                    }

                }
                if (b2)
                    break;
            }
            if (b2)
                status = "Failed";
            else status = "Passed";
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }*/

    /**
     * @param entityUrl        to update
     * @param updatedEntityXml new entity descripion. only lists updated fields. unmentioned fields will not
     *                         change.
     * @return xml description of the entity on the serverside, after update.
     * @throws Exception
     */
  /*  public Response update(String entityUrl, String updatedEntityXml) throws Exception {
        Map<String, String> requestHeaders = new HashMap<String, String>();
        requestHeaders.put("Content-Type", "application/xml");
        requestHeaders.put("Accept", "application/xml");
        Response put = connection.httpPut(entityUrl, updatedEntityXml.getBytes(), requestHeaders);
        return put;
    }*/

    /*private String generateUpdateXml(String field, String value) {
        return "<Entity Type=\"test-instances\"><Fields>"
                + "<Field Name=\""
                + field
                + "\"><Value>"
                + value
                + "</Value></Field>"
                + "</Fields></Entity>";
    }*/

   /* public String checkout(String entityUrl, String comment, int version) throws Exception {
        String commentXmlBit =
                ((comment != null) && !comment.isEmpty()
                        ? "<Comment>" + comment + "</Comment>"
                        : "");
        String versionXmlBit = (version >= 0 ? "<Version>" + version + "</Version>" : "");
        String xmlData = commentXmlBit + versionXmlBit;
        String xml =
                xmlData.isEmpty() ? "" : "<CheckOutParameters>" + xmlData + "</CheckOutParameters>";
        Map<String, String> requestHeaders = new HashMap<String, String>();
        requestHeaders.put("Content-Type", "application/xml");
        requestHeaders.put("Accept", "application/xml");
        Response response =
                connection.httpPost(entityUrl + "/versions/check-out", xml.getBytes(), requestHeaders);
        return response.toString();
    }*/

    /**
     * @param entityUrl to checkin
     * @return true if operation is successful
     * @throws Exception
     */
   /* public boolean checkin(String entityUrl) throws Exception {
        //Execute a post operation on the checkin resource of your entity.
        Response response = connection.httpPost(entityUrl + "/versions/check-in", null, null);
        boolean ret = response.getStatusCode() == HttpURLConnection.HTTP_OK;
        return ret;
    }*/

    /**
     * @param entityUrl to lock
     * @return the locked entity xml
     * @throws Exception
     */
    /*public String lock(String entityUrl) throws Exception {
        Map<String, String> requestHeaders = new HashMap<String, String>();
        requestHeaders.put("Accept", "application/xml");
        return connection.httpPost(entityUrl + "/lock", null, requestHeaders).toString();
    }*/

    /**
     * @param entityUrl to unlock
     * @return
     * @throws Exception
     */
   /* public boolean unlock(String entityUrl) throws Exception {
        return connection.httpDelete(entityUrl + "/lock", null).getStatusCode() == HttpURLConnection.HTTP_OK;
    }


}*/
