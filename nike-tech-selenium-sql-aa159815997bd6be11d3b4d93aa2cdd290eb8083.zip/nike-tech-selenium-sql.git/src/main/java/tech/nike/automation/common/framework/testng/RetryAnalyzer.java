package tech.nike.automation.common.framework.testng;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;
import org.testng.Reporter;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicInteger;

import static org.testng.internal.Constants.displayStatus;
import static org.uncommons.reportng.ReportNGUtils.arrayToString;

public class RetryAnalyzer implements IRetryAnalyzer {
    private static final int MAX_TRIES = Integer.valueOf(System.getProperty("test.retryCount", "3"));
    private static ConcurrentMap<String, AtomicInteger> executionCounts = new ConcurrentHashMap<String, AtomicInteger>();

    @Override
    public boolean retry(ITestResult result) {
        String key = generateKey(result);
        executionCounts.putIfAbsent(key, new AtomicInteger(0));
        int tries = executionCounts.get(key).incrementAndGet();
        result.setAttribute("iteration", tries);
        if (result.getStatus() != ITestResult.SUCCESS && result.getStatus() != ITestResult.SKIP && tries < MAX_TRIES) {
            String message = result.getName() + ": " + displayStatus(result.getStatus()) + ", Retrying up to " + (MAX_TRIES - tries) + " more times.";
            System.out.println(message);
            Reporter.log(message);
            return true;
        }
        return false;
    }

    private String generateKey(ITestResult result) {
        return result.getMethod().getRealClass().getName() + ":" + result.getMethod().getMethodName() + ":" + arrayToString(result.getParameters());
    }
}
