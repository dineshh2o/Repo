package tech.nike.automation.common.framework.utility;

import java.util.Random;
/**
 * Created by nchou4 on 9/19/2016.
 */
public class GenerateDONum {

    public static String DONumber() {
        Random rand = new Random();
        String strDONum = Integer.toString(rand.nextInt(90000000)) ;
        strDONum = System.getProperty("user.name").toUpperCase() + strDONum ;
        return strDONum;
    }
}
