package tech.nike.automation.common.framework;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.util.HashMap;
import java.util.Iterator;


/**
 * Created by PSibb1 on 6/7/2016.
 */
public class ExcelUtil {

    public static HashMap<String, Integer> columnmap;
    public static HashMap<String, Integer> rowmap;
    static Selenium se;

    public ExcelUtil(Selenium se) {
        this.se = se;
    }

    public void readXLSFile(String path) {
        InputStream ExcelFileToRead = null;
        try {
            ExcelFileToRead = new FileInputStream(path);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        HSSFWorkbook wb = null;
        try {
            wb = new HSSFWorkbook(ExcelFileToRead);
        } catch (IOException e) {
            e.printStackTrace();
        }
        HSSFSheet sheet = wb.getSheetAt(0);
        HSSFRow row;
        HSSFCell cell;
        Iterator rows = sheet.rowIterator();
        while (rows.hasNext()) {
            row = (HSSFRow) rows.next();
            Iterator cells = row.cellIterator();
            while (cells.hasNext()) {
                cell = (HSSFCell) cells.next();
                if (cell.getCellType() == HSSFCell.CELL_TYPE_STRING) {
                    se.log.logSeStep(cell.getStringCellValue() + " ");
                } else if (cell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC) {
                    se.log.logSeStep(cell.getNumericCellValue() + " ");
                } else {
                    //U Can Handel Boolean, Formula, Errors
                }
            }
            se.log.logSeStep("");
        }
    }

    public void writeXLSFile(String excelFileName, String valueToWrite)  {
        int colNumb =0;
        String sheetName = "Sheet1";//name of sheet
        HSSFWorkbook wb = new HSSFWorkbook();
        HSSFSheet sheet = wb.createSheet(sheetName);
        int rowNumb = sheet.getLastRowNum();
        if(rowNumb != 0) {
            colNumb = sheet.getRow(rowNumb).getLastCellNum();
        }
        HSSFRow row = sheet.createRow(rowNumb+1);
        HSSFCell cell = row.createCell(colNumb+1);
        cell.setCellValue(valueToWrite);
        FileOutputStream fileOut = null;
        try {
            fileOut = new FileOutputStream(excelFileName);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        //write this workbook to an Outputstream.
        try {
            wb.write(fileOut);
            fileOut.flush();
            fileOut.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void readXLSXFile(String path)  {
        InputStream ExcelFileToRead = null;
        try {
            ExcelFileToRead = new FileInputStream(path);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        XSSFWorkbook wb = null;
        try {
            wb = new XSSFWorkbook(ExcelFileToRead);
        } catch (IOException e) {
            e.printStackTrace();
        }
        XSSFWorkbook test = new XSSFWorkbook();
        XSSFSheet sheet = wb.getSheetAt(0);
        XSSFRow row;
        XSSFCell cell;
        Iterator rows = sheet.rowIterator();
        while (rows.hasNext()) {
            row = (XSSFRow) rows.next();
            Iterator cells = row.cellIterator();
            while (cells.hasNext()) {
                cell = (XSSFCell) cells.next();
                if (cell.getCellType() == XSSFCell.CELL_TYPE_STRING) {
                    se.log.logSeStep(cell.getStringCellValue() + " ");
                } else if (cell.getCellType() == XSSFCell.CELL_TYPE_NUMERIC) {
                    se.log.logSeStep(cell.getNumericCellValue() + " ");
                } else {
                    //U Can Handel Boolean, Formula, Errors
                }
            }
            se.log.logSeStep("");
        }

    }

    public void writeXLSXFile(String excelFileName, String valueToWrite) {
        String sheetName = "Sheet1";//name of sheet
        XSSFWorkbook wb = new XSSFWorkbook();
        XSSFSheet sheet = wb.createSheet(sheetName);
        int rowNumb = sheet.getLastRowNum();
        int colNumb = sheet.getRow(rowNumb).getLastCellNum();
        XSSFRow row = sheet.createRow(rowNumb+1);
        XSSFCell cell = row.createCell(colNumb+1);
        cell.setCellValue(valueToWrite);
        FileOutputStream fileOut = null;
        try {
            fileOut = new FileOutputStream(excelFileName);
            //write this workbook to an Outputstream.
            wb.write(fileOut);
            fileOut.flush();
            fileOut.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}