package tech.nike.automation.common.framework.sql;

/**
 * Created by psibb1 on 8/31/2016.
 */
public class INT2Queries {
    public static String[] getQuery(String strTestCaseName) {
        String[] arrSQL = {};
        switch (strTestCaseName) {
            case "OB_1064_PW03AT_HP_01_INT2_TaskCr_PallEquip_Non_VAS":
                String sql1 = "select  LPN.TC_PARENT_LPN_ID, LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, " +
                        "LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,  " +
                        "SUM(WMI.ON_HAND_QTY - WMI.WM_ALLOCATED_QTY + WMI.TO_BE_FILLED_QTY) ALLOC_QTY  " +
                        "from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD ,RESV_LOCN_HDR RLH, ITEM_CBO ICB " +
                        "where WMI.LPN_ID = LPN.LPN_ID " +
                        "and ICB.ITEM_ID = WMI.ITEM_ID " +
                        "and ICB.ITEM_ID = LPN.ITEM_ID " +
                        "and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and WMI.INBOUND_OUTBOUND_INDICATOR = 'I' " +
                        "and WMI.ALLOCATABLE = 'Y' " +
                        "and (WMI.ON_HAND_QTY - WMI.WM_ALLOCATED_QTY + WMI.TO_BE_FILLED_QTY) > 0 " +
                        "and ICB.UNIT_VOLUME is not null and ICB.UNIT_WEIGHT is not null " +
                        "and ICB.UNIT_LENGTH IS NOT NULL and ICB.UNIT_WIDTH IS NOT NULL and ICB.UNIT_HEIGHT IS NOT NULL " +
                        "and ICB.UNIT_VOLUME <> '0.0001' and ICB.UNIT_WEIGHT <> '0.0001' " +
                        "and ICB.ITEM_BAR_CODE <> '0' " +
                        "and LPN.ITEM_NAME NOT IN (  " +
                        "and lpn.lpn_facility_status='30' " +
                        "and LPN.TC_PARENT_LPN_ID is not null  " +
                        "and RLH.INVN_LOCK_CODE is null " +
                        "and LPN.CURR_SUB_LOCN_ID in (select LOCN_ID from LOCN_HDR where LOCN_CLASS = 'R' and PULL_ZONE = 'HP1') " +
                        "and LPN.LPN_ID not in (select LPN_ID from LPN_LOCK) " +
                        "group by (LPN.TC_PARENT_LPN_ID, LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ) " +
                        "order by LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, SUM(WMI.ON_HAND_QTY) desc, LHD.LOCN_PICK_SEQ";
                arrSQL = new String[]{sql1};
                break;

            case "OB_1064NDC_PW03AT_HP_25_INT2_Full_case_NonVAS":
                String sql2 = "select LPN.TC_LPN_ID, LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1," +
                        " LHD.DSP_LOCN, WMI.ON_HAND_QTY,  WMI.INBOUND_OUTBOUND_INDICATOR, WMI.ALLOCATABLE," +
                        " (WMI.ON_HAND_QTY - WMI.WM_ALLOCATED_QTY + WMI.TO_BE_FILLED_QTY) ALLOC_QTY" +
                        " from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD ,RESV_LOCN_HDR RLH, ITEM_CBO ICB" +
                        " where WMI.LPN_ID = LPN.LPN_ID" +
                        " and ICB.ITEM_ID = WMI.ITEM_ID" +
                        " and ICB.ITEM_ID = LPN.ITEM_ID" +
                        " and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID" +
                        " and LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID" +
                        " and WMI.INBOUND_OUTBOUND_INDICATOR = 'I'" +
                        " and WMI.ALLOCATABLE = 'Y'" +
                        " and RLH.INVN_LOCK_CODE is null" +
                        " and LPN.ITEM_NAME not in ( " +
                        " and ICB.UNIT_VOLUME is not null and ICB.UNIT_WEIGHT is not null" +
                        " and ICB.UNIT_LENGTH IS NOT NULL and ICB.UNIT_WIDTH IS NOT NULL" +
                        " and ICB.UNIT_HEIGHT IS NOT NULL" +
                        " and ICB.UNIT_VOLUME <> '0.0001' and ICB.UNIT_WEIGHT <> '0.0001'" +
                        " and ICB.ITEM_BAR_CODE <> '0'" +
                        " and LPN.CURR_SUB_LOCN_ID = '0228114'" +
                        " and LPN.LPN_ID not in (select LPN_ID from LPN_LOCK)" +
                        " and (WMI.ON_HAND_QTY - WMI.WM_ALLOCATED_QTY + WMI.TO_BE_FILLED_QTY) > 0" +
                        " order by LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, WMI.ON_HAND_QTY";
                arrSQL = new String[]{sql2};
                break;

            case "OB_1064NDC_PW03AT_HP_26_INT2_Alloc_TaskCr_Full_Case_VAS":
                String sql4 = "Select aa.* " +
                        "FROM (select LPN.TC_LPN_ID, " +
                        "LPN.ITEM_NAME, " +
                        "WMI.CNTRY_OF_ORGN, " +
                        "WMI.ITEM_ATTR_1, " +
                        "LHD.DSP_LOCN, " +
                        "WMI.ON_HAND_QTY, " +
                        "WMI.INBOUND_OUTBOUND_INDICATOR, " +
                        "WMI.ALLOCATABLE, " +
                        "(WMI.ON_HAND_QTY - WMI.WM_ALLOCATED_QTY + " +
                        "WMI.TO_BE_FILLED_QTY) ALLOC_QTY " +
                        "from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, RESV_LOCN_HDR RLH " +
                        "where WMI.LPN_ID = LPN.LPN_ID " +
                        "and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and WMI.INBOUND_OUTBOUND_INDICATOR = 'I' " +
                        "and WMI.ALLOCATABLE = 'Y' " +
                        "and RLH.INVN_LOCK_CODE is null " +
                        "and LPN.CURR_SUB_LOCN_ID = '0228114' " +
                        "and LPN.ITEM_NAME not in ('307960-103-5', '307960-103-5.5', '307960-103-6.5','307960-103-7', '307960-103-10', '819959-003-5.5','819959-003-7.5') " +
                        "and not exists " +
                        "(select 1 from LPN_LOCK where lpn_id = LPN.LPN_ID) " +
                        "and exists (select 1 " +
                        "from ITEM_PACKAGE_CBO b " +
                        "where b.package_uom_id in (25, 26, 30) " +
                        "and b.mark_for_deletion = 0 " +
                        "and b.item_id = lpn.item_id " +
                        "group by b.Item_id " +
                        "having count(b.item_id) > 2)) aa " +
                        "WHERE aa.alloc_qty > 0 " +
                        "and rownum < 2";
                String sql5 = "SELECT VAS_CODE FROM C_VAS_INFO WHERE SAP_ONLY <>'1' and c_vas_lvl='2'";
                arrSQL = new String[]{sql4, sql5};
                break;

            case "OB_1064NDC_PW03AT_HP_27_INT2_Full_case_VAS_Levl":
                String sql6 = "select LPN.TC_LPN_ID, LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1," +
                        " LHD.DSP_LOCN, WMI.ON_HAND_QTY,  WMI.INBOUND_OUTBOUND_INDICATOR, WMI.ALLOCATABLE" +
                        " from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD ,RESV_LOCN_HDR RLH,ITEM_CBO ICB" +
                        " where WMI.LPN_ID = LPN.LPN_ID" +
                        " and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID" +
                        " and LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID" +
                        " and ICB.ITEM_ID = LPN.ITEM_ID" +
                        " and ICB.ITEM_ID = WMI.ITEM_ID" +
                        " and WMI.INBOUND_OUTBOUND_INDICATOR = 'I'" +
                        " and WMI.ALLOCATABLE = 'Y'" +
                        " and LPN.ITEM_NAME not in ('307960-103-8.5','310095-100-10')" +
                        " and lpn.lpn_facility_status='30'" +
                        " and RLH.INVN_LOCK_CODE is null" +
                        " and LPN.CURR_SUB_LOCN_ID = '0228114'" +
                        " and ICB.UNIT_VOLUME IS NOT NULL and ICB.UNIT_WEIGHT IS NOT NULL" +
                        " and ICB.UNIT_LENGTH IS NOT NULL and ICB.UNIT_WIDTH IS NOT NULL and ICB.UNIT_HEIGHT IS NOT NULL" +
                        " and ICB.UNIT_VOLUME <>'0.0001' and ICB.UNIT_WEIGHT <>'0.0001'" +
                        " and ICB.ITEM_BAR_CODE <>'0'" +
                        " and LPN.LPN_ID not in (select LPN_ID from LPN_LOCK)" +
                        " order by LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, WMI.ON_HAND_QTY";
                String sql7 = "SELECT VAS_CODE FROM C_VAS_INFO WHERE SAP_ONLY <>'1' and c_vas_lvl='2'";
                arrSQL = new String[]{sql6, sql7};
                break;

            case "OB_1064NDC_PW03AT_HP_38_INT2_Spec_VAS_Task_Creation_NEW":
                String sql8 = "select LPN.TC_LPN_ID, LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, " +
                        "LHD.DSP_LOCN, WMI.ON_HAND_QTY,  WMI.INBOUND_OUTBOUND_INDICATOR, WMI.ALLOCATABLE, " +
                        "(WMI.ON_HAND_QTY - WMI.WM_ALLOCATED_QTY + WMI.TO_BE_FILLED_QTY) ALLOC_QTY " +
                        "from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD ,RESV_LOCN_HDR RLH,ITEM_CBO ICB " +
                        "where WMI.LPN_ID = LPN.LPN_ID " +
                        "and ICB.ITEM_ID = LPN.ITEM_ID " +
                        "and ICB.ITEM_ID = WMI.ITEM_ID " +
                        "and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and WMI.INBOUND_OUTBOUND_INDICATOR = 'I' " +
                        "and WMI.ALLOCATABLE = 'Y' " +
                        "and LPN.ITEM_NAME not in ('307960-103-5','307960-103-5.5','307960-103-6','307960-103-6.5','307960-103-7','307960-103-7.5','307960-103-8','307960-103-8.5') " +
                        "and ICB.UNIT_VOLUME IS NOT NULL and ICB.UNIT_WEIGHT IS NOT NULL " +
                        "and ICB.UNIT_LENGTH IS NOT NULL and ICB.UNIT_WIDTH IS NOT NULL and ICB.UNIT_HEIGHT IS NOT NULL " +
                        "and ICB.UNIT_VOLUME <>'0.0001' and ICB.UNIT_WEIGHT <>'0.0001' " +
                        "and ICB.ITEM_BAR_CODE <>'0' " +
                        "and RLH.INVN_LOCK_CODE is null " +
                        "and LPN.CURR_SUB_LOCN_ID = '0228114' " +
                        "and LPN.LPN_ID not in (select LPN_ID from LPN_LOCK) " +
                        "and (WMI.ON_HAND_QTY - WMI.WM_ALLOCATED_QTY + WMI.TO_BE_FILLED_QTY) > 0 " +
                        "order by LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, WMI.ON_HAND_QTY";
                arrSQL = new String[]{sql8};
                break;

            case "OB_1064_PW03AT_HP_02_INT2_TaskCr_PROMO_Pall_Non_VAS":
                String sql9 = "select  LPN.TC_PARENT_LPN_ID, LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, " +
                        "LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,  " +
                        "SUM(WMI.ON_HAND_QTY - WMI.WM_ALLOCATED_QTY + WMI.TO_BE_FILLED_QTY) ALLOC_QTY  " +
                        "from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD ,RESV_LOCN_HDR RLH, ITEM_CBO ICB " +
                        "where WMI.LPN_ID = LPN.LPN_ID " +
                        "and ICB.ITEM_ID = WMI.ITEM_ID " +
                        "and ICB.ITEM_ID = LPN.ITEM_ID " +
                        "and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and WMI.INBOUND_OUTBOUND_INDICATOR = 'I' " +
                        "and WMI.ALLOCATABLE = 'Y' " +
                        "and (WMI.ON_HAND_QTY - WMI.WM_ALLOCATED_QTY + WMI.TO_BE_FILLED_QTY) > 0 " +
                        "and ICB.UNIT_VOLUME is not null and ICB.UNIT_WEIGHT is not null " +
                        "and ICB.UNIT_LENGTH IS NOT NULL and ICB.UNIT_WIDTH IS NOT NULL and ICB.UNIT_HEIGHT IS NOT NULL " +
                        "and ICB.UNIT_VOLUME <> '0.0001' and ICB.UNIT_WEIGHT <> '0.0001' " +
                        "and ICB.ITEM_BAR_CODE <> '0' " +
                        //"and LPN.ITEM_NAME not in ('455656-110-17') "+
                        "and lpn.lpn_facility_status='30' " +
                        "and LPN.TC_PARENT_LPN_ID is not null  " +
                        "and RLH.INVN_LOCK_CODE is null " +
                        "and LPN.CURR_SUB_LOCN_ID in (select LOCN_ID from LOCN_HDR where LOCN_CLASS = 'R' and PULL_ZONE = 'HP2') " +
                        "and LPN.LPN_ID not in (select LPN_ID from LPN_LOCK) " +
                        "group by (LPN.TC_PARENT_LPN_ID, LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ) " +
                        "order by LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, SUM(WMI.ON_HAND_QTY) desc, LHD.LOCN_PICK_SEQ";
                arrSQL = new String[]{sql9};
                break;

            case "OB_1064_PW03AT_HP_03_INT2_TaskCr_CartonEquip_Non_VAS":
            case "OB_1064_PW03AT_HP_04_INT2_Alloc_TaskCr_PROMO_carton_Non_VAS":
                String sql10 = "select  LPN.TC_PARENT_LPN_ID, LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, " +
                        "LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,  " +
                        "SUM(WMI.ON_HAND_QTY - WMI.WM_ALLOCATED_QTY + WMI.TO_BE_FILLED_QTY) ALLOC_QTY  " +
                        "from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD ,RESV_LOCN_HDR RLH, ITEM_CBO ICB " +
                        "where WMI.LPN_ID = LPN.LPN_ID " +
                        "and ICB.ITEM_ID = WMI.ITEM_ID " +
                        "and ICB.ITEM_ID = LPN.ITEM_ID " +
                        "and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and WMI.INBOUND_OUTBOUND_INDICATOR = 'I' " +
                        "and WMI.ALLOCATABLE = 'Y' " +
                        "and (WMI.ON_HAND_QTY - WMI.WM_ALLOCATED_QTY + WMI.TO_BE_FILLED_QTY) > 0 " +
                        "and ICB.UNIT_VOLUME is not null and ICB.UNIT_WEIGHT is not null " +
                        "and ICB.UNIT_LENGTH IS NOT NULL and ICB.UNIT_WIDTH IS NOT NULL and ICB.UNIT_HEIGHT IS NOT NULL " +
                        "and ICB.UNIT_VOLUME <> '0.0001' and ICB.UNIT_WEIGHT <> '0.0001' " +
                        "and ICB.ITEM_BAR_CODE <> '0' " +
                        "and lpn.lpn_facility_status='30' " +
                        "and LPN.TC_PARENT_LPN_ID is not null  " +
                        "and RLH.INVN_LOCK_CODE is null " +
                        "and LPN.CURR_SUB_LOCN_ID in (select LOCN_ID from LOCN_HDR where LOCN_CLASS = 'R' and PULL_ZONE in ('HC1','HG1')) " +
                        "and LPN.LPN_ID not in (select LPN_ID from LPN_LOCK) " +
                        "group by (LPN.TC_PARENT_LPN_ID, LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ) " +
                        "order by LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, SUM(WMI.ON_HAND_QTY) desc, LHD.LOCN_PICK_SEQ";
                arrSQL = new String[]{sql10};
                break;

            case "OB_1064_PW03AT_HP_05_INT2_Alloc_TaskCr_Pall_Equip_VAS":
                String sql11 = "select  LPN.TC_PARENT_LPN_ID, LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, " +
                        "LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,  " +
                        "SUM(WMI.ON_HAND_QTY - WMI.WM_ALLOCATED_QTY + WMI.TO_BE_FILLED_QTY) ALLOC_QTY  " +
                        "from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD ,RESV_LOCN_HDR RLH, ITEM_CBO ICB " +
                        "where WMI.LPN_ID = LPN.LPN_ID " +
                        "and ICB.ITEM_ID = WMI.ITEM_ID " +
                        "and ICB.ITEM_ID = LPN.ITEM_ID " +
                        "and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and WMI.INBOUND_OUTBOUND_INDICATOR = 'I' " +
                        "and WMI.ALLOCATABLE = 'Y' " +
                        "and (WMI.ON_HAND_QTY - WMI.WM_ALLOCATED_QTY + WMI.TO_BE_FILLED_QTY) > 0 " +
                        "and ICB.UNIT_VOLUME is not null and ICB.UNIT_WEIGHT is not null " +
                        "and ICB.UNIT_LENGTH IS NOT NULL and ICB.UNIT_WIDTH IS NOT NULL and ICB.UNIT_HEIGHT IS NOT NULL " +
                        "and ICB.UNIT_VOLUME <> '0.0001' and ICB.UNIT_WEIGHT <> '0.0001' " +
                        "and ICB.ITEM_BAR_CODE <> '0' " +
                        "and LPN.ITEM_NAME not in ('BA4832-702-MISC') " +
                        "and lpn.lpn_facility_status='30' " +
                        "and LPN.TC_PARENT_LPN_ID is not null  " +
                        "and RLH.INVN_LOCK_CODE is null " +
                        "and LPN.CURR_SUB_LOCN_ID in (select LOCN_ID from LOCN_HDR where LOCN_CLASS = 'R' and PULL_ZONE = 'HP1') " +
                        "and LPN.LPN_ID not in (select LPN_ID from LPN_LOCK) " +
                        "group by (LPN.TC_PARENT_LPN_ID, LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ) " +
                        "order by LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, SUM(WMI.ON_HAND_QTY) desc, LHD.LOCN_PICK_SEQ";
                String sql22 = "SELECT VAS_CODE FROM C_VAS_INFO WHERE SAP_ONLY <>'1' and c_vas_lvl='3'";
                arrSQL = new String[]{sql11, sql22};
                break;

            case "OB_1064_PW03AT_HP_06_INT2_Alloc_TaskCr_PROMO_Pall_VAS":
                String sql12 = "select  LPN.TC_PARENT_LPN_ID, LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, " +
                        "LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,  " +
                        "SUM(WMI.ON_HAND_QTY - WMI.WM_ALLOCATED_QTY + WMI.TO_BE_FILLED_QTY) ALLOC_QTY  " +
                        "from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD ,RESV_LOCN_HDR RLH, ITEM_CBO ICB " +
                        "where WMI.LPN_ID = LPN.LPN_ID " +
                        "and ICB.ITEM_ID = WMI.ITEM_ID " +
                        "and ICB.ITEM_ID = LPN.ITEM_ID " +
                        "and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and WMI.INBOUND_OUTBOUND_INDICATOR = 'I' " +
                        "and WMI.ALLOCATABLE = 'Y' " +
                        "and (WMI.ON_HAND_QTY - WMI.WM_ALLOCATED_QTY + WMI.TO_BE_FILLED_QTY) > 0 " +
                        "and ICB.UNIT_VOLUME is not null and ICB.UNIT_WEIGHT is not null " +
                        "and ICB.UNIT_LENGTH IS NOT NULL and ICB.UNIT_WIDTH IS NOT NULL and ICB.UNIT_HEIGHT IS NOT NULL " +
                        "and ICB.UNIT_VOLUME <> '0.0001' and ICB.UNIT_WEIGHT <> '0.0001' " +
                        "and ICB.ITEM_BAR_CODE <> '0' " +
                        "and lpn.lpn_facility_status='30' " +
                        "and LPN.ITEM_NAME not in ('455656-110-17') " +
                        "and LPN.TC_PARENT_LPN_ID is not null  " +
                        "and RLH.INVN_LOCK_CODE is null " +
                        "and LPN.CURR_SUB_LOCN_ID in (select LOCN_ID from LOCN_HDR where LOCN_CLASS = 'R' and PULL_ZONE = 'HP2') " +
                        "and LPN.LPN_ID not in (select LPN_ID from LPN_LOCK) " +
                        "group by (LPN.TC_PARENT_LPN_ID, LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ) " +
                        "order by LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, SUM(WMI.ON_HAND_QTY) desc, LHD.LOCN_PICK_SEQ";
                String sql13 = "SELECT VAS_CODE FROM C_VAS_INFO WHERE SAP_ONLY <>'1' and c_vas_lvl='2'";
                arrSQL = new String[]{sql12, sql13};
                break;

            case "OB_1064_PW03AT_HP_07_INT2_Alloc_TaskCr_Carton_Equip_VAS":
                String sql14 = "select  LPN.TC_PARENT_LPN_ID, LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, " +
                        "LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,  " +
                        "SUM(WMI.ON_HAND_QTY - WMI.WM_ALLOCATED_QTY + WMI.TO_BE_FILLED_QTY) ALLOC_QTY  " +
                        "from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD ,RESV_LOCN_HDR RLH, ITEM_CBO ICB " +
                        "where WMI.LPN_ID = LPN.LPN_ID " +
                        "and ICB.ITEM_ID = WMI.ITEM_ID " +
                        "and ICB.ITEM_ID = LPN.ITEM_ID " +
                        "and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and WMI.INBOUND_OUTBOUND_INDICATOR = 'I' " +
                        "and WMI.ALLOCATABLE = 'Y' " +
                        "and (WMI.ON_HAND_QTY - WMI.WM_ALLOCATED_QTY + WMI.TO_BE_FILLED_QTY) > 0 " +
                        "and ICB.UNIT_VOLUME is not null and ICB.UNIT_WEIGHT is not null " +
                        "and ICB.UNIT_LENGTH IS NOT NULL and ICB.UNIT_WIDTH IS NOT NULL and ICB.UNIT_HEIGHT IS NOT NULL " +
                        "and ICB.UNIT_VOLUME <> '0.0001' and ICB.UNIT_WEIGHT <> '0.0001' " +
                        "and ICB.ITEM_BAR_CODE <> '0' " +
                        "and lpn.lpn_facility_status='30' " +
                        "and LPN.ITEM_NAME not in ('SC2356-100-3') " +
                        "and LPN.TC_PARENT_LPN_ID is not null  " +
                        "and RLH.INVN_LOCK_CODE is null " +
                        "and LPN.CURR_SUB_LOCN_ID in (select LOCN_ID from LOCN_HDR where LOCN_CLASS = 'R' and PULL_ZONE in ('HC1','HG1')) " +
                        "and LPN.LPN_ID not in (select LPN_ID from LPN_LOCK) " +
                        "group by (LPN.TC_PARENT_LPN_ID, LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ) " +
                        "order by LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, SUM(WMI.ON_HAND_QTY) desc, LHD.LOCN_PICK_SEQ";
                String sql15 = "SELECT VAS_CODE FROM C_VAS_INFO WHERE SAP_ONLY <>'1' and c_vas_lvl='2'";
                arrSQL = new String[]{sql14, sql15};
                break;

            case "OB_1064_PW03AT_HP_09_INT2_Alloc_TaskCr_PROMO_carton_VAS":
                String sql16 = "select  LHD.PULL_ZONE, LPN.TC_PARENT_LPN_ID, LPN.TC_LPN_ID, LPN.ITEM_NAME, " +
                        "WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ, WMI.ON_HAND_QTY QTY " +
                        "from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD ,RESV_LOCN_HDR RLH, ITEM_CBO ICB  " +
                        "where WMI.LPN_ID = LPN.LPN_ID " +
                        "and ICB.ITEM_ID = WMI.ITEM_ID " +
                        "and ICB.ITEM_ID = LPN.ITEM_ID " +
                        "and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and WMI.INBOUND_OUTBOUND_INDICATOR = 'I' " +
                        "and WMI.ALLOCATABLE = 'Y' " +
                        "and ICB.UNIT_VOLUME is not null and ICB.UNIT_WEIGHT is not null " +
                        "and ICB.UNIT_LENGTH IS NOT NULL and ICB.UNIT_WIDTH IS NOT NULL and ICB.UNIT_HEIGHT IS NOT NULL " +
                        "and ICB.UNIT_VOLUME <> '0.0001' and ICB.UNIT_WEIGHT <> '0.0001' " +
                        "and ICB.ITEM_BAR_CODE <> '0' " +
                        "and lpn.lpn_facility_status='30' " +
                        "and RLH.INVN_LOCK_CODE is null " +
                        "and LPN.CURR_SUB_LOCN_ID in (select LOCN_ID from LOCN_HDR where LOCN_CLASS = 'R' and " +
                        "PULL_ZONE in ('HG2','HP2')) " +
                        "and LPN.LPN_ID not in (select LPN_ID from LPN_LOCK) " +
                        "order by LHD.PULL_ZONE, LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1,WMI.ON_HAND_QTY desc, " +
                        "LHD.LOCN_PICK_SEQ";
                String sql17 = "SELECT VAS_CODE FROM C_VAS_INFO WHERE SAP_ONLY <>'1' and c_vas_lvl='2'";
                arrSQL = new String[]{sql16, sql17};
                break;

            case "OB_1064_PW03AT_HP_08_INT2_Alloc_TaskCr_Minimize_pulls":
                String sql18 = "select  aa.*     " +
                        " from (SELECT LHD.PULL_ZONE, LPN.TC_PARENT_LPN_ID, LPN.TC_LPN_ID, LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,      " +
                        " (WMI.ON_HAND_QTY - WMI.WM_ALLOCATED_QTY + WMI.TO_BE_FILLED_QTY) ALLOC_QTY      " +
                        " from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD ,RESV_LOCN_HDR RLH     " +
                        " where WMI.LPN_ID = LPN.LPN_ID     " +
                        " and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID     " +
                        " and LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID     " +
                        " and WMI.INBOUND_OUTBOUND_INDICATOR = 'I'     " +
                        " and WMI.ALLOCATABLE = 'Y'     " +
                        " and lpn.lpn_facility_status='30'     " +
                        " and RLH.INVN_LOCK_CODE is null     " +
                        " and exists (select 1 from LOCN_HDR LH where LH.LOCN_CLASS = 'R' and LH.PULL_ZONE = 'HC1'     " +
                        " and LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID)     " +
                        " and  not exists (select LPN_ID from LPN_LOCK where lpn_id=LPN.LPN_ID)     " +
                        " and exists (select 1     " +
                        " from ITEM_PACKAGE_CBO b     " +
                        " where b.package_uom_id in (25, 26, 30)     " +
                        " and b.mark_for_deletion = 0     " +
                        " and b.item_id = lpn.item_id     " +
                        " group by b.Item_id     " +
                        " having count(b.item_id) > 2) )aa     " +
                        " WHERE aa.alloc_qty >0     " +
                        " ORDER BY  AA.PULL_ZONE, AA.ITEM_NAME, AA.CNTRY_OF_ORGN, AA.ITEM_ATTR_1, AA.ALLOC_QTY  desc, AA.LOCN_PICK_SEQ";
                arrSQL = new String[]{sql18};
                break;

            case "OB_1064_PW03AT_HP_03_INT2_TaskCr_CartonEquip_Non_VAS_Multiple_Detail_lines_Valid_PG_NEW":
                String sql20 = "select LHD.PULL_ZONE, " +
                        "LPN.TC_PARENT_LPN_ID, " +
                        "LPN.TC_LPN_ID, " +
                        "LPN.ITEM_NAME, " +
                        "WMI.CNTRY_OF_ORGN, " +
                        "WMI.ITEM_ATTR_1, " +
                        "LHD.DSP_LOCN, " +
                        "LHD.LOCN_PICK_SEQ, " +
                        "(WMI.ON_HAND_QTY - WMI.WM_ALLOCATED_QTY + WMI.TO_BE_FILLED_QTY) ALLOC_QTY " +
                        "from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, RESV_LOCN_HDR RLH " +
                        "where WMI.LPN_ID = LPN.LPN_ID " +
                        "and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and WMI.INBOUND_OUTBOUND_INDICATOR = 'I' " +
                        "and WMI.ALLOCATABLE = 'Y' " +
                        "and lpn.lpn_facility_status = '30' " +
                        "and RLH.INVN_LOCK_CODE is null " +
                        "and EXISTS  " +
                        "(select 1  LOCN_ID " +
                        "from LOCN_HDR LH " +
                        "where LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and LH.LOCN_CLASS = 'R' " +
                        "and PULL_ZONE in ('HC1', 'HG1')) " +
                        "AND EXISTS (SELECT 1 FROM  ITEM_CBO ICB  " +
                        "WHERE ICB.ITEM_ID = LPN.ITEM_ID " +
                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001  " +
                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001 " +
                        "AND ICB.ITEM_BAR_CODE <>'0' ) " +
                        "and not exists " +
                        "(select 1 from LPN_LOCK where lpn_id = LPN.LPN_ID) " +
                        "and (WMI.ON_HAND_QTY - WMI.WM_ALLOCATED_QTY + WMI.TO_BE_FILLED_QTY) > 0 " +
                        "order by LHD.PULL_ZONE, " +
                        "LPN.ITEM_NAME, " +
                        "WMI.CNTRY_OF_ORGN, " +
                        "WMI.ITEM_ATTR_1, " +
                        "WMI.ON_HAND_QTY desc, " +
                        "LHD.LOCN_PICK_SEQ";

                String sql21 = "SELECT FACILITY_ALIAS_ID as customer,FAC.COUNTRY_CODE FROM FACILITY_ALIAS FA,FACILITY FAC " +
                        "WHERE FA.FACILITY_ID=FAC.FACILITY_ID " +
                        "AND FA.FACILITY_ALIAS_ID IN(SELECT OTMP.TC_ORDER_ID FROM ORDER_NOTE_TEMPLATE ONT,ORDERS_TEMPLATE OTMP  " +
                        "WHERE OTMP.ORDER_ID = ONT.ORDER_ID AND NOTE_TYPE='PG' AND NOTE='CO' ) " +
                        "AND FA.FACILITY_ALIAS_ID IN(SELECT OTMP.TC_ORDER_ID FROM ORDER_NOTE_TEMPLATE ONT,ORDERS_TEMPLATE OTMP  " +
                        "WHERE OTMP.ORDER_ID = ONT.ORDER_ID AND NOTE_TYPE='GF' AND NOTE='Y' ) " +
                        "AND FAC. FACILITY_TYPE_BITS='64' " +
                        "AND FA.FACILITY_ID NOT IN (SELECT FACILITY_ID FROM FACILITY_NOTE WHERE FACILITY_NOTE_TYPE='2' AND NOTE='1') " +
                        "AND FAC.COUNTRY_CODE IN(SELECT COUNTRY_CODE FROM COUNTRY WHERE CNTRY_ID IS NULL)";
                arrSQL = new String[]{sql20, sql21};
                break;

            case "OB_1064_PW03AT_HP_03_INT2_TaskCr_CartonEquip_Non_VAS_Multiple_Detail_lines_NEW":
                String sql23 = "select LHD.PULL_ZONE, " +
                        " LPN.TC_PARENT_LPN_ID, " +
                        " LPN.TC_LPN_ID, " +
                        " LPN.ITEM_NAME, " +
                        " WMI.CNTRY_OF_ORGN, " +
                        " WMI.ITEM_ATTR_1, " +
                        " LHD.DSP_LOCN, " +
                        " LHD.LOCN_PICK_SEQ, " +
                        " (WMI.ON_HAND_QTY - WMI.WM_ALLOCATED_QTY + WMI.TO_BE_FILLED_QTY) ALLOC_QTY " +
                        " from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, RESV_LOCN_HDR RLH " +
                        " where WMI.LPN_ID = LPN.LPN_ID " +
                        " and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        " and LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        " and WMI.INBOUND_OUTBOUND_INDICATOR = 'I' " +
                        " and WMI.ALLOCATABLE = 'Y' " +
                        " and lpn.lpn_facility_status = '30' " +
                        " and RLH.INVN_LOCK_CODE is null " +
                        " and exists (select 1 from LOCN_HDR LH where LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND " +
                        " LH.LOCN_CLASS = 'R' and LH.PULL_ZONE in ('HC1','HG1')) " +
                        " AND EXISTS (SELECT 1 FROM  ITEM_CBO ICB  " +
                        " WHERE ICB.ITEM_ID = LPN.ITEM_ID " +
                        " AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001  " +
                        " AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001 " +
                        " AND ICB.ITEM_BAR_CODE <>'0' ) " +
                        " and not exists " +
                        " (select 1 from LPN_LOCK where lpn_id = LPN.LPN_ID) --added by AD on 7-SEP-2016 " +
                        " and (WMI.ON_HAND_QTY - WMI.WM_ALLOCATED_QTY + WMI.TO_BE_FILLED_QTY) > 0 --added by AD on 7-SEP-2016 " +
                        " order by LHD.PULL_ZONE, " +
                        " LPN.ITEM_NAME, " +
                        " WMI.CNTRY_OF_ORGN, " +
                        " WMI.ITEM_ATTR_1, " +
                        " WMI.ON_HAND_QTY desc, " +
                        " LHD.LOCN_PICK_SEQ";
                arrSQL = new String[]{sql23};
                break;

            case "OB_1064_PW03AT_HP_03_INT2_Task_Carton_Substitution_Non_VAS_NEW":
                String sql24 = "with aa as (select  LHD.PULL_ZONE, LPN.TC_PARENT_LPN_ID,  LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, " +
                        "WMI.ITEM_ATTR_1, LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,  " +
                        "min(WMI.ON_HAND_QTY - WMI.WM_ALLOCATED_QTY + WMI.TO_BE_FILLED_QTY) ALLOC_QTY " +
                        ", count(LPN.TC_LPN_ID)  " +
                        "from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD ,RESV_LOCN_HDR RLH " +
                        "where WMI.LPN_ID = LPN.LPN_ID " +
                        "and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and WMI.INBOUND_OUTBOUND_INDICATOR = 'I' " +
                        "and WMI.ALLOCATABLE = 'Y' " +
                        "and lpn.lpn_facility_status = '30' " +
                        "and RLH.INVN_LOCK_CODE is null " +
                        "AND EXISTS (SELECT 1 FROM  ITEM_CBO ICB  " +
                        "WHERE ICB.ITEM_ID = LPN.ITEM_ID " +
                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001  " +
                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001 " +
                        "AND ICB.ITEM_BAR_CODE <>'0' ) " +
                        "and exists (select 1 from LOCN_HDR LH where LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID  " +
                        "AND LH.LOCN_CLASS = 'R' and LH.PULL_ZONE in ('HC1','HG1')) " +
                        "and NOT EXISTS  (select 1 from LPN_LOCK L WHERE L.LPN_ID = LPN.LPN_ID) " +
                        "and TC_PARENT_LPN_ID is not null " +
                        "group by LHD.PULL_ZONE, LPN.TC_PARENT_LPN_ID,LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, " +
                        "LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ " +
                        ") " +
                        "Select * from aa where ALLOC_QTY > 0";
                arrSQL = new String[]{sql24};
                break;


        }
        return arrSQL;
    }
}