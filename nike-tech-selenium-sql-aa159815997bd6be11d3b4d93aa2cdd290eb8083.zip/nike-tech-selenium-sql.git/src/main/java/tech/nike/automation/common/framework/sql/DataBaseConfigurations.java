package tech.nike.automation.common.framework.sql;

/**
 * Created by PSibb1 on 8/15/2016.
 */
public class DataBaseConfigurations {

    public String[] getDatabaseConnection(String strSite) {
        String[] arrConnections = {};
        switch (strSite) {
            case "NALC-ER":
                // Database NALC URL
                String NALC_ER_DB_URL = "jdbc:oracle:thin:@wt1014rd.cfjm42ijcp90.us-west-2.rds.amazonaws.com:1521:WT1014RD";
                // Database NALC credentials
                String NALC_ER_USER = "nikewm1014er";
                String NALC_ER_PASS = "nikewm1014er";
                arrConnections = new String[]{NALC_ER_USER, NALC_ER_PASS, NALC_ER_DB_URL};
                break;
            case "HTLS-ER":
                // Database HLTS URL
                String HLTS_ER_DB_URL = "jdbc:oracle:thin:@nke-lnx-wms-d054.nike.com:1521:wm1064er";

                // Database HTLS credentials
                String HLTS_ER_USER = "NIKEWM1064ER";
                String HLTS_ER_PASS = "NIKEWM1064ER";
                arrConnections = new String[]{HLTS_ER_USER, HLTS_ER_PASS, HLTS_ER_DB_URL};
                break;
            case "HAM-ER":
                // Database HLTS URL
                String HAM_ER_DB_URL = "jdbc:oracle:thin:@nke-lnx-wms-d067.nike.com:1521:W10642ER";

                // Database HTLS credentials
                String HAM_ER_USER = "NIKEWM10642ER";
                String HAM_ER_PASS = "NIKEWM10642ER";
                arrConnections = new String[]{HAM_ER_USER, HAM_ER_PASS, HAM_ER_DB_URL};
                break;
            case "HAM-AT":
                // Database HLTS URL
                String HAM_AT_DB_URL = "jdbc:oracle:thin:@nke-lnx-dbt-x103:1521:wm1014x3";

                // Database HTLS credentials
                String HAM_AT_USER = "NIKEWM10642X3";
                String HAM_AT_PASS = "NIKEWM10642X3";
                arrConnections = new String[]{HAM_AT_USER, HAM_AT_PASS, HAM_AT_DB_URL};
                break;
            case "HTLS-AT":
                // Database HLTS URL
                String HLTS_AT_DB_URL = "jdbc:oracle:thin:@nke-lnx-dbt-x103:1521:wm1014x2";

                // Database HTLS credentials
                String HLTS_AT_USER = "NIKEWM1064AT";
                String HLTS_AT_PASS = "NIKEWM1064AT";
                arrConnections = new String[]{HLTS_AT_USER, HLTS_AT_PASS, HLTS_AT_DB_URL};
                break;
        }
        return arrConnections;
    }
}