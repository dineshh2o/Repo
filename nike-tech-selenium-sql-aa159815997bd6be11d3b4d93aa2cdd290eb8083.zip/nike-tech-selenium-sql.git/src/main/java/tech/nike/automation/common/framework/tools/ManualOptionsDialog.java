package tech.nike.automation.common.framework.tools;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.util.HashMap;
import java.util.Map;

/**
 * Wrapper close to raise a awt Dialog that will prompt for a set of text values.
 * <p>
 * Mainly designed to enable quick manual testing of a configurable set of test code.
 * <p>
 * See ManualStaticBrowserTest in the nike-selenium function test suite for an example.
 *
 * @author jle114
 */
public class ManualOptionsDialog {

    private static Object lock = new Object();
    private final JFrame guiFrame = new JFrame("Manual Test Executor");

    private Map<String, String> options;
    private boolean doTest = false;

    /**
     * Construct a ManualOptionsDialog by giving it a list of options to prompt for.
     *
     * @param options Map of options, with option default values
     */
    public ManualOptionsDialog(Map<String, String> options) {
        this.options = new HashMap<String, String>(options);
    }

    /**
     * Shows a dialog with room for all the options specified in the constructor.
     * <p>
     * Blockes till the dialog is closed.
     *
     * @return true if [Test] was clicked, else false
     */
    public boolean show() {
        // Just hide on close, we will handle how to exit.
        guiFrame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        // Setup GridBagLayout
        guiFrame.setLayout(new GridBagLayout());
        // Pick a size for the dialog...  
        // TODO: Make this dynamic based on options
        guiFrame.setSize(300, 250);

        //This will center the JFrame in the middle of the screen
        guiFrame.setLocationRelativeTo(null);

        // Make the dynamically sized option panel
        final JPanel comboPanel = new JPanel(new GridBagLayout());
        int optionsCount = 0;
        // Go through the options and create a JLabel and JTextField for each
        for (Map.Entry<String, String> option : options.entrySet()) {
            JLabel optionLbl = new JLabel(option.getKey() + ":");
            JTextField optionText = new JTextField(option.getValue(), 30);
            optionText.setName(option.getKey());

            comboPanel.add(optionLbl, new GridBagConstraints(
                    0, optionsCount,
                    1, 1,
                    0, 0,
                    GridBagConstraints.EAST,
                    GridBagConstraints.NONE,
                    new Insets(0, 10, 0, 0),
                    0, 0
            ));
            comboPanel.add(optionText, new GridBagConstraints(
                    1, optionsCount,
                    5, 1,
                    10, 00,
                    GridBagConstraints.WEST,
                    GridBagConstraints.HORIZONTAL,
                    new Insets(0, 5, 0, 10),
                    0, 0
            ));
            optionsCount++;
        }

        // Make the Test/Cancel buttons
        JButton test = new JButton("Test");
        JButton cancel = new JButton("Cancel");

        // Register a listener for the Test button to save the options values, set doTest true and hide the frame
        test.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                for (Component component : comboPanel.getComponents()) {
                    if (component instanceof JTextField) {
                        JTextField textField = ((JTextField) component);
                        options.put(textField.getName(), textField.getText());
                    }
                }
                doTest = true;
                guiFrame.setVisible(false);
            }
        });

        // Register a listener for the Cancel button, to hide the frame and set doTest to false
        cancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                guiFrame.setVisible(false);
            }
        });

        // Put the comboPanel with the options on the frame
        // Sized so it takes up the entire top portion of the frame
        guiFrame.add(comboPanel, new GridBagConstraints(
                0, 0,
                4, optionsCount,
                10, 10,
                GridBagConstraints.NORTH,
                GridBagConstraints.BOTH,
                new Insets(0, 0, 0, 0),
                0, 0
        ));
        // Put the test/cancel buttons on the frame
        // Positioned to the bottom right
        guiFrame.add(test, new GridBagConstraints(
                2, optionsCount,
                1, 1,
                10, 0,
                GridBagConstraints.EAST,
                GridBagConstraints.NONE,
                new Insets(0, 0, 0, 0),
                0, 0
        ));
        guiFrame.add(cancel, new GridBagConstraints(
                3, optionsCount,
                1, 1,
                0, 0,
                GridBagConstraints.EAST,
                GridBagConstraints.NONE,
                new Insets(0, 0, 0, 0),
                0, 0
        ));

        // Listen for the hide event, so we can let the blocking code below, unblock
        guiFrame.addComponentListener(new ComponentAdapter() {
            public void componentHidden(ComponentEvent e) {
                synchronized (lock) {
                    lock.notify();
                }
            }
        });

        // Show the JFrame
        guiFrame.setVisible(true);

        // Now wait for it to exit, by waiting on the lock (see addComponentListener above)
        synchronized (lock) {
            while (guiFrame.isVisible())
                try {
                    lock.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
        }

        // Return the result of test/cancel buttons
        return doTest;
    }

    /**
     * Check if you should run the tests.
     *
     * @return true if [test] button clicked, false otherwise.
     */
    public boolean shouldDoTest() {
        return doTest;
    }

    /**
     * Get the value of an option
     *
     * @param name Name of option
     * @return final value of option
     */
    public String getOption(String name) {
        return options.get(name);
    }
}
