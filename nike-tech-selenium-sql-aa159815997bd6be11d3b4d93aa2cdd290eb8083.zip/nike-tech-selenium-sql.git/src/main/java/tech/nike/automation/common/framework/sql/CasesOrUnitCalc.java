package tech.nike.automation.common.framework.sql;

/**
 * Created by psibb1 on 8/31/2016.
 */
public class CasesOrUnitCalc {
    public static String[] getQuery(String strTestCaseName) {
        String[] arrSQL = {};
        switch (strTestCaseName) {
            case "OB_1064NDC_PW04MISC_HP_05_MAX_CASES_Calculation":
            case "OB_1064NDC_PW04MISC_HP_04_LC_3D_Items_Units_Calculation":
                String sql1 = "SELECT ICBO.ITEM_NAME, IWMS.SPL_INSTR_1 " +
                        "FROM ITEM_CBO ICBO, ITEM_WMS IWMS  " +
                        "WHERE IWMS.ITEM_ID = ICBO.ITEM_ID " +
                        "AND ((ICBO.UNIT_VOLUME IS NULL AND ICBO.UNIT_WEIGHT IS  NULL) " +
                        "OR (ICBO.UNIT_VOLUME <>'0.0001' AND ICBO.UNIT_WEIGHT <>'0.0001')) " +
                        "AND ICBO.ITEM_BAR_CODE <>'0' " +
                        "AND ICBO.ITEM_NAME NOT IN ('537384-007-12','537384-007-14','537384-007-15','537384-007-6.5') "+
                        "AND ICBO.MARK_FOR_DELETION <> '1' " +
                        "AND IWMS.SPL_INSTR_1 = '3D'";
                arrSQL = new String[]{sql1};
                break;

            case "OB_1064NDC_PW04MISC_HP_02_LC_FY_Items_Units_Calculation":
                String sql2 = "SELECT ICBO.ITEM_NAME, IWMS.SPL_INSTR_1  " +
                        "FROM ITEM_CBO ICBO, ITEM_WMS IWMS   " +
                        "WHERE IWMS.ITEM_ID = ICBO.ITEM_ID  " +
                        "AND ((ICBO.UNIT_VOLUME IS NULL AND ICBO.UNIT_WEIGHT IS  NULL) " +
                        "OR (ICBO.UNIT_VOLUME <>'0.0001' AND ICBO.UNIT_WEIGHT <>'0.0001'))  " +
                        "AND ICBO.ITEM_BAR_CODE <>'0'  " +
                        "AND ICBO.ITEM_NAME NOT IN ('644451-063-11.5','644451-100-11.5') "+
                        "AND ICBO.MARK_FOR_DELETION <> '1'  " +
                        "AND IWMS.SPL_INSTR_1 = 'FY'";
                arrSQL = new String[]{sql2};
                break;

            case "OB_1064NDC_PW04MISC_HP_01_LC_FN_Items_Units_Calculation":
                String sql3="SELECT ICBO.ITEM_NAME, IWMS.SPL_INSTR_1 " +
                        "FROM ITEM_CBO ICBO, ITEM_WMS IWMS  " +
                        "WHERE IWMS.ITEM_ID = ICBO.ITEM_ID " +
                        "AND ((ICBO.UNIT_VOLUME IS NULL AND ICBO.UNIT_WEIGHT IS  NULL) " +
                        "OR (ICBO.UNIT_VOLUME <>'0.0001' AND ICBO.UNIT_WEIGHT <>'0.0001')) " +
                        "AND ICBO.ITEM_BAR_CODE <>'0' " +
                        "AND ICBO.MARK_FOR_DELETION <> '1' " +
                        "AND IWMS.SPL_INSTR_1 = 'FN'";
                arrSQL = new String[]{sql3};
                break;

            case "OB_1064NDC_PW03AT_HP_40_Task_Creation_for_UPDF_Shipvia_NEW":
                String sql4="select LHDP.DSP_LOCN, LHDP.SKU_DEDCTN_TYPE, ICB.ITEM_NAME, " +
                        "(WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) as ALLOCATABLE_QTY, " +
                        "PLD.MAX_INVN_QTY,icb.unit_volume,icb.unit_weight,    " +
                        "pld.min_invn_qty, pld.cntry_of_orgn, pld.sku_attr_1,wmi.ITEM_ATTR_1  " +
                        "from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi    " +
                        "where     " +
                        "lhdp.locn_id = plh.locn_id     " +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id    " +
                        "and pld.item_id = icb.item_id    " +
                        "and WMI.LOCATION_ID = PLH.LOCN_ID    " +
                        "and LHDP.LOCN_CLASS = 'C'    " +
                        "and lhdp.sku_dedctn_type = 'P'    " +
                        "and ICB.ITEM_BAR_CODE <>'0'    " +
                        "and ICB.ITEM_NAME not in ('883819-002-8.5')  "+
                        "and plh.invn_lock_code is null    " +
                        "and wmi.on_hand_qty <>'0'    " +
                        "and icb.item_id not in (select item_id from item_package_cbo where package_uom_id='26')    " +
                        "AND ICB.UNIT_VOLUME IS NOT NULL AND ICB.UNIT_WEIGHT IS NOT NULL  " +
                        "AND ICB.UNIT_LENGTH IS NOT NULL AND ICB.UNIT_WIDTH IS NOT NULL AND ICB.UNIT_HEIGHT IS NOT NULL    " +
                        "and icb.unit_volume <>'0.0001' and icb.unit_weight <>'0.0001'    " +
                        "and ICB.ITEM_BAR_CODE <>'0'    " +
                        "order by icb.unit_volume,icb.unit_weight";
                arrSQL = new String[]{sql4};
                break;

            case "OB_1064_PW03AT_HP_24_Full_case_alloc_from_case_resv":
                String sql5="select LPN.TC_PARENT_LPN_ID, " +
                        "       LPN.TC_LPN_ID, " +
                        "       LPN.ITEM_NAME, " +
                        "       WMI.CNTRY_OF_ORGN, " +
                        "       WMI.ITEM_ATTR_1, " +
                        "       LHD.PULL_ZONE, " +
                        "       LHD.DSP_LOCN, " +
                        "       LHD.LOCN_PICK_SEQ, " +
                        "       WMI.ON_HAND_QTY QTY " +
                        "  from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, RESV_LOCN_HDR RLH " +
                        " where WMI.LPN_ID = LPN.LPN_ID " +
                        "   and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "   and lhd.locn_id = lpn.curr_sub_locn_id " +
                        "   and WMI.INBOUND_OUTBOUND_INDICATOR = 'I' " +
                        "   and wmi.allocatable = 'Y' " +
                        "   and RLH.INVN_LOCK_CODE is null " +
                        "   and exists " +
                        "       (select 1 " +
                        "          from LOCN_HDR " +
                        "         where LOCN_CLASS = 'R' " +
                        "           and PULL_ZONE in ('HC1', 'HP1') " +
                        "           and LOCN_id=LPN.CURR_SUB_LOCN_ID) " +
                        "   and  not exists  (select 1 from LPN_LOCK WHERE LPN_ID=LPN.LPN_ID) " +
                        "   and  exists " +
                        "       (select 1 " +
                        "          from ITEM_CBO " +
                        "         where ITEM_ID in (select ITEM_ID " +
                        "                             from ITEM_FACILITY_MAPPING_WMS " +
                        "                            where SLOT_MISC_2 = 'Y') " +
                        "           and ITEM_BAR_CODE <> '0' " +
                        "           and ITEM_NAME=LPN.ITEM_NAME " +
                        "           and (UNIT_VOLUME is not null or UNIT_WEIGHT is not null) " +
                        "           and (UNIT_VOLUME <> '0.0001' or UNIT_WEIGHT <> '0.0001')) " +
                        "   and  exists " +
                        "       (select 1 " +
                        "          from LPN LPN1, WM_INVENTORY WMI, LOCN_HDR LHD, RESV_LOCN_HDR RLH " +
                        "         where WMI.LPN_ID = LPN1.LPN_ID " +
                        "           and RLH.LOCN_ID = LPN1.CURR_SUB_LOCN_ID " +
                        "           and lhd.locn_id = lpn1.curr_sub_locn_id " +
                        "           and WMI.INBOUND_OUTBOUND_INDICATOR = 'I' " +
                        "           and WMI.ALLOCATABLE = 'Y' " +
                        "           and lpn1.lpn_facility_status = '30' " +
                        "           and RLH.INVN_LOCK_CODE is null " +
                        "           and LPN1.ITEM_NAME = LPN.ITEM_NAME " +
                        "           and exists               (select LOCN_ID " +
                        "                  from LOCN_HDR " +
                        "                 where LOCN_CLASS = 'R' " +
                        "                   and PULL_ZONE = 'HC1' " +
                        "                   and LPN1.CURR_SUB_LOCN_ID = LOCN_ID))";
                arrSQL = new String[]{sql5};
                break;
        }
        return arrSQL;
    }
}