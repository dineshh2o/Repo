package tech.nike.automation.common.framework.sql;

/**
 * Created by psibb1 on 8/18/2016.
 */
public class INT992Queries {

    public static String[] getQuery(String strTestCaseName) {
        String[] arrSQL = {};
        switch (strTestCaseName) {

            case "OB_1064_PW03AT_HP_23_INT992":
                String sql1 = "select LPN.TC_PARENT_LPN_ID, LPN.TC_LPN_ID, LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ, WMI.ON_HAND_QTY QTY" +
                        " from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD,RESV_LOCN_HDR RLH" +
                        " where WMI.LPN_ID = LPN.LPN_ID and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID and lhd.locn_id = lpn.curr_sub_locn_id" +
                        " and (WMI.ON_HAND_QTY) > 0"+
                        " and wmi.inbound_outbound_indicator = 'I'and wmi.allocatable = 'Y'and  RLH.INVN_LOCK_CODE is null" +
                        " and LPN.CURR_SUB_LOCN_ID in (select LOCN_ID from LOCN_HDR where LOCN_CLASS = 'R' and PULL_ZONE in('HP1','HP2'))" +
                        " and lpn.lpn_id not in (select lpn_id from lpn_lock)" +
                        " and LPN.ITEM_ID in (select PLD.ITEM_ID from PICK_LOCN_HDR PLH, LOCN_HDR LHD, PICK_LOCN_DTL PLD where  LHD.LOCN_ID = PLH.LOCN_ID and PLD.PICK_LOCN_HDR_ID = PLH.PICK_LOCN_HDR_ID" +
                        " and LHD.SKU_DEDCTN_TYPE = 'P' and LHD.LOCN_CLASS = 'C' and PLH.INVN_LOCK_CODE is null)" +
                        " and LPN.ITEM_NAME in (select ITEM_NAME from ITEM_CBO where ITEM_ID in (select ITEM_ID from ITEM_FACILITY_MAPPING_WMS" +
                        " where SLOT_MISC_2 ='Y') and ITEM_BAR_CODE <>'0' and (UNIT_VOLUME is not null or UNIT_WEIGHT is not null)" +
                        " and (UNIT_VOLUME <>'0.0001' or UNIT_WEIGHT <>'0.0001'))" +
                        " and LPN.ITEM_NAME NOT IN (select  LPN.ITEM_NAME" +
                        " from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD,RESV_LOCN_HDR RLH" +
                        " where WMI.LPN_ID = LPN.LPN_ID and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID and lhd.locn_id = lpn.curr_sub_locn_id" +
                        " and WMI.INBOUND_OUTBOUND_INDICATOR = 'I'and WMI.ALLOCATABLE = 'Y'and LPN.TC_PARENT_LPN_ID is not null" +
                        " and RLH.INVN_LOCK_CODE is null and LPN.CURR_SUB_LOCN_ID" +
                        " in (select LOCN_ID from LOCN_HDR where LOCN_CLASS = 'R' and PULL_ZONE in('HG1','HG2','HC1')))" +
                        " order by LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1,LHD.PULL_ZONE, WMI.ON_HAND_QTY desc, LHD.LOCN_PICK_SEQ";
                arrSQL = new String[]{sql1};
                break;

            case "OB_1064_PW03AT_HP_23_INT992_PROMO_NEW":
                String sql2="select LPN.TC_PARENT_LPN_ID, LPN.TC_LPN_ID, LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ, WMI.ON_HAND_QTY QTY " +
                        "from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD,RESV_LOCN_HDR RLH " +
                        "where WMI.LPN_ID = LPN.LPN_ID and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID and lhd.locn_id = lpn.curr_sub_locn_id " +
                        "and wmi.inbound_outbound_indicator = 'I'and wmi.allocatable = 'Y'and  RLH.INVN_LOCK_CODE is null " +
                        "and LPN.CURR_SUB_LOCN_ID in (select LOCN_ID from LOCN_HDR where LOCN_CLASS = 'R' and PULL_ZONE in('HP1','HP2')) " +
                        "and lpn.lpn_id not in (select lpn_id from lpn_lock) " +
                        "and LPN.ITEM_ID in (select PLD.ITEM_ID from PICK_LOCN_HDR PLH, LOCN_HDR LHD, PICK_LOCN_DTL PLD where  LHD.LOCN_ID = PLH.LOCN_ID and PLD.PICK_LOCN_HDR_ID = PLH.PICK_LOCN_HDR_ID  " +
                        "and LHD.SKU_DEDCTN_TYPE = 'P' and LHD.LOCN_CLASS = 'C' and PLH.INVN_LOCK_CODE is null) " +
                        "and LPN.ITEM_NAME in (select ITEM_NAME from ITEM_CBO where ITEM_ID in (select ITEM_ID from ITEM_FACILITY_MAPPING_WMS " +
                        "where SLOT_MISC_2 ='Y') and ITEM_BAR_CODE <>'0' and (UNIT_VOLUME is not null or UNIT_WEIGHT is not null) " +
                        "and (UNIT_VOLUME <>'0.0001' or UNIT_WEIGHT <>'0.0001')) " +
                        "and LPN.ITEM_NAME NOT IN (select  LPN.ITEM_NAME " +
                        "from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD,RESV_LOCN_HDR RLH " +
                        "where WMI.LPN_ID = LPN.LPN_ID and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID and lhd.locn_id = lpn.curr_sub_locn_id " +
                        "and WMI.INBOUND_OUTBOUND_INDICATOR = 'I'and WMI.ALLOCATABLE = 'Y'and LPN.TC_PARENT_LPN_ID is not null  " +
                        "and RLH.INVN_LOCK_CODE is null and LPN.CURR_SUB_LOCN_ID " +
                        "in (select LOCN_ID from LOCN_HDR where LOCN_CLASS = 'R' and PULL_ZONE in('HG1','HG2','HC1'))) " +
                        "order by LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1,LHD.PULL_ZONE, WMI.ON_HAND_QTY desc, LHD.LOCN_PICK_SEQ";
                arrSQL = new String[]{sql2};
                break;
        }
        return arrSQL;
    }
}