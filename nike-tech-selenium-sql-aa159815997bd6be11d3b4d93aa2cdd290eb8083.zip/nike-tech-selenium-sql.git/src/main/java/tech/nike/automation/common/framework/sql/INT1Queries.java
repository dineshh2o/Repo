package tech.nike.automation.common.framework.sql;

/**
 * Created by nchou4 on 9/03/2016.
 */
public class INT1Queries {

    public static String[] getQuery(String strTestCaseName) {
        String[] arrSQL = {};
        String sql1 = "";
        String sql2 = "";
        switch (strTestCaseName) {
//        case "OB_1014_PW03AT_HP_01_SW_INT2_TASKCR_FULLPALL_FROM_PALLRESV":
//            sql1 = "SELECT * FROM ( " +
//                    "SELECT  LPN.TC_PARENT_LPN_ID,LPN2.LPN_FACILITY_STATUS,LPN.ITEM_NAME,WMI.CNTRY_OF_ORGN,  " +
//                    "WMI.ITEM_ATTR_1, LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,SUM(WMI.ON_HAND_QTY) QTY  " +
//                    "FROM LPN LPN,LPN LPN2, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB  " +
//                    "where wmi.lpn_id = lpn.lpn_id " +
//                    "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
//                    "AND ICB.ITEM_ID = WMI.ITEM_ID " +
//                    "and icb.item_id = LPN.item_id " +
//                    "and wmi.inbound_outbound_indicator = 'I' " +
//                    "and wmi.allocatable = 'Y' " +
//                    "AND LPN.TC_PARENT_LPN_ID IS NOT NULL  " +
//                    "AND LPN.LPN_FACILITY_STATUS='30' " +
//                    "AND LPN2.TC_LPN_ID=LPN.TC_PARENT_LPN_ID " +
//                    "AND LPN2.lpn_facility_status='30' " +
//                    "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN ('22A','22B','23A','23B','24A','24B','26A','26B','PAL')) " +
//                    "AND NOT EXISTS (SELECT 1 FROM LPN_LOCK L WHERE L.LPN_ID = LPN.LPN_ID) " +
//                    "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001  " +
//                    "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001 " +
//                    "AND ICB.ITEM_BAR_CODE <>'0' " +
//                    "GROUP BY (LPN.TC_PARENT_LPN_ID,LPN2.lpn_facility_status,LPN.ITEM_NAME,LPN.LPN_FACILITY_STATUS,WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ) ) AA " +
//                    "WHERE AA.QTY > 0 " +
//                    "AND ROWNUM < 2";
//
//            arrSQL = new String[]{sql1};
//            break;
//        case "OB_1014_PW03AT_HP_02_SW_INT2_Alloc_TaskCr_FullPall_from_PallResv_VAS" :
//            sql1 = "SELECT * FROM ( " +
//                    "SELECT  LPN.TC_PARENT_LPN_ID,LPN2.LPN_FACILITY_STATUS,LPN.ITEM_NAME,WMI.CNTRY_OF_ORGN,  " +
//                    "WMI.ITEM_ATTR_1, LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,SUM(WMI.ON_HAND_QTY) QTY  " +
//                    "FROM LPN LPN,LPN LPN2, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB  " +
//                    "where wmi.lpn_id = lpn.lpn_id " +
//                    "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
//                    "AND ICB.ITEM_ID = WMI.ITEM_ID " +
//                    "and icb.item_id = LPN.item_id " +
//                    "and wmi.inbound_outbound_indicator = 'I' " +
//                    "and wmi.allocatable = 'Y' " +
//                    "AND LPN.TC_PARENT_LPN_ID IS NOT NULL  " +
//                    "AND LPN.LPN_FACILITY_STATUS='30' " +
//                    "AND LPN2.TC_LPN_ID=LPN.TC_PARENT_LPN_ID " +
//                    "AND LPN2.lpn_facility_status='30' " +
//                    "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN ('22A','22B','23A','23B','24A','24B','26A','26B','PAL')) " +
//                    "AND NOT EXISTS (SELECT 1 FROM LPN_LOCK L WHERE L.LPN_ID = LPN.LPN_ID) " +
//                    "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001  " +
//                    "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001 " +
//                    "AND ICB.ITEM_BAR_CODE <>'0' " +
//                    "GROUP BY (LPN.TC_PARENT_LPN_ID,LPN2.lpn_facility_status,LPN.ITEM_NAME,LPN.LPN_FACILITY_STATUS,WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ) ) AA " +
//                    "WHERE AA.QTY > 0 " +
//                    "AND ROWNUM < 2";
//
//            arrSQL = new String[]{sql1};
//            break;
//        case "OB_1014_PW03AT_HP_03_SW_INT2_TaskCr_Cartons_from_Shv_towers" :
//            sql1 = "SELECT  LPN.TC_LPN_ID,LPN.LPN_FACILITY_STATUS,LPN.ITEM_NAME,WMI.CNTRY_OF_ORGN, " +
//                    "WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,WMI.ON_HAND_QTY QTY  " +
//                    "FROM LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB  " +
//                    "where wmi.lpn_id = lpn.lpn_id " +
//                    "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
//                    "AND ICB.ITEM_ID = WMI.ITEM_ID " +
//                    "and icb.item_id = LPN.item_id " +
//                    "and wmi.inbound_outbound_indicator = 'I' " +
//                    "and wmi.allocatable = 'Y' " +
//                    "AND LPN.LPN_FACILITY_STATUS='30' " +
//                    "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN('SHT','DYR')) " +
//                    "AND NOT EXISTS (SELECT 1 FROM LPN_LOCK L WHERE L.LPN_ID = LPN.LPN_ID) " +
//                    "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001  " +
//                    "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001 " +
//                    "AND ICB.ITEM_BAR_CODE <>'0' " +
//                    " And LPN.ITEM_NAME NOT IN ( " +
//                    "AND ROWNUM < 2";
//
//            arrSQL = new String[]{sql1};
//            break;
//        case "OB_1014_PW03AT_HP_04_SW_INT2_TASKCR_CARtONS_FROM_SHV_TOWERS_VAS":
//            sql1 = "SELECT  LPN.TC_LPN_ID,LPN.LPN_FACILITY_STATUS,LPN.ITEM_NAME,WMI.CNTRY_OF_ORGN, " +
//                    "WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,WMI.ON_HAND_QTY QTY  " +
//                    "FROM LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB  " +
//                    "where wmi.lpn_id = lpn.lpn_id " +
//                    "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
//                    "AND ICB.ITEM_ID = WMI.ITEM_ID " +
//                    "and icb.item_id = LPN.item_id " +
//                    "and wmi.inbound_outbound_indicator = 'I' " +
//                    "and wmi.allocatable = 'Y' " +
//                    "AND LPN.LPN_FACILITY_STATUS='30' " +
//                    "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN('SHT','DYR')) " +
//                    "AND NOT EXISTS (SELECT 1 FROM LPN_LOCK L WHERE L.LPN_ID = LPN.LPN_ID) " +
//                    "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001  " +
//                    "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001 " +
//                    "AND ICB.ITEM_BAR_CODE <>'0' " +
//                    " And LPN.ITEM_NAME NOT IN ( " +
//                    "AND ROWNUM < 2";
//
//            arrSQL = new String[]{sql1};
//            break;
//        case "OB_1014_PW03AT_HP_05_SW_INT2_TASKCR_CARTONS_FROM_CARTONRESV":
//            sql1 = "SELECT  LPN.TC_LPN_ID,LPN.LPN_FACILITY_STATUS,LPN.ITEM_NAME,WMI.CNTRY_OF_ORGN, " +
//                    "WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,WMI.ON_HAND_QTY QTY  " +
//                    "FROM LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB  " +
//                    "where wmi.lpn_id = lpn.lpn_id " +
//                    "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
//                    "AND ICB.ITEM_ID = WMI.ITEM_ID " +
//                    "and icb.item_id = LPN.item_id " +
//                    "and wmi.inbound_outbound_indicator = 'I' " +
//                    "and wmi.allocatable = 'Y' " +
//                    "AND LPN.LPN_FACILITY_STATUS='30' " +
//                    "AND LPN.TC_PARENT_LPN_ID IS NULL  " +
//                    "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN('29A','29B')) " +
//                    "AND NOT EXISTS (SELECT 1 FROM LPN_LOCK L WHERE L.LPN_ID = LPN.LPN_ID) " +
//                    "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001  " +
//                    "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001 " +
//                    "AND ICB.ITEM_BAR_CODE <>'0' " +
//                    "AND WMI.CNTRY_OF_ORGN IS NOT NULL  " +
//                    " And LPN.ITEM_NAME NOT IN ( " +
//                    "ORDER BY LPN.ITEM_NAME, WMI.ITEM_ATTR_1,WMI.ON_HAND_QTY,LHD.PULL_ZONE,LHD.LOCN_PICK_SEQ";
//
//            arrSQL = new String[]{sql1};
//            break;
//        case "OB_1014_PW03AT_HP_06_SW_INT2_TaskCr_Cartons_from_CartonResv_VAS" :
//            sql1 = "SELECT  LPN.TC_LPN_ID,LPN.LPN_FACILITY_STATUS,LPN.ITEM_NAME,WMI.CNTRY_OF_ORGN, " +
//                    "WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,WMI.ON_HAND_QTY QTY  " +
//                    "FROM LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB  " +
//                    "where wmi.lpn_id = lpn.lpn_id " +
//                    "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
//                    "AND ICB.ITEM_ID = WMI.ITEM_ID " +
//                    "and icb.item_id = LPN.item_id " +
//                    "and wmi.inbound_outbound_indicator = 'I' " +
//                    "and wmi.allocatable = 'Y' " +
//                    "AND LPN.LPN_FACILITY_STATUS='30' " +
//                    "AND LPN.TC_PARENT_LPN_ID IS NULL  " +
//                    "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN('29A','29B')) " +
//                    "AND NOT EXISTS (SELECT 1 FROM LPN_LOCK L WHERE L.LPN_ID = LPN.LPN_ID) " +
//                    "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001  " +
//                    "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001 " +
//                    "AND ICB.ITEM_BAR_CODE <>'0' " +
//                    "AND WMI.CNTRY_OF_ORGN IS NOT NULL " +
//                    "ORDER BY LPN.ITEM_NAME, WMI.ITEM_ATTR_1,WMI.ON_HAND_QTY,LHD.PULL_ZONE,LHD.LOCN_PICK_SEQ";
//            arrSQL = new String[]{sql1};
//            break;
//        case "OB_1014_PW03AT_HP_07_SW_INT1_CARTON_FROM_SHAVE_TOWER":
//            sql1 = "SELECT  DISTINCT LPN.ITEM_NAME,WMI.ITEM_ATTR_1,(WMI.ON_HAND_QTY-1) QTY  " +
//                    "FROM LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB  " +
//                    "where wmi.lpn_id = lpn.lpn_id " +
//                    "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
//                    "AND ICB.ITEM_ID = WMI.ITEM_ID " +
//                    "and icb.item_id = LPN.item_id " +
//                    "and wmi.inbound_outbound_indicator = 'I' " +
//                    "and wmi.allocatable = 'Y' " +
//                    "AND LPN.LPN_FACILITY_STATUS='30' " +
//                    "AND LPN.TC_PARENT_LPN_ID IS NULL  " +
//                    "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN('SHT','DYR')) " +
//                    "AND NOT EXISTS (SELECT 1 FROM LPN_LOCK L WHERE L.LPN_ID = LPN.LPN_ID) " +
//                    "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001  " +
//                    "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001 " +
//                    "AND ICB.ITEM_BAR_CODE <>'0' " +
//                    "AND WMI.ON_HAND_QTY > 1 " +
//                    "AND ROWNUM < 2";
//
//            arrSQL = new String[]{sql1};
//            break;
//        case "OB_1014_PW03AT_HP_08_SW_INT1_CARTON_FROM_CARTON_RESERVES":
//                sql1 = "SELECT  DISTINCT LPN.ITEM_NAME,WMI.ITEM_ATTR_1,(WMI.ON_HAND_QTY-1) QTY  " +
//                        "FROM LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB  " +
//                        "where wmi.lpn_id = lpn.lpn_id " +
//                        "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
//                        "AND ICB.ITEM_ID = WMI.ITEM_ID " +
//                        "and icb.item_id = LPN.item_id " +
//                        "and wmi.inbound_outbound_indicator = 'I' " +
//                        "and wmi.allocatable = 'Y' " +
//                        "AND LPN.LPN_FACILITY_STATUS='30' " +
//                        "AND LPN.TC_PARENT_LPN_ID IS NULL  " +
//                        "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN('29A','29B','SHT','DYR')) " +
//                        "AND NOT EXISTS (SELECT 1 FROM LPN_LOCK L WHERE L.LPN_ID = LPN.LPN_ID) " +
//                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001  " +
//                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001 " +
//                        "AND ICB.ITEM_BAR_CODE <>'0' " +
//                        "AND WMI.ON_HAND_QTY > 1 " +
//                        "AND ROWNUM < 2";
//
//                arrSQL = new String[]{sql1};
//            break;
//        case "OB_1014_PW03AT_HP_09_SW_INT1_PALLET_FROM_PALLET_RESERVES":
//            sql1 = "SELECT DISTINCT A.ITEM_NAME,A.ITEM_ATTR_1,A.QTY - 1 QTY " +
//                    "FROM ( " +
//                    " SELECT  LPN.TC_PARENT_LPN_ID,LPN2.LPN_FACILITY_STATUS,LPN.ITEM_NAME,WMI.CNTRY_OF_ORGN,  " +
//                    "WMI.ITEM_ATTR_1, LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,SUM(WMI.ON_HAND_QTY) QTY  " +
//                    "FROM LPN LPN,LPN LPN2, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB  " +
//                    "where wmi.lpn_id = lpn.lpn_id " +
//                    "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
//                    "AND ICB.ITEM_ID = WMI.ITEM_ID " +
//                    "and icb.item_id = LPN.item_id " +
//                    "and wmi.inbound_outbound_indicator = 'I' " +
//                    "and wmi.allocatable = 'Y' " +
//                    "AND LPN.TC_PARENT_LPN_ID IS NOT NULL  " +
//                    "AND LPN.LPN_FACILITY_STATUS='30' " +
//                    "AND LPN2.TC_LPN_ID=LPN.TC_PARENT_LPN_ID " +
//                    "AND LPN2.lpn_facility_status='30' " +
//                    "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN('22A','22B','23A','23B','24A','24B','26A','26B','PAL')) " +
//                    "AND NOT EXISTS (SELECT 1 FROM LPN_LOCK L WHERE L.LPN_ID = LPN.LPN_ID) " +
//                    "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001  " +
//                    "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001 " +
//                    "AND ICB.ITEM_BAR_CODE <>'0' " +
//                    "GROUP BY (LPN.TC_PARENT_LPN_ID,LPN2.lpn_facility_status,LPN.ITEM_NAME,LPN.LPN_FACILITY_STATUS,WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ) " +
//                    ") A " +
//                    "WHERE A.QTY > 1 " +
//                    "AND ROWNUM < 2";
//
//            arrSQL = new String[]{sql1};
//            break;
//        case "OB_1014_PW03AT_HP_10_SW_INT3_REPLEN_FROM_PICK_MODULE_NON_PACKS":
//            sql1 = "select lhdp.dsp_locn, lhdp.sku_dedctn_type, lhdp.locn_pick_seq, icb.item_name,  " +
//                    "WMI.ON_HAND_QTY, WMI.WM_ALLOCATED_QTY, WMI.TO_BE_FILLED_QTY, (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) AS ALLOCATABLE_QTY " +
//                    ",(WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) - 1 AS QTY " +
//                    ", PLD.MAX_INVN_QTY, PLD.MIN_INVN_QTY, PLD.CNTRY_OF_ORGN, PLD.SKU_ATTR_1 ITEM_ATTR_1 ,PLD.PROD_STAT, PLD.LOCN_SEQ_NBR   " +
//                    "FROM PICK_LOCN_HDR PLH, LOCN_HDR LHDP, ITEM_CBO ICB, PICK_LOCN_DTL PLD, WM_INVENTORY WMI " +
//                    "where lhdp.locn_id = plh.locn_id  " +
//                    "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id " +
//                    "AND PLD.ITEM_ID = ICB.ITEM_ID " +
//                    "AND NOT EXISTS (SELECT 1 FROM ITEM_PACKAGE_CBO CB WHERE CB.ITEM_ID = icb.ITEM_ID AND PACKAGE_UOM_ID='26' AND IS_STD='1') " +
//                    "AND WMI.LOCATION_ID = PLH.LOCN_ID " +
//                    "--and lhdp.sku_dedctn_type = 'P' " +
//                    "AND LHDP.LOCN_CLASS = 'C' " +
//                    "and WMI.ON_HAND_QTY > 0 " +
//                    "AND PLH.INVN_LOCK_CODE IS NULL " +
//                    "AND LHDP.ZONE BETWEEN 47 AND 49 ";
//
//            arrSQL = new String[]{sql1};
//            break;
            case "OB_1014_PW03AT_HP_01_SW_INT2_TASKCR_FULLPALL_FROM_PALLRESV":
                sql1 = "SELECT * FROM (\n" +
                        "SELECT  LPN.TC_PARENT_LPN_ID--,LPN2.LPN_FACILITY_STATUS\n" +
                        ",LPN.ITEM_NAME--,LPN.LPN_FACILITY_STATUS\n" +
                        ",WMI.CNTRY_OF_ORGN, \n" +
                        "WMI.ITEM_ATTR_1, LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,SUM(WMI.ON_HAND_QTY) QTY , SUM (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) ALLOCATABLE_QTY\n" +
                        "FROM LPN LPN,LPN LPN2\n" +
                        ", WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB \n" +
                        "where wmi.lpn_id = lpn.lpn_id\n" +
                        "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID\n" +
                        "AND ICB.ITEM_ID = WMI.ITEM_ID\n" +
                        "and icb.item_id = LPN.item_id\n" +
                        "and wmi.inbound_outbound_indicator = 'I'\n" +
                        "and wmi.allocatable = 'Y'\n" +
                        "AND LPN.TC_PARENT_LPN_ID IS NOT NULL \n" +
                        "--AND LPN.LPN_FACILITY_STATUS='30'\n" +
                        "AND LPN2.TC_LPN_ID=LPN.TC_PARENT_LPN_ID\n" +
                        "--AND LPN2.lpn_facility_status='30\n" +
                        "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN ('PAL','B12','BAB'))\n" +
                        "AND NOT EXISTS (SELECT 1 FROM LPN_LOCK L WHERE L.LPN_ID = LPN.LPN_ID)\n" +
                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001 \n" +
                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001\n" +
                        "AND ICB.ITEM_BAR_CODE <>'0'\n" +
                        //"AND icb.prod_type = '30' \n"+
                        //"AND LPN.ITEM_NAME = 'BA4886-005-MISC' \n" +
                        "GROUP BY (LPN.TC_PARENT_LPN_ID\n" +
                        "--,LPN2.lpn_facility_status\n" +
                        ",LPN.ITEM_NAME--,LPN.LPN_FACILITY_STATUS\n" +
                        ",WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ) \n" +
                        "ORDER BY LPN.ITEM_NAME,WMI.CNTRY_OF_ORGN,SUM(WMI.ON_HAND_QTY)) AA\n" +
                        "WHERE AA.QTY > 0\n" +
                        "AND AA.QTY = AA.ALLOCATABLE_QTY\n" +
                        "AND ROWNUM < 2";

                arrSQL = new String[]{sql1};
                break;

            case "OB_1014_PW03AT_HP_02_SW_INT2_Alloc_TaskCr_FullPall_from_PallResv_VAS":
                sql1 = "SELECT * FROM (\n" +
                        "  SELECT  LPN.TC_PARENT_LPN_ID--,LPN2.LPN_FACILITY_STATUS\n" +
                        "  ,LPN.ITEM_NAME--,LPN.LPN_FACILITY_STATUS\n" +
                        "  ,WMI.CNTRY_OF_ORGN, \n" +
                        "  WMI.ITEM_ATTR_1, LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,SUM(WMI.ON_HAND_QTY)  QTY , SUM (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) ALLOCATABLE_QTY\n" +
                        "  FROM LPN LPN,LPN LPN2\n" +
                        "  , WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB \n" +
                        "  where wmi.lpn_id = lpn.lpn_id\n" +
                        "  AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID\n" +
                        "  AND ICB.ITEM_ID = WMI.ITEM_ID\n" +
                        "  and icb.item_id = LPN.item_id\n" +
                        "  and wmi.inbound_outbound_indicator = 'I'\n" +
                        "  and wmi.allocatable = 'Y'\n" +
                        "  AND LPN.TC_PARENT_LPN_ID IS NOT NULL \n" +
                        "  --AND LPN.LPN_FACILITY_STATUS='30'\n" +
                        "  AND LPN2.TC_LPN_ID=LPN.TC_PARENT_LPN_ID\n" +
                        "  --AND LPN2.lpn_facility_status='30\n" +
                        "  AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN ('PAL','B12','BAB'))\n" +
                        "  AND NOT EXISTS (SELECT 1 FROM LPN_LOCK L WHERE L.LPN_ID = LPN.LPN_ID)\n" +
                        "  AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001 \n" +
                        "  AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001\n" +
                        "  AND ICB.ITEM_BAR_CODE <>'0'\n" +
                        "  AND LPN.ITEM_NAME NOT IN ( \n" +
                        "  GROUP BY (LPN.TC_PARENT_LPN_ID\n" +
                        "  --,LPN2.lpn_facility_status\n" +
                        "  ,LPN.ITEM_NAME--,LPN.LPN_FACILITY_STATUS\n" +
                        "  ,WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ) \n" +
                        "  ORDER BY LPN.ITEM_NAME,WMI.CNTRY_OF_ORGN,SUM(WMI.ON_HAND_QTY)) AA\n" +
                        "  WHERE AA.QTY > 0\n" +
                        "  AND AA.QTY = AA.ALLOCATABLE_QTY\n" +
                        "  AND ROWNUM < 2" ;

                sql2 = "SELECT C.VAS_CODE,C.DESCRIPTION FROM C_VAS_INFO C WHERE C.SAP_ONLY <>'1' and C.c_vas_lvl='2'" ;

                arrSQL = new String[]{sql1,sql2};
                break;

            case "OB_1014_PW03AT_HP_03_SW_INT2_TaskCr_Cartons_from_Shv_towers":
                sql1 = "SELECT  LPN.TC_LPN_ID,LPN.LPN_FACILITY_STATUS,LPN.ITEM_NAME,WMI.CNTRY_OF_ORGN, " +
                        "WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,WMI.ON_HAND_QTY QTY  " +
                        "FROM LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB  " +
                        "where wmi.lpn_id = lpn.lpn_id " +
                        "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "AND ICB.ITEM_ID = WMI.ITEM_ID " +
                        "and icb.item_id = LPN.item_id " +
                        "and wmi.inbound_outbound_indicator = 'I' " +
                        "and wmi.allocatable = 'Y' " +
                        "AND LPN.LPN_FACILITY_STATUS='30' " +
                        "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN('SHT','DYR')) " +
                        "AND NOT EXISTS (SELECT 1 FROM LPN_LOCK L WHERE L.LPN_ID = LPN.LPN_ID) " +
                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001  " +
                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001 " +
                        "AND ICB.ITEM_BAR_CODE <>'0' " +
                        "AND WMI.ON_HAND_QTY > 0 " +
                        "AND LPN.ITEM_NAME NOT IN (  " +
                        "AND ROWNUM < 2";

                arrSQL = new String[]{sql1};
                break;
            case "OB_1014_PW03AT_HP_04_SW_INT2_TaskCr_Cartons_from_Shv_towers_VAS":
                sql1 = "SELECT  LPN.TC_LPN_ID,LPN.LPN_FACILITY_STATUS,LPN.ITEM_NAME,WMI.CNTRY_OF_ORGN, " +
                        "WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,WMI.ON_HAND_QTY QTY  " +
                        "FROM LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB  " +
                        "where wmi.lpn_id = lpn.lpn_id " +
                        "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "AND ICB.ITEM_ID = WMI.ITEM_ID " +
                        "and icb.item_id = LPN.item_id " +
                        "and wmi.inbound_outbound_indicator = 'I' " +
                        "and wmi.allocatable = 'Y' " +
                        "AND LPN.LPN_FACILITY_STATUS='30' " +
                        "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN('SHT','DYR')) " +
                        "AND NOT EXISTS (SELECT 1 FROM LPN_LOCK L WHERE L.LPN_ID = LPN.LPN_ID) " +
                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001  " +
                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001 " +
                        "AND ICB.ITEM_BAR_CODE <>'0'  " +
                        "AND WMI.ON_HAND_QTY > 0 " +
                       // "AND LPN.ITEM_NAME != '315121-115-10' " +
                        "AND LPN.ITEM_NAME NOT IN ( " +
                        "AND ROWNUM < 2";
                sql2 = "SELECT C.VAS_CODE,C.DESCRIPTION FROM C_VAS_INFO C WHERE C.SAP_ONLY <>'1' and C.c_vas_lvl='2'" ;

                arrSQL = new String[]{sql1,sql2};
                break;
            case "OB_1014_PW03AT_HP_05_SW_INT2_TASKCR_CARTONS_FROM_CARTONRESV":
                sql1 = "SELECT  LPN.TC_LPN_ID,LPN.LPN_FACILITY_STATUS,LPN.ITEM_NAME,WMI.CNTRY_OF_ORGN,\n" +
                        "WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,WMI.ON_HAND_QTY QTY \n" +
                        "FROM LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB \n" +
                        "where wmi.lpn_id = lpn.lpn_id\n" +
                        "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID\n" +
                        "AND ICB.ITEM_ID = WMI.ITEM_ID\n" +
                        "and icb.item_id = LPN.item_id\n" +
                        "and wmi.inbound_outbound_indicator = 'I'\n" +
                        "and wmi.allocatable = 'Y'\n" +
                        "AND LPN.LPN_FACILITY_STATUS='30'\n" +
                        "AND LPN.TC_PARENT_LPN_ID IS NULL \n" +
                        "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN('29B'))\n" +
                        "AND NOT EXISTS (SELECT 1 FROM LPN_LOCK L WHERE L.LPN_ID = LPN.LPN_ID)\n" +
                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001 \n" +
                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001\n" +
                        "AND ICB.ITEM_BAR_CODE <>'0'\n" +
                        "AND LPN.ITEM_NAME NOT IN (  " +
                        "AND WMI.ON_HAND_QTY > 0\n" +
                        "AND WMI.CNTRY_OF_ORGN IS NOT NULL\n" +
                        "AND ROWNUM  < 2 " ;

                arrSQL = new String[]{sql1};
                break;
            case "OB_1014_PW03AT_HP_06_SW_INT2_TaskCr_Cartons_from_CartonResv_VAS":
                sql1 = "SELECT  LPN.TC_LPN_ID,LPN.LPN_FACILITY_STATUS,LPN.ITEM_NAME,WMI.CNTRY_OF_ORGN, " +
                        "WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,WMI.ON_HAND_QTY QTY  " +
                        "FROM LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB  " +
                        "where wmi.lpn_id = lpn.lpn_id " +
                        "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "AND ICB.ITEM_ID = WMI.ITEM_ID " +
                        "and icb.item_id = LPN.item_id " +
                        "and wmi.inbound_outbound_indicator = 'I' " +
                        "and wmi.allocatable = 'Y' " +
                        "AND LPN.LPN_FACILITY_STATUS='30' " +
                        "AND LPN.TC_PARENT_LPN_ID IS NULL  " +
                        "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN('BAB')) " +
                        "AND NOT EXISTS (SELECT 1 FROM LPN_LOCK L WHERE L.LPN_ID = LPN.LPN_ID) " +
                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001  " +
                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001 " +
                        "AND ICB.ITEM_BAR_CODE <>'0' " +
                        "AND WMI.CNTRY_OF_ORGN IS NOT NULL " +
                        "AND LPN.ITEM_NAME IS NOT NULL " +
                        //"AND LPN.ITEM_NAME != '704674-100-9' " +
                        "AND LPN.ITEM_NAME NOT IN ( " +
                        "AND WMI.ON_HAND_QTY > 0" +
                        "AND ROWNUM < 2";
                sql2 = "SELECT C.VAS_CODE,C.DESCRIPTION FROM C_VAS_INFO C WHERE C.SAP_ONLY <>'1' and C.c_vas_lvl='2'" ;

                arrSQL = new String[]{sql1,sql2};
                break;
            case "OB_1014_PW03AT_HP_07_SW_INT1_CARTON_FROM_SHAVE_TOWER":
                sql1 = "SELECT * FROM ( " +
                        "SELECT ROWNUM RN,LPN.LPN_ID, LPN.ITEM_NAME,WMI.ITEM_ATTR_1,WMI.ON_HAND_QTY,(WMI.ON_HAND_QTY-1) QTY  " +
                        "FROM LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB  " +
                        "where wmi.lpn_id = lpn.lpn_id " +
                        "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "AND ICB.ITEM_ID = WMI.ITEM_ID " +
                        "and icb.item_id = LPN.item_id " +
                        "and wmi.inbound_outbound_indicator = 'I' " +
                        "and wmi.allocatable = 'Y' " +
                        "AND LPN.LPN_FACILITY_STATUS='30' " +
                        "AND LPN.TC_PARENT_LPN_ID IS NULL  " +
                        "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN('SHT','DYR')) " +
                        "AND NOT EXISTS (SELECT 1 FROM LPN_LOCK L WHERE L.LPN_ID = LPN.LPN_ID) " +
                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001  " +
                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001 " +
                        "AND ICB.ITEM_BAR_CODE <>'0' " +
                        "AND WMI.ON_HAND_QTY > 1 " +
                        "AND LPN.ITEM_NAME NOT IN (  " +
                        "AND (SELECT count(WMI1.LPN_ID) from WM_INVENTORY WMI1,LPN L1 " +
                        "WHERE WMI1.ITEM_ID = WMI.Item_Id " +
                        "AND wmi1.inbound_outbound_indicator = 'I' " +
                        "and wmi1.allocatable = 'Y'  " +
                        "and wmi1.ON_HAND_QTY > 1  " +
                        "and L1.LPN_ID = WMI1.lpn_id " +
                        "and L1.LPN_FACILITY_STATUS='30') > 2 " +
                        "ORDER BY LPN.ITEM_NAME,WMI.ITEM_ATTR_1,WMI.ON_HAND_QTY DESC )  " +
                        "WHERE RN < 3";

                arrSQL = new String[]{sql1};
                break;
            case "OB_1014_PW03AT_HP_08_SW_INT1_CARTON_FROM_CARTON_RESERVES":
                sql1 = "SELECT * FROM ( " +
                        "SELECT LPN.ITEM_NAME,WMI.ITEM_ATTR_1,(WMI.ON_HAND_QTY-1) QTY ,LPN.item_id " +
                        "FROM LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB  " +
                        "where wmi.lpn_id = lpn.lpn_id " +
                        "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "AND ICB.ITEM_ID = WMI.ITEM_ID " +
                        "and icb.item_id = LPN.item_id " +
                        "and wmi.inbound_outbound_indicator = 'I' " +
                        "and wmi.allocatable = 'Y' " +
                        "AND LPN.LPN_FACILITY_STATUS='30' " +
                        "AND LPN.TC_PARENT_LPN_ID IS NULL  " +
                        "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN('29A','29B','SHT','DYR')) " +
                        "AND NOT EXISTS (SELECT 1 FROM LPN_LOCK L WHERE L.LPN_ID = LPN.LPN_ID) " +
                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001  " +
                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001 " +
                        "AND ICB.ITEM_BAR_CODE <>'0' " +
                        "AND WMI.ON_HAND_QTY > 1 " +
                        "AND LPN.ITEM_NAME NOT IN (  " +
                        "AND (SELECT count(WMI1.LPN_ID) FROM LPN LPN1, WM_INVENTORY WMI1, LOCN_HDR LHD1, ITEM_CBO ICB1  " +
                        "        where WMI1.ITEM_ID = WMI.ITEM_ID  " +
                        "        AND wmi1.lpn_id = lpn1.lpn_id " +
                        "        and Wmi1.ITEM_ATTR_1 = wmi.ITEM_ATTR_1 " +
                        "        AND LHD1.LOCN_ID = LPN1.CURR_SUB_LOCN_ID " +
                        "        AND ICB1.ITEM_ID = WMI1.ITEM_ID " +
                        "        and icb1.item_id = LPN1.item_id " +
                        "        and wmi1.inbound_outbound_indicator = 'I' " +
                        "        and wmi1.allocatable = 'Y' " +
                        "        AND LPN1.LPN_FACILITY_STATUS='30' " +
                        "        AND LPN1.TC_PARENT_LPN_ID IS NULL  " +
                        "        AND EXISTS (SELECT 1 FROM LOCN_HDR LH1 WHERE LH1.LOCN_ID = LPN1.CURR_SUB_LOCN_ID  " +
                        "                    AND LH1.LOCN_CLASS = 'R' AND LH1.PULL_ZONE IN('29A','29B','SHT','DYR')) " +
                        "        AND NOT EXISTS (SELECT 1 FROM LPN_LOCK L1 WHERE L1.LPN_ID = LPN1.LPN_ID) " +
                        "        AND NVL(ICB1.UNIT_VOLUME,0.0001) <> 0.0001  " +
                        "        AND NVL(ICB1.UNIT_WEIGHT,0.0001) <> 0.0001 " +
                        "        AND ICB1.ITEM_BAR_CODE <>'0' " +
                        "        AND WMI1.ON_HAND_QTY > 1) > 1 " +
                        "ORDER BY LPN.ITEM_NAME,WMI.ITEM_ATTR_1,WMI.ON_HAND_QTY DESC )  " +
                        "WHERE ROWNUM < 3";

                arrSQL = new String[]{sql1};
                break;
            case "OB_1014_PW03AT_HP_09_SW_INT1_PALLET_FROM_PALLET_RESERVES":
                sql1 = "SELECT * FROM (\n" +
                        "SELECT  LPN.ITEM_NAME,WMI.ITEM_ATTR_1,(WMI.ON_HAND_QTY-1) QTY ,LPN.item_id \n" +
                        "FROM LPN LPN,LPN LPN2, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB \n" +
                        "where wmi.lpn_id = lpn.lpn_id\n" +
                        "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID\n" +
                        "AND ICB.ITEM_ID = WMI.ITEM_ID\n" +
                        "and icb.item_id = LPN.item_id\n" +
                        "and wmi.inbound_outbound_indicator = 'I'\n" +
                        "and wmi.allocatable = 'Y'\n" +
                        "AND LPN.TC_PARENT_LPN_ID IS NOT NULL \n" +
                        "AND LPN.LPN_FACILITY_STATUS='30'\n" +
                        "AND LPN2.TC_LPN_ID=LPN.TC_PARENT_LPN_ID\n" +
                        "AND LPN2.lpn_facility_status='30'\n" +
                        "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN('HV2','PAL'))\n" +
                        "AND NOT EXISTS (SELECT 1 FROM LPN_LOCK L WHERE L.LPN_ID = LPN.LPN_ID)\n" +
                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001 \n" +
                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001\n" +
                        "AND ICB.ITEM_BAR_CODE <>'0'\n" +
                        "AND WMI.ON_HAND_QTY > 1\n" +
                        "AND LPN.ITEM_NAME NOT IN (  " +
                        "AND (SELECT  Count(WMI1.LPN_ID)\n" +
                        "      FROM LPN LPN1,LPN LPN3, WM_INVENTORY WMI1, LOCN_HDR LHD1, ITEM_CBO ICB1 \n" +
                        "      where WMI1.ITEM_ID =WMI.ITEM_ID\n" +
                        "      AND WMI1.ITEM_ATTR_1 = WMI.ITEM_ATTR_1\n" +
                        "      and wmi1.lpn_id = lpn1.lpn_id\n" +
                        "      AND LHD1.LOCN_ID = LPN1.CURR_SUB_LOCN_ID\n" +
                        "      AND ICB1.ITEM_ID = WMI1.ITEM_ID\n" +
                        "      and icb1.item_id = LPN1.item_id\n" +
                        "      and wmi1.inbound_outbound_indicator = 'I'\n" +
                        "      and wmi1.allocatable = 'Y'\n" +
                        "      AND LPN1.TC_PARENT_LPN_ID IS NOT NULL \n" +
                        "      AND LPN1.LPN_FACILITY_STATUS='30'\n" +
                        "      AND LPN3.TC_LPN_ID=LPN1.TC_PARENT_LPN_ID\n" +
                        "      AND LPN3.lpn_facility_status='30'\n" +
                        "      AND EXISTS (SELECT 1 FROM LOCN_HDR LH1 WHERE LH1.LOCN_ID = LPN1.CURR_SUB_LOCN_ID AND LH1.LOCN_CLASS = 'R' AND LH1.PULL_ZONE IN('HV2','PAL'))\n" +
                        "      AND NOT EXISTS (SELECT 1 FROM LPN_LOCK L1 WHERE L1.LPN_ID = LPN1.LPN_ID)\n" +
                        "      AND NVL(ICB1.UNIT_VOLUME,0.0001) <> 0.0001 \n" +
                        "      AND NVL(ICB1.UNIT_WEIGHT,0.0001) <> 0.0001\n" +
                        "      AND ICB1.ITEM_BAR_CODE <>'0'\n" +
                        "      AND WMI1.ON_HAND_QTY > 1) > 1\n" +
                        "ORDER BY LPN.ITEM_NAME,WMI.ITEM_ATTR_1,WMI.ON_HAND_QTY DESC ) \n" +
                        "WHERE ROWNUM < 3";

                arrSQL = new String[]{sql1};
                break;
            case "OB_1014_PW03AT_HP_10_SW_INT3_REPLEN_FROM_PICK_MODULE_NON_PACKS":
                sql1 = "select lhdp.dsp_locn, lhdp.sku_dedctn_type, lhdp.locn_pick_seq, icb.item_name, icb.item_id,\n" +
                        "WMI.ON_HAND_QTY, WMI.WM_ALLOCATED_QTY, WMI.TO_BE_FILLED_QTY, (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) AS ALLOCATABLE_QTY,\n" +
                        "(SELECT MIN(CB1.QUANTITY) FROM ITEM_PACKAGE_CBO CB1 WHERE CB1.ITEM_ID = icb.ITEM_ID AND CB1.PACKAGE_UOM_ID='25' and CB1.QUANTITY > 1) Case_Qty\n" +
                        ",LEAST ((SELECT MIN(CB1.QUANTITY) FROM ITEM_PACKAGE_CBO CB1 WHERE CB1.ITEM_ID = icb.ITEM_ID AND CB1.PACKAGE_UOM_ID='25' and CB1.QUANTITY > 1),\n" +
                        "(WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY)) - 1 AS QTY\n" +
                        ", PLD.MAX_INVN_QTY, PLD.MIN_INVN_QTY, PLD.CNTRY_OF_ORGN, PLD.SKU_ATTR_1 ITEM_ATTR_1 ,PLD.PROD_STAT, PLD.LOCN_SEQ_NBR  \n" +
                        "FROM PICK_LOCN_HDR PLH, LOCN_HDR LHDP, ITEM_CBO ICB, PICK_LOCN_DTL PLD, WM_INVENTORY WMI\n" +
                        "where lhdp.locn_id = plh.locn_id \n" +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id\n" +
                        "AND PLD.ITEM_ID = ICB.ITEM_ID\n" +
                        "AND NOT EXISTS (SELECT 1 FROM ITEM_PACKAGE_CBO CB WHERE CB.ITEM_ID = icb.ITEM_ID AND PACKAGE_UOM_ID='26' AND IS_STD='1')\n" +
                        "AND WMI.LOCATION_ID = PLH.LOCN_ID\n" +
                        "--and lhdp.sku_dedctn_type = 'P'\n" +
                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001 \n" +
                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001\n" +
                        "AND ICB.ITEM_BAR_CODE <>'0'\n" +
                        "AND LHDP.LOCN_CLASS = 'C'\n" +
                        "and WMI.ON_HAND_QTY > 1\n" +
                        "and (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) > 1\n" +
                        "AND PLH.INVN_LOCK_CODE IS NULL\n" +
                        "--and WMI.ON_HAND_QTY = (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY)\n" +
                        "AND LHDP.ZONE BETWEEN 47 AND 49 \n" +
                        "AND ICB.ITEM_NAME NOT IN (  " +
                        "and Rownum < 2";

                arrSQL = new String[]{sql1};
                break;

            case "OB_1014_PW03AT_HP_11_SW_INT3_Replen_from_Pick_Module_Packs":
                sql1 = "select * from (select lhdp.dsp_locn, lhdp.sku_dedctn_type, lhdp.locn_pick_seq, icb.item_name, icb.item_id,\n" +
                        "WMI.ON_HAND_QTY, WMI.WM_ALLOCATED_QTY, WMI.TO_BE_FILLED_QTY, (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) AS ALLOCATABLE_QTY\n" +
                        ",CBO.QUANTITY QTY\n" +
                        ",PLD.MAX_INVN_QTY, PLD.MIN_INVN_QTY, PLD.CNTRY_OF_ORGN, PLD.SKU_ATTR_1 ITEM_ATTR_1 ,PLD.PROD_STAT, PLD.LOCN_SEQ_NBR  \n" +
                        "FROM PICK_LOCN_HDR PLH, LOCN_HDR LHDP, ITEM_CBO ICB, PICK_LOCN_DTL PLD, WM_INVENTORY WMI , ITEM_PACKAGE_CBO CBO\n" +
                        "where lhdp.locn_id = plh.locn_id \n" +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id\n" +
                        "AND PLD.ITEM_ID = ICB.ITEM_ID\n" +
                        "AND CBO.ITEM_ID = icb.ITEM_ID \n" +
                        "AND CBO.PACKAGE_UOM_ID='26' \n" +
                        "AND CBO.IS_STD='1'\n" +
                        "AND WMI.LOCATION_ID = PLH.LOCN_ID\n" +
                        "--and lhdp.sku_dedctn_type = 'P'\n" +
                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001 \n" +
                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001\n" +
                        "AND ICB.ITEM_BAR_CODE <>'0'\n" +
                        "AND LHDP.LOCN_CLASS = 'C'\n" +
                        "and WMI.ON_HAND_QTY > 1\n" +
                        "and (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) > 1\n" +
                        "AND PLH.INVN_LOCK_CODE IS NULL\n" +
                        "AND ICB.ITEM_NAME NOT IN (  " +
                        //"--AND ICB.Item_name not like ('SX%') \n" +
                        //" AND ICB.Item_name in  ('SX4842-932-M')\n" +
                        "--and WMI.ON_HAND_QTY = (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY)\n" +
                        "AND LHDP.ZONE BETWEEN 47 AND 49  \n" +
                        "and CBO.QUANTITY < (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY))\n" +
                        "where Rownum < 2";

                arrSQL = new String[]{sql1};
                break;

            case "OB_1014_PW03AT_HP_12_SW_INT3_Replen_from_Cart_Pick_Non_Packs":
                sql1 = "select lhdp.dsp_locn, lhdp.sku_dedctn_type, lhdp.locn_pick_seq, icb.item_name, icb.item_id,\n" +
                        "WMI.ON_HAND_QTY, WMI.WM_ALLOCATED_QTY, WMI.TO_BE_FILLED_QTY, (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) AS ALLOCATABLE_QTY,\n" +
                        "(SELECT MIN(CB1.QUANTITY) FROM ITEM_PACKAGE_CBO CB1 WHERE CB1.ITEM_ID = icb.ITEM_ID AND CB1.PACKAGE_UOM_ID='25' and CB1.QUANTITY > 1) Case_Qty\n" +
                        ",LEAST ((SELECT MIN(CB1.QUANTITY) FROM ITEM_PACKAGE_CBO CB1 WHERE CB1.ITEM_ID = icb.ITEM_ID AND CB1.PACKAGE_UOM_ID='25' and CB1.QUANTITY > 1),\n" +
                        "(WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY)) - 1 AS QTY\n" +
                        ", PLD.MAX_INVN_QTY, PLD.MIN_INVN_QTY, PLD.CNTRY_OF_ORGN, PLD.SKU_ATTR_1 ITEM_ATTR_1 ,PLD.PROD_STAT, PLD.LOCN_SEQ_NBR  \n" +
                        "FROM PICK_LOCN_HDR PLH, LOCN_HDR LHDP, ITEM_CBO ICB, PICK_LOCN_DTL PLD, WM_INVENTORY WMI\n" +
                        "where lhdp.locn_id = plh.locn_id \n" +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id\n" +
                        "AND PLD.ITEM_ID = ICB.ITEM_ID\n" +
                        "AND NOT EXISTS (SELECT 1 FROM ITEM_PACKAGE_CBO CB WHERE CB.ITEM_ID = icb.ITEM_ID AND PACKAGE_UOM_ID='26' AND IS_STD='1')\n" +
                        "AND WMI.LOCATION_ID = PLH.LOCN_ID\n" +
                        "--and lhdp.sku_dedctn_type = 'P'\n" +
                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001 \n" +
                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001\n" +
                        "AND ICB.ITEM_BAR_CODE <>'0'\n" +
                        "AND LHDP.LOCN_CLASS = 'C'\n" +
                        "and WMI.ON_HAND_QTY > 1\n" +
                        "and (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) > 1\n" +
                        "AND PLH.INVN_LOCK_CODE IS NULL\n" +
                        "--and WMI.ON_HAND_QTY = (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY)\n" +
                        "AND LHDP.ZONE BETWEEN 42 AND 43 \n" +
                        "AND ICB.ITEM_NAME NOT IN (  " +
                        "and Rownum < 2";

                arrSQL = new String[]{sql1};
                break;

            case "OB_1014_PW03AT_HP_13_SW_INT3_Replen_from_Cart_Pick_Packs":
                sql1 = "select * from (select lhdp.dsp_locn, lhdp.sku_dedctn_type, lhdp.locn_pick_seq, icb.item_name, icb.item_id,\n" +
                        "WMI.ON_HAND_QTY, WMI.WM_ALLOCATED_QTY, WMI.TO_BE_FILLED_QTY, (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) AS ALLOCATABLE_QTY\n" +
                        ",CBO.QUANTITY QTY\n" +
                        ",PLD.MAX_INVN_QTY, PLD.MIN_INVN_QTY, PLD.CNTRY_OF_ORGN, PLD.SKU_ATTR_1 ITEM_ATTR_1 ,PLD.PROD_STAT, PLD.LOCN_SEQ_NBR  \n" +
                        "FROM PICK_LOCN_HDR PLH, LOCN_HDR LHDP, ITEM_CBO ICB, PICK_LOCN_DTL PLD, WM_INVENTORY WMI , ITEM_PACKAGE_CBO CBO\n" +
                        "where lhdp.locn_id = plh.locn_id \n" +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id\n" +
                        "AND PLD.ITEM_ID = ICB.ITEM_ID\n" +
                        "AND CBO.ITEM_ID = icb.ITEM_ID \n" +
                        "AND CBO.PACKAGE_UOM_ID='26' \n" +
                        "AND CBO.IS_STD='1'\n" +
                        "AND WMI.LOCATION_ID = PLH.LOCN_ID\n" +
                        "--and lhdp.sku_dedctn_type = 'P'\n" +
                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001 \n" +
                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001\n" +
                        "AND ICB.ITEM_BAR_CODE <>'0'\n" +
                        "AND LHDP.LOCN_CLASS = 'C'\n" +
                        "and WMI.ON_HAND_QTY > 1\n" +
                        "and (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) > 1\n" +
                        "AND PLH.INVN_LOCK_CODE IS NULL\n" +
                        "AND ICB.ITEM_NAME NOT IN (  " +
                       // "--and WMI.ON_HAND_QTY = (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY)\n" +
                        "AND LHDP.ZONE BETWEEN 42 AND 43  \n" +
                        "and CBO.QUANTITY < (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY))\n" +
                        "where Rownum < 2";

                arrSQL = new String[]{sql1};
                break;

            case "OB_1014_PW03AT_HP_14_SW_INT3_Replen_from_Order_Pick_Non_Packs":
                sql1 = "select lhdp.dsp_locn, lhdp.sku_dedctn_type, lhdp.locn_pick_seq, icb.item_name, \n" +
                        "WMI.ON_HAND_QTY, WMI.WM_ALLOCATED_QTY, WMI.TO_BE_FILLED_QTY, (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) AS ALLOCATABLE_QTY\n" +
                        ",LEAST ((SELECT CB1.QUANTITY FROM ITEM_PACKAGE_CBO CB1 WHERE CB1.ITEM_ID = icb.ITEM_ID AND CB1.PACKAGE_UOM_ID='25'),\n" +
                        "(WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY)) - 1 AS QTY\n" +
                        ", PLD.MAX_INVN_QTY, PLD.MIN_INVN_QTY, PLD.CNTRY_OF_ORGN, PLD.SKU_ATTR_1 ITEM_ATTR_1 ,PLD.PROD_STAT, PLD.LOCN_SEQ_NBR  \n" +
                        "FROM PICK_LOCN_HDR PLH, LOCN_HDR LHDP, ITEM_CBO ICB, PICK_LOCN_DTL PLD, WM_INVENTORY WMI\n" +
                        "where lhdp.locn_id = plh.locn_id \n" +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id\n" +
                        "AND PLD.ITEM_ID = ICB.ITEM_ID\n" +
                        "AND NOT EXISTS (SELECT 1 FROM ITEM_PACKAGE_CBO CB WHERE CB.ITEM_ID = icb.ITEM_ID AND PACKAGE_UOM_ID='26' AND IS_STD='1')\n" +
                        "AND WMI.LOCATION_ID = PLH.LOCN_ID\n" +
                        "--and lhdp.sku_dedctn_type = 'P'\n" +
                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001 \n" +
                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001\n" +
                        "AND ICB.ITEM_BAR_CODE <>'0'\n" +
                        "AND LHDP.LOCN_CLASS = 'C'\n" +
                        "and WMI.ON_HAND_QTY > 1\n" +
                        "and (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) > 1\n" +
                        "AND PLH.INVN_LOCK_CODE IS NULL\n" +
                        "--and WMI.ON_HAND_QTY = (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY)\n" +
                        "AND LHDP.ZONE =41\n" +
                        "AND LHDP.AISLE BETWEEN '01' AND '78'\n" +
                        "and icb.ITEM_NAME NOT IN ( " +
                        "and Rownum < 2" ;

                arrSQL = new String[]{sql1};
                break;

            case "OB_1014_PW03AT_HP_15_SW_INT3_Replen_from_Order_Pick_Packs":
                sql1 = "select lhdp.dsp_locn, lhdp.sku_dedctn_type, lhdp.locn_pick_seq, icb.item_name, \n" +
                        "WMI.ON_HAND_QTY, WMI.WM_ALLOCATED_QTY, WMI.TO_BE_FILLED_QTY, (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) AS ALLOCATABLE_QTY\n" +
                        ",LEAST ((SELECT CB1.QUANTITY FROM ITEM_PACKAGE_CBO CB1 WHERE CB1.ITEM_ID = icb.ITEM_ID AND CB1.PACKAGE_UOM_ID='25'),\n" +
                        "(WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY)) - 1 AS QTY\n" +
                        ", PLD.MAX_INVN_QTY, PLD.MIN_INVN_QTY, PLD.CNTRY_OF_ORGN, PLD.SKU_ATTR_1 ITEM_ATTR_1 ,PLD.PROD_STAT, PLD.LOCN_SEQ_NBR  \n" +
                        "FROM PICK_LOCN_HDR PLH, LOCN_HDR LHDP, ITEM_CBO ICB, PICK_LOCN_DTL PLD, WM_INVENTORY WMI\n" +
                        "where lhdp.locn_id = plh.locn_id \n" +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id\n" +
                        "AND PLD.ITEM_ID = ICB.ITEM_ID\n" +
                        "AND  EXISTS (SELECT 1 FROM ITEM_PACKAGE_CBO CB WHERE CB.ITEM_ID = icb.ITEM_ID AND PACKAGE_UOM_ID='26' AND IS_STD='1')\n" +
                        "AND WMI.LOCATION_ID = PLH.LOCN_ID\n" +
                        "--and lhdp.sku_dedctn_type = 'P'\n" +
                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001 \n" +
                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001\n" +
                        "AND ICB.ITEM_BAR_CODE <>'0'\n" +
                        "AND LHDP.LOCN_CLASS = 'C'\n" +
                        "and WMI.ON_HAND_QTY > 1\n" +
                        "and (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) > 1\n" +
                        "AND PLH.INVN_LOCK_CODE IS NULL\n" +
                        "--and WMI.ON_HAND_QTY = (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY)\n" +
                        "AND LHDP.ZONE =41\n" +
                        "AND LHDP.AISLE BETWEEN '01' AND '78' \n" +
                        "and icb.ITEM_NAME NOT IN ( " +
                        "AND ROWNUM < 2";

                arrSQL = new String[]{sql1};
                break;

            case "OB_1014_PW03AT_HP_16_SW_Pick_Assign_Type_B_Grades":
                sql1 = "SELECT * FROM ( " +
                        "SELECT  LPN.ITEM_NAME,WMI.ITEM_ATTR_1,MIN(WMI.ON_HAND_QTY) -1 QTY  " +
                        "FROM LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB  " +
                        "where wmi.lpn_id = lpn.lpn_id " +
                        "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "AND ICB.ITEM_ID = WMI.ITEM_ID " +
                        "and icb.item_id = LPN.item_id " +
                        "and wmi.inbound_outbound_indicator = 'I' " +
                        "and wmi.allocatable = 'Y' " +
                        "AND LPN.LPN_FACILITY_STATUS='30' " +
                        "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN " +
                        "('22A','22B','23A','23B','24A','24B','26A','26B','PAL','SHT','DYR','29A','29B')) " +
                        "AND WMI.ITEM_ATTR_1='02000' " +
                        "AND NOT EXISTS (SELECT 1 FROM LPN_LOCK L WHERE L.LPN_ID = LPN.LPN_ID) " +
                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001  " +
                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001 " +
                        "AND ICB.ITEM_BAR_CODE <>'0' " +
                        "and NOT EXISTS (select 1 from PICK_LOCN_HDR PLH, LOCN_HDR LHD, PICK_LOCN_DTL PLD where  LHD.LOCN_ID = PLH.LOCN_ID  " +
                        "    AND PLD.PICK_LOCN_HDR_ID = PLH.PICK_LOCN_HDR_ID  " +
                        "    AND LHD.SKU_DEDCTN_TYPE = 'P' AND LHD.LOCN_CLASS = 'C' AND PLH.INVN_LOCK_CODE IS NULL AND PLD.SKU_ATTR_1='02000' " +
                        "    AND PLD.ITEM_ID = LPN.ITEM_ID) " +
                        "AND WMI.ON_HAND_QTY > 1 " +
                        "AND LPN.ITEM_NAME IS NOT NULL " +
                        "and icb.ITEM_NAME NOT IN ( " +
                        "GROUP BY LPN.ITEM_NAME, WMI.ITEM_ATTR_1) A " +
                        "WHERE ROWNUM < 2";

                arrSQL = new String[]{sql1};
                break;

            case "OB_1014_PW03AT_HP_17_SW_Pick_Assign_Type_items_without_Permanent_Locn":
                sql1 = "SELECT * FROM ( " +
                        "SELECT  LPN.ITEM_NAME,WMI.ITEM_ATTR_1,MIN(WMI.ON_HAND_QTY) -1 QTY  " +
                        "FROM LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB  " +
                        "where wmi.lpn_id = lpn.lpn_id " +
                        "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "AND ICB.ITEM_ID = WMI.ITEM_ID " +
                        "and icb.item_id = LPN.item_id " +
                        "and wmi.inbound_outbound_indicator = 'I' " +
                        "and wmi.allocatable = 'Y' " +
                        "AND LPN.LPN_FACILITY_STATUS='30' " +
                        "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN " +
                        "('22A','22B','23A','23B','24A','24B','26A','26B','PAL','SHT','DYR','29A','29B')) " +
                        "AND WMI.ITEM_ATTR_1 <> '02000' " +
                        "AND NOT EXISTS (SELECT 1 FROM LPN_LOCK L WHERE L.LPN_ID = LPN.LPN_ID) " +
                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001  " +
                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001 " +
                        "AND ICB.ITEM_BAR_CODE <>'0' " +
                        "and NOT EXISTS (select 1 from PICK_LOCN_HDR PLH, LOCN_HDR LHD, PICK_LOCN_DTL PLD where  LHD.LOCN_ID = PLH.LOCN_ID  " +
                        "    AND PLD.PICK_LOCN_HDR_ID = PLH.PICK_LOCN_HDR_ID  " +
                        "    AND LHD.SKU_DEDCTN_TYPE = 'P' AND LHD.LOCN_CLASS = 'C' AND PLH.INVN_LOCK_CODE IS NULL AND PLD.ITEM_ID = LPN.ITEM_ID) " +
                        "AND WMI.ON_HAND_QTY > 1 " +
                        "AND LPN.ITEM_NAME IS NOT NULL " +
                        "and icb.ITEM_NAME NOT IN ( " +
                        "GROUP BY LPN.ITEM_NAME, WMI.ITEM_ATTR_1) A " +
                        "WHERE ROWNUM < 2";

                arrSQL = new String[]{sql1};
                break;


            case "OB_1014_PW03AT_HP_18_SW_Pick_Assign_Type_items_with_Permanent_Locn":
                sql1 = "SELECT * FROM ( " +
                        "SELECT  LPN.ITEM_NAME,WMI.ITEM_ATTR_1,MIN(WMI.ON_HAND_QTY) -1 QTY  " +
                        "FROM LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB  " +
                        "where wmi.lpn_id = lpn.lpn_id " +
                        "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "AND ICB.ITEM_ID = WMI.ITEM_ID " +
                        "and icb.item_id = LPN.item_id " +
                        "and wmi.inbound_outbound_indicator = 'I' " +
                        "and wmi.allocatable = 'Y' " +
                        "AND LPN.LPN_FACILITY_STATUS='30' " +
                        "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND " +
                        "PULL_ZONE IN('22A','22B','23A','23B','24A','24B','26A','26B','PAL','SHT','DYR','29A','29B')) " +
                        "AND WMI.ITEM_ATTR_1 <> '02000' " +
                        "AND NOT EXISTS (SELECT 1 FROM LPN_LOCK L WHERE L.LPN_ID = LPN.LPN_ID) " +
                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001  " +
                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001 " +
                        "AND ICB.ITEM_BAR_CODE <>'0' " +
                        "and EXISTS (select 1 from PICK_LOCN_HDR PLH, LOCN_HDR LHD, PICK_LOCN_DTL PLD where  LHD.LOCN_ID = PLH.LOCN_ID  " +
                        "    AND PLD.PICK_LOCN_HDR_ID = PLH.PICK_LOCN_HDR_ID  " +
                        "    AND LHD.SKU_DEDCTN_TYPE = 'P' AND LHD.LOCN_CLASS = 'C' AND PLH.INVN_LOCK_CODE IS NULL AND PLD.ITEM_ID = LPN.ITEM_ID) " +
                        "AND WMI.ON_HAND_QTY > 1 " +
                        "AND LPN.ITEM_NAME IS NOT NULL " +
                        "and icb.ITEM_NAME NOT IN ( " +
                        "GROUP BY LPN.ITEM_NAME, WMI.ITEM_ATTR_1) A " +
                        "WHERE ROWNUM < 2";

                arrSQL = new String[]{sql1};
                break;


            case "OB_1014_PW03AT_HP_19_SW_INT50_Sorter_Pick_from_Active":
                sql1 = "SELECT  LPN.TC_LPN_ID,LPN.LPN_FACILITY_STATUS,LPN.ITEM_NAME,WMI.CNTRY_OF_ORGN, " +
                        "WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,WMI.ON_HAND_QTY QTY  " +
                        "FROM LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB ,ITEM_WMS IW " +
                        "where wmi.lpn_id = lpn.lpn_id " +
                        "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "AND ICB.ITEM_ID = WMI.ITEM_ID " +
                        "AND ICB.ITEM_ID = LPN.ITEM_ID " +
                        "AND ICB.ITEM_ID=IW.ITEM_ID " +
                        "and wmi.inbound_outbound_indicator = 'I' " +
                        "and wmi.allocatable = 'Y' " +
                        "AND LPN.LPN_FACILITY_STATUS='30' " +
                        "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN " +
                        "('22A','22B','23A','23B','24A','24B','26A','26B','PAL','SHT','DYR','29A','29B')) " +
                        "AND WMI.ITEM_ATTR_1<>'02000' " +
                        "AND NOT EXISTS (SELECT 1 FROM LPN_LOCK L WHERE L.LPN_ID = LPN.LPN_ID) " +
                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001  " +
                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001 " +
                        "AND ICB.ITEM_BAR_CODE <>'0' " +
                        "AND IW.SPL_INSTR_CODE_10 IN ('FT','AP','MX') " +
                        "AND WMI.ON_HAND_QTY > 0 " +
                        "and icb.ITEM_NAME NOT IN ( " +
                        "and Rownum < 2";

                arrSQL = new String[]{sql1};
                break;

            case "OB_1014_PW03AT_HP_20_DW_INT2_TaskCr_FullPall_from_PallResv":
                sql1 = "SELECT * FROM (\n" +
                        "SELECT  LPN.TC_PARENT_LPN_ID--,LPN2.LPN_FACILITY_STATUS\n" +
                        ",LPN.ITEM_NAME--,LPN.LPN_FACILITY_STATUS\n" +
                        ",WMI.CNTRY_OF_ORGN, \n" +
                        "WMI.ITEM_ATTR_1, LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,SUM(WMI.ON_HAND_QTY)  QTY , SUM (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) ALLOCATABLE_QTY\n" +
                        "FROM LPN LPN,LPN LPN2\n" +
                        ", WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB \n" +
                        "where wmi.lpn_id = lpn.lpn_id\n" +
                        "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID\n" +
                        "AND ICB.ITEM_ID = WMI.ITEM_ID\n" +
                        "and icb.item_id = LPN.item_id\n" +
                        "and wmi.inbound_outbound_indicator = 'I'\n" +
                        "and wmi.allocatable = 'Y'\n" +
                        "AND LPN.TC_PARENT_LPN_ID IS NOT NULL \n" +
                        "--AND LPN.LPN_FACILITY_STATUS='30'\n" +
                        "AND LPN2.TC_LPN_ID=LPN.TC_PARENT_LPN_ID\n" +
                        "--AND LPN2.lpn_facility_status='30\n" +
                        "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN ('PAL','B12','BAB'))\n" +
                        "AND NOT EXISTS (SELECT 1 FROM LPN_LOCK L WHERE L.LPN_ID = LPN.LPN_ID)\n" +
                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001 \n" +
                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001\n" +
                        "AND ICB.ITEM_BAR_CODE <>'0'\n" +
                        "AND LPN.ITEM_NAME NOT IN (  " +
                        "GROUP BY (LPN.TC_PARENT_LPN_ID\n" +
                        "--,LPN2.lpn_facility_status\n" +
                        ",LPN.ITEM_NAME--,LPN.LPN_FACILITY_STATUS\n" +
                        ",WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ) \n" +
                        "ORDER BY LPN.ITEM_NAME,WMI.CNTRY_OF_ORGN,SUM(WMI.ON_HAND_QTY)) AA\n" +
                        "WHERE AA.QTY > 0\n" +
                        "AND AA.QTY = AA.ALLOCATABLE_QTY\n" +
                        "AND ROWNUM < 2";

                arrSQL = new String[]{sql1};
                break;

            case "OB_1014_PW03AT_HP_21_DW_INT2_Alloc_TaskCr_FullPall_from_PallResv_VAS":
                sql1 = "SELECT * FROM (\n" +
                        "SELECT  LPN.TC_PARENT_LPN_ID--,LPN2.LPN_FACILITY_STATUS\n" +
                        ",LPN.ITEM_NAME--,LPN.LPN_FACILITY_STATUS\n" +
                        ",WMI.CNTRY_OF_ORGN, \n" +
                        "WMI.ITEM_ATTR_1, LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,SUM(WMI.ON_HAND_QTY)  QTY , SUM (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) ALLOCATABLE_QTY\n" +
                        "FROM LPN LPN,LPN LPN2\n" +
                        ", WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB \n" +
                        "where wmi.lpn_id = lpn.lpn_id\n" +
                        "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID\n" +
                        "AND ICB.ITEM_ID = WMI.ITEM_ID\n" +
                        "and icb.item_id = LPN.item_id\n" +
                        "and wmi.inbound_outbound_indicator = 'I'\n" +
                        "and wmi.allocatable = 'Y'\n" +
                        "AND LPN.TC_PARENT_LPN_ID IS NOT NULL \n" +
                        "--AND LPN.LPN_FACILITY_STATUS='30'\n" +
                        "AND LPN2.TC_LPN_ID=LPN.TC_PARENT_LPN_ID\n" +
                        "--AND LPN2.lpn_facility_status='30\n" +
                        "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN ('PAL','B12','BAB'))\n" +
                        "AND NOT EXISTS (SELECT 1 FROM LPN_LOCK L WHERE L.LPN_ID = LPN.LPN_ID)\n" +
                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001 \n" +
                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001\n" +
                        "AND ICB.ITEM_BAR_CODE <>'0'\n" +
                        "AND LPN.ITEM_NAME NOT IN (  " +
                        "GROUP BY (LPN.TC_PARENT_LPN_ID\n" +
                        "--,LPN2.lpn_facility_status\n" +
                        ",LPN.ITEM_NAME--,LPN.LPN_FACILITY_STATUS\n" +
                        ",WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1, LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ) \n" +
                        "ORDER BY LPN.ITEM_NAME,WMI.CNTRY_OF_ORGN,SUM(WMI.ON_HAND_QTY)) AA\n" +
                        "WHERE AA.QTY > 0\n" +
                        "AND AA.QTY = AA.ALLOCATABLE_QTY\n" +
                        "AND ROWNUM < 2";

                sql2 = "SELECT C.VAS_CODE,C.DESCRIPTION FROM C_VAS_INFO C WHERE C.SAP_ONLY <>'1' and C.c_vas_lvl='2'" ;

                arrSQL = new String[]{sql1,sql2};

                break;

            case "OB_1014_PW03AT_HP_22_DW_INT2_TaskCr_Cartons_from_Shv_towers":
                sql1 = "SELECT  LPN.TC_LPN_ID,LPN.LPN_FACILITY_STATUS,LPN.ITEM_NAME,WMI.CNTRY_OF_ORGN, " +
                        "WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,WMI.ON_HAND_QTY QTY  " +
                        "FROM LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB  " +
                        "where wmi.lpn_id = lpn.lpn_id " +
                        "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "AND ICB.ITEM_ID = WMI.ITEM_ID " +
                        "and icb.item_id = LPN.item_id " +
                        "and wmi.inbound_outbound_indicator = 'I' " +
                        "and wmi.allocatable = 'Y' " +
                        "AND LPN.LPN_FACILITY_STATUS='30' " +
                        "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN('SHT','DYR')) " +
                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001  " +
                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001 " +
                        "AND ICB.ITEM_BAR_CODE <>'0' " +
                        "AND WMI.ON_HAND_QTY > 0" +
                        "and icb.ITEM_NAME NOT IN ( " +
                        "AND ROWNUM < 2";

                arrSQL = new String[]{sql1};
                break;
            case "OB_1014_PW03AT_HP_23_DW_INT2_TaskCr_DW_Cartons_from_Shv_towers_VAS":
                sql1 = "SELECT  LPN.TC_LPN_ID,LPN.LPN_FACILITY_STATUS,LPN.ITEM_NAME,WMI.CNTRY_OF_ORGN, " +
                        "WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,WMI.ON_HAND_QTY QTY  " +
                        "FROM LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB  " +
                        "where wmi.lpn_id = lpn.lpn_id " +
                        "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "AND ICB.ITEM_ID = WMI.ITEM_ID " +
                        "and icb.item_id = LPN.item_id " +
                        "and wmi.inbound_outbound_indicator = 'I' " +
                        "and wmi.allocatable = 'Y' " +
                        "AND LPN.LPN_FACILITY_STATUS='30' " +
                        "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN('SHT','DYR')) " +
                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001  " +
                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001 " +
                        "AND ICB.ITEM_BAR_CODE <>'0' " +
                        "AND WMI.ON_HAND_QTY > 0" +
                        "and icb.ITEM_NAME NOT IN ( " +
                        "AND ROWNUM < 2";
                sql2 = "SELECT C.VAS_CODE,C.DESCRIPTION FROM C_VAS_INFO C WHERE C.SAP_ONLY <>'1' and C.c_vas_lvl='2'" ;

                arrSQL = new String[]{sql1,sql2};
                break;
            case "OB_1014_PW03AT_HP_24_DW_INT2_TaskCr_Cartons_from_CartonResv":
                sql1 = "SELECT  LPN.TC_LPN_ID,LPN.LPN_FACILITY_STATUS,LPN.ITEM_NAME,WMI.CNTRY_OF_ORGN, " +
                        "WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,WMI.ON_HAND_QTY QTY  " +
                        "FROM LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB  " +
                        "where wmi.lpn_id = lpn.lpn_id " +
                        "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "AND ICB.ITEM_ID = WMI.ITEM_ID " +
                        "and icb.item_id = LPN.item_id " +
                        "and wmi.inbound_outbound_indicator = 'I' " +
                        "and wmi.allocatable = 'Y' " +
                        "AND LPN.LPN_FACILITY_STATUS='30' " +
                        "AND LPN.TC_PARENT_LPN_ID IS NULL  " +
                        "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN('BAB','29B')) " +
                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001  " +
                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001 " +
                        "AND ICB.ITEM_BAR_CODE <>'0' " +
                        "and icb.ITEM_NAME NOT IN ( " +
                        "AND ROWNUM < 2";

                arrSQL = new String[]{sql1};
                break;

            case "OB_1014_PW03AT_HP_25_DW_INT2_TaskCr_Cartons_from_CartonResv_VAS":
                sql1 = "SELECT  LPN.TC_LPN_ID,LPN.LPN_FACILITY_STATUS,LPN.ITEM_NAME,WMI.CNTRY_OF_ORGN, " +
                        "WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,WMI.ON_HAND_QTY QTY  " +
                        "FROM LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB  " +
                        "where wmi.lpn_id = lpn.lpn_id " +
                        "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "AND ICB.ITEM_ID = WMI.ITEM_ID " +
                        "and icb.item_id = LPN.item_id " +
                        "and wmi.inbound_outbound_indicator = 'I' " +
                        "and wmi.allocatable = 'Y' " +
                        "AND LPN.LPN_FACILITY_STATUS='30' " +
                        "AND LPN.TC_PARENT_LPN_ID IS NULL  " +
                        "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID AND LOCN_CLASS = 'R' AND PULL_ZONE IN('BAB','29B')) " +
                        "AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001  " +
                        "AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001 " +
                        "AND ICB.ITEM_BAR_CODE <>'0' " +
                        "AND WMI.ON_HAND_QTY > 0" +
                        "and icb.ITEM_NAME NOT IN ( " +
                        "AND ROWNUM < 2";
                sql2 = "SELECT C.VAS_CODE,C.DESCRIPTION FROM C_VAS_INFO C WHERE C.SAP_ONLY <>'1' and C.c_vas_lvl='2'" ;

                arrSQL = new String[]{sql1,sql2};
                break;


            case "OB_1014_PW03AT_HP_26_DW_INT9_Carton_from_Carton_Reserves":
                sql1 = "SELECT  AA.ITEM_NAME, AA.ITEM_ATTR_1 , AA.QTY " +
                        "FROM ( " +
                        "SELECT  LPN.ITEM_NAME,WMI.ITEM_ATTR_1, MIN(WMI.ON_HAND_QTY)-1 QTY  " +
                        "FROM LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB  " +
                        "where wmi.lpn_id = lpn.lpn_id " +
                        "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "AND ICB.ITEM_ID = WMI.ITEM_ID " +
                        "and icb.item_id = LPN.item_id " +
                        "and wmi.inbound_outbound_indicator = 'I' " +
                        "and wmi.allocatable = 'Y' " +
                        "AND LPN.LPN_FACILITY_STATUS='30' " +
                        "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID  " +
                        "          AND LOCN_CLASS = 'R' AND PULL_ZONE IN('29A','29B','22A','22B','23A','23B','24A','24B','26A','26B')) " +
                        "AND NOT EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID  " +
                        "          AND LOCN_CLASS = 'R' AND PULL_ZONE IN('SHT','DYR')) " +
                        "AND NVL(ICB.UNIT_VOLUME,'') <> '0.0001'  " +
                        "AND NVL(ICB.UNIT_WEIGHT,'') <> '0.0001'  " +
                        "AND ICB.ITEM_BAR_CODE <>'0' " +
                        "and EXISTS (select 1 from PICK_LOCN_HDR PLH, LOCN_HDR LHD, PICK_LOCN_DTL PLD  " +
                        "  where PLD.ITEM_ID = LPN.ITEM_ID  " +
                        "  AND LHD.LOCN_ID = PLH.LOCN_ID  " +
                        "  AND PLD.PICK_LOCN_HDR_ID = PLH.PICK_LOCN_HDR_ID  " +
                        "  AND LHD.SKU_DEDCTN_TYPE = 'P' AND LHD.LOCN_CLASS = 'C'  " +
                        "  AND PLH.INVN_LOCK_CODE IS NULL)  " +
                        "AND WMI.ON_HAND_QTY  > 0 " +
                        "GROUP BY  LPN.ITEM_NAME,WMI.ITEM_ATTR_1 " +
                        ") AA , " +
                        " (select lhdp.dsp_locn, lhdp.sku_dedctn_type, lhdp.locn_pick_seq, icb.item_name,  " +
                        "WMI.ON_HAND_QTY, WMI.WM_ALLOCATED_QTY, WMI.TO_BE_FILLED_QTY,  " +
                        "(wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) as allocatable_qty, pld.max_invn_qty, pld.min_invn_qty, pld.cntry_of_orgn, pld.sku_attr_1,pld.prod_stat, pld.locn_seq_nbr   " +
                        "from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi where  " +
                        "lhdp.locn_id = plh.locn_id  " +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id " +
                        "and pld.item_id = icb.item_id " +
                        "and wmi.location_id = plh.locn_id " +
                        "and lhdp.sku_dedctn_type = 'P' " +
                        "and lhdp.locn_class = 'C' " +
                        "AND PLH.INVN_LOCK_CODE IS NULL ) BB " +
                        "WHERE AA.ITEM_NAME = BB.ITEM_NAME " +
                        "AND AA.ITEM_ATTR_1 = BB.SKU_ATTR_1 " +
                        "AND AA.QTY > BB.allocatable_qty  " +
                        "and AA.ITEM_NAME NOT IN ( " +
                        " and AA.ITEM_NAME != 'SX5705-102-M' " +
                        " and AA.ITEM_NAME = '511881-026-10.5' " +
                        "AND ROWNUM < 2";

                arrSQL = new String[]{sql1};
                break;


            case "OB_1014_PW03AT_HP_27_DW_INT9_Carton_from_Shave":
                sql1 = "SELECT  AA.ITEM_NAME, AA.ITEM_ATTR_1 , AA.QTY " +
                        "FROM ( " +
                        "SELECT  LPN.ITEM_NAME,WMI.ITEM_ATTR_1, MIN(WMI.ON_HAND_QTY)-1 QTY  " +
                        "FROM LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB  " +
                        "where wmi.lpn_id = lpn.lpn_id " +
                        "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "AND ICB.ITEM_ID = WMI.ITEM_ID " +
                        "and icb.item_id = LPN.item_id " +
                        "and wmi.inbound_outbound_indicator = 'I' " +
                        "and wmi.allocatable = 'Y' " +
                        "AND LPN.LPN_FACILITY_STATUS='30' " +
                        "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID  " +
                        "          AND LOCN_CLASS = 'R' AND PULL_ZONE IN('SHT')) " +
                        "AND NVL(ICB.UNIT_VOLUME,'') <> '0.0001'  " +
                        "AND NVL(ICB.UNIT_WEIGHT,'') <> '0.0001'  " +
                        "AND ICB.ITEM_BAR_CODE <>'0' " +
                        "and EXISTS (select 1 from PICK_LOCN_HDR PLH, LOCN_HDR LHD, PICK_LOCN_DTL PLD  " +
                        "  where PLD.ITEM_ID = LPN.ITEM_ID  " +
                        "  AND LHD.LOCN_ID = PLH.LOCN_ID  " +
                        "  AND PLD.PICK_LOCN_HDR_ID = PLH.PICK_LOCN_HDR_ID  " +
                        "  AND LHD.SKU_DEDCTN_TYPE = 'P' AND LHD.LOCN_CLASS = 'C'  " +
                        "  AND PLH.INVN_LOCK_CODE IS NULL)  " +
                        "AND WMI.ON_HAND_QTY  > 0 " +
                        "GROUP BY  LPN.ITEM_NAME,WMI.ITEM_ATTR_1 " +
                        ") AA , " +
                        " (select lhdp.dsp_locn, lhdp.sku_dedctn_type, lhdp.locn_pick_seq, icb.item_name,  " +
                        "WMI.ON_HAND_QTY, WMI.WM_ALLOCATED_QTY, WMI.TO_BE_FILLED_QTY,  " +
                        "(wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) as allocatable_qty, pld.max_invn_qty, pld.min_invn_qty, pld.cntry_of_orgn, pld.sku_attr_1,pld.prod_stat, pld.locn_seq_nbr   " +
                        "from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi where  " +
                        "lhdp.locn_id = plh.locn_id  " +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id " +
                        "and pld.item_id = icb.item_id " +
                        "and wmi.location_id = plh.locn_id " +
                        "and lhdp.sku_dedctn_type = 'P' " +
                        "and lhdp.locn_class = 'C' " +
                        "AND PLH.INVN_LOCK_CODE IS NULL ) BB " +
                        "WHERE AA.ITEM_NAME = BB.ITEM_NAME " +
                        "AND AA.ITEM_ATTR_1 = BB.SKU_ATTR_1 " +
                        "AND AA.QTY > BB.allocatable_qty  " +
                        "and AA.ITEM_NAME NOT IN ( " +
                        "AND ROWNUM < 2";

                arrSQL = new String[]{sql1};
                break;


            case "OB_1014_PW03AT_HP_28_DW_INT9_Pallets_From_Reserves":
                sql1 = "SELECT  AA.ITEM_NAME, AA.ITEM_ATTR_1 , AA.QTY\n" +
                        "FROM (\n" +
                        "SELECT  LPN.ITEM_NAME,WMI.ITEM_ATTR_1,WMI.ON_HAND_QTY-1 QTY \n" +
                        "FROM LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD, ITEM_CBO ICB \n" +
                        "where wmi.lpn_id = lpn.lpn_id\n" +
                        "AND LHD.LOCN_ID = LPN.CURR_SUB_LOCN_ID\n" +
                        "AND ICB.ITEM_ID = WMI.ITEM_ID\n" +
                        "and icb.item_id = LPN.item_id\n" +
                        "and wmi.inbound_outbound_indicator = 'I'\n" +
                        "and wmi.allocatable = 'Y'\n" +
                        "AND LPN.LPN_FACILITY_STATUS='30'\n" +
                        "AND EXISTS (SELECT 1 FROM LOCN_HDR LH WHERE LH.LOCN_ID = LPN.CURR_SUB_LOCN_ID \n" +
                        "          AND LOCN_CLASS = 'R' AND PULL_ZONE IN ('B12','BAB','PAL'))\n" +
                        "AND NVL(ICB.UNIT_VOLUME,'') <> '0.0001' \n" +
                        "AND NVL(ICB.UNIT_WEIGHT,'') <> '0.0001' \n" +
                        "AND ICB.ITEM_BAR_CODE <>'0'\n" +
                        "and EXISTS (select 1 from PICK_LOCN_HDR PLH, LOCN_HDR LHD, PICK_LOCN_DTL PLD \n" +
                        "  where PLD.ITEM_ID = LPN.ITEM_ID \n" +
                        "  AND LHD.LOCN_ID = PLH.LOCN_ID \n" +
                        "  AND PLD.PICK_LOCN_HDR_ID = PLH.PICK_LOCN_HDR_ID \n" +
                        "  AND LHD.SKU_DEDCTN_TYPE = 'P' AND LHD.LOCN_CLASS = 'C' \n" +
                        "  AND PLH.INVN_LOCK_CODE IS NULL) \n" +
                        "AND WMI.ON_HAND_QTY  > 1\n" +
                        "AND (SELECT COUNT(LPN1.LPN_ID)\n" +
                        "FROM LPN LPN1, WM_INVENTORY WMI1, LOCN_HDR LHD1, ITEM_CBO ICB1 \n" +
                        "where WMI1.ITEM_ID = WMI.ITEM_ID\n" +
                        "AND wmi1.lpn_id = lpn1.lpn_id\n" +
                        "AND LHD1.LOCN_ID = LPN1.CURR_SUB_LOCN_ID\n" +
                        "AND ICB1.ITEM_ID = WMI1.ITEM_ID\n" +
                        "and icb1.item_id = LPN1.item_id\n" +
                        "and wmi1.inbound_outbound_indicator = 'I'\n" +
                        "and wmi1.allocatable = 'Y'\n" +
                        "AND LPN1.LPN_FACILITY_STATUS='30'\n" +
                        "AND EXISTS (SELECT 1 FROM LOCN_HDR LH1 WHERE LH1.LOCN_ID = LPN1.CURR_SUB_LOCN_ID \n" +
                        "          AND LH1.LOCN_CLASS = 'R' AND LH1.PULL_ZONE IN ('B12','BAB','PAL'))\n" +
                        "AND NVL(ICB1.UNIT_VOLUME,'') <> '0.0001' \n" +
                        "AND NVL(ICB1.UNIT_WEIGHT,'') <> '0.0001' \n" +
                        "AND ICB1.ITEM_BAR_CODE <>'0'\n" +
                        "and EXISTS (select 1 from PICK_LOCN_HDR PLH1, LOCN_HDR LHD1, PICK_LOCN_DTL PLD1 \n" +
                        "  where PLD1.ITEM_ID = LPN1.ITEM_ID \n" +
                        "  AND LHD1.LOCN_ID = PLH1.LOCN_ID \n" +
                        "  AND PLD1.PICK_LOCN_HDR_ID = PLH1.PICK_LOCN_HDR_ID \n" +
                        "  AND LHD1.SKU_DEDCTN_TYPE = 'P' AND LHD1.LOCN_CLASS = 'C' \n" +
                        "  AND PLH1.INVN_LOCK_CODE IS NULL) \n" +
                        "AND WMI1.ON_HAND_QTY  > 1 ) > 1\n" +
                        "\n" +
                        ") AA ,\n" +
                        " (select lhdp.dsp_locn, lhdp.sku_dedctn_type, lhdp.locn_pick_seq, icb.item_name, \n" +
                        "WMI.ON_HAND_QTY, WMI.WM_ALLOCATED_QTY, WMI.TO_BE_FILLED_QTY, \n" +
                        "(wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) as allocatable_qty, pld.max_invn_qty, pld.min_invn_qty, pld.cntry_of_orgn, pld.sku_attr_1,pld.prod_stat, pld.locn_seq_nbr  \n" +
                        "from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi where \n" +
                        "lhdp.locn_id = plh.locn_id \n" +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id\n" +
                        "and pld.item_id = icb.item_id\n" +
                        "and wmi.location_id = plh.locn_id\n" +
                        "and lhdp.sku_dedctn_type = 'P'\n" +
                        "and lhdp.locn_class = 'C'\n" +
                        "AND PLH.INVN_LOCK_CODE IS NULL ) BB\n" +
                        "WHERE AA.ITEM_NAME = BB.ITEM_NAME\n" +
                        "AND AA.ITEM_ATTR_1 = BB.SKU_ATTR_1\n" +
                        "AND (AA.QTY * 2) > BB.allocatable_qty \n" +
                        "AND ROWNUM < 3";

                arrSQL = new String[]{sql1};
                break;


            case "OB_1014_PW03AT_HP_29_DW_INT51_Discrete_Pick":
                sql1 = "select lhdp.dsp_locn, lhdp.sku_dedctn_type, lhdp.locn_pick_seq, icb.item_name, \n" +
                        "WMI.ON_HAND_QTY, (WMI.ON_HAND_QTY - 1)  as QTY,WMI.WM_ALLOCATED_QTY, WMI.TO_BE_FILLED_QTY, (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) AS ALLOCATABLE_QTY\n" +
                        ", PLD.MAX_INVN_QTY, PLD.MIN_INVN_QTY, PLD.CNTRY_OF_ORGN, PLD.SKU_ATTR_1 as ITEM_ATTR_1,PLD.PROD_STAT, PLD.LOCN_SEQ_NBR  \n" +
                        "FROM PICK_LOCN_HDR PLH, LOCN_HDR LHDP, ITEM_CBO ICB, PICK_LOCN_DTL PLD, WM_INVENTORY WMI\n" +
                        "where lhdp.locn_id = plh.locn_id \n" +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id\n" +
                        "AND PLD.ITEM_ID = ICB.ITEM_ID\n" +
                        "AND WMI.LOCATION_ID = PLH.LOCN_ID\n" +
                        "and lhdp.sku_dedctn_type = 'P'\n" +
                        "AND LHDP.LOCN_CLASS = 'C'\n" +
                        "AND PLH.INVN_LOCK_CODE IS NULL\n" +
                        "AND EXISTS (SELECT 1 FROM ITEM_CBO ICB \n" +
                        "            WHERE ICB.ITEM_ID = WMI.ITEM_ID \n" +
                        "            AND NVL(ICB.UNIT_VOLUME,0.0001) <> 0.0001 \n" +
                        "            AND NVL(ICB.UNIT_WEIGHT,0.0001) <> 0.0001\n" +
                        "            AND ICB.ITEM_BAR_CODE <>'0' )\n" +
                        "AND LHDP.ZONE BETWEEN '47' AND '49'\n" +
                        "AND (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) > 0\n" +
                        "and WMI.ON_HAND_QTY = (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY)\n" +
                        "and icb.ITEM_NAME NOT IN ( " +
                        "and rownum < 2";

                arrSQL = new String[]{sql1};
                break;


            case "OB_1014_PW03AT_HP_30_DW_INT19_R2R_Shave_Towers":
                sql1 = "SELECT (select item_name from item_cbo where item_id = wi.item_id " +
                        "and ITEM_NAME NOT IN (  " +
                        " )item_name, locn_brcd  " +
                        "from locn_hdr lh, WM_INVENTORY wi  " +
                        "where lh.locn_class = 'R'  " +
                        "AND lh.SKU_DEDCTN_TYPE = 'P'  " +
                        "and wi.LOCATION_ID = lh.locn_id  " +
                        "and wi.ON_HAND_QTY > 0  " +
                        "and EXISTS " +
                        "(SELECT 1  " +
                        "from ITEM_PACKAGE_CBO ipc, SIZE_UOM su, PUTWY_ZONE_ITEM pzi,ITEM_CBO IC  " +
                        "where ic.ITEM_ID = wi.item_id " +
                        "and IPC.PACKAGE_UOM_ID= SU.SIZE_UOM_ID  " +
                        "AND SU.TC_COMPANY_ID = 1  " +
                        "and exists " +
                        "(SELECT 1 ITEM_ID  " +
                        "from ITEM_FACILITY_MAPPING_WMS W  " +
                        "where  W.ITEM_ID = ipc.ITEM_ID  " +
                        "and PUTWY_TYPE = 'SHT')  " +
                        "and su.DESCRIPTION like 'Palle%'  " +
                        "and pzi.ITEM_ID = ipc.ITEM_ID  " +
                        "and ic.ITEM_ID = ipc.ITEM_ID)";

                arrSQL = new String[]{sql1};
                break;

        }
        return arrSQL;
    }
}