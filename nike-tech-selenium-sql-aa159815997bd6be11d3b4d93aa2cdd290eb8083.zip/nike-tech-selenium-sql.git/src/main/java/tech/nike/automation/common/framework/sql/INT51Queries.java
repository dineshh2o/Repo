package tech.nike.automation.common.framework.sql;

/**
 * Created by psibb1 on 8/18/2016.
 */
public class INT51Queries {

    public static String[] getQuery(String strTestCaseName) {
        String[] arrSQL = {};
        switch (strTestCaseName) {
            case "OB_1064_PW03AT_HP_10_INT51_Low_Volume_PROMO_NEW":
                String sql1 = "select LPN.TC_PARENT_LPN_ID, LPN.TC_LPN_ID, LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN," +
                        " WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN,LHD.LOCN_PICK_SEQ, WMI.ON_HAND_QTY QTY" +
                        " from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD,RESV_LOCN_HDR RLH" +
                        " where WMI.LPN_ID = LPN.LPN_ID" +
                        " and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID" +
                        " and lhd.locn_id = lpn.curr_sub_locn_id" +
                        " and wmi.inbound_outbound_indicator = 'I'" +
                        " and (WMI.ON_HAND_QTY) > 0"+
                        " and wmi.allocatable = 'Y'" +
                        " and lpn.lpn_facility_status='30'" +
                        " and lpn.tc_parent_lpn_id is not null" +
                        " and RLH.INVN_LOCK_CODE is null" +
                        " and LPN.CURR_SUB_LOCN_ID in (select LOCN_ID from LOCN_HDR where LOCN_CLASS = 'R'" +
                        " and PULL_ZONE IN('HG2','HP2'))" +
                        " and lpn.lpn_id not in (select lpn_id from lpn_lock)" +
                        " and LPN.ITEM_ID in (select PLD.ITEM_ID from PICK_LOCN_HDR PLH, LOCN_HDR LHD," +
                        " PICK_LOCN_DTL PLD where  LHD.LOCN_ID = PLH.LOCN_ID and " +
                        " PLD.PICK_LOCN_HDR_ID = PLH.PICK_LOCN_HDR_ID" +
                        " and LHD.SKU_DEDCTN_TYPE = 'P' and LHD.LOCN_CLASS = 'C' and PLH.INVN_LOCK_CODE is null)" +
                        " order by lpn.item_name, wmi.cntry_of_orgn, wmi.item_attr_1,LHD.PULL_ZONE," +
                        " wmi.on_hand_qty desc, lhd.locn_pick_seq";

                String sql2 = "select lhdp.dsp_locn, lhdp.sku_dedctn_type, lhdp.locn_pick_seq, icb.item_name," +
                        " wmi.on_hand_qty, wmi.wm_allocated_qty, wmi.to_be_filled_qty," +
                        " (wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) as allocatable_qty," +
                        " pld.max_invn_qty, pld.min_invn_qty, pld.cntry_of_orgn, pld.sku_attr_1, pld.locn_seq_nbr" +
                        " from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi where" +
                        " lhdp.locn_id = plh.locn_id" +
                        " and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id" +
                        " and pld.item_id = icb.item_id" +
                        " and wmi.location_id = plh.locn_id" +
                        " and lhdp.sku_dedctn_type = 'P'" +
                        " and lhdp.locn_class = 'C'" +
                        " and (wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) > 0"+
                        " and LHDP.pick_DETRM_ZONE<>'002'" +
                        " and PLH.INVN_LOCK_CODE is null" +
                        " and ICB.ITEM_NAME = '" + System.getProperty("ITEM_NAME") + "'" +
                        " and PLD.CNTRY_OF_ORGN = '" + System.getProperty("CNTRY_OF_ORGN") + "'" +
                        " and PLD.SKU_ATTR_1= '" + System.getProperty("ITEM_ATTR_1") + "'";
                arrSQL = new String[]{sql1, sql2};
                break;

            case "OB_1064_PW03AT_HP_19_INT51_Alloc_and_Task_Creation_equip_VAS_4_Multi_NEW":
                String sql3 = "select lhdp.dsp_locn, lhdp.sku_dedctn_type, lhdp.locn_pick_seq, icb.item_name," +
                        " (wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) as allocatable_qty," +
                        " pld.max_invn_qty, pld.min_invn_qty, pld.cntry_of_orgn, pld.sku_attr_1, pld.locn_seq_nbr" +
                        " from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi where" +
                        " lhdp.locn_id = plh.locn_id" +
                        " and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id" +
                        " and (wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) > 0"+
                        " and PLD.ITEM_ID = ICB.ITEM_ID" +
                        " and WMI.LOCATION_ID = PLH.LOCN_ID" +
                        " and LHDP.LOCN_CLASS = 'C'" +
                        " and lhdp.sku_dedctn_type = 'P'" +
                        " and ICB.ITEM_BAR_CODE <>'0'" +
                        " and PLH.INVN_LOCK_CODE is null" +
                        " and WMI.ON_HAND_QTY <>'0'" +
                        " and LHDP.PICK_DETRM_ZONE='001'";
                arrSQL = new String[]{sql3};
                break;

            case "OB_1064NDC_PW03AT_HP_39_INT51_INT2_Task_Creation_NEW":
                String sql4 = "select LHDP.DSP_LOCN, LHDP.SKU_DEDCTN_TYPE, ICB.ITEM_NAME," +
                        " (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) as ALLOCATABLE_QTY," +
                        " PLD.MAX_INVN_QTY,icb.unit_volume,icb.unit_weight," +
                        " pld.min_invn_qty, pld.cntry_of_orgn, pld.sku_attr_1 ,wmi.ITEM_ATTR_1,wmi.cntry_of_orgn" +
                        " from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi" +
                        " where lhdp.locn_id = plh.locn_id" +
                        " and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id" +
                        " and pld.item_id = icb.item_id" +
                        " and WMI.LOCATION_ID = PLH.LOCN_ID" +
                        " and LHDP.LOCN_CLASS = 'C'" +
                        " and lhdp.sku_dedctn_type = 'P'" +
                        " and ICB.ITEM_BAR_CODE <>'0'" +
                        " and ICB.ITEM_NAME not in ('883819-002-8.5','631261-310-4')"+
                        " and plh.invn_lock_code is null" +
                        " and (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) > 0"+
                        " and wmi.on_hand_qty <>'0' " +
                        " and icb.item_id not in (select item_id from item_package_cbo where package_uom_id='26')" +
                        " and ICB.UNIT_VOLUME IS NOT NULL AND ICB.UNIT_WEIGHT IS NOT NULL  and" +
                        " ICB.UNIT_LENGTH IS NOT NULL AND ICB.UNIT_WIDTH IS NOT NULL AND ICB.UNIT_HEIGHT IS NOT NULL" +
                        " and icb.unit_volume <>'0.0001' and icb.unit_weight <>'0.0001'" +
                        " and ICB.ITEM_BAR_CODE <>'0'" +
                        " order by icb.unit_volume,icb.unit_weight";

                String sql5 = "SELECT FACILITY_ALIAS_ID as customer,FAC.COUNTRY_CODE FROM FACILITY_ALIAS FA,FACILITY FAC" +
                        " WHERE FA.FACILITY_ID = FAC.FACILITY_ID AND FA.FACILITY_ALIAS_ID" +
                        " IN(SELECT OTMP.TC_ORDER_ID FROM ORDER_NOTE_TEMPLATE ONT,ORDERS_TEMPLATE OTMP" +
                        " WHERE OTMP.ORDER_ID = ONT.ORDER_ID AND NOTE_TYPE='PG' AND NOTE='CO' )" +
                        " AND FA.FACILITY_ALIAS_ID IN(SELECT OTMP.TC_ORDER_ID FROM ORDER_NOTE_TEMPLATE ONT,ORDERS_TEMPLATE OTMP" +
                        " WHERE  OTMP.ORDER_ID = ONT.ORDER_ID AND NOTE_TYPE='GF' AND NOTE='Y' )" +
                        " AND FAC. FACILITY_TYPE_BITS='64'" +
                        " AND FA.FACILITY_ID NOT IN (SELECT FACILITY_ID FROM FACILITY_NOTE WHERE FACILITY_NOTE_TYPE='2' AND NOTE='1')" +
                        " AND FAC.COUNTRY_CODE IN(SELECT COUNTRY_CODE FROM COUNTRY WHERE CNTRY_ID IS NULL)";
                arrSQL = new String[]{sql4, sql5};
                break;

            case "OB_1064NDC_PW03AT_HP_37_INT51_3Box_Multi_Zone_Pick_Pass_Creation_NEW":
                String sql6 = "select lhdp.zone,LHDP.DSP_LOCN, ICB.ITEM_NAME, " +
                        "(WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) as ALLOCATABLE_QTY, " +
                        "PLD.MAX_INVN_QTY,pld.min_invn_qty, pld.cntry_of_orgn, pld.sku_attr_1  " +
                        "from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi " +
                        "where lhdp.locn_id = plh.locn_id  " +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id " +
                        "and pld.item_id = icb.item_id " +
                        "and WMI.LOCATION_ID = PLH.LOCN_ID " +
                        "and LHDP.LOCN_CLASS = 'C' " +
                        "and lhdp.sku_dedctn_type = 'P' " +
                        "and ICB.ITEM_BAR_CODE <>'0' " +
                        "and ICB.ITEM_NAME not in ('828404-006-9.5','749263-100-5.5') "+
                        "and plh.invn_lock_code is null " +
                        "and wmi.on_hand_qty >wmi.WM_ALLOCATED_QTY " +
                        "and icb.item_id not in (select item_id from item_package_cbo where package_uom_id='26') " +
                        "AND NVL(ICB.UNIT_VOLUME,'0.0001') <> '0.0001' " +
                        "AND NVL(ICB.UNIT_WEIGHT,'0.0001') <> '0.0001' " +
                        "AND NVL(ICB.UNIT_LENGTH,'0.0001') <> '0.0001' " +
                        "AND NVL(ICB.UNIT_WIDTH,'0.0001')  <> '0.0001' " +
                        "AND NVL(ICB.UNIT_HEIGHT,'0.0001') <> '0.0001' " +
                        "and ICB.ITEM_BAR_CODE <>'0' " +
                        "and lhdp.zone = '31' " +
                        "AND ROWNUM < 2 " +
                        "UNION " +
                        "select lhdp.zone,LHDP.DSP_LOCN, ICB.ITEM_NAME, " +
                        "(WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) as ALLOCATABLE_QTY, " +
                        "PLD.MAX_INVN_QTY,pld.min_invn_qty, pld.cntry_of_orgn, pld.sku_attr_1 " +
                        "from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi " +
                        "where lhdp.locn_id = plh.locn_id " +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id " +
                        "and pld.item_id = icb.item_id " +
                        "and WMI.LOCATION_ID = PLH.LOCN_ID " +
                        "and LHDP.LOCN_CLASS = 'C' " +
                        "and lhdp.sku_dedctn_type = 'P' " +
                        "and ICB.ITEM_BAR_CODE <>'0' " +
                        "and plh.invn_lock_code is null " +
                        "and wmi.on_hand_qty >wmi.WM_ALLOCATED_QTY " +
                        "and icb.item_id not in (select item_id from item_package_cbo where package_uom_id='26') " +
                        "AND NVL(ICB.UNIT_VOLUME,'0.0001') <> '0.0001' " +
                        "AND NVL(ICB.UNIT_WEIGHT,'0.0001') <> '0.0001' " +
                        "AND NVL(ICB.UNIT_LENGTH,'0.0001') <> '0.0001' " +
                        "AND NVL(ICB.UNIT_WIDTH,'0.0001')  <> '0.0001' " +
                        "AND NVL(ICB.UNIT_HEIGHT,'0.0001') <> '0.0001' " +
                        "and ICB.ITEM_BAR_CODE <>'0' " +
                        "and lhdp.zone = '32' " +
                        "and ROWNUM < 2";
                String sql7 = "SELECT VAS_CODE FROM C_VAS_INFO WHERE SAP_ONLY <>'1' and c_vas_lvl='2'";
                arrSQL = new String[]{sql6, sql7};
                break;

            case "OB_1064NDC_PW03AT_HP_33_INT51_casePickTaskCapacity_6LPNs":
                String sql8 = "select LHDP.DSP_LOCN, LHDP.SKU_DEDCTN_TYPE, ICB.ITEM_NAME, " +
                        "(WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) as ALLOCATABLE_QTY " +
                        ",PLD.MAX_INVN_QTY,icb.unit_volume,icb.unit_weight, " +
                        "pld.min_invn_qty, pld.cntry_of_orgn, pld.sku_attr_1   " +
                        "from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi " +
                        "where lhdp.locn_id = plh.locn_id  " +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id " +
                        "and pld.item_id = icb.item_id " +
                        "and WMI.LOCATION_ID = PLH.LOCN_ID " +
                        "and LHDP.LOCN_CLASS = 'C' " +
                        "and lhdp.sku_dedctn_type = 'P' " +
                        "and ICB.ITEM_BAR_CODE <>'0' " +
                        "and plh.invn_lock_code is null " +
                        "and wmi.on_hand_qty <>'0' " +
                        "and NVL(ICB.UNIT_VOLUME ,0.0001 ) <> 0.0001  " +
                        "and NVL(ICB.UNIT_HEIGHT ,0.0001 ) <> 0.0001  " +
                        "and ICB.UNIT_WEIGHT IS NOT NULL   " +
                        "and ICB.UNIT_LENGTH IS NOT NULL  " +
                        "and ICB.UNIT_WIDTH IS NOT NULL  " +
                        "and ICB.ITEM_BAR_CODE <>'0' " +
                        "and icb.unit_volume < ( select max(cn.MAX_CNTR_VOL ) from CNTR_TYPE cn where cn.CNTR_TYPE='DIG' " +
                        "and cn.cntr_size in ('D1','D2','DC','DY')) " +
                        "and icb.unit_weight < ( select max(cn.MAX_CNTR_WT ) from CNTR_TYPE cn where cn.CNTR_TYPE='DIG' " +
                        "and cn.cntr_size in ('D1','D2','DC','DY')) " +
                        "and rownum < 2";

                String sql9 = "select FAA.FACILITY_ALIAS_ID,FAA.FACILITY_NAME,FAC.ADDRESS_1, " +
                        "FAC.ADDRESS_2,FAC.CITY,FAC.COUNTRY_CODE,FAC.STATE_PROV,FAC.POSTAL_CODE,CN.CNTRY_ID " +
                        "from FACILITY FAC,FACILITY_ALIAS FAA,COUNTRY CN " +
                        "where FAC.FACILITY_ID=FAA.FACILITY_ID " +
                        "and FAC.FACILITY_TYPE_BITS='64' " +
                        "and FAC.COUNTRY_CODE = CN.COUNTRY_CODE " +
                        "and CN.CNTRY_ID is null " +
                        "and FAA.FACILITY_ALIAS_ID in " +
                        "(select SUBSTR(TC_ORDER_ID,2,length(TC_ORDER_ID)) from ORDERS_TEMPLATE where ORDER_ID in( " +
                        "select ORDER_ID  from ORDER_LINE_ITEM_TEMPLATE where LPN_TYPE ='DIG'))";

                arrSQL = new String[]{sql8, sql9};
                break;

            case "OB_1064NDC_PW03AT_HP_34_INT51_casePickTaskCapacity_3LPNs":
                String sql11 = "select LHDP.DSP_LOCN, LHDP.SKU_DEDCTN_TYPE, ICB.ITEM_NAME, " +
                        "(WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) as ALLOCATABLE_QTY " +
                        ",PLD.MAX_INVN_QTY,icb.unit_volume,icb.unit_weight, " +
                        "pld.min_invn_qty, pld.cntry_of_orgn, pld.sku_attr_1  ,  " +
                        " FLOOR( (select MAX(cn.MAX_CNTR_VOL) MAX_CNTR_VOL  from CNTR_TYPE cn " +
                        "where cn.CNTR_TYPE='CTN'and cn.cntr_size in ('01','02')) / icb.unit_volume ) QTY " +
                        "from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi " +
                        "where lhdp.locn_id = plh.locn_id  " +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id " +
                        "and pld.item_id = icb.item_id " +
                        "and WMI.LOCATION_ID = PLH.LOCN_ID " +
                        "and LHDP.LOCN_CLASS = 'C' " +
                        "and lhdp.sku_dedctn_type = 'P' " +
                        "and plh.invn_lock_code is null " +
                        "and wmi.on_hand_qty <> 0 " +
                        "and not exists (select 1 from item_package_cbo cb where cb.item_id = icb.item_id " +
                        "and cb.package_uom_id='26') " +
                        "and NVL(ICB.UNIT_VOLUME ,0.0001 ) <> 0.0001  " +
                        "and NVL(ICB.UNIT_HEIGHT ,0.0001 ) <> 0.0001  " +
                        "and ICB.UNIT_WEIGHT IS NOT NULL   " +
                        "AND ICB.UNIT_LENGTH IS NOT NULL  " +
                        "AND ICB.UNIT_WIDTH IS NOT NULL  " +
                        "and ICB.ITEM_BAR_CODE <>'0' " +
                        "and rownum < 2";

                String sql12 = "select FAA.FACILITY_ALIAS_ID,FAA.FACILITY_NAME,FAC.ADDRESS_1," +
                        "FAC.ADDRESS_2,FAC.CITY,FAC.COUNTRY_CODE,FAC.STATE_PROV,FAC.POSTAL_CODE,CN.CNTRY_ID " +
                        "from FACILITY FAC,FACILITY_ALIAS FAA,COUNTRY CN " +
                        "where FAC.FACILITY_ID=FAA.FACILITY_ID " +
                        "and FAC.FACILITY_TYPE_BITS='64' " +
                        "and FAC.COUNTRY_CODE = CN.COUNTRY_CODE " +
                        "and CN.CNTRY_ID is null " +
                        "and FAA.FACILITY_ALIAS_ID not in  " +
                        "(select SUBSTR(TC_ORDER_ID,2,length(TC_ORDER_ID)) from ORDERS_TEMPLATE where ORDER_ID in( " +
                        "select ORDER_ID  from ORDER_LINE_ITEM_TEMPLATE where LPN_TYPE in('DIG','')))";
                arrSQL = new String[]{sql11, sql12};
                break;

            case"OB_1064NDC_PW03AT_HP_35_INT51_Zone_Pick_Task_Creation_NEW":
                String sql14 = "select LHDP.DSP_LOCN, LHDP.SKU_DEDCTN_TYPE, ICB.ITEM_NAME, " +
                    "(WMI.ON_HAND_QTY - WMI.WM_ALLOCATED_QTY + WMI.TO_BE_FILLED_QTY) as ALLOCATABLE_QTY, " +
                    "PLD.MAX_INVN_QTY,icb.unit_volume,icb.unit_weight, " +
                    "pld.min_invn_qty, pld.cntry_of_orgn, pld.sku_attr_1  " +
                    "from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi " +
                    "where lhdp.locn_id = plh.locn_id  " +
                    "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id " +
                    "and pld.item_id = icb.item_id " +
                    "and WMI.LOCATION_ID = PLH.LOCN_ID " +
                    "and LHDP.LOCN_CLASS = 'C' " +
                    "and lhdp.sku_dedctn_type = 'P' " +
                    "and ICB.ITEM_BAR_CODE <>'0' " +
                    "and ICB.ITEM_NAME not in ('883819-002-8.5','631261-310-4') "+
                    "and plh.invn_lock_code is null " +
                    "and wmi.on_hand_qty <>'0' " +
                    "and (WMI.ON_HAND_QTY - WMI.WM_ALLOCATED_QTY + WMI.TO_BE_FILLED_QTY) > 0 "+
                    "and icb.item_id not in (select item_id from item_package_cbo where package_uom_id='26') " +
                    "AND ICB.UNIT_VOLUME IS NOT NULL AND ICB.UNIT_WEIGHT IS NOT NULL  " +
                    "AND ICB.UNIT_LENGTH IS NOT NULL AND ICB.UNIT_WIDTH IS NOT NULL AND ICB.UNIT_HEIGHT IS NOT NULL " +
                    "and icb.unit_volume <>'0.0001' and icb.unit_weight <>'0.0001' " +
                    "and ICB.ITEM_BAR_CODE <>'0' " +
                    "order by icb.unit_volume,icb.unit_weight";
                String sql15 = "SELECT FACILITY_ALIAS_ID as customer,FAC.COUNTRY_CODE FROM FACILITY_ALIAS FA,FACILITY FAC " +
                        "WHERE FA.FACILITY_ID=FAC.FACILITY_ID " +
                        "AND FA.FACILITY_ALIAS_ID IN(SELECT OTMP.TC_ORDER_ID FROM ORDER_NOTE_TEMPLATE ONT,ORDERS_TEMPLATE OTMP  " +
                        "WHERE  OTMP.ORDER_ID = ONT.ORDER_ID AND NOTE_TYPE='PG' AND NOTE='CO' ) " +
                        "AND FA.FACILITY_ALIAS_ID IN(SELECT OTMP.TC_ORDER_ID FROM ORDER_NOTE_TEMPLATE ONT,ORDERS_TEMPLATE OTMP  " +
                        "WHERE  OTMP.ORDER_ID = ONT.ORDER_ID AND NOTE_TYPE='GF' AND NOTE='Y' ) " +
                        "AND FAC. FACILITY_TYPE_BITS='64' " +
                        "AND FA.FACILITY_ID NOT IN (SELECT FACILITY_ID FROM FACILITY_NOTE WHERE FACILITY_NOTE_TYPE='2' AND NOTE='1') " +
                        "AND FAC.COUNTRY_CODE IN(SELECT COUNTRY_CODE FROM COUNTRY WHERE CNTRY_ID IS NULL)";
                arrSQL = new String[]{sql14, sql15};
                break;

            case "OB_1064_PW03AT_HP_22_INT51_Alloc_and_Task_Creation_Digital_Brkn_Ppacks":
                String sql16="select LHDP.DSP_LOCN, LHDP.SKU_DEDCTN_TYPE, LHDP.LOCN_PICK_SEQ, ICB.ITEM_NAME,IPC.QUANTITY AS STD_PACK_QTY,WMI.item_attr_1, " +
                        "(WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) as ALLOCATABLE_QTY, PLD.MAX_INVN_QTY, " +
                        "PLD.MIN_INVN_QTY, PLD.CNTRY_OF_ORGN, PLD.SKU_ATTR_1, PLD.LOCN_SEQ_NBR   " +
                        "from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi,item_package_cbo IPC where  " +
                        "lhdp.locn_id = plh.locn_id  " +
                        "and PLD.PICK_LOCN_HDR_ID = PLH.PICK_LOCN_HDR_ID " +
                        "and PLD.ITEM_ID = ICB.ITEM_ID " +
                        "AND IPC.ITEM_ID = ICB.ITEM_ID " +
                        "and WMI.LOCATION_ID = PLH.LOCN_ID " +
                        "and LHDP.LOCN_CLASS = 'C' " +
                        "and ICB.ITEM_BAR_CODE <>'0' " +
                        "and PLH.INVN_LOCK_CODE is null " +
                        "and WMI.ON_HAND_QTY <>'0' " +
                        "and IPC.PACKAGE_UOM_ID='26' " +
                        "and IPC.IS_STD='1' " +
                        "and LHDP.ZONE='31'";
                arrSQL = new String[]{sql16};

            case "OB_1064_PW03AT_HP_19_INT51_Alloc_and_Task_Creation_equip_Brkn_prepacks_MultiLine_NEW":
                String sql19="select lhdp.bay,lhdp.aisle,lhdp.zone,LHDP.DSP_LOCN, LHDP.SKU_DEDCTN_TYPE, LHDP.LOCN_PICK_SEQ,      " +
                        "ICB.ITEM_NAME,IPC.QUANTITY AS STD_PACK_QTY, WMI.ITEM_ATTR_1,IPC.QUANTITY,          " +
                        "(WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) as ALLOCATABLE_QTY, PLD.MAX_INVN_QTY,          " +
                        "PLD.MIN_INVN_QTY, PLD.CNTRY_OF_ORGN, PLD.SKU_ATTR_1, PLD.LOCN_SEQ_NBR           " +
                        "from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi,item_package_cbo IPC where      " +
                        "lhdp.locn_id = plh.locn_id            " +
                        "and PLD.PICK_LOCN_HDR_ID = PLH.PICK_LOCN_HDR_ID           " +
                        "and PLD.ITEM_ID = ICB.ITEM_ID          " +
                        "AND IPC.ITEM_ID = ICB.ITEM_ID          " +
                        "and WMI.LOCATION_ID = PLH.LOCN_ID          " +
                        "and LHDP.LOCN_CLASS = 'C'          " +
                        "and ICB.ITEM_BAR_CODE <>'0'          " +
                        "and PLH.INVN_LOCK_CODE is null         " +
                        "and WMI.ON_HAND_QTY <>'0'           " +
                        "and (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) > 0 "+
                        "and IPC.PACKAGE_UOM_ID='26'         " +
                        "and IPC.IS_STD='1'         " +
                        "and LHDP.ZONE='31'";
                arrSQL = new String[]{sql19};
                break;

            case "OB_1064_PW03AT_HP_21_INT51_Alloc_and_Task_Creation_Digital_packs":
                String sql17="select lhdp.dsp_locn, lhdp.sku_dedctn_type, lhdp.locn_pick_seq, icb.item_name,    " +
                        "(wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) as allocatable_qty, pld.max_invn_qty,   " +
                        "pld.min_invn_qty, pld.cntry_of_orgn, pld.sku_attr_1,   " +
                        "pld.locn_seq_nbr,WMI.ITEM_ATTR_1,IPC.QUANTITY STD_PACK_QTY      " +
                        "from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi,ITEM_PACKAGE_CBO IPC where    " +
                        "IPC.ITEM_ID=ICB.ITEM_ID   " +
                        "and lhdp.locn_id = plh.locn_id    " +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id   " +
                        "and PLD.ITEM_ID = ICB.ITEM_ID   " +
                        "and WMI.LOCATION_ID = PLH.LOCN_ID   " +
                        "and LHDP.LOCN_CLASS = 'C'   " +
                        "and lhdp.sku_dedctn_type = 'P'   " +
                        "and ICB.ITEM_BAR_CODE <>'0'   " +
                        "and PLH.INVN_LOCK_CODE is null   " +
                        "and WMI.ON_HAND_QTY <>'0'   " +
                        "and LHDP.PICK_DETRM_ZONE='001'";
                arrSQL = new String[]{sql17};
                break;

            case "OB_1064_PW03AT_HP_19_INT51_Alloc_and_Task_Creation_equip":
                String sql21="select lhdp.dsp_locn, lhdp.sku_dedctn_type, lhdp.locn_pick_seq, icb.item_name,  " +
                        "(wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) as allocatable_qty, " +
                        "pld.max_invn_qty, pld.min_invn_qty, pld.cntry_of_orgn, pld.sku_attr_1, pld.locn_seq_nbr,IPCBO.QUANTITY ,WMI.ITEM_ATTR_1 " +
                        "from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi,ITEM_PACKAGE_CBO IPCBO where  " +
                        "IPCBO.ITEM_ID=ICB.ITEM_ID " +
                        "and lhdp.locn_id = plh.locn_id  " +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id " +
                        "and PLD.ITEM_ID = ICB.ITEM_ID " +
                        "and WMI.LOCATION_ID = PLH.LOCN_ID " +
                        "and LHDP.LOCN_CLASS = 'C' " +
                        "and lhdp.sku_dedctn_type = 'P' " +
                        "and ICB.ITEM_BAR_CODE <>'0' " +
                        "and PLH.INVN_LOCK_CODE is null " +
                        "and WMI.ON_HAND_QTY <>'0' " +
                        "and (wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) > 0 "+
                        "and LHDP.PICK_DETRM_ZONE='001'";
                arrSQL = new String[]{sql21};
                break;

            case "OB_1064_PW03AT_HP_19_INT51_Alloc_and_Task_Creation_equip_8_box_NEW":
                String sql22 = "select lhdp.dsp_locn, lhdp.sku_dedctn_type, lhdp.locn_pick_seq, icb.item_name, " +
                        "(wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) as allocatable_qty, pld.max_invn_qty, pld.min_invn_qty, " +
                        "pld.cntry_of_orgn, pld.sku_attr_1, pld.locn_seq_nbr,ipcbo.quantity  " +
                        "from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi,item_package_cbo ipcbo where " +
                        "lhdp.locn_id = plh.locn_id " +
                        "and ipcbo.item_id=icb.item_id " +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id " +
                        "and PLD.ITEM_ID = ICB.ITEM_ID " +
                        "and WMI.LOCATION_ID = PLH.LOCN_ID " +
                        "and LHDP.LOCN_CLASS = 'C' " +
                        "and lhdp.sku_dedctn_type = 'P' " +
                        "and ICB.ITEM_BAR_CODE <>'0' " +
                        "and PLH.INVN_LOCK_CODE is null " +
                        "and WMI.ON_HAND_QTY <>'0' " +
                        "and (wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) > 0 "+
                        "and LHDP.PICK_DETRM_ZONE='001'" ;
                arrSQL = new String[]{sql22};
                break;

            case  "OB_1064_PW03AT_HP_20_INT51_Alloc_and_Task_Creation_PROMO":
                String sql18="select lhdp.dsp_locn, lhdp.sku_dedctn_type, lhdp.locn_pick_seq, icb.item_name,     " +
                        "(wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) as allocatable_qty,     " +
                        "wmi.on_hand_qty, wmi.wm_allocated_qty, wmi.to_be_filled_qty,    " +
                        "pld.max_invn_qty, pld.min_invn_qty, pld.cntry_of_orgn, pld.sku_attr_1, pld.locn_seq_nbr,IPCBO.QUANTITY      " +
                        "from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi,ITEM_PACKAGE_CBO IPCBO where     " +
                        "IPCBO.ITEM_ID=ICB.ITEM_ID    " +
                        "AND lhdp.locn_id = plh.locn_id     " +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id    " +
                        "and PLD.ITEM_ID = ICB.ITEM_ID    " +
                        "and WMI.LOCATION_ID = PLH.LOCN_ID    " +
                        "and lhdp.locn_class = 'C'    " +
                        "and PLH.INVN_LOCK_CODE is null    " +
                        "and (wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) > 0 "+
                        "and WMI.ON_HAND_QTY <>'0'    " +
                        "and WMI.item_id = icb.item_id    " +
                        "and LHDP.PICK_DETRM_ZONE='003'";
                arrSQL = new String[]{sql18};
                break;
            
            case "OB_1064NDC_PW03AT_HP_36_INT51_Zone_Pick_VAS_Task_Creation_NEW":
                String sql23 = "select LHDP.DSP_LOCN, LHDP.SKU_DEDCTN_TYPE, ICB.ITEM_NAME, " +
                        "(WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) as ALLOCATABLE_QTY, " +
                        "PLD.MAX_INVN_QTY,icb.unit_volume,icb.unit_weight, " +
                        "pld.min_invn_qty, pld.cntry_of_orgn, pld.sku_attr_1   " +
                        "from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi " +
                        "where  " +
                        "lhdp.locn_id = plh.locn_id  " +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id " +
                        "and pld.item_id = icb.item_id " +
                        "and WMI.LOCATION_ID = PLH.LOCN_ID " +
                        "and LHDP.LOCN_CLASS = 'C' " +
                        "and lhdp.sku_dedctn_type = 'P' " +
                        "and ICB.ITEM_BAR_CODE <>'0' " +
                        "and ICB.ITEM_NAME not in ('883819-002-8.5') "+
                        "and plh.invn_lock_code is null " +
                        "and wmi.on_hand_qty <>'0' " +
                        "and (WMI.ON_HAND_QTY-WMI.WM_ALLOCATED_QTY+WMI.TO_BE_FILLED_QTY) > 0 "+
                        "and icb.item_id not in (select item_id from item_package_cbo where package_uom_id='26') " +
                        "AND ICB.UNIT_VOLUME IS NOT NULL AND ICB.UNIT_WEIGHT IS NOT NULL  AND ICB.UNIT_LENGTH IS NOT NULL AND ICB.UNIT_WIDTH IS NOT NULL AND ICB.UNIT_HEIGHT IS NOT NULL " +
                        "and icb.unit_volume <>'0.0001' and icb.unit_weight <>'0.0001' " +
                        "and ICB.ITEM_BAR_CODE <>'0' " +
                        "order by icb.unit_volume,icb.unit_weight";
                String sql24 = "SELECT VAS_CODE FROM C_VAS_INFO WHERE SAP_ONLY <>'1'and c_vas_lvl='2'";
                arrSQL = new String[]{sql23, sql24};
                break;
        }
        return arrSQL;
    }
}