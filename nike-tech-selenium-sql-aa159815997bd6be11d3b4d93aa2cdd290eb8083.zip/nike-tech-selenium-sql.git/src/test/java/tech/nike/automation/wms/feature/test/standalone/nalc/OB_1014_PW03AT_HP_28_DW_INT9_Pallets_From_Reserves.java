package tech.nike.automation.wms.feature.test.standalone.nalc;

import org.xml.sax.SAXException;
import tech.nike.automation.common.framework.sql.INT1Queries;
import tech.nike.automation.common.framework.utility.FlatFileGenerator;
import tech.nike.automation.common.framework.utility.GenerateDONum;
import tech.nike.automation.common.framework.utility.QueryHelper;
import tech.nike.automation.common.framework.utility.updateXML;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static tech.nike.automation.common.framework.utility.Constants.FLAT_FILE_PATH;
import static tech.nike.automation.common.framework.utility.Constants.NALC_DB;
import static tech.nike.automation.common.framework.utility.Constants.NALC_FLAT_FILE_PATH;

/**
 * Created by dyelur on 9/10/2016.
 */
public class OB_1014_PW03AT_HP_28_DW_INT9_Pallets_From_Reserves {
    //global variables instantiation
   // public static String strTextFilePath = "c:\\WMS-Automation\\records.txt";
	 public static String strTextFilePath = FLAT_FILE_PATH;
	 static String strTestCaseID = "OB_1014_PW03AT_HP_28_DW_INT9_Pallets_From_Reserves";
	 static String strItemName;
	 static String strQuery1;
     static String strDoNums[] = new String[2];
	 
	 public static String runQuery(ArrayList<String> itemList) throws ParserConfigurationException, SAXException, TransformerException{
	        List<String> itemNames = new ArrayList<String>();
	        List<String> countryOfOrigins = new ArrayList<String>();
	        List<String> itemAttributes = new ArrayList<String>();
	        String strCountryOfOrigin = "*";
	        HashMap<String, String> xmlAttributes= new HashMap<String, String>();
            String strDONum = "";
            int Reccount = 0;
	        try {
	        	FlatFileGenerator.createFlatFile(NALC_FLAT_FILE_PATH);
	            String[] getArrQL = INT1Queries.getQuery(strTestCaseID);
	            strQuery1=QueryHelper.queryUpdateToAvoidDuplicateItemID(getArrQL[0], itemList);
	            ResultSet result=QueryHelper.executeQuery(NALC_DB, strQuery1);
            if (result.isBeforeFirst()) {

                while (result.next()) {
                    System.out.println("Record found writing to file...");
                    String strItemName = result.getString("ITEM_NAME");
                    System.setProperty("ITEM_NAME", strItemName);
                    String strItemAttribute = result.getString("ITEM_ATTR_1");
                    System.setProperty("ITEM_ATTR_1", strItemAttribute);
                    String strLPNQty = result.getString("QTY");
                    System.setProperty("QTY", strLPNQty);
                    int LPN1Qty = Integer.parseInt(strLPNQty);
                    itemNames.add(strItemName);
                    itemAttributes.add(strItemAttribute);

                    try {
                        FlatFileGenerator.appendDataToFlatFile(strTestCaseID+",");
                        FlatFileGenerator.appendDataToFlatFile(strItemName+",");
                        FlatFileGenerator.appendDataToFlatFile(strCountryOfOrigin+",");
                        FlatFileGenerator.appendDataToFlatFile(strItemAttribute+",");
                        FlatFileGenerator.appendDataToFlatFile(strLPNQty);

                        strDONum = GenerateDONum.DONumber();
                        strDoNums [Reccount] = strDONum;
                        System.out.println("Do Num:" + strDONum);

                        xmlAttributes.put("DistributionOrderId", strDONum);
                        xmlAttributes.put("ItemName", strItemName);
                        xmlAttributes.put("OrderQty", strLPNQty);
                        xmlAttributes.put("CountryOfOrigin", strCountryOfOrigin);
                        xmlAttributes.put("ItemAttribute1", strItemAttribute);
                        if(strItemName!=null){
                        	updateXML.postDatatoXML(strTestCaseID,xmlAttributes,Reccount);
                        	Reccount = Reccount + 1;
                        }
                        else
                        	strItemName = "1";
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            } else {
            	 System.out.println("No records found");
            	 FlatFileGenerator.appendDataToFlatFile(strTestCaseID+",");
            	 FlatFileGenerator.appendDataToFlatFile("No records found");
            	 FlatFileGenerator.closeFlatFile();
                 result.close();
                 System.out.println("Done");
            }
            QueryHelper.closeConnection();
                FlatFileGenerator.closeFlatFile();
        } catch (SQLException e) {
            try {
            	QueryHelper.closeConnection();
                e.printStackTrace();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        } catch (IOException e) {
            try {
            	QueryHelper.closeConnection();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        }
        if(strItemName!=null)
        	return strItemName;
        else
        	return "1";
    }
}