package tech.nike.automation.wms.feature.test.data;

import org.testng.annotations.Test;
import tech.nike.automation.common.framework.BaseTest;
import tech.nike.automation.common.framework.Browser;
import tech.nike.automation.common.framework.Selenium;
import tech.nike.automation.common.utils.NikePageFactory;
import tech.nike.automation.wms.feature.page.*;
import tech.nike.automation.wms.feature.page.sql.ham.INT2;
import tech.nike.automation.wms.feature.test.standalone.nalc.NALC_TestCase_Runner;
import tech.nike.automation.wms.feature.test.standalone.nalc.OB_1014_PW03AT_HP_01_SW_INT2_TASKCR_FULLPALL_FROM_PALLRESV;

import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Created by psibb1 on 6/23/2016.
 */
public class WMSTestData extends BaseTest {

    /**
     * Test method to create a new routing wave template and verify the same
     *
     * @param myBrowser
     * @param se
     * @param params
     */
    @Test(description = "Verify full case quantity", dataProvider = "browserXml",
            groups = {"smoke", "regression"}, timeOut = 1200000)
    @TestData(fileName = "wms/data/inputdata.xml")
    public void createINT2TestData(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);
        WMSRunWaveTemplatesPage wmsRunWave = NikePageFactory.initElements(se.myDriver, WMSRunWaveTemplatesPage.class);
        WMSTemplateRulePage wmsTemplatePage = NikePageFactory.initElements(se.myDriver, WMSTemplateRulePage.class);
        WMSWavesPage wmsWavePage = NikePageFactory.initElements(se.myDriver, WMSWavesPage.class);
        WMSoLPNPage wmsLPNPage = NikePageFactory.initElements(se.myDriver, WMSoLPNPage.class);
        WMSDistributionOrdersPage wmsDoPage = NikePageFactory.initElements(se.myDriver, WMSDistributionOrdersPage.class);
        WMSTasksPage wmsTaskPage = NikePageFactory.initElements(se.myDriver, WMSTasksPage.class);
        INT2 INT2 = new INT2();

        //read input data from parametrized xml file
        String strUrl = (String)params.get("environment");
        String strRuleName = (String)params.get("rulename");
        String[] argv = {"A","B"};

        //Pre-requisites
        NALC_TestCase_Runner.main(argv);

        //calling the environment variable to retrive the DO number
        String DOs = System.getProperty("DO_NUMBERS");

        //invoke browser
        se.myDriver.get(strUrl);
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //verify user login to WMS
        se.assertion.verifyTrue("User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));

        //verify post xml is successful
        se.assertion.verifyTrue("post xml", wmsHomePageObject.verifyPostXML(params));

        //se.element.explicitWait(10000);

        //verify navigate to system codes page
        se.assertion.verifyTrue("navigate to ship wave templates",
                wmsHomePageObject.menuNavigation("Distribution", "Distribution Orders"));

        //search for the DO number
        se.assertion.verifyTrue("search for the DO", wmsDoPage.searchForDO(DOs));

        //verify the DO status
        se.assertion.verifyTrue("verify the status of DO", wmsDoPage.verifyDOStatus());

        //verify navigate to system codes page
        se.assertion.verifyTrue("navigate to ship wave templates",
        wmsHomePageObject.menuNavigation("Distribution", "Run Waves"));

        //navigate to run waves
        //se.assertion.verifyTrue("navigate to run waves", wmsRunWave.navigateToRunWaves(params));
        se.assertion.verifyTrue("navigate to run waves", wmsRunWave.navigateToRunWaves("AT - STANDARD ROUTING WAVE"));
        //select a rule
        se.assertion.verifyTrue("select a rule", wmsTemplatePage.selectRule("Do Number"));

        /*String[] arr = new String[] {"DUGAL42016001", "DUGAL42016002", "DUGAL42016003",
                "DUGAL42016004", "DUGAL42016005", "DUGAL42016007", "DUGAL42016005",
                "DUGAL42016005", "DUGAL42016009", "DUGAL42016007", "DUGAL42016005", "DUGAL42016005", "DUGAL42016007",
                "DUGAL42016007", "DUGAL42016005", "DUGAL42016007"};*/


        String[] arr = DOs.split(",");
        //enter the Do
        se.assertion.verifyTrue("enter the do to wave", wmsTemplatePage.updateDoNumbers(DOs));

        //submit the wave
        se.assertion.verifyTrue("submit the wave", wmsTemplatePage.submitWave());

        //verify the wave number generated
        se.assertion.verifyTrue("verify if the wave number is generated", wmsTemplatePage.verifyWaveGenerated());

        //verify if the wave status
        se.assertion.verifyTrue("verify if the wave status is completed", wmsWavePage.verifyWaveStatus());

        //search by wave number
        //se.assertion.verifyTrue("search by wave number",wmsWavePage.searchByWaveNumber(System.getProperty("WAVE_NUMBER")));

        //select a wave number
        //se.assertion.verifyTrue("select a wave number", wmsWavePage.selectWaveNumber(System.getProperty("WAVE_NUMBER")));

        //navigate to LPN page
        //se.assertion.verifyTrue("navigate to LPN page", wmsWavePage.navigateToLPNs());

        //get the shipping id
        //se.assertion.verifyTrue("get the shipping id", wmsLPNPage.getLPNDetails());

        //verify navigate to system codes page
        se.assertion.verifyTrue("navigate to ship wave templates",
                wmsHomePageObject.menuNavigation("Distribution", "Run Waves"));

        //navigate to run waves to run a pick wave
        //se.assertion.verifyTrue("navigate to run waves", wmsRunWave.navigateToRunWaves("AT - STANDARD SORTER PICKING WAVE"));
        se.assertion.verifyTrue("navigate to run waves", wmsRunWave.navigateToRunWaves(params));

        //select a rule
        //se.assertion.verifyTrue("select a rule", wmsTemplatePage.selectRule("Do by DO"));
        se.assertion.verifyTrue("select a rule", wmsTemplatePage.selectRule(strRuleName));

        //String[] arr1 = new String[] {"DUGAL42016001", "DUGAL42016002"};
        //enter the Do
        se.assertion.verifyTrue("enter the do to wave", wmsTemplatePage.updateDoNumbers(DOs));

        //submit the wave
        se.assertion.verifyTrue("submit the wave", wmsTemplatePage.submitWave());

        //verify the wave number generated
        se.assertion.verifyTrue("verify if the wave number is generated", wmsTemplatePage.verifyWaveGenerated());

        //verify if the wave status
        se.assertion.verifyTrue("verify if the wave status is completed", wmsWavePage.verifyWaveStatus());

        //select a wave number
        se.assertion.verifyTrue("select a wave number", wmsWavePage.selectWaveNumber(System.getProperty("WAVE_NUMBER")));

        //verify
        se.assertion.verifyTrue("navigate to LPN page", wmsWavePage.verifyTask());

        //verify
        se.assertion.verifyTrue("INT Page details", wmsTaskPage.getTaskDetails(params));
        //verify
        //se.assertion.verifyTrue("INT Page details", wmsTaskPage.getTaskDetails());
        //Garbage collection of failed steps
        testTearDown(se);
    }




    /**
     * Method to post synthetic data into WMS
     *
     * @param myBrowser : browser type used for test
     * @param se        : driver type used for test
     * @param params    : external file data parameters
     */
   //@Test(description = "Create Synthetic data", dataProvider = "browserXml",
    // groups = {"smoke", "regression"}, timeOut = 400000)
   //@TestData(fileName = "wms/data/inputdata.xml")
    public void verifyPostXMLData(Browser.Browsers myBrowser, Selenium se, Map<String, Object> params) {
        WMSLoginPage wmsLoginPageObject = NikePageFactory.initElements(se.myDriver, WMSLoginPage.class);
        WMSHomePage wmsHomePageObject = NikePageFactory.initElements(se.myDriver, WMSHomePage.class);

        //read input data from parametrized xml file
        String strUrl = (String)params.get("environment");

        //invoke browser
        se.myDriver.get(strUrl);
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //verify user login to WMS
        se.assertion.verifyTrue("User Logged into WMS", wmsLoginPageObject.verifyWMSLogin(params));

        //verify post xml is successful
        se.assertion.verifyTrue("post xml", wmsHomePageObject.verifyPostXML(params));

        //verify sign-out from wms
        se.assertion.verifyTrue("User clicked on sign-out", wmsHomePageObject.verifyAndClickSignOut());

        //verify sign-out from wms
        se.assertion.verifyTrue("user confirmed to sign-out", wmsHomePageObject.verifyAndClickConfirmSignOut());

        //Garbage collection of failed steps
        testTearDown(se);
    }
}
