package tech.nike.automation.wms.feature.test.standalone.herentals;

import tech.nike.automation.common.framework.sql.DBConnect;
import tech.nike.automation.common.framework.sql.INT2Queries;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by rurs on 9/5/16.
 */
public class OB_1064_PW03AT_HP_03_INT2_TaskCr_CartonEquip_Non_VAS {
    //global variables instantiation
    public static String strTextFilePath = "c:\\records.txt";

    public static void main(String[] argv) {
        //local variables instantiation
        PreparedStatement statement = null;
        PreparedStatement statement1 = null;
        Connection connection = null;
        String strEnv = "HTLS-ER";
        String strTestCaseID = "OB_1064_PW03AT_HP_03_INT2_TaskCr_CartonEquip_Non_VAS";
        //int recordsLimit = 5000;
        long startTime = System.currentTimeMillis(); // Get the start Time
        long endTime = 0;
        String[] arrItem = new String[2];
        int x1 = 0;
        int index = 0;
        int counter = 0;
        boolean blnFound = false;
        FileWriter fstream = null;
        List<String> itemNames = new ArrayList<String>();
        List<String> countryOfOrigins = new ArrayList<String>();
        List<String> itemAttributes = new ArrayList<String>();
        try {
            //file to save the sku details required for xml posting
            File file = new File(strTextFilePath);
            fstream = new FileWriter(file, true);
            BufferedWriter out = new BufferedWriter(fstream);
            String[] getArrQL = INT2Queries.getQuery(strTestCaseID);
            String strQuery1 = getArrQL[0];
            connection = DBConnect.getDatabaseConnection(strEnv);
            //System.out.println("System memory before executing the query  " + Runtime.getRuntime().freeMemory());
            //do {
            //execute the first sql query
            statement = connection.prepareStatement(strQuery1);
            //statement.setFetchSize(recordsLimit);
            //add the output from from first sql to result set
            ResultSet result = statement.executeQuery();
            //iterate the first result set data for second sql
            if (result.next()) {
                while (result.next()) {
                    //System.out.println("System memory after executing the query  " + Runtime.getRuntime().freeMemory());
                    //endTime = System.currentTimeMillis();
                    //System.out.println("Time taken to execute the first query " + (((endTime - startTime) / 1000) / 60) + " minutes");
                    String strItemName = result.getString("ITEM_NAME");
                    //write to system variable to read it easily
                    System.setProperty("ITEM_NAME", strItemName);
                    String strCountryOfOrigin = result.getString("CNTRY_OF_ORGN");
                    //write to system variable to read it easily
                    System.setProperty("CNTRY_OF_ORGN", strCountryOfOrigin);
                    String strItemAttribute = result.getString("ITEM_ATTR_1");
                    //write to system variable to read it easily
                    System.setProperty("ITEM_ATTR_1", strItemAttribute);
                    String strAllocQty = result.getString("ALLOC_QTY");
                    //write to system variable to read it easily
                    System.setProperty("ALLOC_QTY", strAllocQty);
                    int intAllocQty = Integer.parseInt(strAllocQty);
                    itemNames.add(strItemName);
                    /*if (itemNames.size() > 1) {
                        for(int i=0; i<itemNames.size(); i++){
                            if(itemNames.get(0).equals(itemNames.get(i))){
                                blnFound = true;
                            }else{
                                blnFound = false;
                            }
                        }
                    }
                    if (blnFound) {*/
                        try {
                            out.append(strTestCaseID).append(",");
                            out.append(strItemName);
                            out.append(", ");
                            out.append(Integer.toString(intAllocQty)).append(", ");
                            out.append(strCountryOfOrigin);
                            out.append(", ");
                            out.append(strItemAttribute);
                            out.newLine();
                            out.flush();
                            out.close();
                            statement.close();
                            connection.close();
                            return;
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    //}
                    if(itemNames.size() > 1) {
                        itemNames.clear();
                    }
                }
            } else {
                System.out.println("No records found");
                out.append("No records found");
                out.close();
                result.close();
            }
            // } while ((endTime - startTime) / 1000 == 600);
        } catch (SQLException e) {
            try {
                statement.close();
                connection.close();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        } catch (IOException e) {
            try {
                statement.close();
                connection.close();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        }
    }
}