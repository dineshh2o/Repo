package tech.nike.automation.wms.feature.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import tech.nike.automation.common.page.Page;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by PSibb1 on 9/20/2016.
 */
public class WMSoLPNPage extends Page {
    public By lnkShippingId = By.cssSelector("[id$='LPNList_Inbound_ShipmentId_param_out']");
    public By lblLPNId = By.cssSelector("[id$='LPNList_Outbound_Link_NameText_param_out']");
    public By lnkDO = By.cssSelector("[id$='LPNList_Outbound_DistributionOrderId_param_out']");
    public By lnkItem = By.cssSelector("[id$='Case_LPN_With_PO_LPN_POLine_Item_param_out1_Commnd2']");
    List<String> arrItemNames = new ArrayList<String>();
    List<String> arrLPNIds = new ArrayList<String>();
    List<String> arrDOs = new ArrayList<String>();
    List<String> arrShippingIds = new ArrayList<String>();

    public boolean getLPNDetails(){
        boolean result = true;
        //verify if the table is having records displayed
        result &= se.element.getElements(lnkShippingId).size() > 0;
        List<WebElement> shippingIds = se.element.getElements(lnkShippingId);
        List<WebElement> lpnIds = se.element.getElements(lblLPNId);
        List<WebElement> dos = se.element.getElements(lnkDO);
        List<WebElement> items = se.element.getElements(lnkItem);
        for(int i=0; i<=shippingIds.size() -1; i++){
            arrShippingIds.add(shippingIds.get(i).getText().trim());
            arrItemNames.add(items.get(i).getText().trim());
            arrLPNIds.add(lpnIds.get(i).getText().trim());
            arrDOs.add(dos.get(i).getText().trim());
        }
        System.out.println(arrItemNames);
        System.out.println(arrShippingIds);
        System.out.println(arrLPNIds);
        System.out.println(arrDOs);
        return result;
    }
}