package tech.nike.automation.wms.feature.test.standalone.nalc;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import tech.nike.automation.common.framework.utility.FlatFileGenerator;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Scanner;

import static tech.nike.automation.common.framework.utility.Constants.NALC_EXECUTION_SHEET_PATH;
import static tech.nike.automation.common.framework.utility.Constants.NALC_FLAT_FILE_PATH;

;

/**
 * Created by dyelur on 9/10/2016.
 */
public class NALC_TestCase_Runner {
	static ArrayList testcases = new ArrayList();
	public static ArrayList<String> strItem= new ArrayList<String>();
	static Calendar cal;
    public static void main(String[] argv){
    	/*
    	 * Reading the option from user to check if the old data in flat file needs to be cleared. 
    	 */
    	Scanner reader = new Scanner(System.in); 
    	//System.out.println("Do you want to clear the old data in flat file file (Y/N) ");
    	//String s = reader.nextLine();
        String s = "N";
    	if(s.equalsIgnoreCase("y"))
            try {
                FlatFileGenerator.clearFileContents(NALC_FLAT_FILE_PATH);
            } catch (IOException e) {
                e.printStackTrace();
            }
    	
    	/*
    	 * Printing execution start time
    	 */
    	 System.out.println( "Execution Start time==>"+ getCurrentTime() );	
        
        /*
         * Reading the test cases needs to be executed during run time from excel and executing the
         * test cases marked as "yes" in excel
         */
        String pkgName = NALC_TestCase_Runner.class.getCanonicalName().toString().replace("."+NALC_TestCase_Runner.class.getSimpleName(), ".");
        try {
            ReadTestCases();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(testcases);
    	for (int i=0;i<testcases.size();i++){
            Class testClass = null;
            try {
                testClass = Class.forName(pkgName+testcases.get(i).toString());
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            Object ob = null;
            try {
                ob = testClass.newInstance();
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
            Method[] method = testClass.getDeclaredMethods();
            try {
                strItem.add( method[0].invoke(ob,strItem).toString());
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
        }
    	System.out.println("Unique Items Names Used==>"+strItem);
    	
    	 // Printing execution start time
    	System.out.println( "Execution end time==>"+getCurrentTime() );
    }
   
    /*
     * This method will read the excel data and serves as input for execution
     */
   public static void ReadTestCases() throws IOException{
	   String excelFilePath = NALC_EXECUTION_SHEET_PATH;
       String AbsolutePath = new File(".").getAbsolutePath();

       AbsolutePath = AbsolutePath.substring(0,AbsolutePath.length() - 1) ;
       excelFilePath = AbsolutePath + excelFilePath ;
       System.out.println("Full XLS Path: " + excelFilePath) ;
       FileInputStream inputStream = new FileInputStream(new File(excelFilePath));
        
       Workbook workbook = new XSSFWorkbook(inputStream);
       Sheet firstSheet = workbook.getSheet("NALC_TestCases");
       Iterator<Row> iterator = firstSheet.iterator();
       while (iterator.hasNext()) {
           Row nextRow = iterator.next();
           Iterator<Cell> cellIterator = nextRow.cellIterator();
            
           while (cellIterator.hasNext()) {
               Cell cell = cellIterator.next();
               	if(cell.getStringCellValue().equalsIgnoreCase("yes")){
               		cell=cellIterator.next();
              // 	System.out.println(cell.getStringCellValue());	
               	testcases.add(cell.getStringCellValue());
               }
           }
       }
       workbook.close();
       inputStream.close();
   }
   
  public static String getCurrentTime(){
	  cal = Calendar.getInstance();
      SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
      return sdf.format(cal.getTime());
  }
}