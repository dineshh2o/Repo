package tech.nike.automation.common.utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import tech.nike.automation.common.framework.Selenium;
import tech.nike.automation.common.page.Page;

public class NikePageFactory {

    public static <T> T initElements(WebDriver driver, java.lang.Class<T> pageClassToProxy) {
        T obj = PageFactory.initElements(driver, pageClassToProxy);
        Selenium se = new Selenium();
        se.setWebDriver(driver);
        ((Page) obj).setWebDriver(se);
        return obj;
    }

    public static <T> T initElements(Selenium se, java.lang.Class<T> pageClassToProxy) {
        T obj = PageFactory.initElements(se.myDriver, pageClassToProxy);
        ((Page) obj).setWebDriver(se);
        return obj;
    }

}
