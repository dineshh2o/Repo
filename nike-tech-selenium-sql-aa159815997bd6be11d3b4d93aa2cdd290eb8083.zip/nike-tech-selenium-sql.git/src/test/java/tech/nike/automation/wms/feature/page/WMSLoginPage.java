package tech.nike.automation.wms.feature.page;

import org.openqa.selenium.By;
import tech.nike.automation.common.framework.Data;
import tech.nike.automation.common.page.Page;

import java.util.Map;

/**
 * Page Objects for WMS LoginPage
 *
 * @author PSIBB1
 */
public class WMSLoginPage extends Page {

    /**
     * Locators
     */
    public By txtWMSLoginUserName = By.id("j_username");
    public By txtWMSLoginPassword = By.id("j_password");
    public By btnWMSSignIn = By.name("btnEnter");

    /**
     * Method to verify if the user name field was visible
     *
     * @return
     */
    public boolean verifyUserNameDisplay() {
        //wait for the element() to display
        se.element.requireIsDisplayed("User Name field", txtWMSLoginUserName);
        //wait for the element to get visible
        boolean result = se.element.isVisible(txtWMSLoginUserName);
        result &= se.element.waitForElementToBeClickable(txtWMSLoginUserName);
        return result;
    }

    /**
     * Method to verify if password field was visible
     *
     * @return
     */
    public boolean verifyPasswordDisplay() {
        //wait for the element() to display
        se.element.requireIsDisplayed("Password field", txtWMSLoginUserName);
        //wait for the element to get visible
        boolean result = se.element.isVisible(txtWMSLoginPassword);
        result &= se.element.waitForElementToBeClickable(txtWMSLoginPassword);
        return result;
    }

    /**
     * Method to verify if sign in button was visible and clickable
     *
     * @return
     */
    public boolean verifySignInDisplay() {
        se.element.requireIsDisplayed("Sign-in button", btnWMSSignIn);
        //wait for the element() to get visible
        boolean result = se.element.isVisible(btnWMSSignIn);
        //wait for the element() to become clickable
        result &= se.element.waitForElementToBeClickable(btnWMSSignIn);
        return result;
    }

    /**
     * Method to verify and enter the user name
     *
     * @param testdata
     * @return
     */
    public boolean verifyAndEnterLoginUserName(Map<String, Object> testdata) {
        String strUserName = (String) testdata.get("username");
        //verify if the user name field was displayed
        boolean result = se.assertion.verifyTrue("Verify user name field was displayed on Login Page Page", verifyUserNameDisplay());
        if (result) {
            //click user name field
            se.element.clickElement(txtWMSLoginUserName);
            //set the value for user name field
            se.element.enterText(txtWMSLoginUserName, strUserName);
            //report user name to html report
            se.log.logSeStep("user id " + strUserName.toUpperCase().trim() + " was entered successfully");
            verifyEnteredTextIsCorrectlyDisplayed(txtWMSLoginUserName, strUserName);
        }
        return result;
    }

    /**
     * Method to verify and enter password
     *
     * @param testdata
     * @return
     */
    public boolean verifyAndEnterLoginPassword(Map<String, Object> testdata) {
        String strPassword = (String) testdata.get("password");
        //decrypt the user provided encrypted password
        Data.EncryptedString es = new Data.EncryptedString(strPassword);
        strPassword = es.getString();
        //verify if the password field was displayed
        boolean result = se.assertion.verifyTrue("Verify wms login password field was displayed on Login Page Page", verifyPasswordDisplay());
        if (result) {
            //click password field
            se.element.clickElement(txtWMSLoginPassword);
            //set the value for password field
            System.out.println("Password: " + strPassword);
            se.element.enterText(txtWMSLoginPassword, strPassword);
            //report user name to html report
            se.log.logSeStep("password was entered successfully");
            verifyEnteredTextIsCorrectlyDisplayed(txtWMSLoginPassword, strPassword);
        }
        return result;
    }

    /**
     * Method to verify and click sign in button
     *
     * @return
     */
    public boolean verifyAndClickSignIn() {
        //verify if the sign-in field was displayed
        boolean result = se.assertion.verifyTrue("Verify wms sign-in field was displayed on Login Page Page", verifySignInDisplay());
        if (result) {
            //click sign-in field
            se.element.clickElement(btnWMSSignIn);
            //report user name to html report
            se.log.logSeStep("sign-in was clicked successfully");
        }
        return result;
    }

    /**
     * Method to login to wms application
     *
     * @param testdata
     * @return
     */
    public boolean verifyWMSLogin(Map<String, Object> testdata) {
        String strUName = (String) testdata.get("username");
        String strPwd = (String) testdata.get("password");
        boolean result = verifyAndEnterLoginUserName(testdata);
        result &= verifyAndEnterLoginPassword(testdata);
        result &= verifyAndClickSignIn();
        //report user name to html report
        se.log.logSeStep("user " + strUName.toUpperCase().trim() + "  sign-in was successfully");
        return result;
    }
}