package tech.nike.automation.wms.feature.page;

import org.openqa.selenium.By;
import tech.nike.automation.common.page.Page;

/**
 * Created by PSibb1 on 9/21/2016.
 */
public class WMSDistributionOrdersPage extends Page {
    public By txtDistributionOrderNumber = By.cssSelector("[id*='DistributionOrderlist'][alt='Find Distribution Order']");
    public By lstStatus = By.cssSelector("span.msdstattext");
    public By btnApply = By.cssSelector("[id$='DistributionOrderlist1apply']");
    public By lblDistributionOrder = By.cssSelector("[id$='DOList_DOId_Link_Param_Out']");
    public By lblFulfillmentStatus = By.cssSelector("[id*='DOList_OrderFulfillmentStatus']");
    public By btnRefresh = By.cssSelector("[id$='DOList_MainListTable_rfsh_but']");

    /**
     * method to search for the distribution orders in DO screen
     * @param testdata
     * @return
     */
    public boolean searchForDO(String[] testdata){
        boolean result = true;
        //verify if the Do number search field was displayed
        se.element.requireIsDisplayed("Distribution Order Number",txtDistributionOrderNumber);
        //verify if the status field was displayed
        se.element.requireIsDisplayed("Fulfillment Status dropdown", lstStatus);
        //verify if the DO number is clickable
        result &= se.element.isClickable(txtDistributionOrderNumber);
        //enter the DO numbers
        se.element.sendKeys(txtDistributionOrderNumber, testdata);
        //verify if apply button was displayed
        se.element.requireIsDisplayed("Apply button", btnApply);
        //click on the apply button
        se.element.clickElement(btnApply);
        //wait until the page load is completed
        se.element.waitForPageLoad();
        return result;
    }

    /**
     * method to search for the distribution orders in DO screen
     * @param testdata
     * @return
     */
    public boolean searchForDO(String testdata){
        boolean result = true;
        //verify if the Do number search field was displayed
        se.element.requireIsDisplayed("Distribution Order Number",txtDistributionOrderNumber);
        //verify if the status field was displayed
        se.element.requireIsDisplayed("Fulfillment Status dropdown", lstStatus);
        //verify if the DO number is clickable
        result &= se.element.isClickable(txtDistributionOrderNumber);
        //enter the DO numbers
        se.element.sendKeys(txtDistributionOrderNumber, testdata);
        //verify if apply button was displayed
        se.element.requireIsDisplayed("Apply button", btnApply);
        //click on the apply button
        se.element.clickElement(btnApply);
        //wait until the page load is completed
        se.element.waitForPageLoad();
        return result;
    }

    /**
     * verify the DO status is released
     * @return
     */
    public boolean verifyDOStatus(){
        boolean result = true;
        //wait for the page load to complete
        se.element.explicitWait(3000);
        //iterate for the DO status to complete
        for(int i=0; i<= 60 ; i++){
            if(!se.element.getElements(lblFulfillmentStatus).get(1).getText().equalsIgnoreCase("Released")) {
                se.element.clickElement(btnRefresh);
                se.element.explicitWait(3000);
            }
        }
        return result;
    }
}