package tech.nike.automation.wms.feature.test.standalone.ham;

import tech.nike.automation.common.framework.sql.DBConnect;
import tech.nike.automation.common.framework.sql.INT2Queries;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by psibb1 on 8/30/2016.
 */
public class OB_1064NDC_PW03AT_HP_38_INT2_Spec_VAS_Task_Creation_NEW {
    //global variables instantiation
    public static String strTextFilePath = "c:\\records.txt";

    public static void main(String[] argv) {
        //local variables instantiation
        PreparedStatement statement = null;
        Connection connection = null;
        String strEnv = "HAM-ER";
        String strTestCaseID = "OB_1064NDC_PW03AT_HP_38_INT2_Spec_VAS_Task_Creation_NEW";
        //int recordsLimit = 5000;
        long startTime = System.currentTimeMillis(); // Get the start Time
        long endTime = 0;
        String[] arrItem = new String[2];
        int index = 0;
        int counter = 0;
        boolean blnFound = false;
        FileWriter fstream = null;
        List<String> itemNames = new ArrayList<String>();
        try {
            //file to save the sku details required for xml posting
            File file = new File(strTextFilePath);
            fstream = new FileWriter(file, true);
            BufferedWriter out = new BufferedWriter(fstream);
            String[] getArrQL = INT2Queries.getQuery(strTestCaseID);
            String strQuery1 = getArrQL[0];
            connection = DBConnect.getDatabaseConnection(strEnv);
            statement = connection.prepareStatement(strQuery1);
            //statement.setFetchSize(recordsLimit);
            ResultSet result = statement.executeQuery();
            //iterate the first result set data for second sql
            if (result.next()) {
                while (result.next()) {
                    String itemName = result.getString("ITEM_NAME");
                    String strAllocQty = result.getString("ALLOC_QTY");
                    int x1 = Integer.parseInt(strAllocQty);
                    try {
                        itemNames.add(itemName);
                        //checking for same item name
                        if (itemName.length() > 1) {
                            blnFound = true;
                        } else {
                            break;
                        }
                    } finally {
                        //the below try catch code will eliminate max cursors exceeded issue
                        try {
                            result.close();
                        } catch (SQLException ignore) {
                        }
                        //check condition to write into the text file
                        if (blnFound) {
                            try {
                                out.append(strTestCaseID).append(",");
                                out.append(itemNames.get(0)).append(", ");
                                out.append(strAllocQty);
                                out.newLine();
                                out.flush();
                                out.close();
                                statement.close();
                                connection.close();
                                return;
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            } else {
                System.out.println("No records found");
                out.append(strTestCaseID).append(",");
                out.append("No records found");
                out.close();
                result.close();
            }
            // } while ((endTime - startTime) / 1000 == 600);
        } catch (SQLException e) {
            try {
                statement.close();
                connection.close();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        } catch (IOException e) {
            try {
                statement.close();
                connection.close();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        }
    }
}