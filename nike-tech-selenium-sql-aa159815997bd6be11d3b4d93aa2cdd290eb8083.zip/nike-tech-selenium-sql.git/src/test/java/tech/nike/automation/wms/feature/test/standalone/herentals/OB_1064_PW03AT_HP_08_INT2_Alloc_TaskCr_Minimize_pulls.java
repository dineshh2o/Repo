package tech.nike.automation.wms.feature.test.standalone.herentals;

import tech.nike.automation.common.framework.sql.DBConnect;
import tech.nike.automation.common.framework.sql.INT2Queries;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Not Implemented refer notes for logic
 * Notes:
 * a) Select item with Alloc_qty > 0 from above query, and has only one size of LPNs.
 * b) Select Item that has multiple LPNs in case reserve.
 * c) Create DO with qty matching the sum of multiple LPNs, but less than the pallet size.
 * d) Make sure multiple number is 5 at least. (Ex: 5 * LPN size)
 */

public class OB_1064_PW03AT_HP_08_INT2_Alloc_TaskCr_Minimize_pulls {
    //global variables instantiation
    public static String strTextFilePath = "c:\\records.txt";

    public static void main(String[] argv) {
        //local variables instantiation
        PreparedStatement statement = null;
        PreparedStatement statement1 = null;
        Connection connection = null;
        String strEnv = "HTLS-ER";
        String strTestCaseID = "OB_1064_PW03AT_HP_08_INT2_Alloc_TaskCr_Minimize_pulls";
        //int recordsLimit = 5000;
        long startTime = System.currentTimeMillis(); // Get the start Time
        long endTime = 0;
        String[] arrItem = new String[1];
        int x1 = 0;
        int index = 0;
        int counter = 0;
        boolean blnFound = false;
        FileWriter fstream = null;
        List<String> criteria = new ArrayList<String>();
        List<Integer> quantity = new ArrayList<Integer>();
        try {
            //file to save the sku details required for xml posting
            File file = new File(strTextFilePath);
            fstream = new FileWriter(file, true);
            BufferedWriter out = new BufferedWriter(fstream);
            String[] getArrQL = INT2Queries.getQuery(strTestCaseID);
            String strQuery1 = getArrQL[0];
            connection = DBConnect.getDatabaseConnection(strEnv);
            statement = connection.prepareStatement(strQuery1);
            ResultSet result = statement.executeQuery();
            //iterate the first result set data for second sql
            boolean flag = false;
            if (result.next()) {
                while (result.next()) {
                    String strItemName = result.getString("ITEM_NAME");
                    System.setProperty("ITEM_NAME", strItemName);
                    String strCountryOfOrigin = result.getString("CNTRY_OF_ORGN");
                    System.setProperty("CNTRY_OF_ORGN", strCountryOfOrigin);
                    String strItemAttribute = result.getString("ITEM_ATTR_1");
                    System.setProperty("ITEM_ATTR_1", strItemAttribute);
                    int intAllocQty = Integer.parseInt(result.getString("ALLOC_QTY"));
                    System.setProperty("ALLOCATABLE_QTY", Integer.toString(intAllocQty));
                    try {
                        x1 = intAllocQty;
                        out.append(strTestCaseID).append(",");
                        out.append(strItemName);
                        out.append(", ");
                        out.append(Integer.toString(x1)).append(", ");
                        out.append(strCountryOfOrigin);
                        out.append(", ");
                        out.append(strItemAttribute);
                        out.newLine();
                        out.flush();
                        out.close();
                        statement.close();
                        connection.close();
                        return;

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            } else {
                System.out.println("No records found");
                out.append("No records found");
                out.close();
                result.close();
            }
            // } while ((endTime - startTime) / 1000 == 600);
        } catch (SQLException e) {
            try {
                statement.close();
                connection.close();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        } catch (IOException e) {
            try {
                statement.close();
                connection.close();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        }
    }

}
