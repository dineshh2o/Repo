package tech.nike.automation.wms.feature.test.standalone.herentals;

import tech.nike.automation.common.framework.sql.DBConnect;
import tech.nike.automation.common.framework.sql.INT51Queries;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Not Implemented refer notes for logic
 * Notes:
 * a) Select item with Alloc_qty > 0 from above query, and has only one size of LPNs.
 * b) Select Item that has multiple LPNs in case reserve.
 * c) Create DO with qty matching the sum of multiple LPNs, but less than the pallet size.
 *d) Make sure multiple number is 5 at least. (Ex: 5 * LPN size)
 */

public class OB_1064_PW03AT_HP_19_INT51_Alloc_and_Task_Creation_equip_8_box_NEW {
    //global variables instantiation
    public static String strTextFilePath = "c:\\records.txt";

    public static void main(String[] argv) {
        //local variables instantiation
        PreparedStatement statement = null;
        PreparedStatement statement1 = null;
        Connection connection = null;
        String strEnv = "HTLS-ER";
        String strTestCaseID = "OB_1064_PW03AT_HP_19_INT51_Alloc_and_Task_Creation_equip_8_box_NEW";
        //int recordsLimit = 5000;
        long startTime = System.currentTimeMillis(); // Get the start Time
        long endTime = 0;
        String[] arrItem = new String[1];
        int x1 = 0;
        int index = 0;
        int counter = 0;
        boolean blnFound = false;
        FileWriter fstream = null;
        List<String> locationItemName= new ArrayList<String>();
        List<String> lpn= new ArrayList<String>();
        try {
            //file to save the sku details required for xml posting
            File file = new File(strTextFilePath);
            fstream = new FileWriter(file, true);
            BufferedWriter out = new BufferedWriter(fstream);
            String[] getArrQL = INT51Queries.getQuery(strTestCaseID);
            String strQuery1 = getArrQL[0];
            connection = DBConnect.getDatabaseConnection(strEnv);
            //System.out.println("System memory before executing the query  " + Runtime.getRuntime().freeMemory());
            //do {
            //execute the first sql query
            statement = connection.prepareStatement(strQuery1);
            //statement.setFetchSize(recordsLimit);
            //add the output from from first sql to result set
            ResultSet result = statement.executeQuery();
            //iterate the first result set data for second sql
            boolean flag=false;
            Integer orderQty = 0;
            Integer count=0;
            if (result.next()) {
                while (result.next()) {
                    //System.out.println("System memory after executing the query  " + Runtime.getRuntime().freeMemory());
                    //endTime = System.currentTimeMillis();
                    //System.out.println("Time taken to execute the first query " + (((endTime - startTime) / 1000) / 60) + " minutes");
                    String strItemName = result.getString("ITEM_NAME");
                    //write to system variable to read it easily
                    System.setProperty("ITEM_NAME", strItemName);
                    String strAllocatableQty = result.getString("ALLOCATABLE_QTY");
                    //write to system variable to read it easily
                    System.setProperty("ALLOCATABLE_QTY", strAllocatableQty);
                    Integer intAllocatableQty = Integer.parseInt(strAllocatableQty);
                    String strFullCaseQty = result.getString("QUANTITY");
                    //write to system variable to read it easily
                    System.setProperty("QUANTITY", strFullCaseQty);
                    Integer intFullCaseQty = Integer.parseInt(strFullCaseQty);
                    
                    if (intAllocatableQty > 8) {
                    	orderQty = (intAllocatableQty > intFullCaseQty)?(intFullCaseQty -1): (intAllocatableQty -1);
                        try {
                            out.append(strTestCaseID).append(",");
                            out.append(strItemName);
                            out.append(", ");
                            out.append(orderQty.toString());
                            out.newLine();
	                          if(count > 7){  
	                            out.close();
	                            statement.close();
	                            connection.close();
	                            return;
	                          }
                              count++;  
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            } else {
                System.out.println("No records found");
                out.append("No records found");
                out.close();
                result.close();
            }
            // } while ((endTime - startTime) / 1000 == 600);
        } catch (SQLException e) {
            try {
                statement.close();
                connection.close();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        } catch (IOException e) {
            try {
                statement.close();
                connection.close();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        }
    }
}
