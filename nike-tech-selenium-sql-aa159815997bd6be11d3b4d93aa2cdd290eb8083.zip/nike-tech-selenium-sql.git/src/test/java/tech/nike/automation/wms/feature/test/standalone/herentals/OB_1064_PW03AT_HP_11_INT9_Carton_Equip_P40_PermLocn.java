package tech.nike.automation.wms.feature.test.standalone.herentals;

import tech.nike.automation.common.framework.sql.DBConnect;
import tech.nike.automation.common.framework.sql.INT9Queries;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static java.lang.Integer.sum;

public class OB_1064_PW03AT_HP_11_INT9_Carton_Equip_P40_PermLocn {
    //global variables instantiation
    public static String strTextFilePath = "c:\\records.txt";

    public static void main(String[] argv) {
        //local variables instantiation
        PreparedStatement statement = null;
        PreparedStatement statement1 = null;
        Connection connection = null;
        String strEnv = "HTLS-ER";
        String strTestCaseID = "OB_1064_PW03AT_HP_11_INT9_Carton_Equip_P40_PermLocn";
        //int recordsLimit = 5000;
        long startTime = System.currentTimeMillis(); // Get the start Time
        long endTime = 0;
        String[] arrItem = new String[2];
        int x1 = 0;
        int index = 0;
        int counter = 0;
        boolean blnFound = false;
        FileWriter fstream = null;
        List<String> itemNames = new ArrayList<String>();
        List<String> countryOfOrigins = new ArrayList<String>();
        List<String> itemAttributes = new ArrayList<String>();
        try {
            //file to save the sku details required for xml posting
            File file = new File(strTextFilePath);
            fstream = new FileWriter(file,true);
            BufferedWriter out = new BufferedWriter(fstream);
            String[] getArrQL = INT9Queries.getQuery(strTestCaseID);
            String strQuery1 = getArrQL[0];
            connection = DBConnect.getDatabaseConnection(strEnv);
            //System.out.println("System memory before executing the query  " + Runtime.getRuntime().freeMemory());
            //do {
            //execute the first sql query
            statement = connection.prepareStatement(strQuery1);
            //statement.setFetchSize(recordsLimit);
            //add the output from from first sql to result set
            ResultSet result = statement.executeQuery();
            //iterate the first result set data for second sql
            if (result.next()) {
                while (result.next()) {
                    //System.out.println("System memory after executing the query  " + Runtime.getRuntime().freeMemory());
                    //endTime = System.currentTimeMillis();
                    //System.out.println("Time taken to execute the first query " + (((endTime - startTime) / 1000) / 60) + " minutes");
                    String strItemName = result.getString("ITEM_NAME");
                    //write to system variable to read it easily
                    System.setProperty("ITEM_NAME", strItemName);
                    String strCountryOfOrigin = result.getString("CNTRY_OF_ORGN");
                    //write to system variable to read it easily
                    System.setProperty("CNTRY_OF_ORGN", strCountryOfOrigin);
                    String strItemAttribute = result.getString("ITEM_ATTR_1");
                    //write to system variable to read it easily
                    System.setProperty("ITEM_ATTR_1", strItemAttribute);
                    String strLPNQty = result.getString("QTY");
                    //write to system variable to read it easily
                    System.setProperty("QTY", strLPNQty);
                    int LPN1Qty = Integer.parseInt(strLPNQty);
                    //calling the SQL statement with new variables each time
                    getArrQL = INT9Queries.getQuery(strTestCaseID);
                    String strQuery2 = getArrQL[1];
                    statement1 = connection.prepareStatement(strQuery2);
                    ResultSet res = statement1.executeQuery();
                    //verify the output of second sql for preconditions
                    try {
                        while (res.next()) {
                            //endTime = System.currentTimeMillis();
                            //System.out.println("Time taken to execute the second query " + (((endTime - startTime) / 1000) / 60) + " minutes");
                            int allQty = Integer.parseInt(res.getString("ALLOCATABLE_QTY"));
                            int maxQty = Integer.parseInt(res.getString("MAX_INVN_QTY"));
                                    /* Identify the Order Quantity (X1):
                                     a.Order Qty X1 should be less than the LPN Quantities ( X1 < LQ1,LQ2....) to avoid full case shipment
                                     b.Order Qty X1 should be greater than the Allocatable Quantity ( X1 > AQ1)
                                     c.Make sure sum (AQ1 +LQ1) is LESS than the Maximum capacity (i.e. (AQ1+LQ1) < MAX1)*/
                            //verify if the allocatable quantity is greater than 0
                            if (allQty > 0) {
                                //set the order quantity to be less than the any one of the LPN quantity
                                x1 = LPN1Qty - 2;
                                //verify the preconditions
                                if (x1 < LPN1Qty && allQty > x1 && sum(allQty, LPN1Qty) < maxQty) {
                                    itemNames.add(strItemName);
                                    countryOfOrigins.add(strCountryOfOrigin);
                                    itemAttributes.add(strItemAttribute);
                                    //checking for same item name
                                    if (itemNames.size() > 2) {
                                        for (int i = 0; i < itemNames.size(); i++) {
                                            if (itemNames.get(0).equals(itemNames.get(i))) {
                                                blnFound = true;
                                            } else {
                                                blnFound = false;
                                                break;
                                            }
                                        }
                                    }
                                    //checking for same country of origin
                                    if (countryOfOrigins.size() > 2) {
                                        for (int i = 0; i < countryOfOrigins.size(); i++) {
                                            if (countryOfOrigins.get(0).equals(countryOfOrigins.get(i))) {
                                                blnFound = true;
                                            } else {
                                                blnFound = false;
                                                break;
                                            }
                                        }
                                    }
                                    //checking for same item attributes
                                    if (itemAttributes.size() > 2) {
                                        for (int i = 0; i < itemAttributes.size(); i++) {
                                            if (itemAttributes.get(0).equals(itemAttributes.get(i))) {
                                                blnFound = true;
                                            } else {
                                                blnFound = false;
                                                break;
                                            }
                                        }
                                    }
                                } else {
                                    System.out.println(strItemName + "  checked for pre-requisite conditions, didn't satisfy conditions");
                                }
                            } else {
                                System.out.println(strItemName + "   didn't satisfy allocatable quantity condition");
                            }
                        }
                    } finally {//the below try catch code will eliminate max cursors exceeded issue
                        try {
                            res.close();
                            statement1.close();
                        } catch (SQLException ignore) {
                        }
                    }
                    //check condition to write into the text file
                    //check condition to write into the text file
                    if (blnFound) {
                        try {
                            out.append(itemNames.get(0)).append(", ");
                            out.append(Integer.toString(x1)).append(", ");
                            out.append(countryOfOrigins.get(0)).append(", ");
                            out.append(itemAttributes.get(0));
                            out.newLine();
                            out.flush();
                            out.close();
                            statement1.close();
                            statement.close();
                            connection.close();
                            return;
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    itemNames.clear();
                    countryOfOrigins.clear();
                    itemAttributes.clear();
                }
            } else {
                System.out.println("No records found");
                out.append("No records found");
                out.close();
                result.close();
            }
            // } while ((endTime - startTime) / 1000 == 600);
        } catch (SQLException e) {
            try {
                statement1.close();
                statement.close();
                connection.close();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        } catch (IOException e) {
            try {
                statement1.close();
                statement.close();
                connection.close();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        }
    }
}