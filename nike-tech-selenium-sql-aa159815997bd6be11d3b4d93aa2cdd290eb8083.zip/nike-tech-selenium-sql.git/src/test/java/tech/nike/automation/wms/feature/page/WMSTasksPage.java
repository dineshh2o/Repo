package tech.nike.automation.wms.feature.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import tech.nike.automation.common.framework.tools.UFTExcelAdaptorAPI;
import tech.nike.automation.common.page.Page;

import java.util.*;

/**
 * Created by psibb1 on 9/22/2016.
 */
public class WMSTasksPage extends Page {
    public By lblTaskId = By.cssSelector("[id$='taskIdVal']");
    public By lnkItemType = By.cssSelector("[id$='ItemBOMDetailsListEV_item_popup_button']");
    public By lblTaskType = By.cssSelector(".advtbl_row>.advtbl_col.advtbl_body_col:nth-child(4)>[id*='dataForm:lview:dataTable']");
    public By lblInvNeedType = By.cssSelector("[id$='descVal_InventoryNeedType']");
    public By lblHeaderStatus = By.cssSelector("[id*='dataForm:lview:dataTable:'][id*=':statusVal']");
    public By lblPriority = By.cssSelector("[id*='dataForm:lview:dataTable:'][id*=':descVal3']");
    List<String> arrItemNames = new ArrayList<String>();
    List<String> arrTaskIds = new ArrayList<String>();
    List<String> arrTaskTypes = new ArrayList<String>();
    List<String> arrInvNeedTypes = new ArrayList<String>();
    List<String> arrHeaderStatus = new ArrayList<String>();
    List<String> arrPriority = new ArrayList<String>();
    Map<String, Object> completeData = new TreeMap<>();
    int i = 0;

    /**
     * method to get the task details from the Task page from a selected pick wave number
     *
     * @return
     */
    public boolean getTaskDetails(Map<String, Object> testdata) {
        boolean result = true;
        //verify if the task ids are listed

        result &= se.element.getElements(lblTaskId).size() > 0;
        if (se.element.getElements(lblTaskId).size() > 0) {
            List<WebElement> taskIDs = se.element.getElements(lblTaskId);
            List<WebElement> itemTypes = se.element.getElements(lnkItemType);
            List<WebElement> taskTypes = se.element.getElements(lblTaskType);
            List<WebElement> invNeedTypes = se.element.getElements(lblInvNeedType);
            List<WebElement> headerStatus = se.element.getElements(lblHeaderStatus);
            List<WebElement> priority = se.element.getElements(lblPriority);
            //iterate all the records and capture the task Id, item names, task type and inventory need types
            for (int i = 0; i <= taskIDs.size() - 1; i++) {
                arrTaskIds.add(taskIDs.get(i).getText().trim());
                arrTaskTypes.add(taskTypes.get(i).getText().trim());
                arrHeaderStatus.add(headerStatus.get(i).getText().trim());
                arrPriority.add(priority.get(i).getText().trim());
                arrItemNames.add(itemTypes.get(i).getText().trim());
                Actions actions = new Actions(getDriver());
                actions.moveToElement(invNeedTypes.get(i));
                actions.perform();
                arrInvNeedTypes.add(invNeedTypes.get(i).getText().trim());
            }
            System.setProperty("INT_FOUND", "Yes");
            completeData.put("Task ID", arrTaskIds);
            completeData.put("Task Type", arrTaskTypes);
            completeData.put("Header Status", arrHeaderStatus);
            completeData.put("Priority", arrPriority);
            completeData.put("Item Names", arrItemNames);
            completeData.put("Inventory Need Type", arrInvNeedTypes);

            se.log.logTestStep("************" + arrTaskIds + "****************");
            se.log.logTestStep("************" + arrTaskTypes + "************");
            se.log.logTestStep("************" + arrHeaderStatus + "************");
            se.log.logTestStep("************" + arrPriority + "************");
            se.log.logTestStep("************" + arrItemNames + "************");
            se.log.logTestStep("************" + arrInvNeedTypes + "************");
        } else
            System.setProperty("INT_FOUND", "No");
        UFTExcelAdaptorAPI reporter=new UFTExcelAdaptorAPI();
        //System.out.println ("Test Case Exist in test data xls : " + reporter.getTestData());
        reporter.updateExcelSheet(testdata,completeData);
        return result;
    }

}