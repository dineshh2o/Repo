package tech.nike.automation.wms.feature.test.standalone.ham;

/**
 * Created by psibb1 on 9/11/2016.
 */
public class test {

    public static void main(String[] argv) {
        int x1 = 7;
        int x2 ;
        x2 = (int)Math.ceil(x1/2);
        System.out.println(x2);
    }
}
