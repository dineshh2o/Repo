package tech.nike.automation.wms.feature.test.standalone.herentals;

import tech.nike.automation.common.framework.sql.DBConnect;
import tech.nike.automation.common.framework.sql.INT9Queries;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Not Implemented refer notes for logic
 * Notes:
 * a) Select item with Alloc_qty > 0 from above query, and has only one size of LPNs.
 * b) Select Item that has multiple LPNs in case reserve.
 * c) Create DO with qty matching the sum of multiple LPNs, but less than the pallet size.
 *d) Make sure multiple number is 5 at least. (Ex: 5 * LPN size)
 */

public class OB_1064_PW03AT_HP_13_INT9_Carton_Equip_P60_PermLocn_for_Packs_NEW {
    //global variables instantiation
    public static String strTextFilePath = "c:\\records.txt";

    public static void main(String[] argv) {
        //local variables instantiation
        PreparedStatement statement1 = null;
        PreparedStatement statement2 = null;
        Connection connection = null;
        String strEnv = "HTLS-ER";
        String strTestCaseID = "OB_1064_PW03AT_HP_13_INT9_Carton_Equip_P60_PermLocn_for_Packs_NEW";
        long startTime = System.currentTimeMillis(); // Get the start Time
        long endTime = 0;
        String[] arrItem = new String[2];
        FileWriter fstream = null;
        List<String> criteria=new ArrayList<String>();
        List<Integer> lpnQty=new ArrayList<Integer>();
        List<Integer> allocQty=new ArrayList<Integer>();
        List<Integer> minQtyList=new ArrayList<Integer>();
        List<String> itemName=new ArrayList<String>();
        List<String> coo=new ArrayList<String>();
        List<String> attribute=new ArrayList<String>();
        try {
            //file to save the sku details required for xml posting
            File file = new File(strTextFilePath);
            fstream = new FileWriter(file, true);
            BufferedWriter out = new BufferedWriter(fstream);
            String[] getArrQL = INT9Queries.getQuery(strTestCaseID);
            String strQuery1 = getArrQL[0];
            String strQuery2 = getArrQL[1];
            connection = DBConnect.getDatabaseConnection(strEnv);
            //execute the first sql query
            statement1 = connection.prepareStatement(strQuery1);
            statement2 = connection.prepareStatement(strQuery2);
            //add the output from from first sql to result set
            ResultSet result = statement1.executeQuery();
            int x1=0,x2=0,orderQty=0;
            //iterate the first result set data for second sql
            boolean flag=false;
            if (result.next()) {
                while (result.next()) {
                    String strItemName = result.getString("ITEM_NAME");
                    //write to system variable to read it easily
                    System.setProperty("ITEM_NAME", strItemName);
                    String strCountryOfOrigin = result.getString("CNTRY_OF_ORGN");
                    //write to system variable to read it easily
                    System.setProperty("CNTRY_OF_ORGN", strCountryOfOrigin);

                    String strItemAttribute = result.getString("ITEM_ATTR_1");
                    System.setProperty("ITEM_ATTR_1", strItemAttribute);
                    
                    String temp=strItemName+","+strCountryOfOrigin+","+strItemAttribute;
                    if(criteria.contains(temp) && flag==false)
                        flag=true;
                    else if(flag==false)
                        criteria.add(temp);
                        try {
                            if(flag==true){
                                statement2.setString(1,strItemName);
                                statement2.setString(2,strCountryOfOrigin);
                                statement2.setString(3,strItemAttribute);
                                ResultSet result2 = statement2.executeQuery();
                                flag=false;
                                int i=0;
                                lpnQty.clear();
                                allocQty.clear();
                                minQtyList.clear();
                                itemName.clear();
                                coo.clear();
                                attribute.clear();
                                if (result2.next()) {
                                    while (result2.next()) {
                                        
                                        int allocatableQty=0;
                                        int strLPNQty=0;
                                        int minQty = 0;
                                        if(result2.getString("allocatable_qty").length()>0) {
                                            allocatableQty = Integer.parseInt(result2.getString("ALLOCATABLE_QTY"));
                                            System.setProperty("ALLOCATABLE_QTY", Integer.toString(allocatableQty));

                                            if (result2.getString("ON_HAND_QTY").length() > 0) {
                                                strLPNQty = Integer.parseInt(result2.getString("ON_HAND_QTY"));
                                                System.setProperty("ON_HAND_QTY", Integer.toString(strLPNQty));
                                            }
                                            
                                            if (result2.getString("MIN_INVN_QTY").length() > 0) {
                                            	minQty = Integer.parseInt(result2.getString("MIN_INVN_QTY"));
                                                System.setProperty("MIN_INVN_QTY", Integer.toString(minQty));
                                            }
                                            
                                            strItemName = result2.getString("ITEM_NAME");
                                            System.setProperty("ITEM_NAME", strItemName);
                                            strCountryOfOrigin = result2.getString("CNTRY_OF_ORGN");
                                            System.setProperty("CNTRY_OF_ORGN", strCountryOfOrigin);
                                            strItemAttribute = result2.getString("SKU_ATTR_1");
                                            System.setProperty("SKU_ATTR_1", strItemAttribute);
                                        }
                                        if( flag==false && allocatableQty>0 ) {
                                            lpnQty.add(strLPNQty);
                                            allocQty.add(allocatableQty);
                                            minQtyList.add(minQty);
                                            itemName.add(strItemName);
                                            coo.add(strCountryOfOrigin);
                                            attribute.add(strItemAttribute);
                                            flag=false;
                                            i++;
                                        }
                                        if(i>0 && i%2==0 && lpnQty.size()==2){
                                        	x1=allocQty.get(0);
                                            x2=lpnQty.get(0);
                                        	orderQty = ((lpnQty.get(0) > lpnQty.get(1))?(lpnQty.get(1) -1): (lpnQty.get(0) -1));
                                        	orderQty = orderQty < x1 ? orderQty : (x1+1);
                                        	orderQty = orderQty > (x1-minQtyList.get(0))?orderQty:(x1-minQtyList.get(0)+1);
                                        	if(orderQty > 0){
                                        		 flag=true;
                                        	}
                                        }
                                           
                                        if( flag==true){
                                        	out.append(strTestCaseID).append(",");
                                        	out.append(itemName.get(0));
                                            out.append(", ");
                                            out.append(Integer.toString(orderQty)).append(", ");
                                            out.append(coo.get(0));
                                            out.append(", ");
                                            out.append(attribute.get(0));
                                            out.close();
                                            connection.close();
                                            return;
                                        } else{
                                            flag=false;
                                            lpnQty.clear();
                                            allocQty.clear();
                                            minQtyList.clear();
                                            itemName.clear();
                                            coo.clear();
                                            attribute.clear();
                                        }
                                    }
                                }

                            }


                        }
                         catch (IOException e) {
                            e.printStackTrace();
                        }

                }
            } else {
                System.out.println("No records found");
                out.append("No records found");
                out.close();
                result.close();
            }
            // } while ((endTime - startTime) / 1000 == 600);
        } catch (SQLException e) {
            try {
                statement1.close();
                statement2.close();
                connection.close();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        } catch (IOException e) {
            try {
                statement1.close();
                statement2.close();
                connection.close();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        }
    }
}
