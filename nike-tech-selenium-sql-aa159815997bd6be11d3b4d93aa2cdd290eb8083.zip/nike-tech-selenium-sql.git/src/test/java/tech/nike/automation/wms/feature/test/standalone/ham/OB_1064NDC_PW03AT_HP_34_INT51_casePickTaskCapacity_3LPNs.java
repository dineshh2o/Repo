package tech.nike.automation.wms.feature.test.standalone.ham;

import tech.nike.automation.common.framework.sql.DBConnect;
import tech.nike.automation.common.framework.sql.INT51Queries;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by PSibb1 on 9/5/2016.
 */
public class OB_1064NDC_PW03AT_HP_34_INT51_casePickTaskCapacity_3LPNs {
    //global variables instantiation
    public static String strTextFilePath = "c:\\records.txt";

    public static void main(String[] argv) {
        //local variables instantiation
        PreparedStatement statement = null;
        PreparedStatement statement1 = null;
        PreparedStatement statement2 = null;
        Connection connection = null;
        String strEnv = "HAM-ER";
        String strTestCaseID = "OB_1064NDC_PW03AT_HP_34_INT51_casePickTaskCapacity_3LPNs";
        //int recordsLimit = 5000;
        long startTime = System.currentTimeMillis(); // Get the start Time
        long endTime = 0;
        String[] arrItem = new String[2];
        int index = 0;
        int counter = 0;
        BigDecimal x1;
        boolean blnFound = false;
        FileWriter fstream = null;
        List<String> itemNames = new ArrayList<String>();
        List<String> itemAttr = new ArrayList<String>();
        List<Integer> orderQuantity = new ArrayList<Integer>();
        List<String> countryOfOrigins = new ArrayList<String>();
        List<String> itemAttributes = new ArrayList<>();
        String custName = null;
        try {
            //file to save the sku details required for xml posting
            File file = new File(strTextFilePath);
            fstream = new FileWriter(file, true);
            BufferedWriter out = new BufferedWriter(fstream);
            String[] getArrQL = INT51Queries.getQuery(strTestCaseID);
            String strQuery1 = getArrQL[0];
            String strQuery2 = getArrQL[1];
            //String strQuery3 = getArrQL[2];
            connection = DBConnect.getDatabaseConnection(strEnv);
            statement = connection.prepareStatement(strQuery1);
            //statement.setFetchSize(recordsLimit);
            ResultSet result = statement.executeQuery();
            //iterate the first result set data for second sql
            if (result.isBeforeFirst()) {
                while (result.next()) {
                        /*int allocatableQty = Integer.parseInt(result.getString("ALLOCATABLE_QTY"));
                        //write to system variable to read it easily
                        System.setProperty("ALLOCATABLE_QTY", Integer.toString(allocatableQty));*/
                    String itemName = result.getString("ITEM_NAME");
                    //write to system variable to read it easily
                    System.setProperty("ITEM_NAME", itemName);
                    String itemAttr1 = result.getString("SKU_ATTR_1");
                    //write to system variable to read it easily
                    System.setProperty("ITEM_ATTR_1", itemAttr1);
                    String coo = result.getString("CNTRY_OF_ORGN");
                    //write to system variable to read it easily
                    System.setProperty("CNTRY_OF_ORGN", coo);
                    BigDecimal uv = result.getBigDecimal("UNIT_VOLUME");
                    //get allocatable qty
                    String strAllocQty = result.getString("QTY");
                    //BigDecimal alloqty = new BigDecimal(strAllocQty);
                    //execute the second sql
                    /*statement1 = connection.prepareStatement(strQuery2);
                    ResultSet result2 = statement1.executeQuery();*/
                    try {
                        /*while (result2.next()) {
                            //get max container volume
                            BigDecimal maxcntrvol = result2.getBigDecimal("MAX_CNTR_VOL");
                            //get max container weight
                            x1 = alloqty;
                          *//*Identify the Item
               a. b.Calculate the Order Qty (Y1) in such a way that the order volume Exceeds the
               Largest MAX_CNTR_VOL value identified Order Volume (Y1 * UV1) >  MAX_CNTR_VOL *//*
                            if (((x1.multiply(uv)).compareTo(maxcntrvol)) > 0) {
                                blnFound = true;*/
                                //checking for same item name

                                //get the customer name
                                statement2 = connection.prepareStatement(strQuery2);
                                ResultSet result3 = statement2.executeQuery();
                                if (result3.next()) {
                                    custName = result3.getString("FACILITY_ALIAS_ID");
                                    //write to system variable to read it easily
                                    System.setProperty("CUSTOMER_NAME", custName);
                                    if (custName != null) {
                                        blnFound &= true;
                                    }
                                }
                            /*} else {
                                System.out.println(itemName + "  max container volume and max container weight " +
                                        "condition not satisfied");
                            }*/
                        //}
                        //check condition to write into the text file
                        if (blnFound) {
                            try {
                                out.append(strTestCaseID).append(",");
                                out.append(itemName).append(", ");
                                //out.append(Integer.b.).append(",");
                                out.append(itemAttr1).append(", ");
                                out.append(coo).append(", ");
                                out.append(custName);
                                out.newLine();
                                out.flush();
                                out.close();
                                statement2.close();
                                //statement1.close();
                                statement.close();
                                connection.close();
                                return;
                            } catch (IOException e) {
                                e.printStackTrace();
                            } catch (SQLException e1) {
                                e1.printStackTrace();
                            }
                            if(itemNames.size() > 4){
                                itemNames.clear();
                                countryOfOrigins.clear();
                                itemAttributes.clear();
                            }
                        }
                    } finally { // to handle max cursor issue
                        try {
                            result.close();
                            statement.close();
                        } catch (SQLException ignore) {
                        }
                    }
                }
            } else {
                System.out.println("No records found");
                out.append(strTestCaseID).append(",");
                out.append("No records found");
                out.close();
                result.close();
            }
        } catch (SQLException e) {
            try {
                connection.close();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}