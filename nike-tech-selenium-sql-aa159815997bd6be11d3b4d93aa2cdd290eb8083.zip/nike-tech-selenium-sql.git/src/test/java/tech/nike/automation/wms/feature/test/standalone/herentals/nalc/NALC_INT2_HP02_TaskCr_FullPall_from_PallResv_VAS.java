package tech.nike.automation.wms.feature.test.standalone.herentals.nalc;

import tech.nike.automation.common.framework.sql.DBConnect;
import tech.nike.automation.common.framework.sql.INT1Queries;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by nchou4 on 9/08/2016.
 */
public class NALC_INT2_HP02_TaskCr_FullPall_from_PallResv_VAS {
    //global variables instantiation
    public static String strTextFilePath = "c:\\WMS-Automation\\records.txt";

    public static void main(String[] argv) {
        //local variables instantiation
        PreparedStatement statement = null;
        PreparedStatement statement1 = null;
        Connection connection = null;
        String strEnv = "NALC-ER";
        String strTestCaseID = "OB_1014_PW03AT_HP_02_SW_INT2_Alloc_TaskCr_FullPall_from_PallResv_VAS";
        //int recordsLimit = 5000;
        long startTime = System.currentTimeMillis(); // Get the start Time
        long endTime = 0;
        String[] arrItem = new String[2];
        int x1 = 0;
        int x2 = 0;
        int index = 0;
        int counter = 0;
        boolean blnFound = false;
        FileWriter fstream = null;
        List<String> itemNames = new ArrayList<String>();
        List<String> countryOfOrigins = new ArrayList<String>();
        List<String> itemAttributes = new ArrayList<String>();
        try {
            //file to save the sku details required for xml posting
            File file = new File(strTextFilePath);
            fstream = new FileWriter(file, true);
            BufferedWriter out = new BufferedWriter(fstream);
            String[] getArrQL = INT1Queries.getQuery(strTestCaseID);
            String strQuery1 = getArrQL[0];
            //System.out.println(strQuery1);
            connection = DBConnect.getDatabaseConnection(strEnv);
            //System.out.println("System memory before executing the query  " + Runtime.getRuntime().freeMemory());
            //do {
            //execute the first sql query
            statement = connection.prepareStatement(strQuery1);
            //statement.setFetchSize(recordsLimit);
            //add the output from from first sql to result set
            System.out.println("Executing Query Please Wait......");
            ResultSet result = statement.executeQuery();
            //iterate the first result set data for second sql

            if (result.isBeforeFirst()) {
                System.out.println("Record found and writing to the file...");
                while (result.next()) {
                    //System.out.println("System memory after executing the query  " + Runtime.getRuntime().freeMemory());
                    //endTime = System.currentTimeMillis();
                    //System.out.println("Time taken to execute the first query " + (((endTime - startTime) / 1000) / 60) + " minutes");
                    String strItemName = result.getString("ITEM_NAME");
                    //write to system variable to read it easily
                    System.setProperty("ITEM_NAME", strItemName);
                    String strCountryOfOrigin = result.getString("CNTRY_OF_ORGN");
                    //write to system variable to read it easily
                    System.setProperty("CNTRY_OF_ORGN", strCountryOfOrigin);
                    String strItemAttribute = result.getString("ITEM_ATTR_1");
                    //write to system variable to read it easily
                    System.setProperty("ITEM_ATTR_1", strItemAttribute);
                    String strLPNQty = result.getString("QTY");
                    //write to system variable to read it easily
                    System.setProperty("QTY", strLPNQty);
                    int LPN1Qty = Integer.parseInt(strLPNQty);

                    itemNames.add(strItemName);
                    countryOfOrigins.add(strCountryOfOrigin);
                    itemAttributes.add(strItemAttribute);

                    try {
                        out.append(strTestCaseID).append(",");
                        out.append(strItemName).append(", ");
                        out.append(strCountryOfOrigin).append(", ");
                        out.append(strItemAttribute).append(", ");
                        out.append(strLPNQty);

                        out.newLine();
                        out.flush();
                        out.close();
                        return;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            } else {
                System.out.println("No records found");
                out.append("No records found");
                out.close();
                result.close();
            }

            statement.close();
            connection.close();
            // } while ((endTime - startTime) / 1000 == 600);
        } catch (SQLException e) {
            try {

                statement.close();
                connection.close();
                e.printStackTrace();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        } catch (IOException e) {
            try {

                statement.close();
                connection.close();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        }

    }


}