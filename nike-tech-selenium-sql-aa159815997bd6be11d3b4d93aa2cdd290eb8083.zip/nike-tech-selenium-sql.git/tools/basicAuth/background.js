var gPendingCallbacks = [];
var bkg = chrome.extension.getBackgroundPage();

var enabled = true;

bkg.console.log("Listening")
chrome.webRequest.onAuthRequired.addListener(handleAuthRequest,
    {urls: sites.urlFilter}, ["asyncBlocking"]);

chrome.browserAction.onClicked.addListener(handleClickEvent);

function processPendingCallbacks() {
    var data = gPendingCallbacks.pop();
    var authd = false;
    if (enabled) {
        for (var i = 0; i < sites.credentials.length; i++) {
            if (typeof data.details.realm != 'undefined' && sites.credentials[i].realm.toLowerCase() == data.details.realm.toLowerCase()) {
                bkg.console.log("Adding credentials for:", data.details.realm, data.details.challenger.host + ":" + data.details.challenger.port);
                data.callback({authCredentials: {username: sites.credentials[i].username, password: sites.credentials[i].password}});
                authd = true;
                break;
            }
        }
    }
    if (!authd) {
        bkg.console.log("Ignoring:", data.details.realm, data.details.challenger.host + ":" + data.details.challenger.port);
        data.callback({});
    }
}

function handleAuthRequest(details, callback) {
    gPendingCallbacks.push({callback:callback, details:details});
    processPendingCallbacks();
}

function handleClickEvent() {
    if (enabled) {
        bkg.console.log('Disabling basicAuth');
        chrome.browserAction.setIcon({'path': "off-19.png"})
        chrome.browserAction.setTitle({'title': "Disabled"})
        enabled = false;
    } else {
        bkg.console.log('Enabling basicAuth');
        chrome.browserAction.setIcon({'path': "on-19.png"})
        chrome.browserAction.setTitle({'title': "Enabled"})
        enabled = true;
    }
}