var BasicAuth = {
    load: function () {
        removeEventListener("load", BasicAuth.load, false);
        window.setTimeout(BasicAuth.login(), 100);
    },

    login: function () {
        try {
            var args = window.arguments[0].QueryInterface(Ci.nsIWritablePropertyBag2).QueryInterface(Ci.nsIWritablePropertyBag);

            if (args.getProperty("promptType") != "promptUserAndPass") {
                BasicAuth.log("Ignoring non-authentication dialog.");
                return;
            }

            var authKey = args.getProperty("text");
            var matches = /^.* requested by ([^ ]+)\. The site says: "([^"]*)"$/.exec(authKey);
            var site = matches[1];
            var realm = matches[2];

            var authd = false;
            for (var i = 0; i < sites.credentials.length; i++) {
                if (typeof realm != 'undefined' && sites.credentials[i].realm.toLowerCase() == realm.toLowerCase()) {
                    BasicAuth.log("Logging into: " + realm + ", " + site);
                    document.getElementById("loginTextbox").setAttribute("value", sites.credentials[i].username);
                    document.getElementById("password1Textbox").setAttribute("value", sites.credentials[i].password);
                    authd = true;
                    break;
                }
            }

            if (authd) {
                if (typeof commonDialogOnAccept != 'undefined') {
                    commonDialogOnAccept();
                } else {
                    document.getElementById("commonDialog").acceptDialog();
                }
                window.close();
            } else {
                BasicAuth.log("Ignoring: " + realm + ", " + site);
            }
        } catch (e) {
            BasicAuth.log(e);
        }

    },

    log: function (msg) {
        var consoleService = Components.classes["@mozilla.org/consoleservice;1"].getService(Components.interfaces.nsIConsoleService);
        consoleService.logStringMessage("BASICAUTH: " + msg);
    }
};