package tech.nike.automation.common.framework.sql;

/**
 * Created by psibb1 on 8/17/2016.
 */
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Utility for converting ResultSets into some Output formats
 *
 */
public class Convertor {
    /**
     * Convert a result set into a JSON file
     * @param resultSet
     * @return a JSONArray
     * @throws Exception
     */
    public static void convertToJSON(ResultSet resultSet, String strJsonFilePath) {
        JSONArray jsonArray = new JSONArray();
        try {
            while (resultSet.next()) {
                int total_rows = resultSet.getMetaData().getColumnCount();
                JSONObject obj = new JSONObject();
                for (int i = 0; i < total_rows; i++) {
                    obj.put(resultSet.getMetaData().getColumnLabel(i + 1)
                            .toLowerCase(), resultSet.getObject(i + 1));
                    jsonArray.put(obj);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        FileWriter file = null;
        try {
            file = new FileWriter(strJsonFilePath);
            file.write(jsonArray.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Convert a result set into XML file
     * @param resultSet
     * @param strXMLFilePath
     */
    public static void convertToXML(ResultSet resultSet, String strXMLFilePath) {
        StringBuffer xmlArray = new StringBuffer("<results>");
        try {
            while (resultSet.next()) {
                int total_rows = resultSet.getMetaData().getColumnCount();
                xmlArray.append("<result ");
                for (int i = 0; i < total_rows; i++) {
                    xmlArray.append(" " + resultSet.getMetaData().getColumnLabel(i + 1)
                            .toLowerCase() + "='" + resultSet.getObject(i + 1) + "'"); }
                xmlArray.append(" />");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        xmlArray.append("</results>");
        FileWriter file = null;
        try {
            file = new FileWriter(strXMLFilePath);
            file.write(xmlArray.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * method convert to json file
     * @param rs
     * @param strJsonFilePath
     */
    public static void getFormattedResult(ResultSet rs, String strJsonFilePath) {
        List<JSONObject> resList = new ArrayList<JSONObject>();
        try {
            // get column names
            ResultSetMetaData rsMeta = rs.getMetaData();
            int columnCnt = rsMeta.getColumnCount();
            List<String> columnNames = new ArrayList<String>();
            for (int i = 1; i <= columnCnt; i++) {
                columnNames.add(rsMeta.getColumnName(i).toUpperCase());
            }
            while (rs.next()) { // convert each object to an human readable JSON object
                JSONObject obj = new JSONObject();
                for (int i = 1; i <= columnCnt; i++) {
                    String key = columnNames.get(i - 1);
                    String value = rs.getString(i);
                    obj.put(key, value);
                }
                resList.add(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        FileWriter file = null;
        try {
            file = new FileWriter(strJsonFilePath);
            file.write(resList.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}