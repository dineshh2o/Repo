package tech.nike.automation.common.framework;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import tech.nike.automation.common.framework.Data.EncryptedString;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Element wrapper class. Contains all things WebElement related.
 * Each method that does something must call myLog.logSeStep
 *
 * @author Cognizant Technology CoE
 */
public class Element {
    private WebDriver myDriver;
    private Log myLog;
    private Assertion myAssertion;
    private Browser myBrowser;
    private int defaultTimeOut = 20;
    private int globalSeTimeOut = 20;
    private Util Util = new Util();
    private boolean inFrame = false;

    /**
     * Waits for a certain text to show up within a certain element
     *
     * @param locator - The element to wait for
     * @param text    - The text to wait for
     * @return true if element with text is found within the timeout window
     */
    private static ExpectedCondition<Boolean> containsText(final By locator, final String text) {
        return new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver driver) {
                List<WebElement> elements = driver.findElements(locator);
                for (WebElement webElement : elements) {
                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView()", webElement);
                    if (webElement.getText().toLowerCase().contains(text.toLowerCase()))
                        return true;
                }
                return false;
            }
        };
    }

    private static ExpectedCondition<WebElement> getElementContainsText(final By locator, final String text) {
        return new ExpectedCondition<WebElement>() {
            public WebElement apply(WebDriver driver) {
                List<WebElement> elements = driver.findElements(locator);
                for (WebElement webElement : elements) {
                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView()", webElement);
                    if (webElement.getText().contains(text))
                        return webElement;
                }
                return null;
            }
        };
    }

    private static ExpectedCondition<Boolean> containsExactText(final By locator, final String text) {
        return new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver driver) {
                List<WebElement> elements = driver.findElements(locator);
                for (WebElement webElement : elements) {
                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView()", webElement);
                    if (webElement.getText().equals(text))
                        return true;
                }
                return false;
            }
        };
    }

    private static ExpectedCondition<Boolean> textLengthIsGreaterThan(final By locator, final int textLength) {
        return new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver driver) {
                List<WebElement> elements = driver.findElements(locator);
                for (WebElement webElement : elements) {
                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView()", webElement);
                    return webElement.getText().length() > textLength;
                }
                return false;
            }
        };
    }

    private static ExpectedCondition<Boolean> containsValue(final By locator, final String value) {
        return new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver driver) {
                List<WebElement> elements = driver.findElements(locator);
                for (WebElement webElement : elements) {
                    if (webElement.getAttribute("value").contains(value))
                        return true;
                }
                return false;
            }
        };
    }

    /**
     * Waits for a certain text to show up within a certain element
     *
     * @param locator    - The element to wait for
     * @param nthElement
     * @param text       - The text to wait for
     * @return true if element with text is found within the timeout window
     */
    private static ExpectedCondition<Boolean> containsText(final By locator, final int nthElement, final String text) {
        return new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver driver) {
                List<WebElement> elements = driver.findElements(locator);
                if (elements.size() < nthElement + 1)
                    return false;
                try {
                    WebElement element = elements.get(nthElement);
                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView()", element);
                    return element.getText().contains(text);
                } catch (Exception e) {
                    return false;
                }
            }
        };
    }

    private static ExpectedCondition<Boolean> elementIsDisplayed(final WebElement element) {
        return new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver driver) {
                return element.isDisplayed();
            }
        };
    }

    /**
     * Waits for one of the two elements to display
     *
     * @param locator1    - The first element to wait for
     * @param locator2	  - The second element to wait for
     * @return true if one of the element displays within time window
     */

    private static ExpectedCondition<Boolean> elementIsDisplayed(final By locator1, final By locator2) {
        return new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver driver) {
                return driver.findElement(locator1).isDisplayed() || driver.findElement(locator2).isDisplayed();
            }
        };
    }

    /**
     * An expectation for checking an element is visible and enabled such that you
     * can click it.
     */
    public static ExpectedCondition<Boolean> elementToBeClickable(
            final By locator, final int nthElement) {
        return new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver driver) {
                List<WebElement> elements = driver.findElements(locator);
                return (elements.get(nthElement).isDisplayed() && elements.get(nthElement).isEnabled());
            }
        };
    }

    public static ExpectedCondition<Boolean> textToBePresentInElement(
            final By locator, final String text) {

        return new ExpectedCondition<Boolean>() {
            @Override
            public Boolean apply(WebDriver driver) {
                try {
                    String elementText = driver.findElement(locator).getText();
                    String elementValue = driver.findElement(locator).getAttribute("value");
                    return elementText.contains(text) || elementValue.contains(text);
                } catch (StaleElementReferenceException e) {
                    return null;
                }
            }

            @Override
            public String toString() {
                return String.format("text ('%s') to be present in element found by %s",
                        text, locator);
            }
        };
    }

    public Element() {
    }

    /**
     * Sets the WebDriver used by this wrapper
     *
     * @param driver
     */
    public void setDriver(WebDriver driver) {
        myDriver = driver;
    }

    /**
     * Sets the Log used by this wrapper
     *
     * @param log
     */
    public void setLog(Log log) {
        myLog = log;
    }

    /**
     * Sets the Assertion used by this wrapper
     *
     * @param assertion
     */
    public void setAssertion(Assertion assertion) {
        myAssertion = assertion;
    }

    /**
     * Change the default timeout for the waits
     *
     * @param seconds
     */
    public void setTimeOut(int seconds) {
        globalSeTimeOut = seconds;
    }

    /**
     * Reset the timeout back to default
     */
    public void resetTimeOut() {
        globalSeTimeOut = defaultTimeOut;
    }

    /**
     * Gets the current setting for the timeout
     *
     * @return the current timeout setting
     */
    public int getTimeOut() {
        return globalSeTimeOut;
    }

    /**
     * Wait for an element, using the default timeout Element.globalSeTimeOut
     *
     * @param locator
     * @return
     */
    public boolean waitForElement(final By locator) {
        return waitForElement(locator, globalSeTimeOut);
    }

    /**
     * Wait for an element to be displayed, using the default timeout Element.globalSeTimeOut
     *
     * @param locator
     * @return
     */
    public boolean waitForElementIsDisplayed(final By locator) {
        return waitForElementIsDisplayed(locator, globalSeTimeOut);
    }


    /**
     * Wait for an element to be displayed, using the default timeout Element.globalSeTimeOut
     *
     * @param locator1
     * @param locator2
     * @return
     */
    public boolean waitForElementIsDisplayed(final By locator1, final By locator2) {
        return waitForElementIsDisplayed(locator1, locator2, globalSeTimeOut);
    }
    /**
     * Wait for an element to be displayed, using the default timeout Element.globalSeTimeOut
     *
     * @param element
     * @return
     */
    public boolean waitForElementIsDisplayed(WebElement element) {
        return waitForElementIsDisplayed(element, globalSeTimeOut);
    }

    /**
     * Wait for an element, using specified timeout
     *
     * @param locator
     * @param timeOutInSeconds
     * @return
     */
    public boolean waitForElement(final By locator, int timeOutInSeconds) {
        try {
            new WebDriverWait(myDriver, timeOutInSeconds)
                    .ignoring(RuntimeException.class)
                    .until(new ExpectedCondition<WebElement>() {
                        public WebElement apply(WebDriver d) {
                            return d.findElement(locator);
                        }
                    });
            return true;
        } catch (TimeoutException e) {
            myLog.logSeStep("Timed out waiting for element " + locator.toString());
            myAssertion.reportError("Timed Out Waiting For Element");
            return false;
        } catch (Exception e) {
            String errorName = "Un-handled Exception in waitForElement: ";
            myLog.logSeStep(errorName + e + ": " + e.getMessage());
            return false;
        }

    }

    /**
     * Wait for an element to be displayed, using specified timeout
     *
     * @param locator
     * @param timeOutInSeconds
     * @return
     */
    public boolean waitForElementIsDisplayed(final By locator, int timeOutInSeconds) {
        try {
            new WebDriverWait(myDriver, timeOutInSeconds)
                    .ignoring(RuntimeException.class)
                    .until(new ExpectedCondition<Boolean>() {
                        public Boolean apply(WebDriver d) {
                            return d.findElement(locator).isDisplayed();
                        }
                    });
            return true;
        } catch (TimeoutException e) {
            myLog.logSeStep("Timed out waiting for element " + locator.toString());
            myAssertion.reportError("Timed Out Waiting For Element");
            return false;
        } catch (Exception e) {
            String errorName = "Un-handled Exception in waitForElement: ";
            myLog.logSeStep(errorName + e + ": " + e.getMessage());
            return false;
        }

    }

    /**
     * Wait for an element to be displayed, using specified timeout
     *
     * @param locator1
     * @param timeOutInSeconds
     * @return
     */
    public boolean waitForElementIsDisplayed(final By locator1, final By locator2, int timeOutInSeconds) {
        try {
            new WebDriverWait(myDriver, timeOutInSeconds)
                    .ignoring(RuntimeException.class)
                    .until(elementIsDisplayed(locator1, locator2));
            return true;
        } catch (TimeoutException e) {
            myLog.logSeStep("Timed out waiting for element " + locator1.toString() + " or "+locator2.toString());
            myAssertion.reportError("Timed Out Waiting For Element");
            return false;
        } catch (Exception e) {
            String errorName = "Un-handled Exception in waitForElement: ";
            myLog.logSeStep(errorName + e + ": " + e.getMessage());
            return false;
        }

    }

    /**
     * Wait for an element to be displayed, using specified timeout
     *
     * @param locator
     * @param position
     * @param timeOutInSeconds
     * @return
     */
    public boolean waitForElementIsDisplayed(final By locator, int position, int timeOutInSeconds) {
        try {
            new WebDriverWait(myDriver, timeOutInSeconds)
                    .ignoring(RuntimeException.class)
                    .until(new ExpectedCondition<Boolean>() {
                        public Boolean apply(WebDriver d) {
                            return d.findElements(locator).get(position).isDisplayed();
                        }
                    });
            return true;
        } catch (TimeoutException e) {
            myLog.logSeStep("Timed out waiting for element " + locator.toString());
            myAssertion.reportError("Timed Out Waiting For Element");
            return false;
        } catch (Exception e) {
            String errorName = "Un-handled Exception in waitForElement: ";
            myLog.logSeStep(errorName + e + ": " + e.getMessage());
            return false;
        }

    }

    /**
     * Wait for an element to be displayed, using specified timeout
     *
     * @param element
     * @param timeOutInSeconds
     * @return
     */
    public boolean waitForElementIsDisplayed(final WebElement element, int timeOutInSeconds) {
        try {
            new WebDriverWait(myDriver, timeOutInSeconds)
                    .ignoring(RuntimeException.class)
                    .until(new ExpectedCondition<Boolean>() {
                        public Boolean apply(WebDriver d) {
                            return element.isDisplayed();
                        }
                    });
            return true;
        } catch (TimeoutException e) {
            myLog.logSeStep("Timed out waiting for element " + element.toString());
            myAssertion.reportError("Timed Out Waiting For Element");
            return false;
        } catch (Exception e) {
            String errorName = "Un-handled Exception in waitForElement: ";
            myLog.logSeStep(errorName + e + ": " + e.getMessage());
            return false;
        }

    }

    /**
     * Wait for an element to be click-able
     *
     * @param locator
     * @param timeOutInSeconds
     * @return
     */
    public boolean waitForElementToBeClickable(final By locator, int timeOutInSeconds) {
        //myLog.logSeStep("Waiting for element to be clickable: " + locator.toString());
        WebDriverWait wait = new WebDriverWait(myDriver, timeOutInSeconds);
        try {
            wait.until(ExpectedConditions.elementToBeClickable(locator));
            return true;
        } catch (TimeoutException e) {
            myLog.logSeStep("Timed out waiting for element " + locator.toString());
            myAssertion.reportError("Timed Out Waiting For Element");
            return false;
        } catch (Exception e) {
            String errorName = "Un-handled Exception in waitForElementToBeClickable: ";
            myLog.logSeStep(errorName + e + ": " + e.getMessage());
            return false;
        }
    }

    /**
     * Wait for an element to be click-able
     *
     * @param locator
     * @return
     */
    public boolean waitForElementToBeClickable(final By locator) {
        return waitForElementToBeClickable(locator, globalSeTimeOut);
    }

    /**
     * Wait for an element to be click-able
     *
     * @param locator
     * @return
     */
    public boolean waitForNthElementToBeClickable(final By locator, int nthElement) {
        //myLog.logSeStep("Waiting for element to be clickable: " + locator.toString());
        try {
            new WebDriverWait(myDriver, globalSeTimeOut)
                    .ignoring(RuntimeException.class)
                    .until(elementToBeClickable(locator, nthElement));
            return true;
        } catch (TimeoutException e) {
            myLog.logSeStep("Timed out waiting for element " + locator.toString());
            myAssertion.reportError("Timed Out Waiting For Element");
            return false;
        } catch (Exception e) {
            String errorName = "Un-handled Exception in waitForNthElementToBeClickable: ";
            myLog.logSeStep(errorName + e + ": " + e.getMessage());
            return false;
        }
    }

    public boolean waitForElementToBeClickable(WebElement element) {
        //myLog.logSeStep("Waiting for element to be clickable: " + locator.toString());
        WebDriverWait wait = new WebDriverWait(myDriver, globalSeTimeOut);
        try {
            wait.until(elementIsDisplayed(element));
            return true;
        } catch (TimeoutException e) {
            myLog.logSeStep("Timed out waiting for element " + element.toString());
            myAssertion.reportError("Timed Out Waiting For Element");
            return false;
        } catch (Exception e) {
            String errorName = "Un-handled Exception in waitForElementToBeClickable:";
            myLog.logSeStep(errorName + e.getMessage());
            //myLog.logTcError(errorName, myLog.takeScreenShot(errorName, false));
            return false;
        }
    }

    /**
     * wait for some text to appear within an element
     * will return false if text does not appear before the globalSeTimeOut is reached
     *
     * @param locator
     * @param text
     * @return
     */
    public boolean waitForTextIsPresent(final By locator, String text) {
        myLog.logSeStep("Waiting for element to contain text: " + locator.toString() + ", " + text);
        WebDriverWait wait = new WebDriverWait(myDriver, globalSeTimeOut);
        try {
            wait.until(containsText(locator, text));
            return true;
        } catch (TimeoutException e) {
            myLog.logSeStep("Timed out waiting for element " + locator.toString());
            myAssertion.reportError("Timed Out Waiting For Element");
            return false;
        } catch (Exception e) {
            String errorName = "Un-handled Exception in waitForTextIsPresent: ";
            myLog.logSeStep(errorName + e + ": " + e.getMessage());
            //myLog.logTcError(errorName, myLog.takeScreenShot(errorName, false));
            return false;
        }
    }

    public boolean waitForExactTextIsPresent(final By locator, String text) {
        myLog.logSeStep("Waiting for element to contain text: " + locator.toString() + ", " + text);
        WebDriverWait wait = new WebDriverWait(myDriver, globalSeTimeOut);
        try {
            wait.until(containsExactText(locator, text));
            return true;
        } catch (TimeoutException e) {
            myLog.logSeStep("Timed out waiting for element " + locator.toString());
            myAssertion.reportError("Timed Out Waiting For Element");
            return false;
        } catch (Exception e) {
            String errorName = "Un-handled Exception in waitForExactTextIsPresent: ";
            myLog.logSeStep(errorName + e + ": " + e.getMessage());
            return false;
        }
    }

    public boolean waitForValueIsPresent(final By locator, String value) {
        myLog.logSeStep("Waiting for element to contain value: " + locator.toString() + ", " + value);
        WebDriverWait wait = new WebDriverWait(myDriver, globalSeTimeOut);
        try {
            wait.until(containsValue(locator, value));
            return true;
        } catch (TimeoutException e) {
            myLog.logSeStep("Timed out waiting for element " + locator.toString());
            myAssertion.reportError("Timed Out Waiting For Element");
            return false;
        } catch (Exception e) {
            String errorName = "Un-handled Exception in waitForValueIsPresent: ";
            myLog.logSeStep(errorName + e + ": " + e.getMessage());
            return false;
        }
    }

    /**
     * wait for some text to appear within an element
     * will return false if text does not appear before the timeOutInSeconds is reached
     *
     * @param locator
     * @param text
     * @return
     */
    public boolean waitForTextIsPresent(final By locator, String text, int timeOutInSeconds) {
        myLog.logSeStep("Waiting for element to contain text: " + locator.toString() + ", " + text);
        WebDriverWait wait = new WebDriverWait(myDriver, timeOutInSeconds);
        try {
            wait.until(containsText(locator, text));
            return true;
        } catch (TimeoutException e) {
            myLog.logSeStep("Timed out waiting for element " + locator.toString());
            myAssertion.reportError("Timed Out Waiting For Element");
            return false;
        } catch (Exception e) {
            String errorName = "Un-handled Exception in waitForTextIsPresent: ";
            myLog.logSeStep(errorName + e + ": " + e.getMessage());
            return false;
        }
    }

    public boolean waitForExactTextIsPresent(final By locator, String text, int timeOutInSeconds) {
        myLog.logSeStep("Waiting for element to contain text: " + locator.toString() + ", " + text);
        WebDriverWait wait = new WebDriverWait(myDriver, timeOutInSeconds);
        try {
            wait.until(containsExactText(locator, text));
            return true;
        } catch (TimeoutException e) {
            myLog.logSeStep("Timed out waiting for element " + locator.toString());
            myAssertion.reportError("Timed Out Waiting For Element");
            return false;
        } catch (Exception e) {
            String errorName = "Un-handled Exception in waitForExactTextIsPresent: ";
            myLog.logSeStep(errorName + e + ": " + e.getMessage());
            return false;
        }
    }

    /**
     * wait for some text to appear within an element
     * will return false if text does not appear before the globalSeTimeOut is reached
     *
     * @param locator
     * @param nthElement
     * @param text
     * @return
     */
    public boolean waitForTextIsPresent(final By locator, int nthElement, String text) {
        return waitForTextIsPresent(locator, nthElement, text, globalSeTimeOut);
    }

    /**
     * wait for some text to appear within an element
     * will return false if text does not appear before the timeOutInSeconds is reached
     *
     * @param locator
     * @param nthElement
     * @param text
     * @return
     */
    public boolean waitForTextIsPresent(final By locator, int nthElement, String text, int timeOutInSeconds) {
        myLog.logSeStep("Waiting for element to contain text: " + locator.toString() + ", " + text);
        WebDriverWait wait = new WebDriverWait(myDriver, timeOutInSeconds);
        try {
            wait.until(containsText(locator, nthElement, text));
            return true;
        } catch (TimeoutException e) {
            myLog.logSeStep("Timed out waiting for element " + locator.toString());
            myAssertion.reportError("Timed Out Waiting For Element");
            return false;
        } catch (Exception e) {
            String errorName = "Un-handled Exception in waitForTextIsPresent: ";
            myLog.logSeStep(errorName + e + ": " + e.getMessage());
            return false;
        }
    }

    /**
     * Wait for an element such as a spinner or modal, to go away.
     *
     * @param locator
     * @return true if element disappears within the timeout limit
     */
    public boolean waitForElementToDisappear(final By locator) {
        boolean elementIsFound = true;
        int timeout = 0;
        myLog.logSeStep("Waiting for element: " + locator.toString() + " to disappear");
        do {
            try {
                WebElement element = myDriver.findElement(locator);
                if (element.isDisplayed() && element.isEnabled()) //&& !element.getAttribute("style").contains("none")
                {
                    Util.sleep(1000);
                    timeout++;
                } else
                    elementIsFound = false;
            } catch (Exception e) {
                elementIsFound = false;
            }
        } while (elementIsFound && (timeout < globalSeTimeOut));

        if (timeout == globalSeTimeOut)
            myLog.logSeStep("Timed out in waitForElementToDisappear");
        return !elementIsFound;
    }

    /**
     * Wait for an element such as a spinner or modal, to go away.
     *
     * @param locator
     * @return true if element disappears within the timeout limit
     */
    public boolean waitForElementToDisappear(final By locator, int timeoutSeconds) {
        boolean elementIsFound = true;
        int timeout = 0;
        myLog.logSeStep("Waiting for element: " + locator.toString() + " to disappear");
        do {
            try {
                WebElement element = myDriver.findElement(locator);
                if (element.isDisplayed() && element.isEnabled()) //&& !element.getAttribute("style").contains("none")
                {
                    Util.sleep(1000);
                    timeout++;
                } else
                    elementIsFound = false;
            } catch (Exception e) {
                elementIsFound = false;
            }
        } while (elementIsFound && (timeout < timeoutSeconds));

        if (timeout == timeoutSeconds)
            myLog.logSeStep("Timed out in waitForElementToDisappear");
        return !elementIsFound;
    }

    /**
     * Wait for an element with some text such as a "loading...", to go away.
     *
     * @param locator
     * @return true if element disappears within the timeout limit
     */
    public boolean waitForElementWithTextToDisappear(final By locator, String text) {
        boolean elementIsFound = true;
        int timeout = 0;
        myLog.logSeStep("Waiting for element: " + locator.toString() + " with text: " + text + " to disappear");
        do {
            try {
                WebElement element = myDriver.findElement(locator);
                if (element.isDisplayed() && element.isEnabled()) {
                    if (myDriver.findElement(locator).getText().contains(text)) {
                        Util.sleep(1000);
                        timeout++;
                    } else
                        elementIsFound = false;

                } else
                    elementIsFound = false;
            } catch (Exception e) {
                elementIsFound = false;
            }

        } while (elementIsFound && (timeout < globalSeTimeOut));

        if (timeout == globalSeTimeOut)
            myLog.logSeStep("Timed out in waitForElementWithTextToDisappear");
        return !elementIsFound;
    }

    public boolean waitForElementWithAttributeToAppear(final By locator, final String attribute, final String attributeValue, int timeOutInSeconds) {
        myLog.logSeStep("Waiting for element: " + locator.toString() + " with attribute: " + attribute + " = " + attributeValue + " to appear");
        try {
            return new WebDriverWait(myDriver, timeOutInSeconds)
                    .ignoring(RuntimeException.class)
                    .until(new ExpectedCondition<Boolean>() {
                        public Boolean apply(WebDriver d) {
                            return d.findElement(locator).getAttribute(attribute).contains(attributeValue);
                        }
                    });

        } catch (TimeoutException e) {
            myAssertion.reportError("Timed Out Waiting For Element");
            return false;
        } catch (Exception e) {
            String errorName = "Un-handled Exception in waitForElement: ";
            myAssertion.reportError(errorName + e + ": " + e.getMessage());
            return false;
        }
    }

    public boolean waitForElementWithAttributeToAppear(final By locator, int nthElement, String attribute, String attributeValue, int waitTime) {
        boolean elementIsFound = false;
        int timeout = 0;
        myLog.logSeStep("Waiting for element: " + locator.toString() + " with attribute: " + attribute + " = " + attributeValue + " to appear");
        do {
            String attr = getAttribute(locator, attribute, nthElement);
            if (attr == null || attr.isEmpty()) {
                Util.sleep(1000);
                timeout++;
                continue;
            } else if (attr.contains(attributeValue)) {
                elementIsFound = true;
            } else {
                Util.sleep(1000);
                timeout++;
            }

        } while (!elementIsFound && (timeout < waitTime));

        if (timeout == globalSeTimeOut)
            myLog.logSeStep("Timed out in waitForElementWithAttributeToAppear");
        return elementIsFound;
    }

    public boolean waitForPageTitle(String text) {
        myLog.logSeStep("Waiting for page title to contain text: " + text);
        WebDriverWait wait = new WebDriverWait(myDriver, globalSeTimeOut);
        try {
            wait.until(ExpectedConditions.titleContains(text));
            return true;
        } catch (TimeoutException e) {
            myLog.logSeStep("Timed out waiting for page title to contain text: " + text);
            myAssertion.reportError("Timed Out Waiting For page title");
            return false;
        } catch (Exception e) {
            String errorName = "Un-handled Exception in waitForPageTitle:";
            myLog.logSeStep(errorName + e.getMessage());
            return false;
        }
    }

    /**
     * wait for the length of the text in the element to be greater than
     * will return false if text does not appear before the timeOutInSeconds is reached
     * @author Cognizant Technology CoE
     * @param locator
     * @param minTextLength
     * @return
     */
    public boolean waitForTextLengthIsGreaterThan(final By locator, int minTextLength) {
        myLog.logSeStep(String.format("Waiting for element %s to contain text with length greater than %d", locator.toString(), minTextLength));
        WebDriverWait wait = new WebDriverWait(myDriver, globalSeTimeOut);
        try {
            wait.until(textLengthIsGreaterThan(locator, minTextLength));
            return true;
        } catch (TimeoutException e) {
            myLog.logSeStep(String.format("Timed out waiting for element %s to contain text with length greater than %d", locator.toString(), minTextLength));
            myAssertion.reportError("Timed Out Waiting For Element");
            return false;
        } catch (Exception e) {
            String errorName = "Un-handled Exception in waitForTextLengthIsGreaterThan: ";
            myLog.logSeStep(errorName + e + ": " + e.getMessage());
            return false;
        }
    }

    public boolean isClickable(final By locator) {
        myLog.logSeStep("Checking if Element is clickable: " + locator.toString());
        try {
            return myDriver.findElement(locator).isEnabled() && myDriver.findElement(locator).isDisplayed();
        } catch (Exception e) {
            //swallow
            return false;
        }
    }

    /**
     * Returns true if element exists
     *
     * @param locator
     * @return
     */
    public boolean exists(final By locator) {
        myLog.logSeStep("Checking if Element exists: " + locator.toString());
        myDriver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
        try {
            myDriver.findElement(locator);
            return true;
        } catch (Exception e) {
            //swallow
            return false;
        }
    }

    /**
     * Returns true if element exists
     *
     * @param locator
     * @param nthElement
     * @return
     */
    public boolean exists(final By locator, int nthElement) {
        myLog.logSeStep("Checking if nthElement exists: " + locator.toString() + " #" + nthElement);
        myDriver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
        try {
            List<WebElement> elements = myDriver.findElements(locator);
            elements.get(nthElement);
            return true;
        } catch (Exception e) {
            return false;
        }
    }


    /**
     * Returns true if element exists with text
     *
     * @param locator
     * @param text
     * @return
     */
    public boolean existsWithText(final By locator, String text) {
        myLog.logSeStep("Checking if Element exists: " + locator.toString() + " with text: " + text);
        myDriver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
        try {
            List<WebElement> elements = getElements(locator);
            for (WebElement webElement : elements) {
                if (webElement.getText().contains(text))
                    return true;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean existsWithExactText(final By locator, String text) {
        myLog.logSeStep("Checking if Element exists: " + locator.toString() + " with text: " + text);
        myDriver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
        try {
            List<WebElement> elements = getElements(locator);
            for (WebElement webElement : elements) {
                if (webElement.getText().equals(text))
                    return true;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Returns true if element exists with text
     *
     * @param locator
     * @param nthElement
     * @param text
     * @return
     */
    public boolean existsWithText(final By locator, int nthElement, String text) {
        myLog.logSeStep("Checking if nthElement exists: " + locator.toString() + " #" + nthElement + " with text: " + text);
        myDriver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
        try {
            List<WebElement> elements = myDriver.findElements(locator);
            WebElement element = elements.get(nthElement);
            return element.getText().contains(text);
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Search frames for an Element
     *
     * @param locator
     * @return
     */
    private WebElement searchForElement(final By locator, final int timeOutInSeconds) {
        if (waitForElement(locator, timeOutInSeconds)) {
            return getElement(locator);
        }
        return null;
    }
    private WebElement searchForElement(final By locator) {
        return searchForElement(locator, globalSeTimeOut);
    }

    /**
     * Search frames for Elements
     *
     * @param locator
     * @return
     */
    private List<WebElement> searchForElements(final By locator) {
        if (waitForElement(locator)) {
            return getElements(locator);
        }
        return null;
    }

    /**
     * Finds and returns the element
     *
     * @param locator
     * @return
     */
    public WebElement getElement(final By locator) {
        try {
            return myDriver.findElement(locator);
        } catch (NoSuchElementException e) {
            String errorName = "NoSuchElementException Exception in getElement:";
            myLog.logSeStep(errorName + e.getMessage());
            //myLog.logTcError(myAssertion.getAssertionCount(), myLog.getTcName(), myBrowser.takeScreenShot(errorName), myAssertion.verdictText());
            return null;
        } catch (Exception e) {
            String errorName = "Un-handled Exception in getElement:";
            myLog.logSeStep(errorName + e.getMessage());
            //myLog.logTcError(errorName, myLog.takeScreenShot(errorName, false));
            return null;
        }
    }

    public WebElement getElementContainingText(final By locator, String containsText, int timeout) {
        try {
            return new WebDriverWait(myDriver, timeout)
                    .ignoring(RuntimeException.class)
                    .until(getElementContainsText(locator, containsText));
        } catch (TimeoutException e) {
            return null;
        }
    }

    public WebElement getElementContainingText(final By locator, String containsText) {
        return getElementContainingText(locator, containsText, globalSeTimeOut);
    }

    /**
     * Wait for, finds, and returns the element
     *
     * @param locator
     * @return
     */
    private WebElement waitForAndGetElement(final By locator) {
        WebElement element;
        waitForElement(locator);
        try {
            element = myDriver.findElement(locator);
            return element;
        } catch (NoSuchElementException e) {
            String errorName = "NoSuchElementException Exception in getElement:";
            myLog.logSeStep(errorName + e.getMessage());
            //myLog.logTcError(myAssertion.getAssertionCount(), myLog.getTcName(), myBrowser.takeScreenShot(errorName), );
            return null;
        } catch (Exception e) {
            String errorName = "Un-handled Exception in getElement:";
            myLog.logSeStep(errorName + e.getMessage());
            //myLog.logTcError(myAssertion.getAssertionCount(), errorName, myLog.takeScreenShot(errorName, false));
            return null;
        }
    }

    private List<WebElement> waitForAndGetElements(final By locator) {
        List<WebElement> element;
        waitForElement(locator);
        try {
            element = myDriver.findElements(locator);
            return element;
        } catch (NoSuchElementException e) {
            String errorName = "NoSuchElementException Exception in getElement:";
            myLog.logSeStep(errorName + e.getMessage());
            //myLog.logTcError(errorName, myLog.takeScreenShot(errorName, false));
            return null;
        } catch (Exception e) {
            String errorName = "Un-handled Exception in getElement:";
            myLog.logSeStep(errorName + e.getMessage());
            //myLog.logTcError(errorName, myLog.takeScreenShot(errorName, false));
            return null;
        }
    }

    @SuppressWarnings("unused")
    private WebElement sleepAndReturnElement(final By locator, int sleep) {
        Util.sleep(sleep);
        return getElement(locator);
    }

    @SuppressWarnings("unused")
    private WebElement sleepAndReturnElement(WebElement element, int sleep) {
        Util.sleep(sleep);
        return element;
    }

    @SuppressWarnings("unused")
    private List<WebElement> sleepAndReturnElements(final By locator, int sleep) {
        Util.sleep(sleep);
        return getElements(locator);
    }

    /**
     * Search frames for an Element
     *
     * @param locator
     * @return
     */
    private WebElement searchForClickableElement(final By locator) {
        return searchForClickableElement(locator, globalSeTimeOut);
    }

    private WebElement searchForClickableElement(final By locator, int timeOutInSeconds) {
        if (!inFrame)
            returnToDefaultContent();
        if (waitForElementToBeClickable(locator, timeOutInSeconds)) {
            return getElement(locator);
        }
        return null;
    }

    /**
     * Search frames for Elements
     *
     * @param locator
     * @return
     */
    private List<WebElement> searchForClickableElements(final By locator) {
        return searchForClickableElements(locator, globalSeTimeOut);
    }

    private List<WebElement> searchForClickableElements(final By locator, int timeOutInSeconds) {
        if (!inFrame)
            returnToDefaultContent();
        if (waitForElementToBeClickable(locator, timeOutInSeconds)) {
            return getElements(locator);
        }
        return null;
    }


    /**
     * Finds and returns a list of matching elements
     *
     * @param locator
     * @return
     */
    public List<WebElement> getElements(final By locator) {
        try {
            return myDriver.findElements(locator);
        } catch (Exception e) {
            String errorName = "Un-handled Exception in getElements:";
            myLog.logSeStep(errorName + e.getMessage());
            //myLog.logTcError(errorName, myLog.takeScreenShot(errorName, false));
            return new ArrayList<WebElement>();
        }
    }

    /**
     * Click the element
     *
     * @param locator
     * @return
     */
    public boolean clickElement(final By locator) {
        return clickElement(locator, null, false, -1, null, -1, -1, null, false);
    }

    public boolean clickElement(final By locator, final By successLocator) {
        return clickElement(locator, null, false, -1, null, -1, -1, successLocator, false);
    }

    public boolean clickElement(final By locator, final By successLocator, final boolean shouldDisappear) {
        return clickElement(locator, null, false, -1, null, -1, -1, successLocator, shouldDisappear);
    }

    public boolean clickElement(final By locator, final int nthElement) {
        return clickElement(locator, null, false, nthElement, null, -1, -1, null, false);
    }

    public boolean clickElementContainingText(final By locator, final String containsText) {
        return clickElement(locator, containsText, false, -1, null, -1, -1, null, false);
    }

    public boolean clickElementContainingText(final By locator, final String containsText, final By successLocator) {
        return clickElement(locator, containsText, false, -1, null, -1, -1, successLocator, false);
    }

    public boolean clickElementContainingText(final By locator, final String containsText, final By successLocator, final boolean shouldDisappear) {
        return clickElement(locator, containsText, false, -1, null, -1, -1, successLocator, shouldDisappear);
    }

    public boolean clickElementContainingExactText(final By locator, final String containsText) {
        return clickElement(locator, containsText, true, -1, null, -1, -1, null, false);
    }

    /**
     * Click an element at location x,y inside the element
     *
     * @param locator
     * @param x
     * @param y
     * @return
     */
    public boolean clickElementAtPoint(final By locator, int x, int y) {
        return clickElement(locator, null, false, -1, null, x, y, null, false);
    }

    /**
     * Click an element at location x,y inside the element
     *
     * @param locator
     * @param nthElement
     * @param x
     * @param y
     * @return
     */
    public boolean clickElementAtPoint(final By locator, int nthElement, int x, int y) {
        return clickElement(locator, null, false, nthElement, null, x, y, null, false);
    }

    public boolean clickElementContainingTextAtPoint(final By locator, String containsText, int x, int y) {
        return clickElement(locator, containsText, false, -1, null, x, y, null, false);
    }

    /**
     * Click an element inside a frame
     *
     * @param locator
     * @param nthElement
     * @param frameName
     * @return
     */
    public boolean clickElement(final By locator, int nthElement, String frameName) {
        return clickElement(locator, null, false, nthElement, frameName, -1, -1, null, false);
    }

    public boolean clickElement(final By locator, final String containsText, final boolean exactText, final int nthElement, final String frameName, final int x, final int y, final By successLocator, final boolean shouldDisappear) {
        // Build logging message from options
        StringBuilder msg = new StringBuilder();
        msg.append("Click");
        if (nthElement != -1)
            msg.append(" (").append(nthElement).append(")");
        msg.append(" element: ").append(locator.toString());
        if (containsText != null && !containsText.isEmpty())
            msg.append(" containing '").append(containsText).append("'");
        if (frameName != null && !frameName.isEmpty())
            msg.append(" in Frame ").append(frameName);
        if (x != -1 || y != -1)
            msg.append(" At (").append(x).append(",").append(y).append(")");
        myLog.logSeStep(msg.toString());

        try {
            return new WebDriverWait(myDriver, globalSeTimeOut)
                    .ignoring(Throwable.class)
                    .withMessage("Unable to click on element")
                    .until(new ExpectedCondition<Boolean>() {
                        public Boolean apply(WebDriver driver) {
                            // Switch frame is specified
                            if (frameName != null && !frameName.isEmpty())
                                switchToFrame(frameName);

                            // Find targetElement
                            WebElement targetElement = null;
                            if (containsText != null && !containsText.isEmpty()) {
                                for (WebElement element : getElements(locator)) {
                                    String elementText = element.getText();
                                    if (elementText.equals(containsText) || (!exactText && elementText.contains(containsText))) {
                                        targetElement = element;
                                        break;
                                    }
                                }
                            } else if (nthElement != -1) {
                                targetElement = getElements(locator).get(nthElement);
                            } else {
                                targetElement = getElement(locator);
                            }

                            // Click on the element
                            if (targetElement != null) {
                                if (x != -1 || y != -1) {
                                    new Actions(driver).moveToElement(targetElement).moveByOffset(x, y).click().perform();
                                } else {
                                    targetElement.click();
                                }
                            }

                            // Check for success locator
                            boolean success = (targetElement != null && successLocator == null) || (shouldDisappear ? waitForElementToDisappear(successLocator, 5) : waitForElementIsDisplayed(successLocator, 5));

                            // Switch frame back to default, if frame was specified
                            if (success && frameName != null && !frameName.isEmpty())
                                returnToDefaultContent();

                            // Did we do it?
                            return success;
                        }
                    });
        } catch (Throwable t) {
            String errorName = "Click Element: ";
            myLog.logSeStep(errorName + t.getMessage() + ": " + ExceptionUtils.getStackTrace(t));
            //myLog.logTcError(errorName, myLog.takeScreenShot(errorName, false));
            // Switch frame back to default, if a frame was specified
            if (frameName != null && !frameName.isEmpty())
                returnToDefaultContent();
            return false;
        }
    }

    public boolean doubleClickElement(final By locator) {
        return doubleClickElement(locator, globalSeTimeOut);
    }

    public boolean doubleClickElement(final By locator, int timeOutInSeconds) {
        myLog.logSeStep("Click Element : " + locator.toString());
        WebElement element = searchForClickableElement(locator, timeOutInSeconds);
        if (element != null) {
            new Actions(myDriver).doubleClick(element).perform();
            return true;
        } else {
            return false;
        }
    }

    public boolean rightClickElement(final By locator) {
        WebElement element;
        myLog.logSeStep("Right Click Element : " + locator.toString());
        element = searchForClickableElement(locator);
        if (element != null) {
            Actions builder = new Actions(myDriver);
            Action action = builder.contextClick(element).build();
            action.perform();
            return true;
        } else
            return false;
    }

    public boolean clickChildElement(WebElement webElement, final By locator) {
        WebElement element;
        myLog.logSeStep("Click Child Element : " + locator.toString());
        if (webElement == null)
            return false;
        element = webElement.findElement(locator);
        if (element != null) {
            hover(element);
            waitForElementToBeClickable(element);
            element.click();
            return true;
        } else
            return false;
    }


    public boolean doubleClickElementContainingText(final By locator, String containsText) {
        myLog.logSeStep("Double Click Element : " + locator.toString() + " containing text " + containsText);
        List<WebElement> elements = getElements(locator);
        for (WebElement webElement : elements) {
            if (webElement.getText().contains(containsText)) {
                new Actions(myDriver).doubleClick(webElement).perform();
                return true;
            }
        }
        return false;
    }


    /**
     * hover over an element
     *
     * @param locator
     * @return
     */
    public boolean hover(final By locator) {
        WebElement element;
        myLog.logSeStep("Hover Over Element: " + locator.toString());
        element = searchForElement(locator);
        if (element != null) {
            Actions action = new Actions(myDriver);
            action = action.moveToElement(element);
            action.perform();
            return true;
        } else
            return false;
    }

    public boolean hover(WebElement element) {
        myLog.logSeStep("Hover Over Element: " + element.toString());
        Actions actions = new Actions(myDriver);
        Action action = actions.moveToElement(element).build();
        action.perform();
        return true;
    }

    public boolean hover(WebElement element, int x, int y) {
        myLog.logSeStep("Hover Over Element: " + element.toString());
        Actions actions = new Actions(myDriver);
        Action action = actions.moveToElement(element, x, y).build();
        action.perform();
        return true;
    }

    /**
     * Hover over an element
     *
     * @param locator
     * @param nthElement
     * @return
     */
    public boolean hover(final By locator, int nthElement) {
        List<WebElement> elements;
        myLog.logSeStep("Hover Over Element: " + locator.toString() + " #"
                + nthElement);
        elements = searchForElements(locator);
        if (elements != null && elements.size() > 0) {
            Actions action = new Actions(myDriver);
            action = action.moveToElement(elements.get(nthElement));
            action.perform();
            return true;
        } else
            return false;
    }

    /**
     * Hover over an element, and then click on another element that pops up.
     *
     * @param locatorForHover
     * @param locatorForClick
     * @return
     */
    public boolean hoverAndClick(final By locatorForHover, final By locatorForClick) {
        WebElement hoverOverElement;
        myLog.logSeStep("Hover Over Element : " + locatorForHover.toString() + " Click On Element : " + locatorForClick.toString());
        hoverOverElement = searchForElement(locatorForHover);
        if (hoverOverElement != null) {
            Actions action = new Actions(myDriver);
            action = action.moveToElement(hoverOverElement).moveToElement(waitForAndGetElement(locatorForClick)).click();
            action.perform();
            return true;
        } else
            return false;
    }

    /**
     * Hover over an element, and then click on another element that pops up.
     *
     * @param locatorForHover
     * @param locatorForClick
     * @param nthElement      for hover
     * @return
     */
    public boolean hoverAndClick(final By locatorForHover, final By locatorForClick, int nthElement) {
        List<WebElement> hoverOverElement;
        myLog.logSeStep("Hover Over Element : " + locatorForHover.toString() + " #"
                + nthElement + " Click On Element : " + locatorForClick.toString());
        hoverOverElement = searchForElements(locatorForHover);
        if (hoverOverElement != null) {
            Actions action = new Actions(myDriver);
            action = action.moveToElement(hoverOverElement.get(nthElement)).moveToElement(getElement(locatorForClick)).click();
            action.perform();
            return true;
        } else
            return false;
    }


    public boolean dragAndDrop(By dragElement, By dropElement, int msDelayBeforeDrop) {
        return dragAndDrop(dragElement, null, -1, dropElement, null, -1, null, msDelayBeforeDrop, -1, -1);
    }

    public boolean dragAndDrop(By dragElement, By dropElement, int msDelayBeforeDrop, int x, int y) {
        return dragAndDrop(dragElement, null, -1, dropElement, null, -1, null, msDelayBeforeDrop, x, y);
    }

    public boolean dragAndDropAcrossFrames(By dragElement, By dropElement, String iFrameName) {
        return dragAndDrop(dragElement, null, -1, dropElement, null, -1, iFrameName, 0, -1, -1);
    }

    public boolean dragAndDropAcrossFrames(By dragElement, By dropElement, String iFrameName, int msDelayBeforeDrop) {
        return dragAndDrop(dragElement, null, -1, dropElement, null, -1, iFrameName, msDelayBeforeDrop, -1, -1);
    }

    public boolean dragAndDropAcrossFrames(By dragElement, By dropElement, String iFrameName, int msDelayBeforeDrop, int x, int y) {
        return dragAndDrop(dragElement, null, -1, dropElement, null, -1, iFrameName, msDelayBeforeDrop, x, y);
    }

    public boolean dragAndDropAcrossFrames(By dragElement, String dragElementText, By dropElement, String dropElementText, String iFrameName, int msDelayBeforeDrop) {
        return dragAndDrop(dragElement, dragElementText, -1, dropElement, dropElementText, -1, iFrameName, msDelayBeforeDrop, -1, -1);
    }

    public boolean dragAndDropAcrossFrames(By dragElement, String dragElementText, By dropElement, String dropElementText, String iFrameName, int msDelayBeforeDrop, int x, int y) {
        return dragAndDrop(dragElement, dragElementText, -1, dropElement, dropElementText, -1, iFrameName, msDelayBeforeDrop, x, y);
    }

    public boolean dragAndDropAcrossFrames(By dragElement, int nthDragElement, By dropElement, int nthDropElement, String iFrameName, int msDelayBeforeDrop) {
        return dragAndDrop(dragElement, null, nthDragElement, dropElement, null, nthDropElement, iFrameName, msDelayBeforeDrop, -1, -1);
    }

    public boolean dragAndDrop(By dragElementLocator, String dragElementText, int nthDragElement, By dropElementLocator, String dropElementText, int nthDropElement, String iFrameName, int msDelayBeforeDrop, int x, int y) {
        try {
            // Build logging message from options
            StringBuilder msg = new StringBuilder();
            msg.append("Drag");
            if (nthDragElement != -1)
                msg.append(" (").append(nthDragElement).append(")");
            msg.append(" element: ").append(dragElementLocator.toString());
            if (dragElementText != null && !dragElementText.isEmpty())
                msg.append(" containing '").append(dragElementText).append("'");
            msg.append(" and Drop on");
            if (nthDropElement != -1)
                msg.append(" (").append(nthDropElement).append(")");
            msg.append(" element: ").append(dropElementLocator.toString());
            if (dropElementText != null && !dropElementText.isEmpty())
                msg.append(" containing '").append(dropElementText).append("'");
            if (iFrameName != null && !iFrameName.isEmpty())
                msg.append(" in Frame ").append(iFrameName);
            myLog.logSeStep(msg.toString());

            // Init our action builder;
            Actions builder = new Actions(myDriver);

            // Find the dragElement
            WebElement dragElement;
            if (dragElementText != null && !dragElementText.isEmpty())
                dragElement = getElementContainingText(dragElementLocator, dragElementText);
            else if (nthDragElement != -1)
                dragElement = waitForAndGetElements(dragElementLocator).get(nthDragElement);
            else
                dragElement = waitForAndGetElement(dragElementLocator);

            // Pickup the dragElement
            builder.clickAndHold(dragElement).perform();

            // If delay required, delay
            if (msDelayBeforeDrop > 0)
                Util.sleep(msDelayBeforeDrop / 2);

            // If across frames, switch frame
            if (iFrameName != null && !iFrameName.isEmpty())
                switchToFrame(iFrameName);

            // Find the dropElement
            WebElement dropElement;
            if (dropElementText != null && !dropElementText.isEmpty())
                dropElement = getElementContainingText(dropElementLocator, dropElementText);
            else if (nthDropElement != -1)
                dropElement = waitForAndGetElements(dropElementLocator).get(nthDropElement);
            else
                dropElement = waitForAndGetElement(dropElementLocator);

            // Move to the dropElement
            if (x != -1 || y != -1) {
                // If we are dropping "Above" the target, drag to the element, then move to above
                if (y < 0) {
                    // Make sure there is space above the element
                    ((JavascriptExecutor) myDriver).executeScript("arguments[0].scrollIntoView(); document.body.scrollTop += " + (y - 5), dropElement);
                    builder.moveToElement(dropElement).perform();
                    Util.sleep(msDelayBeforeDrop / 2);
                }
                builder.moveToElement(dropElement, x, y).perform();
            } else {
                builder.moveToElement(dropElement).perform();
            }

            // If delay required, delay
            if (msDelayBeforeDrop > 0)
                Util.sleep(msDelayBeforeDrop / 2);

            // Release the drag element
            builder.release().perform();
            return true;
        } catch (Exception e) {
            String errorName = "Failure to Drag and Drop: ";
            myLog.logSeStep(errorName + e.getMessage());
            //myLog.logTcError(errorName, myLog.takeScreenShot(errorName, false));
            return false;
        }
    }


    /**
     * Get the number frames on the page
     *
     * @return int number of frames
     */
    public int getNumberFrames() {
        int iframes = 0;
        int framesets = 0;
        List<WebElement> elements = getElements(By.tagName("iframe"));
        if (elements != null)
            iframes = elements.size();
        elements = getElements(By.tagName("frameset"));
        if (elements != null)
            framesets = elements.size();
        return iframes + framesets;
    }

    /**
     * Get the number of windows open
     *
     * @return int number of windows
     */
    public int getNumberWindows() {
        return myDriver.getWindowHandles().size();
    }


    public boolean enterText(By locator, Keys keys) {
        WebElement element;
        myLog.logSeStep("Enter Text '" + keys.toString() + "' in Element: " + locator.toString());
        element = searchForClickableElement(locator);
        if (element != null) {
            try {
                element.sendKeys(keys);
                return true;
            } catch (InvalidElementStateException e) {
                myLog.logSeStep("Could not enter text in " + locator.toString() + ", element not visible or not enabled");
                myAssertion.reportError("Could not enter text, element not visible or not enabled");
                return false;
            } catch (Exception e) {
                myLog.logSeStep("Could not enter text in " + locator.toString());
                myAssertion.reportError("Could not enter text");
                return false;
            }
        } else
            return false;
    }

    /**
     * Enter text into element
     *
     * @param locator
     * @param textToType
     * @return
     */
    public boolean enterText(final By locator, final String textToType) {
        myLog.logSeStep("Enter Text '" + textToType + "' in Element: " + locator.toString());

        try {
            return new WebDriverWait(myDriver, globalSeTimeOut)
                    .ignoring(RuntimeException.class)
                    .until(new ExpectedCondition<Boolean>() {
                        public Boolean apply(WebDriver myDriver) {
                            WebElement element = searchForClickableElement(locator);
                            element.clear();
                            element.sendKeys(Keys.BACK_SPACE);
                            element.sendKeys(textToType);
                            return new WebDriverWait(myDriver, 2).until(textToBePresentInElement(locator, textToType));
                        }
                    });
        } catch (InvalidElementStateException e) {
            myAssertion.reportError("Could not enter text in " + locator.toString() + ", element not visible or not enabled<br>" + e.getMessage());
            return false;
        } catch (Exception e) {
            myAssertion.reportError("Could not enter text in " + locator.toString() + "<br>" + e.getMessage());
            return false;
        }
    }

    public boolean clearText(final By locator) {
        WebElement element;
        myLog.logSeStep("Clear Text in Element: " + locator.toString());
        element = searchForClickableElement(locator);
        if (element != null) {
            try {
                element.clear();
                return true;
            } catch (InvalidElementStateException e) {
                myLog.logSeStep("Could not clear text in " + locator.toString() + ", element not visible or not enabled");
                myAssertion.reportError("Could not clear text, element not visible or not enabled");
                return false;
            } catch (Exception e) {
                myLog.logSeStep("Could not clear text in " + locator.toString());
                myAssertion.reportError("Could not clear text");
                return false;
            }
        } else
            return false;
    }

    public boolean sendKeys(final By locator, CharSequence... keysToSend) {
        WebElement element;
        myLog.logSeStep("Enter Keys '" + keysToSend.toString() + "' in Element: " + locator.toString());
        element = searchForClickableElement(locator);
        if (element != null) {
            element = getElement(locator);
            try {
                element.sendKeys(keysToSend);
                return true;
            } catch (InvalidElementStateException e) {
                myLog.logSeStep("Could not enter text in " + locator.toString() + ", element not visible or not enabled");
                myAssertion.reportError("Could not enter text, element not visible or not enabled");
                return false;
            } catch (Exception e) {
                myLog.logSeStep("Could not enter text in " + locator.toString());
                myAssertion.reportError("Could not enter text");
                return false;
            }
        } else
            return false;
    }

    public boolean enterText(final By locator, int nthElement, String textToType) {
        List<WebElement> elements;
        myLog.logSeStep("Enter Text '" + textToType + "' in Element: " + locator.toString());
        //elements = searchForClickableElements(locator);
        elements = getElements(locator);
        if (elements != null) {
            try {
                elements.get(nthElement).clear();
                elements.get(nthElement).sendKeys(textToType);
                return true;
            } catch (InvalidElementStateException e) {
                myLog.logSeStep("Could not enter text in " + locator.toString() + ", elemet not visible or not enabled");
                myAssertion.reportError("Could not enter text, element not visible or not enabled");
                return false;
            } catch (Exception e) {
                myLog.logSeStep("Could not enter text in " + locator.toString());
                myAssertion.reportError("Could not enter text");
                return false;
            }
        } else
            return false;
    }

    /**
     * Enter text into element
     *
     * @param locator
     * @param encryptedTextToType
     * @return
     */
    public boolean enterText(final By locator, EncryptedString encryptedTextToType) {
        WebElement element;
        myLog.logSeStep("Enter Text \"**********\" in Element: " + locator.toString());
        element = searchForClickableElement(locator);
        if (element != null) {
            try {
                element.clear();
                element.sendKeys(encryptedTextToType.getString());
                return true;
            } catch (InvalidElementStateException e) {
                myLog.logSeStep("Could not enter text in " + locator.toString() + ", element not visible or not enabled");
                myAssertion.reportError("Could not enter text, element not visible or not enabled");
                return false;
            } catch (Exception e) {
                myLog.logSeStep("Could not enter text in " + locator.toString());
                myAssertion.reportError("Could not enter text");
                return false;
            }
        } else
            return false;
    }

    /**
     * Get the text from the element
     *
     * @param locator
     * @return
     */
    public String getText(final By locator) {
        WebElement element;
        String text = "";
        myLog.logSeStep("Get Text From Element: " + locator.toString());
        element = searchForElement(locator);
        if (element != null) {
            try {
                text = element.getText();
            } catch (InvalidElementStateException e) {
                myLog.logSeStep("Could not get text from " + locator.toString() + ", element not visible or not enabled");
                myAssertion.reportError("Could not get text from, element not visible or not enabled");
            } catch (Exception e) {
                myLog.logSeStep("Could not get text from " + locator.toString());
                myAssertion.reportError("Could not get text");
            }
            return text;
        } else
            return text;
    }

    /**
     * Get the text from the element
     *
     * @param locator
     * @param nthElement
     * @return
     */
    public String getText(final By locator, int nthElement) {
        List<WebElement> elements;
        String text = "";
        myLog.logSeStep("Get Text From nth Element: " + locator.toString() + " #" + nthElement);
        elements = searchForElements(locator);
        if (elements != null) {
            try {
                text = elements.get(nthElement).getText();
            } catch (InvalidElementStateException e) {
                myLog.logSeStep("Could not get text from " + locator.toString() + ", element not visible or not enabled");
                myAssertion.reportError("Could not get text from, element not visible or not enabled");
            } catch (Exception e) {
                myLog.logSeStep("Could not get text from " + locator.toString());
                myAssertion.reportError("Could not get text");
            }
            return text;
        } else
            return text;
    }

    public List<String> getTextFromMultiple(final By locator) {
        myLog.logSeStep("Get Text From Multiple: " + locator.toString());
        List<String> foundText = new ArrayList<String>();
        List<WebElement> elements = searchForElements(locator);
        for (WebElement element : elements) {
            try {
                foundText.add(element.getText());
            } catch (InvalidElementStateException e) {
                myLog.logSeStep("Could not get text from " + element.toString() + ", element not visible or not enabled");
            } catch (Exception e) {
                myLog.logSeStep("Could not get text from " + element.toString() + ": " + e.getMessage());
            }
        }
        return foundText;
    }

    /**
     * Get the value from the element
     *
     * @param locator
     * @return value attribute of element
     */
    public String getValue(final By locator) {
        myLog.logSeStep("Get Value From Element: " + locator.toString());
        return getAttribute(locator, "value");
    }

    public String getValue(final By locator, int nthElement) {

        myLog.logSeStep("Get Value From Element: " + locator.toString());
        return getAttribute(locator, "value", nthElement);
    }

    public String getCssProperty(final By locator, String propertyName) {
        WebElement element;
        String text = null;
        myLog.logSeStep("Get CSS Attribute " + propertyName + " From Element: " + locator.toString());
        element = searchForElement(locator);
        if (element != null) {
            try {
                text = element.getCssValue(propertyName);
            } catch (InvalidElementStateException e) {
                myLog.logSeStep("Could not get Attribute from " + locator.toString() + ", element not visible or not enabled");
                myAssertion.reportError("Could not get Attribute from, element not visible or not enabled");
            } catch (Exception e) {
                myLog.logSeStep("Could not get Attribute from " + locator.toString());
                myAssertion.reportError("Could not get Attribute");
            }
            return text;
        } else
            return text;

    }

    public String getCssProperty(final By locator, int nthElement, String propertyName) {
        WebElement element;
        String text = null;
        myLog.logSeStep("Get CSS Attribute " + propertyName + " From Element: " + locator.toString());
        element = searchForElements(locator).get(nthElement);
        if (element != null) {
            try {
                text = element.getCssValue(propertyName);
            } catch (InvalidElementStateException e) {
                myLog.logSeStep("Could not get Attribute from " + locator.toString() + ", element not visible or not enabled");
                myAssertion.reportError("Could not get Attribute from, element not visible or not enabled");
            } catch (Exception e) {
                myLog.logSeStep("Could not get Attribute from " + locator.toString());
                myAssertion.reportError("Could not get Attribute");
            }
            return text;
        } else
            return text;

    }

    /**
     * Get a html attribute from the element
     *
     * @param locator
     * @param attr
     * @return
     */
    public String getAttribute(final By locator, String attr) {
        WebElement element;
        String text = null;
        myLog.logSeStep("Get Attribute " + attr + " From Element: " + locator.toString());
        element = searchForElement(locator);
        if (element != null) {
            try {
                text = element.getAttribute(attr);
            } catch (InvalidElementStateException e) {
                myLog.logSeStep("Could not get Attribute from " + locator.toString() + ", element not visible or not enabled");
                myAssertion.reportError("Could not get Attribute from, element not visible or not enabled");
            } catch (Exception e) {
                myLog.logSeStep("Could not get Attribute from " + locator.toString());
                myAssertion.reportError("Could not get Attribute");
                myAssertion.reportError(e.getMessage());
            }
            return text;
        } else
            return text;
    }

    /**
     * Get a html attribute from the element
     *
     * @param locator
     * @param attr
     * @param nthElement
     * @return
     */
    public String getAttribute(final By locator, String attr, int nthElement) {
        List<WebElement> elements;
        String text = null;
        myLog.logSeStep("Get Attribute " + attr + " From Element: "
                + locator.toString() + " #" + nthElement);
        elements = searchForElements(locator);
        if (elements != null) {
            try {
                text = elements.get(nthElement).getAttribute(attr);
            } catch (InvalidElementStateException e) {
                myLog.logSeStep("Could not get Attribute from " + locator.toString() + ", element not visible or not enabled");
                myAssertion.reportError("Could not get Attribute from, element not visible or not enabled");
            } catch (Exception e) {
                myLog.logSeStep("Could not get Attribute from " + locator.toString());
                myAssertion.reportError("Could not get Attribute");
            }
            return text;
        } else
            return text;
    }

    /**
     * Selects an item from a drop down
     *
     * @param locator
     * @param selection
     * @return
     */
    public boolean selectElement(final By locator, String selection) {
        myLog.logSeStep("Select " + selection + " In Element: "
                + locator.toString());
        String browserName = ((RemoteWebDriver) myDriver).getCapabilities().getBrowserName();
        //Select class does not work on android
        if (browserName.equals("android")) {
            WebElement select = getElement(locator);
            List<WebElement> options = select.findElements(By.tagName("option"));
            int optionNum = 0;
            for (WebElement option : options) {
                if (option.getText().equals(selection)) {
                    try {
                        ((JavascriptExecutor) myDriver).executeScript("document.getElementById(\"newLocationSource\").options[" + optionNum + "].selected = true");
                        Util.sleep(2000);
                        return true;
                    } catch (Exception e) {
                        // TODO: handle exception
                    }
                    break;
                }
                optionNum++;
            }
            return false;

        } else {
            WebElement element = searchForElement(locator);
            if (element != null) {
                Select select = new Select(element);
                try {
                    select.deselectAll();

                } catch (Exception e) {
                    //ignore
                }
                select.selectByVisibleText(selection);
                return true;
            } else
                return false;
        }

    }

    /**
     * Selects an item from a drop down
     *
     * @param locator
     * @param value
     * @return
     */
    public boolean selectElementByValue(final By locator, String value) {
        myLog.logSeStep(String.format("Select By Value%s In Element: %s", value, locator.toString()));
        WebElement element = searchForElement(locator);
        if (element != null) {
            Select select = new Select(element);
            try {
                select.deselectAll();
            } catch (Exception e) {
                //ignore
            }
            select.selectByValue(value);
            return true;
        } else
            return false;
    }

    /**
     * Selects an item from a drop down
     *
     * @param locator
     * @param selection
     * @param nthElement
     * @return
     */
    public boolean selectElement(final By locator, String selection, int nthElement) {
        myLog.logSeStep("Select " + selection + " In Element: "
                + locator.toString() + " #" + nthElement);
        List<WebElement> elements = searchForElements(locator);
        if (elements != null) {
            Select select = new Select(elements.get(nthElement));
            try {
                select.deselectAll();

            } catch (Exception e) {
                //ignore
            }
            select.selectByVisibleText(selection);
            return true;
        } else
            return false;
    }

    /**
     * Selects an item from the drop down, the blank row at the top is index 0
     *
     * @param locator
     * @param index
     * @return
     */
    public boolean selectElement(final By locator, int index) {
        myLog.logSeStep("Select index" + index + " In Element: "
                + locator.toString());
        WebElement element = searchForElement(locator);
        if (element != null) {
            Select select = new Select(element);
            try {
                select.deselectAll();

            } catch (Exception e) {
                //ignore
            }
            select.selectByIndex(index);
            return true;
        } else
            return false;
    }

    /**
     * Selects an item from the drop down, the blank row at the top is index 0
     *
     * @param locator
     * @param index
     * @param nthElement
     * @return
     */
    public boolean selectElement(final By locator, int index, int nthElement) {
        myLog.logSeStep("Select index" + index + " In Element: "
                + locator.toString() + " #" + nthElement);
        List<WebElement> elements = searchForElements(locator);
        if (elements != null) {
            Select select = new Select(elements.get(nthElement));
            try {
                select.deselectAll();

            } catch (Exception e) {
                //ignore
            }
            select.selectByIndex(index);
            return true;
        } else
            return false;
    }

    /**
     * Returns true of element is visible
     *
     * @param locator
     * @return
     */
    public boolean isVisible(final By locator, final int timeOutInSeconds) {
        myLog.logSeStep("Is Element Visible: " + locator.toString());
        WebElement element = searchForElement(locator, timeOutInSeconds);
        return element != null && element.isDisplayed() && element.isEnabled();
    }

    public boolean isVisible(final By locator) {
        return isVisible(locator, globalSeTimeOut);
    }


    /**
     * Switch to a frame by name
     *
     * @param iFrameName
     * @return
     */
    public boolean switchToFrame(String iFrameName) {
        if (inFrame)
            returnToDefaultContent();
        try {
            myDriver.switchTo().frame(iFrameName);
            inFrame = true;
            return true;
        } catch (Exception e) {
            myLog.logSeStep("Un-handled Exception in swithToFrame: " + e.getMessage());
            //System.out.println(e.getMessage());
            myLog.takeScreenShot("Un-handled Exception in swithToFrame", false);
            return false;
        }
    }

    /**
     * Switch to a frame by WebElement
     *
     * @param frame
     * @return
     * @author Cognizant Technology CoE
     */
    public boolean switchToFrame(WebElement frame) {
        if (inFrame)
            returnToDefaultContent();
        try {
            myDriver.switchTo().frame(frame);
            inFrame = true;
            return true;
        } catch (Exception e) {
            myLog.logSeStep("Un-handled Exception in swithToFrame: " + e.getMessage());
            myLog.takeScreenShot("Un-handled Exception in swithToFrame", false);
            return false;
        }
    }

    /**
     * Switch to a frame by index
     *
     * @param iFrameIndex
     * @return
     */
    public boolean switchToFrame(int iFrameIndex) {
        try {
            myDriver.switchTo().frame(iFrameIndex);
            inFrame = true;
            return true;
        } catch (Exception e) {
            String errorName = "Un-handled Exception in swithToFrame:" + e.getMessage();
            myLog.logSeStep(errorName);
            //myLog.logTcError(errorName, myLog.takeScreenShot(errorName, false));
            return false;
        }
    }

    /**
     * Returns to the default browser window or frame
     */
    public void returnToDefaultContent() {
        myDriver.switchTo().defaultContent();
        inFrame = false;
    }

    /**
     * Returns the number of matching elements
     *
     * @param locator
     * @return
     */
    public int getNumberOfElements(By locator) {
        List<WebElement> elements = getElements(locator);
        if (elements == null)
            return 0;
        return elements.size();
    }

    /**
     * Returns a 2-D array representing the table
     *
     * @param tableBodyLocator
     * @return
     */
    public String[][] getTable(By tableBodyLocator) {
        String tableBodyLocatorString = tableBodyLocator.toString().split(": ")[1];
        String tableHeaderLocatorString = tableBodyLocatorString + " tr th";
        String tableRowsLocatorString = tableBodyLocatorString + " tr";
        String tableDataCellsLocatorString = tableBodyLocatorString + " tr td";
        By tableHeaderLocator = By.cssSelector(tableHeaderLocatorString);
        By tableRowsLocator = By.cssSelector(tableRowsLocatorString);
        By tableDataCellsLocator = By.cssSelector(tableDataCellsLocatorString);
        int numberOfColumns = getNumberOfElements(tableHeaderLocator);
        int numberOfRows = getNumberOfElements(tableRowsLocator);
        String[][] table = new String[numberOfRows][numberOfColumns];
        List<WebElement> tableDataCells = getElements(tableDataCellsLocator);
        int row = 0;
        for (int i = 0; i < numberOfColumns; i++) {
            table[row][i] = getText(tableHeaderLocator, i);
        }
        row = 1;
        int col = 0;
        for (int i = 0; i < tableDataCells.size(); i++) {


            table[row][col++] = tableDataCells.get(i).getText();

            if (col == numberOfColumns) {
                col = 0;
                row++;
            }
        }
        return table;
    }

    /**
     * Prints the table to the console
     *
     * @param table
     */
    public void printTable(String[][] table) {
        for (String[] aRow : table) {
            for (String aCell : aRow) {
                System.out.println(aCell);
            }
        }
    }

    public void requireIsDisplayed(String elementName, By locator) {
        myAssertion.requireTrue("Require " + elementName +  " "
                + locator + " is displayed", waitForElementIsDisplayed(locator));
    }

    public void requireIsDisplayed(String elementName, WebElement element) {
        myAssertion.requireTrue("Require " + elementName +  " "
                + element.toString() + " is displayed", waitForElementIsDisplayed(element));
    }

    public void requireIsDisplayed(String elementName, By locator, int position) {
        waitForPageLoad();
        myAssertion.requireTrue("Require " + elementName + " " + locator + " is displayed",
                waitForElementIsDisplayed(locator, position, globalSeTimeOut));
    }


    //Wait for tha Page to Load
    public void waitForPageLoad() {
        long timeOut = 5000;
        long end = System.currentTimeMillis() + timeOut;
        while (System.currentTimeMillis() < end) {
            if (String.valueOf(
                    ((JavascriptExecutor) myDriver)
                            .executeScript("return document.readyState"))
                    .equals("complete")) {
                break;
            }
        }
    }

    /**
     * wait for the jquery to complete
     */
    public void waitForJQueryToComplete() {
        (new WebDriverWait(myDriver, 5)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver myDriver) {
                JavascriptExecutor js = (JavascriptExecutor) myDriver;
               // return (Boolean) js.executeScript("return !!window.jQuery && window.jQuery.active == 0");
                return (Boolean) js.executeScript("return (document.readyState == 'complete' && jQuery.active == 0)");
            }
        });
    }


    //Handle Accept or Decline
    public void javaScriptPopUp(String message) {
        if(message.equals("yes"))
            myDriver.switchTo().alert().accept();
        else
            myDriver.switchTo().alert().dismiss();
    }

    //wait
    public void explicitWait(int seconds) {
        try{
            Thread.sleep(seconds);
        }
        catch(Exception e){}
    }

    public void requireIsDislplayed(String elementName, By locator, int position) {
        waitForPageLoad();
        myAssertion.requireTrue("Require " + elementName + " " + locator + " is displayed", waitForElementIsDisplayed(locator, position, globalSeTimeOut));
    }
}

