package tech.nike.automation.common.framework.sql;

import tech.nike.automation.common.framework.tools.DisableLogs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import static org.apache.log4j.Level.DEBUG;

/**
 * Created by psibb1 on 8/18/2016.
 */
public class DBConnect {
    public static Connection connection = null;
    public static Connection getDatabaseConnection(String strEnvironment){
        //reading db connection details
        DataBaseConfigurations db = new DataBaseConfigurations();
        //getting connections details for specific environment
        String[] arr = db.getDatabaseConnection(strEnvironment);
        //disable logging
        if (DEBUG.equals(true)) {
            DisableLogs.disableLogs();
        }
        System.out.println("-------- Oracle JDBC Connection Testing ------");

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException e) {
            System.out.println("Where is your Oracle JDBC Driver?");
            e.printStackTrace();
        }
        System.out.println("Oracle JDBC Driver Registered!");
        try {
            connection = DriverManager.getConnection(
                    arr[2], arr[0],
                    arr[1]);
        } catch (SQLException e) {
            System.out.println("Connection Failed! Check output console");
            e.printStackTrace();
        }
        if (connection != null) {
            System.out.println("You made it, take control of your database now!");
        } else {
            System.out.println("Failed to make connection!");
        }
        return connection;
    }
}
