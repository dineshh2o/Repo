package tech.nike.automation.common.framework;

import org.apache.commons.collections.ListUtils;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.internal.Base64Encoder;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.util.*;


//import org.openqa.selenium.android.AndroidDriver;

@SuppressWarnings("unused")
public class Browser {
    private WebDriver myDriver;
    private Element myElement;
    private Browsers myBrowserType;
    private Log myLog;
    private Util Util = new Util();

    //Globals
    private String prevWindow = null; //Previous Window Name
    private String prevWindowHandle = null; //Previous Window Handle
    private String currentPopUp = null; //Popup window handle

    /**
     * Supported Browsers
     */
    public enum Browsers {
        Android, Firefox, Chrome, InternetExplorer, HtmlUnit, Safari,
        GridAndroid, GridFirefox, GridChrome, GridInternetExplorer, GridGhostDriver, GridSafari,
        GridFirefoxN1, GridChromeN1, GridInternetExplorerN1,
        GridFirefoxN, GridChromeN, GridInternetExplorerN,
        BrowserMobedChrome, BrowserMobedFirefox, BrowserMobedIE,
        SauceChrome, SauceFirefox, SauceIE, SauceSafari
    }

    //Wait Conditions
    private static ExpectedCondition<Boolean> windowTitleContains(final String windowTitle) {
        return new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver driver) {
                return driver.getTitle().toLowerCase().replaceAll("-", "").replaceAll(" ", "").contains(windowTitle.toLowerCase().replaceAll("-", "").replaceAll(" ", ""));
            }
        };
    }

    /**
     * Default Constructor
     */
    public Browser() {
    }

    /**
     * Set WebDriver instance
     *
     * @param driver
     */
    public void setDriver(WebDriver driver) {
        myDriver = driver;
    }

    /**
     * Set Element instance
     *
     * @param element
     */
    public void setElement(Element element) {
        myElement = element;
    }

    /**
     * Set broweser type
     *
     * @param browser
     */
    public void setBrowserType(Browsers browser) {
        myBrowserType = browser;
    }

    /**
     * Set Log instance
     *
     * @param log
     */
    public void setLog(Log log) {
        myLog = log;
    }

    /**
     * Get current browser type
     *
     * @return
     */
    public Browsers getBrowserType() {
        return myBrowserType;
    }

    /**
     * Close an Alert Pop Up
     *
     * @return
     */
    public boolean closeAlert() {
        // Get a handle to the open alert, prompt or confirmation
        try {
            Alert alert = myDriver.switchTo().alert();
            // And acknowledge the alert (equivalent to clicking "OK")
            alert.accept();
            myLog.logSeStep("Closing Alert");
            return true;
        } catch (Exception e) {
            // no alert
            myLog.logSeStep("Cannot Close Alert");
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Closes the active Pop Up, assumes only 1 Pop Up is open
     *
     * @return
     */
    public boolean closePopUp() {
        try {
            myLog.logSeStep("Closing PopUp:");
            if (currentPopUp != null) {
                myDriver.switchTo().window(currentPopUp).close();
                myDriver.switchTo().window(prevWindowHandle);
                Util.sleep(1000);
                currentPopUp = null;
                prevWindowHandle = null;
                return true;
            } else {
                String currentWindow = myDriver.getWindowHandle();
                Set<String> windows = myDriver.getWindowHandles();
                for (Iterator<String> iterator = windows.iterator(); iterator.hasNext(); ) {
                    String string = iterator.next();
                    if (!currentWindow.equals(string)) {
                        myDriver.switchTo().window(string).close();
                        myDriver.switchTo().window(currentWindow);
                        Util.sleep(1000);
                        return true;
                    }
                }
            }
            return false;
        } catch (Exception e) {
            myLog.logSeStep("Un-handled Exception in closePopUp:");
            myLog.logSeStep(e.getMessage());
            return false;
        }
    }

    /**
     * Get the window handle by iterating all windows searching for the title.
     *
     * @param title
     * @return Window handle of window with the specified title.
     */
    private String getHandleByTitle(String title) {
        String currentHandle = myDriver.getWindowHandle();
        for (String handle : myDriver.getWindowHandles()) {
            if (title.equals(myDriver.switchTo().window
                    (handle).getTitle())) {
                myLog.trace("Found new window handle by title: " + handle);
                return handle;
            }
        }
        myLog.trace("Could not find new window handle by title");
        return currentHandle;
    }

    /**
     * Get the window handle by iterating all windows searching for the url.
     *
     * @param url
     * @return Window handle of window with the specified url
     */
    private String getHandleByUrl(String url) {
        String currentHandle = myDriver.getWindowHandle();
        for (String handle : myDriver.getWindowHandles()) {
            if ((myDriver.switchTo().window
                    (handle).getCurrentUrl()).contains(url)) {
                return handle;
            }
        }
        return currentHandle;
    }

    /**
     * close all open browsers
     * does not work with Grid
     */
    public void closeAllBrowsers() {

        //kill all browser procceses
        String username = System.getenv("USERNAME");
        String killExplore = "taskkill /F /FI \"USERNAME eq " + username + "\" /IM IEDriverServer.exe";
        //String killFireFox = "taskkill /F /FI \"USERNAME eq " + username + "\" /IM firefox.exe";
        String killChrome = "taskkill /F /FI \"USERNAME eq " + username + "\" /IM chromedriver.exe";
        //Log.logVerbose("closing all browsers for username: " + username);
        try {
            // Execute a command
            Process child;
            //Log.logVerbose("Running: " + killExplore);
            child = Runtime.getRuntime().exec(killExplore);
            child.waitFor();
            //Log.logVerbose("Running: " + killFireFox);
            //child = Runtime.getRuntime().exec(killFireFox);
            // child.waitFor();
            // Log.logVerbose("Running: " + killChrome);
            child = Runtime.getRuntime().exec(killChrome);
            child.waitFor();
        } catch (IOException e) {
        } catch (InterruptedException e) {
        }

    }

    /**
     * Maximize the browser using javascript.
     * Chrome has decided not to support this. http://code.google.com/p/chromium/issues/detail?id=2091
     */
    public void maximizeBrowser() {
        myDriver.manage().window().maximize();
    }

    public void setBrowserSize(int width, int height) {
        Dimension targetSize = new Dimension(width, height);
        myDriver.manage().window().setSize(targetSize);
    }

    /**
     * Delete the cookies for the current domain (page must be opened)
     */
    public void deleteCookies() {
        myDriver.manage().deleteAllCookies();
    }

    /**
     * Used for initial get of first page
     * Log.setTcStartTime(); is called.
     * use get(url) to get pages without overwriting the start time.
     *
     * @param url
     */
    public boolean openUrl(String url) {
        myLog.logSeStep("Open URL: " + url);
        try {
            myDriver.get(url);
            deleteCookies();
            myLog.setTcStartTime();
            myDriver.get(url);
        } catch (Exception e) {
            System.out.println("Unhandled Exception in openUrl " + url);
            return false;
        }
        return myDriver.getTitle() != null;
    }

    /**
     * Load a new url in the browser.  Does not log the test case start time.
     * Use openUrl() instead, if this is the first url loaded for the test.
     *
     * @param url
     */
    public boolean get(String url) {
        myLog.logSeStep("Get URL: " + url);
        if (url == null) {
            myLog.logSeStep("url is null, nothing to get");
            return false;
        }
        try {
            myDriver.get(url);
        } catch (Exception e) {
            System.out.println("Unhandled Exception in Browser.get " + url);
            System.out.println(e.getMessage());
            return false;
        }
        return !(myDriver.getTitle() == null ||
                myDriver.getTitle().equals("Problem loading page") ||
                myDriver.getTitle().contains("Oops! Google Chrome could not connect to") ||
                myDriver.getTitle().equals("Internet Explorer cannot display the webpage"));
    }

    /**
     * Get the current url of the browser.
     *
     * @return The url as a string.
     */
    public String getCurrentUrl() {

        try {
            return myDriver.getCurrentUrl();
        } catch (Exception e) {
            System.out.println("Unhandled Exception in getCurrentUrl");
            System.out.println(e.getMessage());
            return null;
        }
    }

    /**
     * Navigate Back in the browser
     */
    public void navigateBack() {
        myDriver.navigate().back();
    }

    /**
     * Refresh current page
     */
    public void refresh() {
        myLog.logSeStep("Refreshing Page");
        myDriver.navigate().refresh();
    }

    /**
     * Navigate Forward in the browser
     */
    public void navigateForward() {
        myDriver.navigate().forward();
    }

    /**
     * Returns True of an Alert Pop Up is present
     *
     * @return
     */
    public boolean hasAlert() {
        // Get a handle to the open alert, prompt or confirmation
        try {
            myDriver.switchTo().alert();
            myLog.logSeStep("Has Alert");
            return true;
        } catch (Exception e) {
            // no alert
            myLog.logSeStep("No Alert");
            myLog.logSeStep(e.getMessage());
            return false;
        }
    }

    /**
     * Switch to a window using the title
     *
     * @param title of window
     * @return true of successful
     */
    public String switchToWindow(String title) {

        try {
            if (prevWindow == null || prevWindow != title) {
                prevWindow = myDriver.getTitle();
                prevWindowHandle = myDriver.getWindowHandle();
                myLog.logSeStep("Saved Prev Window Title:" + prevWindow);
            }
            myLog.logSeStep("Switching To Window Title:" + title);
            return getHandleByTitle(title);
        } catch (Exception e) {
            myLog.logSeStep("Un-handled Exception in switchToWindow:");
            myLog.logSeStep(e.getMessage());
        }

        return null;
    }

    public String switchToWindow(int windowIndex) {
        prevWindow = myDriver.getTitle();
        prevWindowHandle = myDriver.getWindowHandle();
        myLog.logSeStep("Switching To Window Index:" + windowIndex);
        try {
            Set<String> windows = myDriver.getWindowHandles();
            windows.remove(prevWindowHandle);
            List<String> listOfWindows = new ArrayList<String>(windows);
            if (windowIndex <= windows.size()) ;
            myDriver.switchTo().window(listOfWindows.get(windowIndex));
            return myDriver.getWindowHandle();
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Switch to a window containing a certain url
     *
     * @param url of window to switch to
     * @return
     */
    public String switchToWindowByUrl(String url) {
        try {
            return getHandleByUrl(url);
        } catch (Exception e) {
            System.out.println("Un-handled Exception in switchToWindowByUrl:");
            System.out.println(e.getMessage());
        }

        return null;
    }

    /**
     * Return to the previous window, previous window was saved by swithToWindow()
     *
     * @return true of successful
     */
    public boolean returnToPrevWindow() {
        if (prevWindowHandle == null) {
            myLog.logSeStep("No Prev Window Handle Stored");
            myDriver.switchTo().defaultContent();
            return false;
        } else {
            myLog.logSeStep("Switching to Prev Window Handle " + prevWindowHandle);
            myDriver.switchTo().window(prevWindowHandle);
            prevWindow = null;
            return true;
        }

    }

    /**
     * Closes all open windows
     */
    public void closeAllWindows() {

        for (String handle : myDriver.getWindowHandles()) {
            myDriver.switchTo().window(handle).close();
        }
    }

    /**
     * Closes current window and returns to the previous window, if this is the last window the browser will quit
     *
     * @return true if able to return to previous window, false of no more windows are open
     */
    public boolean closeCurrentWindow() {
        myDriver.close();
        return returnToPrevWindow();
    }

    /**
     * Closes a window by the window title
     *
     * @param windowTitle
     * @return true if successful
     */
    public boolean closeWindowByTitle(String windowTitle) {
        try {
            myLog.logSeStep("Closing Window With Title:" + windowTitle);
            String windowHandle = getHandleByTitle(windowTitle);
            myDriver.switchTo().window(windowHandle);
            //((JavascriptExecutor) myDriver).executeScript("window.close()");
            //return returnToPrevWindow();
            return closeCurrentWindow();
        } catch (Exception e) {
            myLog.logSeStep("Un-handled Exception in closeWindowByTitle:");
            myLog.logSeStep(e.getMessage());
            return false;
        }
    }

    /**
     * Closes a window containing a url
     *
     * @param url of window to close (matched using string.contains)
     * @return true if successful
     */
    public boolean closeWindowByUrl(String url) {
        try {
            myLog.logSeStep("Closing Window With Url:" + url);
            String windowHandle = getHandleByUrl(url);
            myDriver.switchTo().window(windowHandle);
            //return returnToPrevWindow();
            return closeCurrentWindow();
        } catch (Exception e) {
            myLog.logSeStep("Un-handled Exception in closeWindowByUrl:");
            myLog.logSeStep(e.getMessage());
            return false;
        }
    }

    /**
     * Returns if Popup is present and switches context to the popup window if present.
     *
     * @return true if popup is present, and switches test context to the popup.
     */
    public boolean isPopup() {
        try {
            myLog.logSeStep("Checking for PopUp:");
            String currentWindow = myDriver.getWindowHandle();
            Set<String> windows = myDriver.getWindowHandles();
            for (Iterator<String> iterator = windows.iterator(); iterator.hasNext(); ) {
                String string = iterator.next();
                if (!currentWindow.equals(string)) {
                    myLog.logSeStep("PopUp Found");
                    currentPopUp = string;
                    prevWindowHandle = currentWindow;
                    myDriver.switchTo().window(currentPopUp);
                    myLog.logSeStep("Switching Context to PopUp window: " + myDriver.getTitle());
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            myLog.logSeStep("Un-handled Exception in isPopup:");
            myLog.logSeStep(e.getMessage());
            return false;
        }
    }

    /**
     * Gets the window Title
     *
     * @return
     */
    public String getWindowTitle() {
        return myDriver.getTitle();
    }

    /**
     * Gets the browser version
     *
     * @return
     */
    public String getBrowserVersion() {
        if (myBrowserType == Browsers.HtmlUnit)
            return "0.0";
        else {
            Capabilities browserCapabilities = ((RemoteWebDriver) myDriver).getCapabilities();
            return browserCapabilities.getVersion();
        }
    }

    /**
     * Gets the browser name
     *
     * @return
     */
    public String getBrowserName() {
        if (myBrowserType == Browsers.HtmlUnit)
            return "HtmlUnit";
        else {
            Capabilities browserCapabilities = ((RemoteWebDriver) myDriver).getCapabilities();
            return browserCapabilities.getBrowserName();
        }
    }

    /**
     * Prints the title and the window handle of the current window to the console
     */
    public void printWindowInfo() {
        System.out.println(myDriver.getTitle());
        System.out.println(myDriver.getWindowHandles().size());
        System.out.println(myDriver.getWindowHandle());
    }

    /**
     * Given the frame ID it will break out frame to the current window
     */
    public void breakOutFrame(String iFrameID) {
        get(myElement.getAttribute(By.id(iFrameID), "src"));
    }

    /**
     * Given the frame ID it will break out frame to the current window
     */
    public void breakOutFrame(int iFrameNum) {
        get(myElement.getAttribute(By.tagName("iframe"), "src", iFrameNum));
    }

    /**
     * Takes a screenshot and returns as a base64 encoded string.
     *
     * Doesn't add to report directly.
     *
     * @return base64 encoded string of screenshot
     */
    public String takeScreenShot() {
        return takeScreenShot(null);
    }

    /**
     * Takes a screenshot and returns as a base64 encoded string.
     *
     * Doesn't add to report directly.
     *

     * @param screenShotFileName, (optional) will write to a file if specified, otherwise only the base64 encoded png is returned
     * @return base64 encoded string of screenshot
     */
    public String takeScreenShot(String screenShotFileName) {
        if (myDriver == null)
            return null;
        WebDriver driver = myDriver;
        if (!(myDriver instanceof TakesScreenshot) )
            driver = myDriver = (new Augmenter()).augment(myDriver);
        try {
            String base64Png = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
            //FileUtils.copyFile(((TakesScreenshot) myDriver).getScreenshotAs(OutputType.FILE), new File(screenShotFileName));
            if (screenShotFileName != null && screenShotFileName.length() > 0)
                FileUtils.copyFile(Util.saveFile(new Base64Encoder().decode(base64Png)), new File(screenShotFileName));
            return base64Png;
        } catch (IOException e) {
            myLog.trace(e.getMessage());
            myLog.trace(e.getStackTrace().toString());
        } catch(Exception e) {
            myLog.trace(e.getMessage());
            myLog.trace(e.getStackTrace().toString());
        }
        Util.sleep(500);
        return null;
    }

    /**
     * Close browser and browser sessoin.
     *
     * !! Should be called after all tests !!
     */
    public void quit() {
        try {
//            if (myDriver instanceof AndroidDriver)
//                ((AndroidDriver) myDriver).quit();
            if (myDriver instanceof FirefoxDriver)
                myDriver.quit();
            if (myDriver instanceof ChromeDriver)
                myDriver.quit();
            if (myDriver instanceof InternetExplorerDriver)
                myDriver.quit();
            /*if (myDriver instanceof HtmlUnitDriver)
                ((HtmlUnitDriver) myDriver).quit();*/
            if (myDriver instanceof RemoteWebDriver) {
                if (((RemoteWebDriver) myDriver).getSessionId() != null) {
                    myDriver.close();
                    myDriver.quit();
                } else
                    myDriver.quit();
            }
        } catch (Exception e) {
            //chrome drive quit throws errors when window is already closed
            //e.printStackTrace();
        }
    }

    /**
     * executes javascript on the document and returns the result
     *
     * @param javascript
     * @return
     */
    public String executeJavascript(String javascript) {
        return executeJavascript(javascript, true);
    }

    /**
     * executes javascript on the document and returns the result
     *
     * @param javascript
     * @return
     */
    public String executeJavascript(String javascript, boolean log) {
        Object result = executeJavascriptReturnsObject(javascript, log);
        return result != null ? result.toString() : "";
    }

    /**
     * executes javascript on the document and returns the result
     *
     * @param javascript
     * @return
     */
    @SuppressWarnings("unchecked")
    public List<String> executeJavascriptReturnsStringList(String javascript, boolean log) {
        Object result = executeJavascriptReturnsObject(javascript, log);
        return result != null ? (List<String>) result : ListUtils.EMPTY_LIST;
    }

    /**
     * executes javascript on the document and returns the result as a java Object
     *
     * @param javascript
     * @return
     */
    public Object executeJavascriptReturnsObject(String javascript, boolean log) {
        if (log)
            myLog.trace("Executing Javascript:" + javascript);
        try {
            Object result = ((JavascriptExecutor) myDriver).executeScript(javascript);
            if (result != null)
                return result;
            else
                return null;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }
    }

    /**
     * Executes javascript on an element and returns the result as a java String
     *
     * @param javascript snippit of javascript that returns a string
     * @param webElement Element to execute the javascript on, reference in snippit as "arguments[0]"
     * @return Returned value of the snippit
     */
    public String executeJavascriptOnWebElement(String javascript, WebElement webElement) {
        myLog.logSeStep("Executing Javascript on WebElement:" + javascript + ", " + webElement.toString());
        try {
            Object result = ((JavascriptExecutor) myDriver).executeScript(javascript, webElement);
            if (result != null)
                return result.toString();
            else
                return "";
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return "";
        }

    }

    /**
     * Adds a Cookie to the current domain
     *
     * @param name Cookie Name
     * @param value Cookie Value
     * @param domain Cookie Domain
     * @param path Cookie path
     * @param expiry Date of expiration
     * @param isSecure True if secure
     */
    public void addCookie(String name, String value, String domain, String path, Date expiry, boolean isSecure) {
        Cookie cookie = new Cookie(name, value, domain, path, expiry, isSecure);
        myLog.logSeStep("Creating Cookie:" + cookie);
        myDriver.manage().addCookie(cookie);
    }

    /**
     * Get a cookie named cookieName
     *
     * @param cookieName Name of cookie to get
     * @return Cookie object
     */
    public Cookie getCookie(String cookieName) {
        myLog.logSeStep("Get Cookie");
        return myDriver.manage().getCookieNamed(cookieName);
    }

    /**
     * Waits for the window title to contain windowTitle
     *
     * @param windowTitle Text for the window title to contain
     * @param timeOut Seconds to wait for the title to contain
     * @return True if WindowTitle found in title before timeOut
     */
    public boolean waitForWindowTitleToContain(String windowTitle, int timeOut) {
        myLog.logSeStep("Waiting for Window Title to contain " + windowTitle + " (" + timeOut + " sec)");

        WebDriverWait wait = new WebDriverWait(myDriver, timeOut);
        try {
            wait.until(windowTitleContains(windowTitle));
            return true;
        } catch (TimeoutException e) {
            myLog.logSeStep("Timed out waiting for Window Title to contain " + windowTitle);
            return false;
        } catch (Exception e) {
            String errorName = "Un-handled Exception in waitForWindowTitleToContain:";
            myLog.logSeStep(errorName + e.getMessage());
            return false;
        }

    }

    /**
     * Scrolls a element into view
     *
     * @param element WebElement you want in view
     */
    public void scrollIntoView(WebElement element) {
        executeJavascriptOnWebElement("arguments[0].scrollIntoView()", element);
    }

    /**
     * Scrolls a element into view, optionally align with top of view
     *
     * @param element WebElement you want in view
     * @param alignWithTop True if you want aligned with top, false for aligning with bottom
     */
    public void scrollIntoView(WebElement element, boolean alignWithTop) {
        executeJavascriptOnWebElement("arguments[0].scrollIntoView("+alignWithTop+")", element);
    }

    public String toString() {
        return "Browser";
    }
}
