package tech.nike.automation.common.framework.sql;

/**
 * Created by psibb1 on 8/31/2016.
 */
public class INT9Queries {
    public static String[] getQuery(String strTestCaseName) {
        String[] arrSQL = {};
        switch (strTestCaseName) {
            case "OB_1064_PW03AT_HP_12_INT9_Carton_Equip_P50_PermLocn":
            case "OB_1064_PW03AT_HP_13_INT9_Carton_Equip_P60_PermLocn":
            case "OB_1064_PW03AT_HP_11_INT9_Carton_Equip_P40_PermLocn":
                String sql1 = "select LPN.TC_PARENT_LPN_ID, LPN.TC_LPN_ID, LPN.ITEM_NAME,"+
                " WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN,LHD.LOCN_PICK_SEQ, WMI.ON_HAND_QTY QTY" +
                        " from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD,RESV_LOCN_HDR RLH" +
                        " where WMI.LPN_ID = LPN.LPN_ID" +
                        " and (WMI.ON_HAND_QTY) > 0" +
                        " and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID" +
                        " and lhd.locn_id = lpn.curr_sub_locn_id" +
                        " and wmi.inbound_outbound_indicator = 'I'" +
                        " and wmi.allocatable = 'Y'" +
                        " and lpn.lpn_facility_status='30'" +
                        " and lpn.tc_parent_lpn_id is not null " +
                        " and RLH.INVN_LOCK_CODE is null" +
                        " and LPN.CURR_SUB_LOCN_ID in (select LOCN_ID from LOCN_HDR where LOCN_CLASS = 'R'" +
                        " and PULL_ZONE IN('HC1','HG1','HP1'))" +
                        " and lpn.lpn_id not in (select lpn_id from lpn_lock)" +
                        " and LPN.ITEM_ID in (select PLD.ITEM_ID from PICK_LOCN_HDR PLH, LOCN_HDR LHD, PICK_LOCN_DTL PLD"+
                        " where LHD.LOCN_ID = PLH.LOCN_ID and PLD.PICK_LOCN_HDR_ID = PLH.PICK_LOCN_HDR_ID " +
                        " and LHD.SKU_DEDCTN_TYPE = 'P' and LHD.LOCN_CLASS = 'C' and PLH.INVN_LOCK_CODE is null)" +
                        " order by lpn.item_name, wmi.cntry_of_orgn, wmi.item_attr_1,LHD.PULL_ZONE," +
                        " wmi.on_hand_qty desc, lhd.locn_pick_seq";

                String sql2 = "select lhdp.dsp_locn, lhdp.sku_dedctn_type, " +
                        "lhdp.locn_pick_seq, icb.item_name, " +
                        "wmi.on_hand_qty, wmi.wm_allocated_qty, wmi.to_be_filled_qty," +
                        " (wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) as allocatable_qty, " +
                        " pld.max_invn_qty, pld.min_invn_qty, pld.cntry_of_orgn, pld.sku_attr_1, pld.locn_seq_nbr" +
                        " from  pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi where" +
                        " lhdp.locn_id = plh.locn_id " +
                        " and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id" +
                        " and pld.item_id = icb.item_id" +
                        " and wmi.location_id = plh.locn_id" +
                        " and lhdp.sku_dedctn_type = 'P'" +
                        " and lhdp.locn_class = 'C'" +
                        " and LHDP.pick_DETRM_ZONE <> '002'" +
                        " and PLH.INVN_LOCK_CODE is null" +
                        " and ICB.ITEM_NAME = '" + System.getProperty("ITEM_NAME") + "'" +
                        " and PLD.CNTRY_OF_ORGN = '" + System.getProperty("CNTRY_OF_ORGN") + "'" +
                        " and PLD.SKU_ATTR_1 = '" + System.getProperty("ITEM_ATTR_1") + "'";
                arrSQL = new String[]{sql1, sql2};
                break;

            case "OB_1064_PW03AT_HP_14_INT9_PROMO_carton_P40_DynLocn":
                String sql3 = "select LPN.TC_PARENT_LPN_ID, LPN.TC_LPN_ID, LPN.ITEM_NAME," +
                        " WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN," +
                        " LHD.LOCN_PICK_SEQ, WMI.ON_HAND_QTY QTY" +
                        " from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD,RESV_LOCN_HDR RLH" +
                        " where WMI.LPN_ID = LPN.LPN_ID" +
                        " and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID" +
                        " and lhd.locn_id = lpn.curr_sub_locn_id" +
                        " and wmi.inbound_outbound_indicator = 'I'" +
                        " and wmi.allocatable = 'Y'" +
                        " and lpn.lpn_facility_status='30'" +
                        " and lpn.tc_parent_lpn_id is not null" +
                        " and RLH.INVN_LOCK_CODE is null" +
                        " and LPN.CURR_SUB_LOCN_ID in (select LOCN_ID from LOCN_HDR where LOCN_CLASS = 'R'" +
                        " and PULL_ZONE in('HG2','HP2'))" +
                        " and LPN.LPN_ID not in (select LPN_ID from LPN_LOCK)" +
                        " and LPN.ITEM_ID not in (select PLD.ITEM_ID from PICK_LOCN_HDR PLH, LOCN_HDR LHD," +
                        " PICK_LOCN_DTL PLD where  LHD.LOCN_ID = PLH.LOCN_ID and PLD.PICK_LOCN_HDR_ID = PLH.PICK_LOCN_HDR_ID" +
                        " and LHD.LOCN_CLASS = 'C' and PLH.INVN_LOCK_CODE is null)" +
                        " and (WMI.ON_HAND_QTY) > 0" +
                        " order by lpn.item_name, wmi.cntry_of_orgn, wmi.item_attr_1,LHD.PULL_ZONE," +
                        " wmi.on_hand_qty desc, lhd.locn_pick_seq";
                arrSQL = new String[]{sql3};
                break;

            case "OB_1064NDC_PW03AT_HP_32_INT9_NoPermLocn":
            case "OB_1064NDC_PW03AT_HP_29_INT9_P40_PermLocn" :
            case "OB_1064NDC_PW03AT_HP_28_INT9_P40_MaxFromDyn":
                String sql4 = "select lpn.tc_lpn_id, lpn.item_name, wmi.cntry_of_orgn, wmi.item_attr_1, lhd.dsp_locn," +
                        " wmi.on_hand_qty,  wmi.inbound_outbound_indicator, wmi.allocatable," +
                        " (wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) as allocatable_qty" +
                        " from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD ,RESV_LOCN_HDR RLH,item_cbo icb" +
                        " where WMI.LPN_ID = LPN.LPN_ID" +
                        " and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID" +
                        " and lhd.locn_id = lpn.curr_sub_locn_id" +
                        " and lpn.item_id=icb.item_id" +
                        " and wmi.item_id=icb.item_id" +
                        " and WMI.INBOUND_OUTBOUND_INDICATOR = 'I'" +
                        " and WMI.ALLOCATABLE = 'Y'" +
                        " and lpn.lpn_facility_status='30'" +
                        " and RLH.INVN_LOCK_CODE is null" +
                        " and lpn.curr_sub_locn_id = '0228114'" +
                        " AND ICB.UNIT_VOLUME IS NOT NULL AND ICB.UNIT_WEIGHT IS NOT NULL  AND" +
                        " ICB.UNIT_LENGTH IS NOT NULL AND ICB.UNIT_WIDTH IS NOT NULL AND ICB.UNIT_HEIGHT IS NOT NULL" +
                        " and icb.unit_volume <>'0.0001' and icb.unit_weight <>'0.0001'" +
                        " AND ICB.ITEM_BAR_CODE <>'0'" +
                        " and lpn.lpn_id not in (select lpn_id from lpn_lock)" +
                        " and LPN.ITEM_ID in (select PLD.ITEM_ID from PICK_LOCN_HDR PLH, LOCN_HDR LHD," +
                        " PICK_LOCN_DTL PLD where  LHD.LOCN_ID = PLH.LOCN_ID and PLD.PICK_LOCN_HDR_ID = PLH.PICK_LOCN_HDR_ID " +
                        " and lhd.sku_dedctn_type = 'P' and lhd.locn_class = 'C' and plh.invn_lock_code is null)" +
                        " order by lpn.item_name, wmi.cntry_of_orgn, wmi.item_attr_1, wmi.on_hand_qty";

                String sql5 = "select lhdp.dsp_locn, lhdp.sku_dedctn_type, icb.item_name," +
                        " wmi.on_hand_qty, wmi.wm_allocated_qty, wmi.to_be_filled_qty," +
                        " (wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) as allocatable_qty," +
                        " pld.max_invn_qty, pld.min_invn_qty,plh.repl_flag,pld.cntry_of_orgn" +
                        " from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi where" +
                        " lhdp.locn_id = plh.locn_id" +
                        " and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id" +
                        " and pld.item_id = icb.item_id" +
                        " and wmi.location_id = plh.locn_id" +
                        " and lhdp.sku_dedctn_type = 'P'" +
                        " and lhdp.locn_class = 'C'" +
                        " and plh.invn_lock_code is null" +
                        " and icb.item_name = '" + System.getProperty("ITEM_NAME") + "'" +
                        " and pld.cntry_of_orgn = '" + System.getProperty("CNTRY_OF_ORGN") + "'" +
                        " and PLD.SKU_ATTR_1= '" + System.getProperty("ITEM_ATTR_1") + "'";
                arrSQL = new String[]{sql4, sql5};
                break;

            case "OB_1064NDC_PW03AT_HP_30_INT9_P50_Perm":
                String sql6 = "select lpn.tc_lpn_id, lpn.item_name, wmi.cntry_of_orgn, wmi.item_attr_1," +
                        " lhd.dsp_locn, wmi.on_hand_qty,  wmi.inbound_outbound_indicator, wmi.allocatable" +
                        " from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD ,RESV_LOCN_HDR RLH ,item_Package_cbo ipc,item_cbo icb" +
                        " where WMI.LPN_ID = LPN.LPN_ID" +
                        " and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID" +
                        " and lhd.locn_id = lpn.curr_sub_locn_id" +
                        " and lpn.item_id=icb.item_id" +
                        " and wmi.item_id=icb.item_id" +
                        " and WMI.INBOUND_OUTBOUND_INDICATOR = 'I'" +
                        " and WMI.ALLOCATABLE = 'Y'" +
                        " and lpn.lpn_facility_status='30'" +
                        " and ipc.package_uom_id='25'" +
                        " and ipc.is_std='1'" +
                        " and wmi.item_id=ipc.item_id" +
                        " and lpn.item_id=ipc.item_id" +
                        " and rlh.invn_lock_code is null" +
                        " and wmi.on_hand_qty > ipc.quantity" +
                        " AND ICB.UNIT_VOLUME IS NOT NULL AND ICB.UNIT_WEIGHT IS NOT NULL" +
                        " AND ICB.UNIT_LENGTH IS NOT NULL AND ICB.UNIT_WIDTH IS NOT NULL AND ICB.UNIT_HEIGHT IS NOT NULL" +
                        " and icb.unit_volume <>'0.0001' and icb.unit_weight <>'0.0001'  " +
                        " AND ICB.ITEM_BAR_CODE <>'0'" +
                        " and LPN.CURR_SUB_LOCN_ID = '0228114'" +
                        " and LPN.LPN_ID not in (select LPN_ID from LPN_LOCK)" +
                        " and LPN.ITEM_ID in (select PLD.ITEM_ID from PICK_LOCN_HDR PLH, LOCN_HDR LHD," +
                        " PICK_LOCN_DTL PLD where  LHD.LOCN_ID = PLH.LOCN_ID and PLD.PICK_LOCN_HDR_ID = PLH.PICK_LOCN_HDR_ID " +
                        " and lhd.sku_dedctn_type = 'P' and lhd.locn_class = 'C' and plh.invn_lock_code is null)" +
                        " order by lpn.item_name, wmi.cntry_of_orgn, wmi.item_attr_1, wmi.on_hand_qty";

                String sql7 = "select lhdp.dsp_locn, lhdp.sku_dedctn_type, icb.item_name," +
                        " wmi.on_hand_qty, wmi.wm_allocated_qty, wmi.to_be_filled_qty," +
                        " (wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) as allocatable_qty," +
                        " pld.max_invn_qty, pld.min_invn_qty,plh.repl_flag,pld.cntry_of_orgn" +
                        " from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi where" +
                        " lhdp.locn_id = plh.locn_id" +
                        " and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id" +
                        " and pld.item_id = icb.item_id" +
                        " and wmi.location_id = plh.locn_id" +
                        " and lhdp.sku_dedctn_type = 'P'" +
                        " and lhdp.locn_class = 'C'" +
                        " and plh.invn_lock_code is null" +
                        " and icb.item_name = '" + System.getProperty("ITEM_NAME") + "'" +
                        " and pld.cntry_of_orgn = '" + System.getProperty("CNTRY_OF_ORGN") + "'" +
                        " and PLD.SKU_ATTR_1= '" + System.getProperty("ITEM_ATTR_1") + "'";
                arrSQL = new String[]{sql6, sql7};
                break;

            case "OB_1064NDC_PW03AT_HP_31_INT9_P60_TopOffMin":
                String sql8 = "select lpn.tc_lpn_id, lpn.item_name, wmi.cntry_of_orgn, wmi.item_attr_1," +
                        " lhd.dsp_locn, wmi.on_hand_qty,  wmi.inbound_outbound_indicator, wmi.allocatable   " +
                        "from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD ,RESV_LOCN_HDR RLH,item_cbo icb   " +
                        "where WMI.LPN_ID = LPN.LPN_ID   " +
                        "and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID   " +
                        "and lhd.locn_id = lpn.curr_sub_locn_id   " +
                        "and lpn.item_id=icb.item_id   " +
                        "and wmi.item_id=icb.item_id   " +
                        "and WMI.INBOUND_OUTBOUND_INDICATOR = 'I'   " +
                        "and WMI.ALLOCATABLE = 'Y'   " +
                        "and lpn.lpn_facility_status='30'   " +
                        "and RLH.INVN_LOCK_CODE is null   " +
                        "and lpn.curr_sub_locn_id = '0228114'   " +
                        "AND ICB.UNIT_VOLUME IS NOT NULL AND ICB.UNIT_WEIGHT IS NOT NULL " +
                        "AND ICB.UNIT_LENGTH IS NOT NULL AND ICB.UNIT_WIDTH IS NOT NULL AND ICB.UNIT_HEIGHT IS NOT NULL   " +
                        "and icb.unit_volume <>'0.0001' and icb.unit_weight <>'0.0001'   " +
                        "AND ICB.ITEM_BAR_CODE <>'0'   " +
                        "and lpn.lpn_id not in (select lpn_id from lpn_lock)   " +
                        "and LPN.ITEM_ID in (select PLD.ITEM_ID from PICK_LOCN_HDR PLH, LOCN_HDR LHD, " +
                        "PICK_LOCN_DTL PLD where  LHD.LOCN_ID = PLH.LOCN_ID and PLD.PICK_LOCN_HDR_ID = PLH.PICK_LOCN_HDR_ID    " +
                        "and lhd.sku_dedctn_type = 'P' and lhd.locn_class = 'C' and plh.invn_lock_code is null)   " +
                        "order by lpn.item_name, wmi.cntry_of_orgn, wmi.item_attr_1, wmi.on_hand_qty";

                String sql9 = "select lhdp.dsp_locn, lhdp.sku_dedctn_type, lhdp.locn_pick_seq, icb.item_name,    " +
                        "wmi.on_hand_qty, wmi.wm_allocated_qty, wmi.to_be_filled_qty,    " +
                        "(wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) as allocatable_qty, " +
                        "pld.max_invn_qty, pld.min_invn_qty, pld.cntry_of_orgn, pld.sku_attr_1, pld.locn_seq_nbr     " +
                        "from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi where    " +
                        "lhdp.locn_id = plh.locn_id    " +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id   " +
                        "and pld.item_id = icb.item_id   " +
                        "and wmi.location_id = plh.locn_id   " +
                        "and lhdp.sku_dedctn_type = 'P'   " +
                        "and lhdp.locn_class = 'C'   " +
                        "and PLH.INVN_LOCK_CODE is null   " +
                        "and ICB.ITEM_NAME = '" + System.getProperty("ITEM_NAME") + "'" +
                        " and PLD.CNTRY_OF_ORGN = '" + System.getProperty("CNTRY_OF_ORGN") + "'" +
                        " and PLD.SKU_ATTR_1= '" + System.getProperty("ITEM_ATTR_1") + "'";
                arrSQL = new String[]{sql8, sql9};
                break;

            case "OB_1064NDC_PW04MISC_HP_06_INT9_Dynamic_Locn_determination_based_on_size":
                String sql10 = "select lpn.tc_lpn_id, lpn.item_name, wmi.cntry_of_orgn, wmi.item_attr_1, " +
                    "lhd.dsp_locn, wmi.on_hand_qty,  wmi.inbound_outbound_indicator, wmi.allocatable, " +
                    "(wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) as allocatable_qtyfrom LPN LPN, " +
                    "WM_INVENTORY WMI, LOCN_HDR LHD ,RESV_LOCN_HDR RLH,item_cbo icb where " +
                    "WMI.LPN_ID = LPN.LPN_ID and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                    "and lhd.locn_id = lpn.curr_sub_locn_idand lpn.item_id=icb.item_id " +
                    "and wmi.item_id=icb.item_id and WMI.INBOUND_OUTBOUND_INDICATOR = 'I' " +
                    "and WMI.ALLOCATABLE = 'Y' and lpn.lpn_facility_status='30' and RLH.INVN_LOCK_CODE is null " +
                    "and lpn.curr_sub_locn_id = '0228114' AND ICB.UNIT_VOLUME IS NOT NULL AND " +
                    "ICB.UNIT_WEIGHT IS NOT NULL  AND ICB.UNIT_LENGTH IS NOT NULL AND ICB.UNIT_WIDTH IS NOT NULL " +
                    "AND ICB.UNIT_HEIGHT IS NOT NULL and icb.unit_volume <>'0.0001' and icb.unit_weight <>'0.0001' " +
                    "AND ICB.ITEM_BAR_CODE <>'0'and lpn.lpn_id not in (select lpn_id from lpn_lock)and LPN.ITEM_ID " +
                    "in (select PLD.ITEM_ID from PICK_LOCN_HDR PLH, LOCN_HDR LHD, PICK_LOCN_DTL PLD where  " +
                    "LHD.LOCN_ID = PLH.LOCN_ID and PLD.PICK_LOCN_HDR_ID = PLH.PICK_LOCN_HDR_ID " +
                    "and lhd.sku_dedctn_type = 'P' and lhd.locn_class = 'C' and plh.invn_lock_code is null)order by " +
                    "lpn.item_name, wmi.cntry_of_orgn, wmi.item_attr_1, wmi.on_hand_qty ";

                String sql11 = "select lhdp.dsp_locn, lhdp.sku_dedctn_type,PLH.PICK_LOCN_ASSIGN_type,icb.item_name, " +
                        "wmi.on_hand_qty, wmi.wm_allocated_qty, wmi.to_be_filled_qty, " +
                        "(wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) as allocatable_qty, " +
                        "pld.max_invn_qty, pld.min_invn_qty,plh.repl_flag,pld.cntry_of_orgn from pick_locn_hdr plh, " +
                        "locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi where " +
                        "lhdp.locn_id = plh.locn_id and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id " +
                        "and pld.item_id = icb.item_id and wmi.location_id = plh.locn_id and lhdp.sku_dedctn_type = 'P' " +
                        "and lhdp.locn_class = 'C' and plh.invn_lock_code is null and icb.item_name = " + System.getProperty("ITEM_NAME") + "'" +
                        "and pld.cntry_of_orgn = '" + System.getProperty("CNTRY_OF_ORGN") + "'" +
                        "and PLD.SKU_ATTR_1= '" + System.getProperty("ITEM_ATTR_1") + "'";

                String sql12 = "select CODE_ID,CODE_DESC,MISC_FLAGS from SYS_CODE  " +
                        "where CODE_TYPE='330'and SUBSTR(MISC_FLAGS,18,1)='Y' " +
                        "and CODE_ID in (select PLH.PICK_LOCN_ASSIGN_ZONE  " +
                        "from LOCN_HDR LH, PICK_LOCN_HDR PLH, PICK_LOCN_ASSIGN_PRTY PLAP " +
                        "where LH.LOCN_ID = PLH.LOCN_ID and PLH.PICK_LOCN_ASSIGN_ZONE  = PLAP.PICK_LOCN_ASSIGN_ZONE " +
                        "and plap.pick_locn_assign_type in ('" + System.getProperty("PICK_LOCN_ASSIGN_TYPE") + "')";
                arrSQL = new String[]{sql10};
                break;

            case "OB_1064_PW03AT_HP_18_INT9_Alloc_type_Digital_Brkn_prepacks":
                String sql22 = "select LPN.TC_PARENT_LPN_ID,LPN.LPN_ID,LPN.ITEM_NAME,IPC.QUANTITY STD_PACK_QTY, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,WMI.ON_HAND_QTY QTY " +
                        "from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD,RESV_LOCN_HDR RLH,ITEM_PACKAGE_CBO IPC " +
                        "where WMI.LPN_ID = LPN.LPN_ID " +
                        "and IPC.ITEM_ID=LPN.ITEM_ID " +
                        "and IPC.PACKAGE_UOM_ID='26' " +
                        "and IPC.IS_STD='1' " +
                        "and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and lhd.locn_id = lpn.curr_sub_locn_id " +
                        "and wmi.inbound_outbound_indicator = 'I' " +
                        "and wmi.allocatable = 'Y' " +
                        "and lpn.tc_parent_lpn_id is not null  " +
                        "and RLH.INVN_LOCK_CODE is null " +
                        "and LPN.CURR_SUB_LOCN_ID in (select LOCN_ID from LOCN_HDR where LOCN_CLASS = 'R' and PULL_ZONE in('HC1','HG1','HP1')) " +
                        "and lpn.lpn_id not in (select lpn_id from lpn_lock) " +
                        "and LPN.ITEM_ID in (select PLD.ITEM_ID from PICK_LOCN_HDR PLH, LOCN_HDR LHD, PICK_LOCN_DTL PLD where  LHD.LOCN_ID = PLH.LOCN_ID  " +
                        "and LHD.pick_DETRM_ZONE='002' " +
                        "and PLD.PICK_LOCN_HDR_ID = PLH.PICK_LOCN_HDR_ID  " +
                        "and LHD.SKU_DEDCTN_TYPE = 'P' and LHD.LOCN_CLASS = 'C' and PLH.INVN_LOCK_CODE is null) " +
                        "group by (LPN.TC_PARENT_LPN_ID,LPN.LPN_ID,LPN.ITEM_NAME,IPC.QUANTITY, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,WMI.ON_HAND_QTY) " +
                        "order by LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1,LHD.PULL_ZONE, WMI.ON_HAND_QTY desc, LHD.LOCN_PICK_SEQ " ;

                String sql23 = "select lhdp.dsp_locn, lhdp.sku_dedctn_type, lhdp.locn_pick_seq, icb.item_name,  " +
                        "wmi.on_hand_qty, wmi.wm_allocated_qty, wmi.to_be_filled_qty,  " +
                        "(wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) as allocatable_qty, pld.max_invn_qty, pld.min_invn_qty, pld.cntry_of_orgn, pld.sku_attr_1, pld.locn_seq_nbr   " +
                        "from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi where  " +
                        "lhdp.locn_id = plh.locn_id  " +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id " +
                        "and pld.item_id = icb.item_id " +
                        "and wmi.location_id = plh.locn_id " +
                        "and lhdp.sku_dedctn_type = 'P' " +
                        "and lhdp.locn_class = 'C' " +
                        "and LHDP.pick_DETRM_ZONE='002' " +
                        "and PLH.INVN_LOCK_CODE is null " +
                        "and ICB.ITEM_NAME = (?) " +
                        "and PLD.CNTRY_OF_ORGN = (?) " +
                        "and PLD.SKU_ATTR_1= (?)";
                arrSQL = new String[]{sql22,sql23};
                break;

            case "OB_1064_PW03AT_HP_17_INT9_Alloc_type_Digital_packs":
                String sql20 = "select LPN.TC_PARENT_LPN_ID,LPN.LPN_ID,LPN.ITEM_NAME,IPC.QUANTITY STD_PACK_QTY, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,WMI.ON_HAND_QTY QTY " +
                        "from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD,RESV_LOCN_HDR RLH,ITEM_PACKAGE_CBO IPC " +
                        "where WMI.LPN_ID = LPN.LPN_ID " +
                        "and IPC.ITEM_ID=LPN.ITEM_ID " +
                        "and IPC.PACKAGE_UOM_ID='26' " +
                        "and IPC.IS_STD='1' " +
                        "and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and lhd.locn_id = lpn.curr_sub_locn_id " +
                        "and wmi.inbound_outbound_indicator = 'I' " +
                        "and wmi.allocatable = 'Y' " +
                        "and lpn.tc_parent_lpn_id is not null  " +
                        "and RLH.INVN_LOCK_CODE is null " +
                        "and LPN.CURR_SUB_LOCN_ID in (select LOCN_ID from LOCN_HDR where LOCN_CLASS = 'R' and PULL_ZONE in('HC1','HG1','HP1')) " +
                        "and lpn.lpn_id not in (select lpn_id from lpn_lock) " +
                        "and LPN.ITEM_ID in (select PLD.ITEM_ID from PICK_LOCN_HDR PLH, LOCN_HDR LHD, PICK_LOCN_DTL PLD where  LHD.LOCN_ID = PLH.LOCN_ID  " +
                        "and PLD.PICK_LOCN_HDR_ID = PLH.PICK_LOCN_HDR_ID  " +
                        "and LHD.SKU_DEDCTN_TYPE = 'P' and LHD.LOCN_CLASS = 'C' and PLH.INVN_LOCK_CODE is null) " +
                        "group by (LPN.TC_PARENT_LPN_ID,LPN.LPN_ID,LPN.ITEM_NAME,IPC.QUANTITY, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,WMI.ON_HAND_QTY) " +
                        "order by LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1,LHD.PULL_ZONE, WMI.ON_HAND_QTY desc, LHD.LOCN_PICK_SEQ " ;

                String sql21 = "select lhdp.dsp_locn, lhdp.sku_dedctn_type, lhdp.locn_pick_seq, icb.item_name,  " +
                        "wmi.on_hand_qty, wmi.wm_allocated_qty, wmi.to_be_filled_qty,  " +
                        "(wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) as allocatable_qty, pld.max_invn_qty, pld.min_invn_qty, pld.cntry_of_orgn, pld.sku_attr_1, pld.locn_seq_nbr   " +
                        "from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi where  " +
                        "lhdp.locn_id = plh.locn_id  " +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id " +
                        "and pld.item_id = icb.item_id " +
                        "and wmi.location_id = plh.locn_id " +
                        "and lhdp.sku_dedctn_type = 'P' " +
                        "and lhdp.locn_class = 'C' " +
                        "and LHDP.pick_DETRM_ZONE<>'002' " +
                        "and PLH.INVN_LOCK_CODE is null " +
                        "and ICB.ITEM_NAME = (?) " +
                        "and PLD.CNTRY_OF_ORGN = (?) " +
                        "and PLD.SKU_ATTR_1= (?)  " ;
                arrSQL = new String[]{sql20,sql21};
                break;

            case "OB_1064_PW03AT_HP_10_INT9_Carton_Equip_P40_dynamicLocn_MultiLine_NEW":
                String sql16="select LPN.TC_PARENT_LPN_ID, LPN.TC_LPN_ID, LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN,LHD.LOCN_PICK_SEQ, WMI.ON_HAND_QTY QTY " +
                        "from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD,RESV_LOCN_HDR RLH " +
                        "where WMI.LPN_ID = LPN.LPN_ID " +
                        "and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and lhd.locn_id = lpn.curr_sub_locn_id " +
                        "and wmi.inbound_outbound_indicator = 'I' " +
                        "and wmi.allocatable = 'Y' " +
                        "and lpn.lpn_facility_status='30' " +
                        "and lpn.tc_parent_lpn_id is not null  " +
                        "and RLH.INVN_LOCK_CODE is null " +
                        "and LPN.CURR_SUB_LOCN_ID in (select LOCN_ID from LOCN_HDR where LOCN_CLASS = 'R' and PULL_ZONE IN('HC1','HG1','HP1')) " +
                        "and lpn.lpn_id not in (select lpn_id from lpn_lock) " +
                        "and LPN.ITEM_ID in (select PLD.ITEM_ID from PICK_LOCN_HDR PLH, LOCN_HDR LHD, PICK_LOCN_DTL PLD where  LHD.LOCN_ID = PLH.LOCN_ID and PLD.PICK_LOCN_HDR_ID = PLH.PICK_LOCN_HDR_ID  " +
                        "and LHD.SKU_DEDCTN_TYPE = 'P' and LHD.LOCN_CLASS = 'C' and PLH.INVN_LOCK_CODE is null) " +
                        "order by lpn.item_name, wmi.cntry_of_orgn, wmi.item_attr_1,LHD.PULL_ZONE, wmi.on_hand_qty desc, lhd.locn_pick_seq";

                String sql17="select lhdp.dsp_locn, lhdp.sku_dedctn_type, lhdp.locn_pick_seq, icb.item_name,  " +
                        "wmi.on_hand_qty, wmi.wm_allocated_qty, wmi.to_be_filled_qty,  " +
                        "(wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) as allocatable_qty, pld.max_invn_qty, pld.min_invn_qty, pld.cntry_of_orgn, pld.sku_attr_1, pld.locn_seq_nbr   " +
                        "from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi where  " +
                        "lhdp.locn_id = plh.locn_id  " +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id " +
                        "and pld.item_id = icb.item_id " +
                        "and wmi.location_id = plh.locn_id " +
                        "and lhdp.sku_dedctn_type = 'P' " +
                        "and lhdp.locn_class = 'C' " +
                        "and LHDP.pick_DETRM_ZONE<>'002' " +
                        "and PLH.INVN_LOCK_CODE is null " +
                        "and ICB.ITEM_NAME = (?) " +
                        "and PLD.CNTRY_OF_ORGN = (?) " +
                        "and PLD.SKU_ATTR_1=(?)";
                arrSQL = new String[]{sql16,sql17};
                break;

            case "OB_1064_PW03AT_HP_11_INT9_Carton_Equip_P40_PermLocn_Carton_Substitution_NEW" :
                String sql24="select LPN.TC_PARENT_LPN_ID, LPN.TC_LPN_ID, LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN,LHD.LOCN_PICK_SEQ, WMI.ON_HAND_QTY QTY " +
                        "from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD,RESV_LOCN_HDR RLH " +
                        "where WMI.LPN_ID = LPN.LPN_ID " +
                        "and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and lhd.locn_id = lpn.curr_sub_locn_id " +
                        "and wmi.inbound_outbound_indicator = 'I' " +
                        "and wmi.allocatable = 'Y' " +
                        " and lpn.lpn_facility_status='30' " +
                        "and lpn.tc_parent_lpn_id is not null  " +
                        "and RLH.INVN_LOCK_CODE is null " +
                        "and LPN.CURR_SUB_LOCN_ID in (select LOCN_ID from LOCN_HDR where LOCN_CLASS = 'R' and PULL_ZONE IN('HC1','HG1','HP1')) " +
                        "and lpn.lpn_id not in (select lpn_id from lpn_lock) " +
                        "and LPN.ITEM_ID in (select PLD.ITEM_ID from PICK_LOCN_HDR PLH, LOCN_HDR LHD, PICK_LOCN_DTL PLD where  LHD.LOCN_ID = PLH.LOCN_ID and PLD.PICK_LOCN_HDR_ID = PLH.PICK_LOCN_HDR_ID  " +
                        "and LHD.SKU_DEDCTN_TYPE = 'P' and LHD.LOCN_CLASS = 'C' and PLH.INVN_LOCK_CODE is null) " +
                        "order by lpn.item_name, wmi.cntry_of_orgn, wmi.item_attr_1,LHD.PULL_ZONE, wmi.on_hand_qty desc, lhd.locn_pick_seq " ;

                String sql25="select lhdp.dsp_locn, lhdp.sku_dedctn_type, lhdp.locn_pick_seq, icb.item_name,  " +
                        "wmi.on_hand_qty, wmi.wm_allocated_qty, wmi.to_be_filled_qty,  " +
                        "(wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) as allocatable_qty, pld.max_invn_qty, pld.min_invn_qty, pld.cntry_of_orgn, pld.sku_attr_1, pld.locn_seq_nbr   " +
                        "from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi where  " +
                        "lhdp.locn_id = plh.locn_id  " +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id " +
                        "and pld.item_id = icb.item_id " +
                        "and wmi.location_id = plh.locn_id " +
                        "and lhdp.sku_dedctn_type = 'P' " +
                        "and lhdp.locn_class = 'C' " +
                        "and LHDP.pick_DETRM_ZONE<>'002' " +
                        "and PLH.INVN_LOCK_CODE is null " +
                        "and ICB.ITEM_NAME = (?) " +
                        "and PLD.CNTRY_OF_ORGN = (?) " +
                        "and PLD.SKU_ATTR_1= (?) " ;
                arrSQL = new String[]{sql24,sql25};
                break;

            case "OB_1064_PW03AT_HP_13_INT9_Carton_Equip_P60_PermLocn_for_Packs_NEW":
                String sql26="select LPN.TC_PARENT_LPN_ID,LPN.LPN_ID,LPN.ITEM_NAME,IPC.QUANTITY STD_PACK_QTY, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,WMI.ON_HAND_QTY QTY " +
                        "from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD,RESV_LOCN_HDR RLH,ITEM_PACKAGE_CBO IPC " +
                        "where WMI.LPN_ID = LPN.LPN_ID " +
                        "and IPC.ITEM_ID=LPN.ITEM_ID " +
                        "and IPC.PACKAGE_UOM_ID='26' " +
                        "and IPC.IS_STD='1' " +
                        "and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and lhd.locn_id = lpn.curr_sub_locn_id " +
                        "and wmi.inbound_outbound_indicator = 'I' " +
                        "and wmi.allocatable = 'Y' " +
                        "and lpn.tc_parent_lpn_id is not null  " +
                        "and RLH.INVN_LOCK_CODE is null " +
                        "and LPN.CURR_SUB_LOCN_ID in (select LOCN_ID from LOCN_HDR where LOCN_CLASS = 'R' and PULL_ZONE in('HC1','HG1','HP1')) " +
                        "and lpn.lpn_id not in (select lpn_id from lpn_lock) " +
                        "and LPN.ITEM_ID in (select PLD.ITEM_ID from PICK_LOCN_HDR PLH, LOCN_HDR LHD, PICK_LOCN_DTL PLD where  LHD.LOCN_ID = PLH.LOCN_ID  " +
                        "and PLD.PICK_LOCN_HDR_ID = PLH.PICK_LOCN_HDR_ID  " +
                        "and LHD.SKU_DEDCTN_TYPE = 'P' and LHD.LOCN_CLASS = 'C' and PLH.INVN_LOCK_CODE is null) " +
                        "group by (LPN.TC_PARENT_LPN_ID,LPN.LPN_ID,LPN.ITEM_NAME,IPC.QUANTITY, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ,WMI.ON_HAND_QTY) " +
                        "order by LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1,LHD.PULL_ZONE, WMI.ON_HAND_QTY desc, LHD.LOCN_PICK_SEQ";
                String sql27="select lhdp.dsp_locn, lhdp.sku_dedctn_type, lhdp.locn_pick_seq, icb.item_name,  " +
                        "wmi.on_hand_qty, wmi.wm_allocated_qty, wmi.to_be_filled_qty,  " +
                        "(wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) as allocatable_qty, pld.max_invn_qty, pld.min_invn_qty, pld.cntry_of_orgn, pld.sku_attr_1, pld.locn_seq_nbr   " +
                        "from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi where  " +
                        "lhdp.locn_id = plh.locn_id  " +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id " +
                        "and pld.item_id = icb.item_id " +
                        "and wmi.location_id = plh.locn_id " +
                        "and lhdp.sku_dedctn_type = 'P' " +
                        "and lhdp.locn_class = 'C' " +
                        "and LHDP.pick_DETRM_ZONE<>'002' " +
                        "and PLH.INVN_LOCK_CODE is null " +
                        "and ICB.ITEM_NAME = (?) " +
                        "and PLD.CNTRY_OF_ORGN = (?) " +
                        "and PLD.SKU_ATTR_1= (?)  ";
                arrSQL = new String[]{sql26,sql27};
                break;

            case "OB_1064_PW03AT_HP_13_INT9_Carton_Equip_P60_PermLocn_PROMO_NEW":
                String sql18 = "select LPN.TC_PARENT_LPN_ID, LPN.TC_LPN_ID, LPN.ITEM_NAME, WMI.CNTRY_OF_ORGN, WMI.ITEM_ATTR_1,LHD.PULL_ZONE,LHD.DSP_LOCN, LHD.LOCN_PICK_SEQ, WMI.ON_HAND_QTY QTY " +
                        "from LPN LPN, WM_INVENTORY WMI, LOCN_HDR LHD,RESV_LOCN_HDR RLH " +
                        "where WMI.LPN_ID = LPN.LPN_ID " +
                        "and RLH.LOCN_ID = LPN.CURR_SUB_LOCN_ID " +
                        "and lhd.locn_id = lpn.curr_sub_locn_id " +
                        "and wmi.inbound_outbound_indicator = 'I' " +
                        "and wmi.allocatable = 'Y' " +
                        "and lpn.lpn_facility_status='30' " +
                        "and lpn.tc_parent_lpn_id is not null  " +
                        "and RLH.INVN_LOCK_CODE is null " +
                        "and LPN.CURR_SUB_LOCN_ID in (select LOCN_ID from LOCN_HDR where LOCN_CLASS = 'R' and PULL_ZONE in('HG2','HP2')) " +
                        "and LPN.LPN_ID not in (select LPN_ID from LPN_LOCK) " +
                        "and LPN.ITEM_ID not in (select PLD.ITEM_ID from PICK_LOCN_HDR PLH, LOCN_HDR LHD, PICK_LOCN_DTL PLD where  LHD.LOCN_ID = PLH.LOCN_ID and PLD.PICK_LOCN_HDR_ID = PLH.PICK_LOCN_HDR_ID  " +
                        "and LHD.LOCN_CLASS = 'C' and PLH.INVN_LOCK_CODE is null) " +
                        "order by lpn.item_name, wmi.cntry_of_orgn, wmi.item_attr_1,LHD.PULL_ZONE, wmi.on_hand_qty desc, lhd.locn_pick_seq " ;
                String sql19 = "select lhdp.dsp_locn, lhdp.sku_dedctn_type, lhdp.locn_pick_seq, icb.item_name,  " +
                        "wmi.on_hand_qty, wmi.wm_allocated_qty, wmi.to_be_filled_qty,  " +
                        "(wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) as allocatable_qty, pld.max_invn_qty, pld.min_invn_qty, pld.cntry_of_orgn, pld.sku_attr_1, pld.locn_seq_nbr   " +
                        "from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi where  " +
                        "lhdp.locn_id = plh.locn_id  " +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id " +
                        "and pld.item_id = icb.item_id " +
                        "and wmi.location_id = plh.locn_id " +
                        "and lhdp.sku_dedctn_type = 'P' " +
                        "and lhdp.locn_class = 'C' " +
                        "and LHDP.pick_DETRM_ZONE<>'002' " +
                        "and PLH.INVN_LOCK_CODE is null " +
                        "and ICB.ITEM_NAME = (?) " +
                        "and PLD.CNTRY_OF_ORGN = (?) " +
                        "and PLD.SKU_ATTR_1= (?)  " ;
                arrSQL = new String[]{sql18,sql19};
                break;

            case "OB_1064_PW03AT_HP_16_INT9_case_pick_from_receiving":
                String sql13="select lhdp.dsp_locn, lhdp.sku_dedctn_type, lhdp.locn_pick_seq, icb.item_name,WMI.ON_HAND_QTY,(wmi.on_hand_qty-wmi.wm_allocated_qty+wmi.to_be_filled_qty) as allocatable_qty, pld.max_invn_qty, pld.min_invn_qty, pld.cntry_of_orgn, pld.sku_attr_1, pld.locn_seq_nbr,WMI.ITEM_ATTR_1   " +
                        "from pick_locn_hdr plh, locn_hdr lhdp, item_cbo icb, pick_locn_dtl pld, wm_inventory wmi where  " +
                        "lhdp.locn_id = plh.locn_id  " +
                        "and pld.pick_locn_hdr_id = plh.pick_locn_hdr_id " +
                        "and pld.item_id = icb.item_id " +
                        "and WMI.LOCATION_ID = PLH.LOCN_ID " +
                        "and lhdp.sku_dedctn_type = 'P' " +
                        "and LHDP.LOCN_CLASS = 'C' " +
                        "and WMI.ON_HAND_QTY='0' " +
                        "and icb.item_bar_code <>'0' " +
                        "and PLH.INVN_LOCK_CODE is null";
                arrSQL = new String[]{sql13};
                break;
        }
        return arrSQL;
    }
}
