package org.uncommons.reportng;

import org.testng.ITestResult;

import java.util.Comparator;

import static org.uncommons.reportng.ReportNGUtils.*;

/**
 * Compares two ITestResults by class > Method > Params > iteration number
 */
public class TestResultArgumentComparator implements Comparator<ITestResult> {
    public int compare(ITestResult result1, ITestResult result2) {
        int compare = result1.getTestClass().getRealClass().getName().compareTo(result2.getTestClass().getRealClass().getName());
        if (compare == 0) {
            compare = result1.getMethod().getMethodName().compareTo(result2.getMethod().getMethodName());
            if (compare == 0) {
                compare = arrayToString(result1.getParameters()).compareTo(arrayToString(result2.getParameters()));
                if (compare == 0) {
                    if (hasIterationCount(result1) && hasIterationCount(result2)) {
                        compare = new Integer(getIterationCount(result1)).compareTo(getIterationCount(result2));
                    } else if (hasIterationCount(result1)) {
                        compare = -1;
                    } else if (hasIterationCount(result2)) {
                        compare = 1;
                    }
                }
            }
        }
        return compare;
    }
}
