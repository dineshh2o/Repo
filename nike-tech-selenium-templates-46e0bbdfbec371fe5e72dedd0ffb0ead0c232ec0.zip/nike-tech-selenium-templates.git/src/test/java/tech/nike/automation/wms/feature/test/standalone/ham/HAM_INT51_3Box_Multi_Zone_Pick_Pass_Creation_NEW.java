package tech.nike.automation.wms.feature.test.standalone.ham;

import tech.nike.automation.common.framework.sql.DBConnect;
import tech.nike.automation.common.framework.sql.INT51Queries;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by psibb1 on 8/30/2016.
 */
public class HAM_INT51_3Box_Multi_Zone_Pick_Pass_Creation_NEW {
    //global variables instantiation
    public static String strTextFilePath = "c:\\records.txt";

    public static void main(String[] argv) {
        {
            //local variables instantiation
            PreparedStatement statement = null;
            Connection connection = null;
            String strEnv = "HAM-ER";
            String strTestCaseID = "OB_1064NDC_PW03AT_HP_37_INT51_3Box_Multi_Zone_Pick_Pass_Creation_NEW";
            //int recordsLimit = 5000;
            long startTime = System.currentTimeMillis(); // Get the start Time
            long endTime = 0;
            String[] arrItem = new String[2];
            int index = 0;
            int counter = 0;
            boolean blnFound = false;
            FileWriter fstream = null;
            List<String> itemNames = new ArrayList<String>();
            List<String> zoneNames = new ArrayList<String>();
            List<String> coos = new ArrayList<>();
            List<Integer> allocatableQuantity= new ArrayList<Integer>();
            try {
                    //file to save the sku details required for xml posting
                    File file = new File(strTextFilePath);
                    fstream = new FileWriter(file,true);
                    BufferedWriter out = new BufferedWriter(fstream);
                    String[] getArrQL = INT51Queries.getQuery(strTestCaseID);
                    String strQuery1 = getArrQL[0];
                    String strQuery2 = getArrQL[1];
                    connection = DBConnect.getDatabaseConnection(strEnv);
                    statement = connection.prepareStatement(strQuery1);
                    //statement.setFetchSize(recordsLimit);
                    ResultSet result = statement.executeQuery();
                    //iterate the first result set data for second sql
                    if (result.next() ) {
                        while (result.next()) {
                            if (!zoneNames.contains(result.getString("ZONE"))) {
                                zoneNames.add(result.getString("ZONE"));
                                int allocatableQty = Integer.parseInt(result.getString("ALLOCATABLE_QTY"));
                                coos.add(result.getString("CNTRY_OF_ORGN"));
                                //write to system variable to read it easily
                                System.setProperty("ALLOCATABLE_QTY", Integer.toString(allocatableQty));

                                String itemName = result.getString("ITEM_NAME");
                                //write to system variable to read it easily
                                System.setProperty("ITEM_NAME", itemName);

                                itemNames.add(itemName);
                                //checking for same item name
                                if (itemName.length() > 1) {
                                    blnFound = true;
                                } else {
                                    break;
                                }
                                allocatableQuantity.add(allocatableQty);

                                if (blnFound) {
                                    if(index>=1)
                                        break;
                                    else
                                        index = index + 1;
                                }
                            }
                        }
                            //check condition to write into the text file
                            if (index >= 1) {
                                try {
                                    out.append(strTestCaseID).append(",");
                                    out.append(itemNames.get(0)).append(", ");
                                    out.append(itemNames.get(1)).append(", ");
                                    out.append(Integer.toString(allocatableQuantity.get(0))).append(", ");
                                    out.newLine();
                                    out.flush();
                                    out.close();
                                    statement.close();
                                    connection.close();
                                    return;
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }

                    } else {
                        System.out.println("No records found");
                        out.append(strTestCaseID).append(",");
                        out.append("No records found");
                        out.close();
                        result.close();
                    }
                    // } while ((endTime - startTime) / 1000 == 600);
                }
                catch (SQLException e) {
                try {
                    statement.close();
                    connection.close();
                } catch (SQLException e1) {
                    e1.printStackTrace();
                }
            } catch (IOException e) {
                try {
                    statement.close();
                    connection.close();
                } catch (SQLException e1) {
                    e1.printStackTrace();
                }
            }
        }
    }
}