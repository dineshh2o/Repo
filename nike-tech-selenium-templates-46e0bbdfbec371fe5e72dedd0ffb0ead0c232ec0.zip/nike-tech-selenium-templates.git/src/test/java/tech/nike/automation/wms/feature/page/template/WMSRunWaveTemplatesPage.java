package tech.nike.automation.wms.feature.page.template;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import tech.nike.automation.common.page.Page;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Created by PSibb1 on 6/24/2016.
 */
public class WMSRunWaveTemplatesPage extends Page {

    //$= is a tail-string match, that's all. Similarly *= is a partial-substring match, and ^= is a head-string match.
    //locators
    public By txtSearchByDesc = By.cssSelector("[alt='Find Description'][type='text']");
    public By txtSearchByPickingWaveParam = By.cssSelector("[alt='Find Template'][type='text']");
    public By btnApply = By.cssSelector("[id$='filterIdapply'][type='button']");
    public By tblRunWaveTemplates = By.id("dataForm:listView:dataTable_body");
    public By btnRunWave = By.cssSelector("[id*='RunWave'][type='button']");
    public By chkRunWaveTemplate = By.cssSelector("[id^='checkAll_c'][type='checkbox']");
    public By txtRunWaveTemplateDesc = By.cssSelector("[id$=':wvdesc']");
    public By txtRunWaveTemplatePickWaveParam = By.cssSelector("[id$=':transType']");


    /**
     * method to select a run wave template by description
     *
     * @param strRunWaveTempDesc
     * @return
     */
    public boolean selectRunWaveTemplateByDesc(String strRunWaveTempDesc)  {
        //verify if the search by description field was visible
        boolean result = se.element.isVisible(txtSearchByDesc);
        //verify if the search by description field was clickable
        result &= se.element.waitForElementToBeClickable(txtSearchByDesc);
        //verify if the entered search template description was correctly displayed
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtSearchByDesc, strRunWaveTempDesc);
        //verify if apply button was visible
        result &= se.element.isVisible(btnApply);
        //verify if the apply button was clickable
        result &= se.element.waitForElementToBeClickable(btnApply);
        //click on the apply button
        se.element.clickElement(btnApply);
        //wait for the page load to complete
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //verify if the required Run Wave templates table was displayed
        se.element.requireIsDisplayed("Run Wave Templates Table", tblRunWaveTemplates);
        //select run way template based on user search type
        List<WebElement> options = se.element.getElements(tblRunWaveTemplates);
        result &= se.myDriver.findElements(txtRunWaveTemplateDesc).size() > 0;
        List<WebElement> weDescs = se.element.getElements(txtRunWaveTemplateDesc);
        result &= se.myDriver.findElements(chkRunWaveTemplate).size() > 0;
        List<WebElement> weChks = se.element.getElements(chkRunWaveTemplate);
        boolean blnFound = false;
        for (int i = 0; i < options.size(); i++) {
            String strDispTemp = weDescs.get(i).getText().trim();
            if (strDispTemp.equalsIgnoreCase(strRunWaveTempDesc)) {
                weChks.get(i).click();
                se.log.logSeStep("run wave template at row # " + i +
                        " was matching search template type as " + strDispTemp);
                blnFound = true;
                break;
            }
        }
        if(blnFound != true){
            result &= false;
        }
        return result;
    }

    /**
     * method to select a run wave template by description
     *
     * @param strPickWaveParam
     * @return
     */
    public boolean selectRunWaveTemplateByPickWaveParam(String strPickWaveParam) {
        //verify if the search by picking wave parameter field was visible
        boolean result = se.element.isVisible(txtSearchByPickingWaveParam);
        //verify if the search by picking wave parameter field was clickable
        result &= se.element.waitForElementToBeClickable(txtSearchByPickingWaveParam);
        //verify if the entered search template picking wave parameter was correctly displayed
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtSearchByPickingWaveParam, strPickWaveParam);
        //verify if apply button was visible
        result &= se.element.isVisible(btnApply);
        //verify if the apply button was clickable
        result &= se.element.waitForElementToBeClickable(btnApply);
        //click on the apply button
        se.element.clickElement(btnApply);
        //wait for the page load to complete
        se.myDriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        //verify if the required Run Wave templates table was displayed
        se.element.requireIsDisplayed("Run Wave Templates Table", tblRunWaveTemplates);
        //select run way template based on user search type
        List<WebElement> options = se.element.getElements(tblRunWaveTemplates);
        result &= se.myDriver.findElements(txtRunWaveTemplatePickWaveParam).size() > 0;
        List<WebElement> wePickWaveParams = se.element.getElements(txtRunWaveTemplatePickWaveParam);
        result &= se.myDriver.findElements(chkRunWaveTemplate).size() > 0;
        List<WebElement> weChks = se.element.getElements(chkRunWaveTemplate);
        boolean blnFound = false;
        for (int i = 0; i < options.size(); i++) {
            String strDispTemp = wePickWaveParams.get(i).getText().trim();
            if (strDispTemp.equalsIgnoreCase(strPickWaveParam)) {
                weChks.get(i).click();
                se.log.logSeStep("run wave template at row # " + i +
                        " was matching search picking wave parameter type as " + strDispTemp);
                blnFound = true;
                break;
            }
        }
        if(blnFound != true){
            result &= false;
        }
        return result;
    }

    /**
     * method to verify and click on the run wave button and navigate to templates rules
     *
     * @return
     */
    public boolean navigateToWaveRules() {
        //verify if the run wave button was displayed
        se.element.requireIsDisplayed("Run Wave button", btnRunWave);
        //verify if the run wave button was clickable
        boolean result = se.element.waitForElementToBeClickable(btnRunWave);
        //click on the run wave button
        se.element.clickElement(btnRunWave);
        //wait for the page load to complete
        se.myDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        return result;
    }

    /**
     * method to navigate to the run waves by selecting a template searching by template description
     * @param testdata
     * @return
     */
    public boolean navigateToRunWaves(Map<String, Object> testdata)  {
        String strTempDesc = (String)testdata.get("newtempDesc");
        boolean result = selectRunWaveTemplateByDesc(strTempDesc);
        result &= navigateToWaveRules();
        return result;
    }
}
