package tech.nike.automation.wms.feature.test.standalone.ham;

import tech.nike.automation.common.framework.sql.DBConnect;
import tech.nike.automation.common.framework.sql.INT2Queries;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by psibb1 on 8/30/2016.
 */
public class HAM_INT51_INT2_TaskCreation_NEW {
    //global variables instantiation
    public static String strTextFilePath = "c:\\records.txt";

    public static void main(String[] argv){
        {
            //local variables instantiation
            PreparedStatement statement = null;
            PreparedStatement statement1 = null;
            Connection connection = null;
            String strEnv = "HAM-ER";
            String strTestCaseID = "OB_1064NDC_PW03AT_HP_39_INT51_ INT2_Task Creation_NEW";
            //int recordsLimit = 5000;
            long startTime = System.currentTimeMillis(); // Get the start Time
            long endTime = 0;
            String[] arrItem = new String[2];
            int index = 0;
            int counter = 0;
            boolean blnFound = false;
            FileWriter fstream = null;
            List<String> itemNames = new ArrayList<String>();
            List<String> itemAttr = new ArrayList<String>();
            List<Integer> orderQuantity = new ArrayList<Integer>();
            List<String> countryOforigin = new ArrayList<String>();
            List<String> custName = new ArrayList<String>();
            try {
                //file to save the sku details required for xml posting
                File file = new File(strTextFilePath);
                fstream = new FileWriter(file,true);
                BufferedWriter out = new BufferedWriter(fstream);
                String[] getArrQL = INT2Queries.getQuery(strTestCaseID);
                String strQuery1 = getArrQL[0];
                String strQuery2 = getArrQL[1];
                connection = DBConnect.getDatabaseConnection(strEnv);
                statement = connection.prepareStatement(strQuery1);
                statement1 = connection.prepareStatement(strQuery2);
                //statement.setFetchSize(recordsLimit);
                ResultSet result = statement.executeQuery();
                ResultSet result2 = statement1.executeQuery();
                //iterate the first result set data for second sql
                if (result.next()  && result2.next() ) {
                    while (result.next() && result2.next()) {
                        int allocatableQty =Integer.parseInt(result.getString("ALLOCATABLE_QTY"));
                        //write to system variable to read it easily
                        System.setProperty("ALLOCATABLE_QTY", Integer.toString(allocatableQty));
                        String itemName = result.getString("ITEM_NAME");
                        //write to system variable to read it easily
                        System.setProperty("ITEM_NAME", itemName);
                        String itemAttr1 = result.getString("ITEM_ATTR_1");
                        //write to system variable to read it easily
                        System.setProperty("ITEM_ATTR_1", itemAttr1);
                        String coo = result.getString("CNTRY_OF_ORGN");
                        //write to system variable to read it easily
                        System.setProperty("CNTRY_OF_ORGN", coo);
                        String customerName = result2.getString("CUSTOMER");
                        //write to system variable to read it easily
                        System.setProperty("CUSTOMER_NAME", customerName);
                        try {
                            int orderQty=allocatableQty-1;
                            itemNames.add(itemName);
                            //checking for same item name
                            if (itemName.length() > 1) {
                                blnFound = true;
                            } else {
                                break;
                            }
                            itemAttr.add(itemAttr1);
                            //checking for same Attribute name
                            if (itemAttr1.length() > 1) {
                                blnFound = true;
                            } else {
                                break;
                            }
                            orderQuantity.add(orderQty);
                            //checking for items with Quantity more than 0
                            if (orderQty > 0) {
                                blnFound = true;
                            } else {
                                break;
                            }
                            countryOforigin.add(coo);
                            if (coo.length() > 1) {
                                blnFound = true;
                            } else {
                                break;
                            }
                            custName.add(customerName);
                            if (customerName.length() > 1) {
                                blnFound = true;
                            } else {
                                break;
                            }
                            if (blnFound) {
                                index = index + 1;
                            }

                        } finally {
                            //the below try catch code will eliminate max cursors exceeded issue
                            try {
                                result.close();
                            } catch (SQLException ignore) {
                            }
                        }
                        //check condition to write into the text file
                        if (index >= 1) {
                            try {
                                out.append(strTestCaseID).append(",");
                                out.append(itemNames.get(0)).append(", ");
                                out.append(Integer.toString(orderQuantity.get(0))).append(", ");
                                out.append(itemAttr.get(0)).append(", ");
                                out.append(countryOforigin.get(0)).append(", ");
                                out.append(custName.get(0)).append(", ");
                                out.newLine();
                                out.flush();
                                out.close();
                                statement.close();
                                connection.close();
                                return;
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                } else {
                    System.out.println("No records found");
                    out.append(strTestCaseID).append(",");
                    out.append("No records found");
                    out.close();
                    result.close();
                }
                // } while ((endTime - startTime) / 1000 == 600);
            } catch (SQLException e) {
                try {
                    statement.close();
                    connection.close();
                } catch (SQLException e1) {
                    e1.printStackTrace();
                }
            } catch (IOException e) {
                try {
                    statement.close();
                    connection.close();
                } catch (SQLException e1) {
                    e1.printStackTrace();
                }
            }
        }
    }
}