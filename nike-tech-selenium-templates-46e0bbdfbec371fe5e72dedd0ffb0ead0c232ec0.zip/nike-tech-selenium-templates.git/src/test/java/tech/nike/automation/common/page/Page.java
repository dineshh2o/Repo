package tech.nike.automation.common.page;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import tech.nike.automation.common.framework.Selenium;

import java.util.List;
import java.util.Map;

public abstract class Page {

    public Selenium se;
    private WebDriver driver;
    private FluentWait<WebDriver> wait;

    public void init(Map<String, Object> params) {
        // Override if there is any initialization on subclass.
    }

    protected WebDriver getDriver() {
        return this.driver;
    }

    protected FluentWait<WebDriver> getWait() {
        return this.wait;
    }

    public void setWebDriver(Selenium se) {
        //this.se = new Selenium();
        this.driver = se.myDriver;
        //se.setWebDriver(driver);
        this.se = se;
        this.wait = new WebDriverWait(this.driver, 30).ignoring(StaleElementReferenceException.class).ignoring(NoSuchElementException.class);
    }

    /**Method to validate entered text correctly displayed
     *
     * @param txtLocator
     * @param strText
     * @return
     */
    public boolean verifyEnteredTextIsCorrectlyDisplayed(By txtLocator, String strText ){
        boolean enteredText = true;
        se.log.testStep("Enter search text on to locator "+txtLocator);
        //click on the locator
        se.element.clickElement(txtLocator);
        //enter the text into the text locator field
        se.element.enterText(txtLocator, strText);
        se.log.testStep("Entered search text on to locator "+txtLocator+ " as "+strText);
        //get the value displayed on the locator
        String strFieldTextValue = se.element.getAttribute(txtLocator, "value").trim();
        //verify if the entered code id was correctly displayed
        enteredText &= se.assertion.verifyEquals("verify if the user entered text was correctly displayed", strFieldTextValue, strText);
        return enteredText;
    }


    /**Method to validate entered text correctly displayed
     *
     * @param element
     * @param strText
     * @return
     */
    public boolean verifyEnteredTextIsCorrectlyDisplayed(WebElement element, String strText ){
        boolean enteredText = true;
        se.log.testStep("Enter search text on to locator "+element.toString());
        //click on the locator
        element.click();
        //enter the text into the text locator field
        element.sendKeys(strText);
        se.log.testStep("Entered search text on to locator "+element.toString()+ " as "+strText);
        //get the value displayed on the locator
        String strFieldTextValue = element.getAttribute("value").trim();
        //verify if the entered code id was correctly displayed
        enteredText &= se.assertion.verifyEquals("verify if the user entered text was correctly displayed", strFieldTextValue, strText);
        return enteredText;
    }

    /**Method to validate selected option was correctly displayed
     *
     * @param lstLocator
     * @param strText
     * @return
     */
    public boolean verifySelectedItemCorrectlyDisplayed(By lstLocator, String strText){
        boolean selectedText = true;
        //select the warehouse
        Select dropdown = new Select(se.myDriver.findElement(lstLocator));
        dropdown.selectByVisibleText(strText);
        WebElement strOption = dropdown.getFirstSelectedOption();
        //get the value of the warehouse selected
        String strSelText = strOption.getText().trim();
        //verify if the user specified value was selected correctly
        selectedText &= se.assertion.verifyEquals("user selection was as correctly selected", strSelText, strText);
        return selectedText;
    }

    /**Method to validate selected option was correctly displayed
     *
     * @param element
     * @param strText
     * @return
     */
    public boolean verifySelectedItemCorrectlyDisplayed(WebElement element, String strText){
        boolean selectedText = true;
        //select the warehouse
        try {
            Select dropdown = new Select(element);
            dropdown.selectByVisibleText(strText);
            WebElement strOption = dropdown.getFirstSelectedOption();
            //get the value of the warehouse selected
            String strSelText = strOption.getText().trim();
            //String strSelText = element.getText();
            //verify if the user specified value was selected correctly
            selectedText &= se.assertion.verifyEquals("user selection was as correctly selected", strSelText, strText);

        }catch(Exception e){
            //Select dropdown = new Select(element);
            //dropdown.selectByVisibleText(strText);
            //WebElement strOption = dropdown.getFirstSelectedOption();
            //get the value of the warehouse selected
            //String strSelText = strOption.getText().trim();
            String strSelText = element.getText();
            //verify if the user specified value was selected correctly
            selectedText &= se.assertion.verifyEquals("user selection was as correctly selected", strSelText, strText);
        }
        return selectedText;
    }


    /**Method to validate selected option was correctly displayed
     *
     * @param lstLocator
     * @param elementPostition
     * @param strText
     * @return
     */
    public boolean verifySelectedItemCorrectlyDisplayed(By lstLocator, int elementPostition,String strText){
        boolean selectedText = true;
        //select the warehouse
        List<WebElement> list=se.myDriver.findElements(lstLocator);
        Select dropdown = new Select(list.get(elementPostition));
        dropdown.selectByVisibleText(strText);
        WebElement strOption = dropdown.getFirstSelectedOption();
        //get the value of the warehouse selected
        String strSelText = strOption.getText().trim();
        //verify if the user specified value was selected correctly
        selectedText &= se.assertion.verifyEquals("user selection was as correctly selected", strSelText, strText);
        return selectedText;
    }

    /**Method to validate entered text correctly displayed
     *
     * @param txtLocator
     * @param txtLocator
     * @param strText
     * @return
     */
    public boolean verifyEnteredTextIsCorrectlyDisplayed(By txtLocator, int position,String strText ){
        boolean enteredText = true;
        se.log.testStep("Enter search text on to locator "+txtLocator);
        List<WebElement> list=se.myDriver.findElements(txtLocator);
        //click on the locator
        se.element.clickElement(txtLocator,position);
        //enter the text into the text locator field
        se.element.enterText(txtLocator,position, strText);
        se.log.testStep("Entered search text on to locator "+txtLocator+ " as "+strText);
        //get the value displayed on the locator
        String strFieldTextValue = se.element.getAttribute(txtLocator, "value",position).trim();
        //verify if the entered code id was correctly displayed
        enteredText &= se.assertion.verifyEquals("verify if the user entered text was correctly displayed", strFieldTextValue, strText);
        return enteredText;
    }

    /**Method to get the displayed text from the disabled dropdown
     *
     * @param Locator
     * @return
     */
    public String getSelectedValue(By Locator){
        Select dropdown = new Select(se.myDriver.findElement(Locator));
        WebElement option = dropdown.getFirstSelectedOption();
        String content = option.getText();
        return content;
    }

    /**Method to get the displayed text from the disabled dropdown
     *
     * @param element
     * @return
     */
    public String getSelectedValue(WebElement element){
        Select dropdown = new Select(element);
        WebElement option = dropdown.getFirstSelectedOption();
        String content = option.getText();
        return content;
    }
}