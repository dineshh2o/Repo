package tech.nike.automation.wms.feature.test.standalone.herentals;

import tech.nike.automation.common.framework.sql.DBConnect;
import tech.nike.automation.common.framework.sql.INT9Queries;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 * Not Implemented refer notes for logic
 * Notes:
 * a) Select item with Alloc_qty > 0 from above query, and has only one size of LPNs.
 * b) Select Item that has multiple LPNs in case reserve.
 * c) Create DO with qty matching the sum of multiple LPNs, but less than the pallet size.
 *d) Make sure multiple number is 5 at least. (Ex: 5 * LPN size)
 */

public class HTLS_INT9_Carton_Equip_P40_dynamicLocn_MultiLine_NEW {
    //global variables instantiation
    public static String strTextFilePath = "c:\\records.txt";

    public static void main(String[] argv) {
        //local variables instantiation
        PreparedStatement statement = null;
        PreparedStatement statement2 = null;
        Connection connection = null;
        String strEnv = "HTLS-ER";
        String strTestCaseID = "OB_1064_PW03AT_HP_10_INT9_Carton_Equip_P40_dynamicLocn_MultiLine_NEW";
        //int recordsLimit = 5000;
        long startTime = System.currentTimeMillis(); // Get the start Time
        long endTime = 0;
        String[] arrItem = new String[1];
        int x1 = 0;
        int index = 0;
        int counter = 0;
        boolean blnFound = false;
        FileWriter fstream = null;
        List<String> criteria= new ArrayList<String>();
        List<Integer> quantity= new ArrayList<Integer>();
        List<Integer> resultQuantity= new ArrayList<Integer>();
        try {
            //file to save the sku details required for xml posting
            File file = new File(strTextFilePath);
            fstream = new FileWriter(file, true);
            BufferedWriter out = new BufferedWriter(fstream);
            String[] getArrQL = INT9Queries.getQuery(strTestCaseID);
            String strQuery1 = getArrQL[0];
            String strQuery2 = getArrQL[1];
            connection = DBConnect.getDatabaseConnection(strEnv);
            statement = connection.prepareStatement(strQuery1);
            statement2 = connection.prepareStatement(strQuery2);
            ResultSet result = statement.executeQuery();

            //iterate the first result set data for second sql
            boolean flag=false;
            if (result.next()) {
                while (result.next()) {
                    String strItemName = result.getString("ITEM_NAME");
                    System.setProperty("ITEM_NAME", strItemName);

                    String strCountryOfOrigin = result.getString("CNTRY_OF_ORGN");
                    System.setProperty("CNTRY_OF_ORGN", strCountryOfOrigin);

                    String strItemAttribute = result.getString("ITEM_ATTR_1");
                    System.setProperty("ITEM_ATTR_1", strItemAttribute);

                    int intQty = Integer.parseInt(result.getString("QTY"));
                    System.setProperty("QTY", Integer.toString(intQty));

                    String temp=strItemName+","+strItemAttribute+","+strCountryOfOrigin;
                    criteria.add(temp);
                    quantity.add(intQty);


                    if(count(criteria,temp,quantity,resultQuantity)==4) {
                        statement2.setString(1, strItemName);
                        statement2.setString(2, strCountryOfOrigin);
                        statement2.setString(3, strItemAttribute);
                        ResultSet result2 = statement.executeQuery();
                        int x2=0;
                        int x3=0;
                        int x4=0;
                        if (result2.next()) {
                            while (result2.next()) {
                                try {
                                    int intAllocQty = Integer.parseInt(result.getString("allocatable_qty"));
                                    System.setProperty("ALLOCATABLE_QTY", Integer.toString(intAllocQty));

                                    x1 = resultQuantity.get(0) - 1;
                                    x2 = resultQuantity.get(1) - 1;
                                    x3 = resultQuantity.get(2) - 1;
                                    x4 = resultQuantity.get(3) - 1;

                                    int sum = x1 + x2 + x3 + x4;
                                    if (sum > intAllocQty && ((sum > resultQuantity.get(0)) || (sum > resultQuantity.get(1)) || (sum > resultQuantity.get(2)) || (sum > resultQuantity.get(3))) && (sum == resultQuantity.get(0) + resultQuantity.get(1))){
                                           x1 = 1;
                                        out.append(strTestCaseID).append(",");
                                        out.append(strItemName);
                                        out.append(", ");
                                        out.append(Integer.toString(x1)).append(", ");
                                        out.append(strCountryOfOrigin);
                                        out.append(", ");
                                        out.append(strItemAttribute);
                                        out.newLine();
                                        out.append(strTestCaseID).append(",");
                                        out.append(strItemName);
                                        out.append(", ");
                                        out.append(Integer.toString(x2)).append(", ");
                                        out.append(strCountryOfOrigin);
                                        out.append(", ");
                                        out.append(strItemAttribute);
                                        out.newLine();
                                        out.append(strTestCaseID).append(",");
                                        out.append(strItemName);
                                        out.append(", ");
                                        out.append(Integer.toString(x3)).append(", ");
                                        out.append(strCountryOfOrigin);
                                        out.append(", ");
                                        out.append(strItemAttribute);
                                        out.newLine();
                                        out.append(strTestCaseID).append(",");
                                        out.append(strItemName);
                                        out.append(", ");
                                        out.append(Integer.toString(x4)).append(", ");
                                        out.append(strCountryOfOrigin);
                                        out.append(", ");
                                        out.append(strItemAttribute);
                                        out.newLine();
                                }
                                    out.close();
                                    statement.close();
                                    connection.close();
                                    return;

                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    }
                }
            } else {
                System.out.println("No records found");
                out.append("No records found");
                out.close();
                result.close();
            }
            // } while ((endTime - startTime) / 1000 == 600);
        } catch (SQLException e) {
            try {
                statement.close();
                connection.close();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        } catch (IOException e) {
            try {
                statement.close();
                connection.close();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        }
    }
    public static int count(List<String> list,String string,List<Integer> integer,List<Integer> result){
        int i=0;
        List<Integer> index=new ArrayList<>();
        for(String s:list){
            if(s.equalsIgnoreCase(string)) {
                index.add(i);
                i++;
            }
            if(i==4)
                break;
        }
        if(i>=4) {
            Set<Integer> set= new TreeSet<>();
            set.add(integer.get(index.get(0)));
            set.add(integer.get(index.get(1)));
            set.add(integer.get(index.get(2)));
            set.add(integer.get(index.get(3)));
            if(set.size()==4) {
                result.clear();
                result.add(integer.get(index.get(0)));
                result.add(integer.get(index.get(1)));
                result.add(integer.get(index.get(2)));
                result.add(integer.get(index.get(3)));
                return 4;
            }
        }
        return 1;
    }

}
