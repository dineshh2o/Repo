/*
package tech.nike.automation.common.framework;

import org.testng.TestListenerAdapter;
import org.testng.TestNG;

public class Main {
	
	public static void main(String[] args) {
		 	*/
/*CommandLineOptions options = new CommandLineOptions();
		    JCommander jCommander = new JCommander(options, args);

		    XmlSuite suite = new XmlSuite();
		    suite.setName("MyTestSuite");
		    suite.setParameters(options.convertToMap());

		    List<XmlClass> classes = new ArrayList<XmlClass>();
		    classes.add(new XmlClass("tech.nike.automation.wms.feature.test.template.WMSWavingTemplateTest"));

		    XmlTest test = new XmlTest(suite);
		    test.setName("WMSWavingTemplateTest");
		    test.setXmlClasses(classes);

		    List<XmlSuite> suites = new ArrayList<XmlSuite>();
		    suites.add(suite);

		    TestNG testNG = new TestNG();
		    testNG.setXmlSuites(suites);
		    testNG.run();*//*


			//TestNG.main(args);
			// Create object of TestNG Class
			*/
/*TestNG runner=new TestNG();

			// Create a list of String
			List<String> suitefiles=new ArrayList<String>();

			// Add xml file which you have to execute
			suitefiles.add(args[0]);

			// now set xml file for execution
			runner.setTestSuites(suitefiles);

			// finally execute the runner using run method
			runner.run();*//*

		    TestListenerAdapter tla = new TestListenerAdapter();
			TestNG testng = new TestNG();
			testng.setTestClasses(new Class[] { tech.nike.automation.wms.feature.test.template.WMSWavingTemplateTest.class });
			testng.addListener(tla);
			testng.run();
		}

}
*/
