package tech.nike.automation.wms.feature.page.template;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import tech.nike.automation.common.page.Page;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Created by PSibb1 on 6/24/2016.
 */
public class WMSTemplateRulePage_OLD extends Page {
    //$= is a tail-string match, that's all. Similarly *= is a partial-substring match, and ^= is a head-string match.
    //locators
    public By btnAddRule = By.cssSelector("[id$='lview:ruleHdrAddButton']");
    public By btnDeleteRule = By.cssSelector("[id$='lview:ruleHdrDeleteButton']");
    public By lstRuleType = By.id("dataForm:rlType");
    public By btnSaveConfiguration = By.cssSelector("[id*='SaveConfiguration'][type='button']");
    public By btnSubmit = By.cssSelector("[id*='SubmitWave'][type='button']");

    //capacities
    public By lnkCapacities = By.xpath("//a[contains(text(),'Capacities')]");
    public By chkDiscretePicking = By.cssSelector("[id$='discretePickingValue'][type='checkbox']");
    public By lstFootwearSorters = By.cssSelector("[id$='FootwearSortersList']");
    public By lstApparelSorters = By.cssSelector("[id$='ApparelSortersList']");
    public By lstMixedSkuSorters = By.cssSelector("[id$='MixedSkuSortersList']");
    public By txtMaxPickZones = By.cssSelector("[id$='custId']");
    public By tblCapacities = By.cssSelector("[id='dataForm:listViewb:dataTableCaps_body']>tbody>tr");
    public By tblNoDataFoundCapacities = By.id("dataForm:listViewb:dataTableCaps:nodataRow");
    public By chkCapacities = By.cssSelector("[id$='dataTableCaps'][type='checkbox'][style^='visibility']");
    public By lstCapacityType = By.cssSelector("[id$='cap_type'][style^='visibility']");
    public By txtVasHrs = By.cssSelector("[style*='visibility: visible'] [id$='sams_custom']");
    public By txtRPUnits = By.cssSelector("[style*='visibility: visible'] [id$='units_custom']");
    public By txtSUnitDO = By.cssSelector("[style*='visibility: visible'] [id$='picks_custom']");
    public By txtRPoLPN = By.cssSelector("[style*='visibility: visible'] [id$='lines_custom']");
    public By txtFCoLPN = By.cssSelector("[style*='visibility: visible'] [id$='dollars_custom']");
    public By txtTotaloLPN = By.cssSelector("[style*='visibility: visible'] [id$='cartons_custom']");
    public By btnAddCapacities = By.id("dataForm:listViewb:capsAddButton");
    public By btnDeleteCapacities = By.id("dataForm:listViewb:ruleHdrDeleteButton");

    //task criteria
    public By lnkTaskCriteria = By.cssSelector("[class='tab'][title='Task Criteria'] a");
    public By btnAddTaskCriteria = By.id("dataForm:listViewbc:capsAddButton");
    public By lstTaskCritDesc = By.cssSelector("[style^='visibility'][id$='crit_nbr']");
    public By chkTask = By.cssSelector("[id$='dataTableCrit'][type='checkbox'][style^='visibility']");
    public By btnDeleteTask = By.id("dataForm:listViewbc:capsDeleteButton");

    // parameters
    public By lnkRuleParameters = By.name("parameterTab");
    public By txtRuleName = By.id("dataForm:ruleNameInputBox");
    public By txtRulePriority = By.id("dataForm:rlPriorty");

    // definition
    public By lnkRuleDefinition = By.name("definitionTab");
    public By btnAddRuleDefinition = By.id("dataForm:ruleSelAddButton");
    public By tblRuleDefinitionRow = By.xpath("//table[@id='dataForm:ruleSelDtlDataTable_body']/tbody/tr[3]");
    public By tblRuleDefinitionColumn = By.xpath("//table[@id='dataForm:ruleSelDtlDataTable_body']/tbody/tr[3]/td");
    public By rdoDefinition = By.cssSelector("[style^='visibility'] [id$='undefined']");
    public By txtOpenParanthesis = By.cssSelector("[id*='newRow'][type='text'][name$='ruleSelDtlOpenParan']");
    public By lstColumn = By.cssSelector("[id$='ruleSelDtlColumnList'][style^='visibility']");
    public By lstOperator = By.cssSelector("[id$='ruleSelDtlOperatorList'][style^='visibility']");
    public By txtComparisonValue = By.cssSelector("[id$='edit'][style^='visibility'] [id$='ruleSelDtlRuleCmparValue']");
    public By txtCloseParenthesis = By.cssSelector("[id*='newRow'][type='text'][name$='ruleSelDtlCloseParan']");
    public By lstBoolean = By.cssSelector("[id$='edit'][style^='visibility'] [id$='ruleSelDtlAndOrOrList']");
    public By btnDeleteDefinition = By.id("dataForm:ruleSelDeleteButton");

    //rule
    public By rdoRule = By.id("[id^='checkAll_c_dataForm:lview:dataTable']");
    public By lblRuleNameFromRuleTbl = By.cssSelector("[id$=':ruleNameText']");


    /**
     * method to add a task criteria and save configuration
     * @param testdata
     * @return
     */
    public boolean addTaskCriteria(Map<String, Object> testdata) {
        String strTaskCriteria = (String)testdata.get("taskcriteria");
        boolean result = true;
        //wait for the page load
        //navigate to task criteria
        se.element.requireIsDisplayed("task criteria button", lnkTaskCriteria);
        //verify if the task criteria button was clickable
        result &= se.element.waitForElementToBeClickable(lnkTaskCriteria);
        //click on the task criteria button
        se.element.clickElement(lnkTaskCriteria);
        //click on the add task criteria
        se.element.requireIsDisplayed("add task criteria button", btnAddTaskCriteria);
        //verify if the aa task criteria button was clickable
        result &= se.element.waitForElementToBeClickable(btnAddTaskCriteria);
        //click on the add task criteria button
        se.element.clickElement(btnAddTaskCriteria);
        //wait for the page load to complete
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        se.myDriver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        //verify if the task criteria drop down was visible
        se.element.requireIsDisplayed("task criteria dropdown", lstTaskCritDesc);
        //verify if the task criteria dropdown was clickable
        result &= se.element.waitForElementToBeClickable(lstTaskCritDesc);
        //verify if the user entered value was correctly selected
        result &= verifySelectedItemCorrectlyDisplayed(lstTaskCritDesc, strTaskCriteria);
        //verify if the save the task criteria button was visible
        se.element.requireIsDisplayed("save configuration button", btnSaveConfiguration);
        //verify if the task criteria button was clickable
        result &= se.element.waitForElementToBeClickable(btnSaveConfiguration);
        //click on the save configuration button
        se.element.clickElement(btnSaveConfiguration);
        //wait for the page load to complete
        se.myDriver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        return result;
    }

    /**
     * method to delete an existing task criteria by criteria description
     *
     * @param strTaskCriteria
     * @return
     */
    public boolean deleteTaskCriteria(String strTaskCriteria) {
        boolean result = true;
        List<WebElement> weAllTasks = se.element.getElements(lstTaskCritDesc);
        List<WebElement> weAllTaskChks = se.element.getElements(chkTask);
        for (int i = 0; i <= weAllTasks.size(); i++) {
            String strDispTask = weAllTaskChks.get(i).getAttribute("value").trim();
            if (strDispTask == strTaskCriteria) {
                weAllTaskChks.get(i).click();
                //verify if the delete button was clickable
                result &= se.element.waitForElementToBeClickable(btnDeleteTask);
                //click on the delete task button
                se.element.clickElement(btnDeleteTask);
                //wait for the page load to complete
                se.myDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
                //confirm the delete
                se.myDriver.switchTo().alert().accept();
                //return to default content
                se.element.returnToDefaultContent();
                //wait for the page to load
                se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
                break;
            }
        }
        return result;
    }


    /**
     * method to select the rule type
     *
     * @param testdata
     * @return
     */
    public boolean selectRuleType(Map<String, Object> testdata) {
        String strRuleType = (String) testdata.get("ruletype");
        //verify if the required Rule type field was displayed
        se.element.requireIsDisplayed("Rule Type Drop Down box", lstRuleType);
        //verify if rule type drop down is clickable
        boolean result = se.element.waitForElementToBeClickable(lstRuleType);
        //verify if user specified rule type was correctly selected
        result &= verifySelectedItemCorrectlyDisplayed(lstRuleType, strRuleType);
        return result;
    }

    /**
     * method to add the parameters to rule
     *
     * @param testdata
     * @return
     */
    public boolean addRuleParameters(Map<String, Object> testdata) {
        String strRuleName = (String) testdata.get("");
        String strRulePriority = (String) testdata.get("");
        //verify if required field was displayed
        se.element.requireIsDisplayed("Rule Name field under Parameters tab", txtRuleName);
        //verify if rule name is clickable
        boolean result = se.element.waitForElementToBeClickable(txtRuleName);
        //verify the rule name entered was correctly displayed
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtRuleName, strRuleName);
        //verify if the required rule priority field was displayed
        se.element.requireIsDisplayed("Rule Priority field under the Parameters tab", txtRulePriority);
        //verify if the rule priority filed was clickable
        result &= se.element.waitForElementToBeClickable(txtRulePriority);
        //verify if the rule priority entered was correctly displayed
        result &= verifyEnteredTextIsCorrectlyDisplayed(txtRulePriority, strRulePriority);
        return result;
    }

    /**
     * method to add a rule definition based on user inputs
     *
     * @param testdata
     * @return
     */
    public boolean addRuleDefinition(Map<String, Object> testdata) {
        int intNumOfRows = Integer.parseInt((String) testdata.get(""));
        String strOpenParenthesis = (String) testdata.get("");
        String strColumn = (String) testdata.get("");
        String strOperator = (String) testdata.get("");
        String strCompValue = (String) testdata.get("");
        String strCloseParenthesis = (String) testdata.get("");
        String strBoolean = (String) testdata.get("");
        //verify if required field was displayed
        se.element.requireIsDisplayed("Add definition button", btnAddRuleDefinition);
        //verify if the add definition button was displayed
        boolean result = se.element.waitForElementToBeClickable(btnAddRuleDefinition);
        //click on the add definition button
        se.element.clickElement(btnAddRuleDefinition);
        //wait for the page load to complete
        se.myDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        //verify if rule definition table was added successfully
        se.element.requireIsDisplayed("Rule Definition table", tblRuleDefinitionRow);
        //get the rows count
        int intRuleDifRowCnt = se.element.getNumberOfElements(tblRuleDefinitionRow);
        //get the columns count
        int intRuleDifColumnCnt = se.element.getNumberOfElements(tblRuleDefinitionColumn);
        List<WebElement> weAllOpenParans = se.element.getElements(txtOpenParanthesis);
        List<WebElement> weAllColumns = se.element.getElements(lstColumn);
        List<WebElement> weAllCompValues = se.element.getElements(txtComparisonValue);
        List<WebElement> weAllCloseParans = se.element.getElements(txtCloseParenthesis);
        List<WebElement> weAllBooleans = se.element.getElements(lstBoolean);
        //add number of definitions based on user inputs and configure the same
        for (int i = 0; i <= intNumOfRows; i++) {
            //add the rows
            se.element.clickElement(btnAddRuleDefinition);
            //configure the row
            result &= intRuleDifRowCnt > 0;
            result &= intRuleDifColumnCnt > 0;
            //add parenthesis
            if (strOpenParenthesis != "") {
                result &= verifyEnteredTextIsCorrectlyDisplayed(weAllOpenParans.get(i), strOpenParenthesis);
                //add column
            }
            if (strColumn != "") {
                result &= verifySelectedItemCorrectlyDisplayed(weAllColumns.get(i), strColumn);
                //add operator
            }
            if (strOperator != "") {
                result &= verifySelectedItemCorrectlyDisplayed(weAllColumns.get(i), strOperator);
            }
            if (strCompValue != "") {
                result &= verifyEnteredTextIsCorrectlyDisplayed(weAllCompValues.get(i), strCompValue);
            }
            if (strCloseParenthesis != "") {
                result &= verifyEnteredTextIsCorrectlyDisplayed(weAllCloseParans.get(i), strCloseParenthesis);
            }
            if (strBoolean != "") {
                result &= verifySelectedItemCorrectlyDisplayed(weAllBooleans.get(i), strBoolean);
            }
        }
        return result;
    }

    /**
     * method to delete a rule form the rule definition table
     *
     * @param strRuleName
     * @return
     */
    public boolean deleteARule(String strRuleName) {
        //verify if the table exists and contains rows
        se.element.requireIsDisplayed("Definition table", tblRuleDefinitionRow);
        List<WebElement> weRules = se.element.getElements(lblRuleNameFromRuleTbl);
        //get the row count
        int intRowCnt = se.element.getNumberOfElements(tblRuleDefinitionRow);
        //verify if the table contains any data
        boolean result = se.element.getNumberOfElements(tblRuleDefinitionRow) > 0;
        List<WebElement> weAllRuleRadios = se.element.getElements(rdoRule);
        for (int i = 0; i <= intRowCnt; i++) {
            se.element.requireIsDisplayed("radio button at row index " + i, weAllRuleRadios.get(i));
            String strDispRuleName = weRules.get(i).getText().trim();
            if (strDispRuleName.equalsIgnoreCase(strRuleName)) {
                weAllRuleRadios.get(i).click();
                break;
            }
        }
        //verify if delete rule button was displayed
        se.element.requireIsDisplayed("Delete Rule button", btnDeleteRule);
        //verify if the delete rule button was clickable
        result &= se.element.waitForElementToBeClickable(btnDeleteRule);
        //click on the delete rule button
        se.element.clickElement(btnDeleteRule);
        //wait for the page load to complete
        se.myDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        //confirm the delete
        se.myDriver.switchTo().alert().accept();
        //return to default content
        se.element.returnToDefaultContent();
        //wait for the page to load
        se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        boolean blnFound = false;
        //verify if delete was successful
        if (se.element.getNumberOfElements(tblRuleDefinitionRow) > 0) {
            for (int i = 0; i <= intRowCnt; i++) {
                se.element.requireIsDisplayed("radio button at row index " + i, weRules.get(i));
                String strDispRuleName = weRules.get(i).getText().trim();
                if (strDispRuleName.equalsIgnoreCase(strRuleName)) {
                    blnFound = true;
                    break;
                }
            }
        } else {
            blnFound = true;
        }
        if (blnFound != true) {
            result &= false;
        }
        return result;
    }

    /**
     * method to delete a user specified definition from the definition table
     *
     * @param testdata
     * @return
     */
    public boolean deleteADefinition(Map<String, Object> testdata) {
        String strColumn = (String) testdata.get("");
        //verify row count of the definition table is not zero
        boolean result = se.element.getNumberOfElements(rdoDefinition) > 0;
        List<WebElement> weAllDefRadios = se.element.getElements(rdoDefinition);
        List<WebElement> weAllColumns = se.element.getElements(lstColumn);
        //delete the definition by row value
        for (int j = 0; j <= weAllDefRadios.size(); j++) {
            String strDispColumn = weAllColumns.get(j).getAttribute("value").trim();
            if (strDispColumn.equalsIgnoreCase(strColumn)) {
                weAllDefRadios.get(j).click();
                //verify if the delete button was displayed
                se.element.requireIsDisplayed("Delete Definition button", btnDeleteDefinition);
                //verify if the delete button was clickable
                result &= se.element.waitForElementToBeClickable(btnDeleteDefinition);
                se.element.clickElement(btnDeleteDefinition);
                //wait for the page load to complete
                se.myDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
                //confirm the delete
                se.myDriver.switchTo().alert().accept();
                //return to default content
                se.element.returnToDefaultContent();
                //wait for the page to load
                se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
                break;
            }
        }
        return result;
    }


    /**
     * method to add a new rule with definitions and parameters
     *
     * @param testdata
     * @return
     */
    public boolean addNewRule(Map<String, Object> testdata) {
        String strRuleType = (String) testdata.get("");
        String strRuleName = (String) testdata.get("");
        String strRulePriority = (String) testdata.get("");
        int rowNum = Integer.parseInt((String) testdata.get(""));
        String strOpenParenthesis = (String) testdata.get("");
        String strColumn = (String) testdata.get("");
        String strOperator = (String) testdata.get("");
        String strCompValue = (String) testdata.get("");
        String strCloseParenthesis = (String) testdata.get("");
        String strBoolean = (String) testdata.get("");
        //verify if rule type drop down was selected
        boolean result = selectRuleType(testdata);
        //verify if the add button was displayed
        se.element.requireIsDisplayed("Add rule button", btnAddRule);
        //verify if the add rule button was clickable
        result &= se.element.waitForElementToBeClickable(btnAddRule);
        //click on the add rule button
        se.element.clickElement(btnAddRule);
        //wait for page load to complete
        se.myDriver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        //verify if the rule parameters were added successfully
        result &= addRuleParameters(testdata);
        //verify if the rule definition were added successfully
        result &= addRuleDefinition(testdata);
        //verify if the save configuration button was displayed
        se.element.requireIsDisplayed("Save Configuration button", btnSaveConfiguration);
        //verify if save configuration button was clickable
        result &= se.element.waitForElementToBeClickable(btnSaveConfiguration);
        //click save configuration button
        se.element.clickElement(btnSaveConfiguration);
        //wait for the page load to complete
        se.myDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        //verify if the rule was displayed under rules table
        List<WebElement> weRules = se.element.getElements(lblRuleNameFromRuleTbl);
        //get the row count
        int intRowCnt = se.element.getNumberOfElements(tblRuleDefinitionRow);
        //verify if the table contains any data
        result &= se.element.getNumberOfElements(tblRuleDefinitionRow) > 0;
        if (se.element.getNumberOfElements(tblRuleDefinitionRow) > 0) {
            for (int i = 0; i <= intRowCnt; i++) {
                String strDispRuleName = weRules.get(i).getText().trim();
                if (strDispRuleName.equalsIgnoreCase(strRuleName)) {
                    result &= true;
                    break;
                }
            }
        } else {
            result &= true;
        }
        return result;
    }

    /**
     * Method to navigate to capacities tab
     *
     * @return
     */
    public boolean navigateToCapacities() {
        //verify if the capacities tab was displayed
        se.element.requireIsDisplayed("Capacities tab", lnkCapacities);
        //verify if the tab was clickable
        boolean result = se.element.waitForElementToBeClickable(lnkCapacities);
        //click on the capacities tab
        se.element.clickElement(lnkCapacities);
        //wait for navigation to complete
        se.myDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        return result;
    }

    /**
     * method to configure capacities with and without default wave header capacity
     *
     * @param testdata
     * @return
     */
    public boolean configureCapacities (Map<String, Object> testdata) {
        String strSiteType = (String) testdata.get("");
        int loopCount = Integer.parseInt((String) testdata.get(""));
        String strCapacityType = (String) testdata.get("capacity1");
        String strVASHrs = (String) testdata.get("");
        String strRPUnits = (String) testdata.get("");
        String strSUnitDO = (String) testdata.get("");
        String strRPoLPN = (String) testdata.get("");
        String strFCoLPN = (String) testdata.get("");
        String strTotaloLPN = (String) testdata.get("");
        String strDiscretePicking = (String) testdata.get("discretepicking");
        String strFWSorters = (String) testdata.get("fwsorters");
        String strAppSorters = (String) testdata.get("appsorters");
        String strMixedSorters = (String) testdata.get("mixedsorters");
        String strMaxPickZone = (String) testdata.get("maxpickzone");
        //verify if the add button was displayed
        se.element.requireIsDisplayed("Add capacities button", btnAddCapacities);
        //verify if the add capacities button was clickable
        boolean result = se.element.waitForElementToBeClickable(btnAddCapacities);
        if (se.assertion.verifyFalse("No data found table exists", se.element.exists(tblNoDataFoundCapacities))) {
            for (int i = 0; i <= loopCount; i++) {
                //click on the add capacities button
                se.element.clickElement(btnAddCapacities);
                //wait for row to get visible
                se.myDriver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
                List<WebElement> weCapTypes = se.element.getElements(lstCapacityType);
                List<WebElement> weVASHrs = se.element.getElements(txtVasHrs);
                List<WebElement> weRPUnits = se.element.getElements(txtRPUnits);
                List<WebElement> weSDOUnits = se.element.getElements(txtSUnitDO);
                List<WebElement> weRPoLPNs = se.element.getElements(txtRPoLPN);
                List<WebElement> weFCoLPNs = se.element.getElements(txtFCoLPN);
                List<WebElement> weTotaloLPNs = se.element.getElements(txtTotaloLPN);
                //add capacity
                if (strCapacityType != "" || strCapacityType != "(none)") {
                    result &= verifySelectedItemCorrectlyDisplayed(weCapTypes.get(i), strCapacityType);
                    //add column
                }
                if (strVASHrs != "") {
                    result &= verifyEnteredTextIsCorrectlyDisplayed(weVASHrs.get(i), strVASHrs);
                    //add operator
                }
                if (strRPUnits != "") {
                    result &= verifyEnteredTextIsCorrectlyDisplayed(weRPUnits.get(i), strRPUnits);
                }
                if (strSUnitDO != "") {
                    result &= verifyEnteredTextIsCorrectlyDisplayed(weSDOUnits.get(i), strSUnitDO);
                }
                if (strRPoLPN != "") {
                    result &= verifyEnteredTextIsCorrectlyDisplayed(weRPoLPNs.get(i), strRPoLPN);
                }
                if (strFCoLPN != "") {
                    result &= verifyEnteredTextIsCorrectlyDisplayed(weFCoLPNs.get(i), strFCoLPN);
                }
                if (strTotaloLPN != "") {
                    result &= verifyEnteredTextIsCorrectlyDisplayed(weTotaloLPNs.get(i), strTotaloLPN);
                }
            }
        } else {
            for (int i = 0; i <= loopCount; i++) {
                //click on the add capacities button
                se.element.clickElement(btnAddCapacities);
                //wait for row to get visible
                se.myDriver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
                List<WebElement> weVASHrs = se.element.getElements(txtVasHrs);
                List<WebElement> weRPUnits = se.element.getElements(txtRPUnits);
                List<WebElement> weSDOUnits = se.element.getElements(txtSUnitDO);
                List<WebElement> weRPoLPNs = se.element.getElements(txtRPoLPN);
                List<WebElement> weFCoLPNs = se.element.getElements(txtFCoLPN);
                List<WebElement> weTotaloLPNs = se.element.getElements(txtTotaloLPN);
                if (strVASHrs != "") {
                    result &= verifyEnteredTextIsCorrectlyDisplayed(weVASHrs.get(i), strVASHrs);
                    //add operator
                }
                if (strRPUnits != "") {
                    result &= verifyEnteredTextIsCorrectlyDisplayed(weRPUnits.get(i), strRPUnits);
                }
                if (strSUnitDO != "") {
                    result &= verifyEnteredTextIsCorrectlyDisplayed(weSDOUnits.get(i), strSUnitDO);
                }
                if (strRPoLPN != "") {
                    result &= verifyEnteredTextIsCorrectlyDisplayed(weRPoLPNs.get(i), strRPoLPN);
                }
                if (strFCoLPN != "") {
                    result &= verifyEnteredTextIsCorrectlyDisplayed(weFCoLPNs.get(i), strFCoLPN);
                }
                if (strTotaloLPN != "") {
                    result &= verifyEnteredTextIsCorrectlyDisplayed(weTotaloLPNs.get(i), strTotaloLPN);
                }
            }
        }
        if (strDiscretePicking.equalsIgnoreCase("yes")) {
            //verify if required discrete picking field was displayed
            se.element.requireIsDisplayed("Discrete Picking checkbox", chkDiscretePicking);
            //click discrete picking checkbox
            se.element.clickElement(chkDiscretePicking);
        }
        if (strAppSorters != "none") {
            //verify if the required Apparel sorters field was displayed
            se.element.requireIsDisplayed("ApparelSorters drop down", lstApparelSorters);
            //verify if the user defined value was selected for the Apparel Sorters
            result &= verifySelectedItemCorrectlyDisplayed(lstApparelSorters, strAppSorters);
        }
        if (strFWSorters != "none") {
            //verify if the required Footwear sorters field was displayed
            se.element.requireIsDisplayed("FootwearSorters drop down", lstFootwearSorters);
            //verify if the user defined value was selected for the FW Sorters
            result &= verifySelectedItemCorrectlyDisplayed(lstFootwearSorters, strFWSorters);
        }
        if (strMixedSorters != "none") {
            //verify if the required Mixed sorters field was displayed
            se.element.requireIsDisplayed("MixedSorters drop down", lstMixedSkuSorters);
            //verify if the user defined value was selected for the Mixed Sorters
            result &= verifySelectedItemCorrectlyDisplayed(lstMixedSkuSorters, strMixedSorters);
        }
        if (strMaxPickZone != "none") {
            //verify if the required FW sorters field was displayed
            se.element.requireIsDisplayed("Max Pick Zone text box", txtMaxPickZones);
            //verify if the user defined value was selected for the Max pick zone
            result &= verifyEnteredTextIsCorrectlyDisplayed(txtMaxPickZones, strMaxPickZone);
        }
        return result;
    }

    /**
     * method to delete a user specified capacity for the capacity table
     *
     * @param testdata
     * @return
     */
    public boolean deleteACapacity(Map<String, Object> testdata) {
        String strCapacityType = (String) testdata.get("");
        //verify row count of the definition table is not zero
        boolean result = se.element.getNumberOfElements(tblCapacities) > 0;
        int rowCount = se.element.getNumberOfElements(tblCapacities);
        List<WebElement> weCapTypes = se.element.getElements(lstCapacityType);
        List<WebElement> weAllCheckboxes = se.element.getElements(chkCapacities);
        //delete the definition by row value
        for (int j = 0; j <= rowCount; j++) {
            String strDispCapacity = weCapTypes.get(j).getAttribute("value").trim();
            if (strDispCapacity.equalsIgnoreCase(strCapacityType)) {
                weAllCheckboxes.get(j).click();
                //verify if the delete button was displayed
                se.element.requireIsDisplayed("Delete Definition button", btnDeleteCapacities);
                //verify if the delete button was clickable
                result &= se.element.waitForElementToBeClickable(btnDeleteCapacities);
                se.element.clickElement(btnDeleteCapacities);
                //wait for the page load to complete
                se.myDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
                //confirm the delete
                se.myDriver.switchTo().alert().accept();
                //return to default content
                se.element.returnToDefaultContent();
                //wait for the page to load
                se.myDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
                break;
            }
        }
        return result;
    }

    /**
     * method to add capacities as per user definition
     * @param testdata
     * @return
     */
    public boolean addCapacities(Map<String, Object>testdata){
        boolean result = true;
        return result;

    }
}